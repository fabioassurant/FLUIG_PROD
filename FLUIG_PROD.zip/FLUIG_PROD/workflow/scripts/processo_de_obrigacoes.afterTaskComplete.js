function afterTaskComplete(colleagueId, nextSequenceId, userList) {

    log.info("afteTtaskComplete processo de obrigações");
    log.dir("ColleagueID: " + colleagueId);
    log.dir("NextSequenceId: " + nextSequenceId);

    var numProcess = getValue("WKNumProces");
    var user = getValue("WKUser");
    var sequenceID = getValue("WKNumState");

    if(sequenceID == 75 && nextSequenceId == 4){
        var boletoAtv = hAPI.getCardValue("ativboletovalido")
        var btnAprov = hAPI.getCardValue("botaoAprovacao")
        var coment = hAPI.getCardValue("boletovalido");

        if(boletoAtv == "true"){
            hAPI.setTaskComments(user, numProcess, 0, coment);
        }
    }
    // if (nextSequenceId == 15) {
    //     var POs = hAPI.getCardValue("POhidden");
    //     var valorOBG = hAPI.getCardValue("valor");
    //     POs = POs.split(",");
    //     var cs = []
    //     for (var i = 0; i < POs.length; i++) {
    //         cs.push(DatasetFactory.createConstraint('solicitacao', POs[i], POs[i], ConstraintType.MUST));
    //     }
    //     cs.push(DatasetFactory.createConstraint('valorObg', valorOBG, valorOBG, ConstraintType.MUST));
    //     var ds = DatasetFactory.getDataset('ds_update_po_value', null, cs, null);
    // }

    // if (nextSequenceId == 4) {
    //     var POs = hAPI.getCardValue("POhidden");
    //     var valorOBG = numberToReal(hAPI.getCardValue("valor")) * -1;
    //     POs = POs.split(",");
    //     var cs = []
    //     for (var i = 0; i < POs.length; i++) {
    //         cs.push(DatasetFactory.createConstraint('solicitacao', POs[i], POs[i], ConstraintType.MUST));
    //     }
    //     log.info("valor obrigacao ### po");
    //     log.dir(valorOBG);
    //     cs.push(DatasetFactory.createConstraint('valorObg', valorOBG, valorOBG, ConstraintType.MUST));
    //     var ds = DatasetFactory.getDataset('ds_update_po_value', null, cs, null);
    // }


}

function stringToNumber(numberInString) {
    while (numberInString.indexOf(".") > -1) {
        numberInString = numberInString.replace(".", "");
    }
    numberInString = numberInString.replace(",", ".");
    return Number(numberInString);
}