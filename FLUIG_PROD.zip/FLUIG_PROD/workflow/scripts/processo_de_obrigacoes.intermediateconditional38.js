function intermediateconditional38() {
    var numerosObrigacoes = hAPI.getCardValue('num_obrigacao') + ""
    log.info('============== Entrou no Intermadiate Condicional 38| Obrigacao: ' + numerosObrigacoes + ' ================')



    var numeroObrigacao = numerosObrigacoes.split('.')[0]
    var pagamento = numerosObrigacoes.split('.')[1]
    var numObrigaConcat = ""
    log.info('============== antes do Var Status ================')
    var status = verificaPagamento(numeroObrigacao, pagamento)

    log.info('============== Retorno do Status ================')
    log.dir(status)

    switch (status.paymentStatus) {

        case '1':
            numObrigaConcat = numeroObrigacao + '.1'
            log.info('@@@@@@ case 1 - numObriConcat')
            log.dir(numObrigaConcat)
            hAPI.setCardValue("pagamentoConlcuido", "Aguardando Pagamento.")
            hAPI.setCardValue('num_obrigacao', numObrigaConcat)
            break;

        case '2':
            // setDate();
            setDate(status.paymentDate);
            return true;

        default:
            numObrigaConcat = numeroObrigacao + '.0'
            break;
    }
    // return true;
}

// hAPI.setCardValue('num_obrigacao', numObrigaConcat)


function setDate(dt) {
    log.info('============== Entrou no setDate ================')
    log.dir(dt);
    // var date = new Date();
    var date = dt.split('');
    log.dir(date);
    var stringDate = ""

    // stringDate = '' + ((date.getDate() < 10) ? "0" + date.getDate() : date.getDate()) + '/' + (((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + date.getFullYear()
    stringDate = date[6] + date[7] + '/' + date[4] + date[5] + '/' + date[0] + date[1] + date[2] + date[3];
    log.dir(stringDate);
    hAPI.setCardValue('dataPagamento', stringDate)

    hAPI.setCardValue("pagamentoConlcuido", "Sim.")
}

function verificaPagamento(numObrig, pagStat) {
    var cCodWorkflow = "F";
    var resultado = consultaStatus(numObrig, cCodWorkflow)

    log.info('============== Retorno do consultaStatus resultado================')
    log.dir(resultado);
    log.dir(resultado['STATUS']);
    log.dir(resultado['FECGTIAPAGO']);

    var statusSwitch = {};

    if (resultado['STATUS'] == 'VAL' || resultado['STATUS'] == 'ACT') {
        // statusSwitch = '1';
        statusSwitch = {
            paymentDate: resultado['FECGTIAPAGO'],
            paymentStatus: '1'
        }
    } else if (resultado['STATUS'] == "PAG") {
        // statusSwitch = '2';
        statusSwitch = {
            paymentDate: resultado['FECGTIAPAGO'],
            paymentStatus: '2'
        }
    } else if (resultado['STATUS'] == "ANU") {
        cancelProcess()
    }

    return statusSwitch;
}

function consultaStatus(numObrig, cCodWorkflow) {
    var chave = DatasetFactory.getDataset('ds_getToken', null, null, null).getValue(0, 'token');

    var properties = {};
    properties["receive.timeout"] = "180000";

    var supplierService = ServiceManager.getService('Acsel_7');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
    var retorno = customClient.consultaStatusObrigacao(chave, numObrig, cCodWorkflow);

    log.info('Intermediate - retorno consulta Status')
    log.dir(retorno)
    log.dir(retorno.getSTATUS())

    return retorno;
}

function cancelProcess() {
    var processo = getValue("WKNumProces");
    var workflowEngineServiceProvider = ServiceManager.getServiceInstance("ECMWorkflowEngineService");
    var workflowServiceLocator = workflowEngineServiceProvider.instantiate("com.totvs.technology.ecm.workflow.ws.ECMWorkflowEngineServiceService");
    var workflowService = workflowServiceLocator.getWorkflowEngineServicePort();

    var cancelamentoProcesso = workflowService.cancelInstance('admin', 'adm', 1, processo, 'admin', 'Cancelado por conta de anulação do pagamento no serviço web.');

    if (cancelamentoProcesso.equals("OK")) {
        log.info('Processo ' + processo + " cancelado por conta de anulação do pagamento serviço web.");
    }
}