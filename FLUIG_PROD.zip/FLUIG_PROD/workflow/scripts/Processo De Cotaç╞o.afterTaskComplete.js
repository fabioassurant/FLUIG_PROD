function afterTaskComplete(colleagueId, nextSequenceId, userList) {
    var numProces = getValue("WKNumProces");

    if (nextSequenceId == 5) {
        hAPI.setCardValue("widget_numSolicitacao", numProces);
    }

    var nomeCampo = "";

    if (nextSequenceId == 5) {
        nomeCampo = "Atuarial recebe e avalia a demanda";
        hAPI.setCardValue("widget_Responsavel", "");
    }

    if (nextSequenceId == 2) {
        nomeCampo = "Início";
        hAPI.setCardValue("widget_Responsavel", hAPI.getCardValue("widget_solicitante"));
    }

    if (nextSequenceId == 10) {
        nomeCampo = "Cotação é efetuada (Analista 1)";
        hAPI.setCardValue("widget_Responsavel", hAPI.getCardValue("widget_analista_pricing1"));
    }

    if (nextSequenceId == 12) {
        nomeCampo = "Peer review cotação (Analista 2)";
        hAPI.setCardValue("widget_Responsavel", hAPI.getCardValue("analista_peer_review"));
    }

    if (nextSequenceId == 17) {
        nomeCampo = "Analista 1 envia cotação p/ comercial";
        hAPI.setCardValue("widget_Responsavel", hAPI.getCardValue("widget_analista_pricing1"));
    }

    if (nextSequenceId == 21) {
        nomeCampo = "Comercial da prosseguimento a negociação";
        hAPI.setCardValue("widget_Responsavel", hAPI.getCardValue("widget_analista_pricing1"));
    }

    if (nextSequenceId == 23) {
        nomeCampo = "Fim";
    }

    hAPI.setCardValue("widget_ativAtual", nomeCampo);



}