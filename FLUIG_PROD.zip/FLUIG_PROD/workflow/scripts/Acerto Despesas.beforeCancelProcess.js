function beforeCancelProcess(colleagueId, processId) {
    if (hAPI.getCardValue('vincularAdiantamento') == 'SIM') {
        var cardServiceProvider = ServiceManager.getServiceInstance("ECMCardService");
        var cardServiceLocator = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.ECMCardServiceService");
        var cardService = cardServiceLocator.getCardServicePort();
        var cardFieldDtoArray = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDtoArray");
        var cardField = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDto");
        cardField.setField("reembolsado");
        cardField.setValue("false");
        var vetCardFields = new Array();
        vetCardFields.push(cardField);
        cardFieldDtoArray.getItem().addAll(vetCardFields);
        var codRegistroForm = hAPI.getCardValue('codRegistroAlterar')
        cardService.updateCardData(1, "admin", "adm", codRegistroForm, cardFieldDtoArray);
    }
    hAPI.setCardValue('reembolsado', 'cancelado')
}