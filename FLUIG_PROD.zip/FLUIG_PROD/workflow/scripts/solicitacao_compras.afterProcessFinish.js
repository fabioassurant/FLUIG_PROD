function afterProcessFinish(processId){
	var usuario = getValue('WKUser'); 
	var numSolicitacao = getValue("WKNumProces");
	var mensagem = hAPI.getCardValue('motivo'); 

	if(mensagem != ""){
		hAPI.setTaskComments(usuario, numSolicitacao, 0, mensagem);	
	}
	
}