function intermediateconditional65() {
	log.info('>>> INICIA NOTIFICA USER THA')
	var dataAtual = dateNow()
	log.info('dataAtual')
	log.dir(dataAtual)
	var dataNot = hAPI.getCardData('dataNotificacaoSolicitante')
	log.info('dataNot ')
	log.info(dataNot)
	// var dataFinal = new Date(parseInt(dataForm)).toLocaleDateString('pt-BR')
	// log.info('dataFinal')
	// log.dir(dataFinal)
	 // if(dataAtual.toLocaleDateString('pt-BR') == dataFinal){
	// 	log.info('>>> ENTROU IF NOTIFICA USER THA')
	// 	return true;
	// }

	return false;
}	

function dateNow() {
    var formato = new java.text.SimpleDateFormat('dd/MM/yyyy');
    return formato.format(new java.util.Date());
}