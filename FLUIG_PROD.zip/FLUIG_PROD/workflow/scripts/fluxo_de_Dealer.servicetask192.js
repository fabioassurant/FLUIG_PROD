function servicetask192(attempt, message) {
		log.info("---------- CONSULTA PROCESSO JURÍDICO ----------");
	
		try{		
			var processInstanceId	= parseInt(hAPI.getCardValue("nr_solic_juridico"));	 
			log.info("---------- Nr Solicitacao ----------: " + processInstanceId);
		    var username 			= "NB6391"; 
		    var password 			= "AIZseguradora23";
		    var companyId			= parseInt(getValue("WKCompany"));
		    var userId 				= "NB6391"; 
		    
		    var serviceHelper  			= ServiceManager.getService('ECMWorkflowEngineService').getBean();	
		    log.info("---------- serviceHelper OK ----------");
		    var workflowEngineService 	= serviceHelper.instantiate('com.totvs.technology.ecm.workflow.ws.ECMWorkflowEngineServiceService');
		    log.info("---------- workflowEngineService OK ----------");
		    var service 				= workflowEngineService.getWorkflowEngineServicePort();
		    log.info("---------- service OK ----------");			
			
		    var returnService = service.getAllActiveStates(
												        username,
												        password,
												        companyId,
												        userId,											       
												        processInstanceId
		    );
		    log.info("---------- Retorno WS ---------- :" + returnService.getItem());
		    
		    var atividade = returnService.getItem().size();	
		    
		    if(atividade == 0){
		    	hAPI.setCardValue("processo_juridico", "Finalizado");
		    } else{
		    	hAPI.setCardValue("processo_juridico", "");
		    }				
		} catch (erro) {	
			throw "Erro na busca do processo " + processInstanceId + ": " + erro;
			log.info("---------- ERRO ---------- : " + erro);	
		}
}