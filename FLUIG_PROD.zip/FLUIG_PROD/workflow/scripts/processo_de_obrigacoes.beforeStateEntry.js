function beforeStateEntry(sequenceId){
    if (sequenceId == 4) { //verificando onde está
        log.info("if do beforeStateEntry Processo obrigacoes atv 4");
        var idUser = "" + getValue("WKUser");
        var solicitacao = "" + getValue("WKNumProces");
        var numObrig = hAPI.getCardValue("num_obrigacao");
        log.dir(idUser);
        log.dir(solicitacao);
        var verifyAprove = hAPI.getCardValue("botaoAprovacao");
        log.info("verificando before State Contestado");
        log.dir(verifyAprove);
        log.dir(numObrig);

        if(verifyAprove == "CONTESTADO"){
            if(hAPI.getCardValue('tipoObrigacaohidden') != 'COM' && hAPI.getCardValue('tipoObrigacaohidden') != 'LIM'){
                log.info("if Contestado Anula  obrig");
                var anulaObrig = DatasetFactory.getDataset("ds_anula_solic_obrig",
                                    null, 
                                    [
                                        DatasetFactory.createConstraint('nNumOblig', numObrig.replace('.0', ''), numObrig.replace('.0', ''), ConstraintType.MUST),
                                        DatasetFactory.createConstraint('cCodWorkFlow', "F", "F", ConstraintType.MUST)
                                    ], 
                                    null
                                );
                log.info('Retorno do dataset WS finaliza obrigação beforestateentry -------  ');
                log.dir(anulaObrig);
            }
            
        }
    }
}