function servicetask32(attempt, message) {
    var processo = getValue("WKNumProces");
    var tipoAcerto = (hAPI.getCardValue('tipoAcerto') == "ADIANTAMENTO") ? true : false
    log.info('===================== Entrou no ServiceTask32 - Solicitação: ' + processo + '; Adiantamento: ' + tipoAcerto + ' =====================');
    if (tipoAcerto) {
        var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0]
        var cIdSolicitacao = processo
        var cTipoOblig = 'DSP'
        var cTipoId = verifyCpfCnpj(hAPI.getCardValue('cpf'))
        var cpf = hAPI.getCardValue('cpf').split('-')
        var cNumid = cpf[0].replace('.', '').replace('/', '')
        var cDvid = cpf[1]
        var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'))
        var cDataVencimento = returnData(hAPI.getCardValue('dataPrevistaPagamento'))
        var cHistorico = "Adiantamento - " + ((hAPI.getCardValue('politicaAdiantamento') == 'NACIONAL') ? hAPI.getCardValue('contabilAdiantNacional') : hAPI.getCardValue('contabilAdiantInternacional'))
        var cNumDocto = ''
        var cCentroCusto = hAPI.getCardValue('codCentroCusto')
        var cCodEstado = "SP"
        var nValorObrigacao = realToNumber(hAPI.getCardValue('valorAdiantamento'));
        var cCodUsr = "ACSEL"
        var cEmiteCheque = "S"; //novo serviço
        var cCodWorkflow = "F"; //novo serviço

        var gson = new com.google.gson.Gson();
        var parser = new com.google.gson.JsonParser();
        var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
        objTipoPago = JSON.parse(gson.toJson(objTipoPago));
        var cTipo_Pago = objTipoPago[0]["tipopago"]; //novo serviço
        var cCodEntFinan = objTipoPago[0]["codentfinan"]; //novo serviço
        var cAgencia = objTipoPago[0]["agencia"]; //novo serviço
        var cDVAgencia = objTipoPago[0]["dvagencia"]; //novo serviço
        var cCuentaCor = objTipoPago[0]["cuentacor"]; //novo serviço
        var cDVCuentaCor = objTipoPago[0]["dvcuentacor"]; //novo serviço
        var cTipo_Conta = objTipoPago[0]["tipoconta"]; //novo serviço
        var cLinhaDigit = ""; //novo serviço
        var cNumDoctoBanco = ""; //novo serviço

        log.info("=== cDVCuentaCor - linha 38: ");
            log.dir(cDVCuentaCor);

        var obj = {
            cChaveAutent: cChaveAutent,
            cIdSolicitacao: cIdSolicitacao.toString(),
            cTipoOblig: cTipoOblig,
            cTipoId: cTipoId,
            cNumid: cNumid,
            cDvid: cDvid,
            cDataEmissao: cDataEmissao,
            cDataVencimento: cDataVencimento,
            cHistorico: cHistorico,
            cNumDocto: cNumDocto,
            cCentroCusto: cCentroCusto,
            cCodEstado: cCodEstado,
            nValorObrigacao: nValorObrigacao,
            cCodUsr: cCodUsr,
            cEmiteCheque: cEmiteCheque,
            cTipo_Pago: cTipo_Pago,
            cCodEntFinan: cCodEntFinan,
            cAgencia: cAgencia,
            cDVAgencia: cDVAgencia,
            cCuentaCor: cCuentaCor,
            cDVCuentaCor: cDVCuentaCor,
            cTipo_Conta: cTipo_Conta,
            cLinhaDigit: cLinhaDigit,
            cNumDoctoBanco: cNumDoctoBanco,
            cCodWorkflow: cCodWorkflow
        }

        var numObrigacao = webserviceUse(obj, true)

        if (numObrigacao == undefined) {
            log.info('Erro -> Problema na integração de gravar obrigação no servidor');
            log.dir(obj);
            throw "Erro na execução do Webservice"
        }

        var conta = retornaCodContaContabil(hAPI.getCardValue('codPolitica'));
        var cClaFluxo = "";
        var cNatCPTOEgre = "";
        var cCodWorkflow = "F";
        gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, conta["grupo"], conta["cod"], obj.nValorObrigacao, cClaFluxo, cNatCPTOEgre, cCodWorkflow, true)
        webserviceGravaCentroCusto(obj.cChaveAutent, numObrigacao, obj.cCentroCusto, obj.nValorObrigacao, 100, "F", true);
        webserviceFinalizaObrigacao(obj.cChaveAutent, numObrigacao, cCodWorkflow)

        var result = numObrigacao + '.0'
        hAPI.setCardValue('num_obrigacao', result)
    } else {
        if (hAPI.getCardValue('vincularAdiantamento') == 'NAO') {

            var arrayRespostas = []

            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0]
            var cIdSolicitacao = processo
            var cTipoOblig = 'DSP'
            var cTipoId = verifyCpfCnpj(hAPI.getCardValue('cpf'))
            var cpf = hAPI.getCardValue('cpf').split('-')
            var cNumid = cpf[0].replace('.', '').replace('/', '')
            var cDvid = cpf[1]
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'))
            var cDataVencimento = returnData(hAPI.getCardValue('dataPrevistaPagamento'))
            var cHistorico = "Reembolso de itens variados"
            var cNumDocto = ''
            var cCentroCusto = hAPI.getCardValue('codCentroCusto')
            var cCodEstado = 'SP'
            var nValorObrigacao = realToNumber(hAPI.getCardValue('valorReembolso'));
            var cCodUsr = "ACSEL";
            var cEmiteCheque = "S"; //novo serviço
            var cCodWorkflow = "F"; //novo serviço

            var gson = new com.google.gson.Gson();
            var parser = new com.google.gson.JsonParser();
            var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
            objTipoPago = JSON.parse(gson.toJson(objTipoPago));
            log.dir(objTipoPago)
            var cTipo_Pago = objTipoPago[0]["tipopago"]; //novo serviço
            log.dir(cTipo_Pago);
            var cCodEntFinan = objTipoPago[0]["codentfinan"]; //novo serviço
            var cAgencia = objTipoPago[0]["agencia"]; //novo serviço
            var cDVAgencia = objTipoPago[0]["dvagencia"]; //novo serviço
            var cCuentaCor = objTipoPago[0]["cuentacor"]; //novo serviço
            var cDVCuentaCor = objTipoPago[0]["dvcuentacor"]; //novo serviço
            var cTipo_Conta = objTipoPago[0]["tipoconta"]; //novo serviço
            var cLinhaDigit = ""; //novo serviço
            var cNumDoctoBanco = ""; //novo serviço

            log.info("=== cDVCuentaCor - linha 126: ");
            log.dir(cDVCuentaCor);

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid,
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.dir(obj)
            var numObrigacao = webserviceUse(obj, true)

            if (numObrigacao == undefined) {
                log.info('Erro -> Problema na integração de gravar obrigação no servidor');
                log.dir(obj);
                throw "Erro na execução do Webservice"
            }

            var result = numObrigacao + '.0'

            var campos = hAPI.getCardData(processo);
            var contador = campos.keySet().iterator();
            while (contador.hasNext()) {
                var id = contador.next();
                if (id.toLowerCase().indexOf('taxa___') > -1) {
                    var seq = id.split("___")[1];
                    var valor = (hAPI.getCardValue('distancia___' + seq) == 'true') ? hAPI.getCardValue('valorKm___' + seq) : (hAPI.getCardValue('politica___' + seq) == "NACIONAL") ? hAPI.getCardValue('valorReal___' + seq) : hAPI.getCardValue('valorFinal___' + seq)
                    var conta = retornaCodContaContabil(hAPI.getCardValue('codAcsel___' + seq));
                    var cClaFluxo = "";
                    var cNatCPTOEgre = "";
                    var cCodWorkflow = "F";
                    log.info('Gravando detalhes da obrigação -> numObrigacao: '+ numObrigacao +', conta["grupo"]: '+ conta["grupo"] +', conta["cod"]: '+ conta["cod"] +', realToNumber(valor): '+ realToNumber(valor) +', cClaFluxo: '+ cClaFluxo +', cNatCPTOEgre: '+ cNatCPTOEgre +', cCodWorkflow: '+ cCodWorkflow +'')
                    gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, conta["grupo"], conta["cod"], realToNumber(valor), cClaFluxo, cNatCPTOEgre, cCodWorkflow, true);
                    var centroCusto = hAPI.getCardValue("codCentroCustoResp1___" + seq);
                    var porcentagem = (Number((valor + "").replace(/\./g, '').replace(",", ".")) / Number((obj.nValorObrigacao + "").replace(",", "."))) * 100;
                    log.info('Gravando centro de custo da obrigação -> numObrigacao: '+ numObrigacao +', centroCusto: '+ centroCusto +', realToNumber(valor): '+ realToNumber(valor) +', realToNumber(porcentagem): '+ realToNumber(porcentagem) +'')
                    webserviceGravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, realToNumber(valor), realToNumber(porcentagem), "F", true);
                }
            }

            webserviceFinalizaObrigacao(obj.cChaveAutent, numObrigacao, cCodWorkflow)
            hAPI.setCardValue('num_obrigacao', result)

        } else {
            if ((hAPI.getCardValue('valorJustificado') + "").replace(/\./g, '').replace(/\,/g, '.') == 0) {
                var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
                var cIdSolicitacao = processo
                var cTipoOblig = 'DSP'
                var cTipoId = verifyCpfCnpj(hAPI.getCardValue('cpf'))
                var cpf = hAPI.getCardValue('cpf').split('-')
                var cNumid = cpf[0].replace('.', '').replace('/', '')
                var cDvid = cpf[1]
                var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'))
                var cDataVencimento = returnData(hAPI.getCardValue('dataPrevistaPagamento'))
                var cHistorico = "Valor de adiantamento não cobriu valor total gasto"
                var cNumDocto = ''
                var cCentroCusto = hAPI.getCardValue('codCentroCusto');
                var cCodEstado = 'SP'
                var nValorObrigacao = realToNumber('0,01')
                var cCodUsr = "ACSEL"
                var cEmiteCheque = "S"; //novo serviço
                var cCodWorkflow = "F"; //novo serviço

                var gson = new com.google.gson.Gson();
                var parser = new com.google.gson.JsonParser();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                var cTipo_Pago = objTipoPago[0]["tipopago"]; //novo serviço
                var cCodEntFinan = objTipoPago[0]["codentfinan"]; //novo serviço
                var cAgencia = objTipoPago[0]["agencia"]; //novo serviço
                var cDVAgencia = objTipoPago[0]["dvagencia"]; //novo serviço
                var cCuentaCor = objTipoPago[0]["cuentacor"]; //novo serviço
                var cDVCuentaCor = objTipoPago[0]["dvcuentacor"]; //novo serviço
                var cTipo_Conta = objTipoPago[0]["tipoconta"]; //novo serviço
                var cLinhaDigit = ""; //novo serviço
                var cNumDoctoBanco = ""; //novo serviço

                log.info("=== cDVCuentaCor - linha 226: ");
                log.dir(cDVCuentaCor);

                var obj = {
                    cChaveAutent: cChaveAutent,
                    cIdSolicitacao: cIdSolicitacao.toString(),
                    cTipoOblig: cTipoOblig,
                    cTipoId: cTipoId,
                    cNumid: cNumid,
                    cDvid: cDvid,
                    cDataEmissao: cDataEmissao,
                    cDataVencimento: cDataVencimento,
                    cHistorico: cHistorico,
                    cNumDocto: cNumDocto,
                    cCentroCusto: cCentroCusto,
                    cCodEstado: cCodEstado,
                    nValorObrigacao: nValorObrigacao,
                    cCodUsr: cCodUsr,
                    cEmiteCheque: cEmiteCheque,
                    cTipo_Pago: cTipo_Pago,
                    cCodEntFinan: cCodEntFinan,
                    cAgencia: cAgencia,
                    cDVAgencia: cDVAgencia,
                    cCuentaCor: cCuentaCor,
                    cDVCuentaCor: cDVCuentaCor,
                    cTipo_Conta: cTipo_Conta,
                    cLinhaDigit: cLinhaDigit,
                    cNumDoctoBanco: cNumDoctoBanco,
                    cCodWorkflow: cCodWorkflow
                }

                var numObrigacao = webserviceUse(obj, true)

                if (numObrigacao == undefined) {
                    log.info('Erro -> Problema na integração de gravar obrigação no servidor');
                    log.dir(obj);
                    throw "Erro na execução do Webservice"
                }

                var result = numObrigacao + '.0'

                var campos = hAPI.getCardData(processo);
                var contador = campos.keySet().iterator();
                while (contador.hasNext()) {
                    var id = contador.next();
                    if (id.toLowerCase().indexOf('taxa___') > -1) {
                        var seq = id.split("___")[1];
                        var valor = (hAPI.getCardValue('distancia___' + seq) == 'true') ? hAPI.getCardValue('valorKm___' + seq) : (hAPI.getCardValue('politica___' + seq) == "NACIONAL") ? hAPI.getCardValue('valorReal___' + seq) : hAPI.getCardValue('valorFinal___' + seq)
                        var conta = retornaCodContaContabil(hAPI.getCardValue('codAcsel___' + seq));
                        var cClaFluxo = "";
                        var cNatCPTOEgre = "";
                        var cCodWorkflow = "F";

                        log.info('Gravando detalhes da obrigação -> numObrigacao: '+ numObrigacao +', conta["grupo"]: '+ conta["grupo"] +', conta["cod"]: '+ conta["cod"] +', realToNumber(valor): '+ realToNumber(valor) +', cClaFluxo: '+ cClaFluxo +', cNatCPTOEgre: '+ cNatCPTOEgre +', cCodWorkflow: '+ cCodWorkflow +'')
                        gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, conta["grupo"], conta["cod"], realToNumber(valor), cClaFluxo, cNatCPTOEgre, cCodWorkflow, true)
                    
                        log.info('Gravando detalhes da obrigação -> numObrigacao: '+ numObrigacao +', conta["grupo"]: '+ conta["grupo"] +', conta["cod"]: '+ conta["cod"] +', realToNumber(valor): '+ ("-" + realToNumber(valor)) +', cClaFluxo: '+ cClaFluxo +', cNatCPTOEgre: '+ cNatCPTOEgre +', cCodWorkflow: '+ cCodWorkflow +'')
                        gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, conta["grupo"], conta["cod"], ("-" + realToNumber(valor)), cClaFluxo, cNatCPTOEgre, true);

                        var porcentagem = (Number((valor + "").replace(/\./g, '').replace(",", ".")) / Number((obj.nValorObrigacao + "").replace(",", "."))) * 100;
                        var centroCusto = hAPI.getCardValue("codCentroCustoResp1___" + seq);

                        log.info('Gravando centro de custo da obrigação -> numObrigacao: '+ numObrigacao +', centroCusto: '+ centroCusto +', realToNumber(valor): '+ realToNumber(valor) +', realToNumber(porcentagem): '+ realToNumber(porcentagem) +'')
                        webserviceGravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, realToNumber(valor), realToNumber(porcentagem), "F", true);
                    }
                }

                gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, 'DSPADM', 'OTRDSP', realToNumber('0,01'), true)
                webserviceFinalizaObrigacao(obj.cChaveAutent, numObrigacao)
                hAPI.setCardValue('num_obrigacao', result)

            } else {

                var arrayRespostas = []

                var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0]
                var cIdSolicitacao = processo
                var cTipoOblig = 'DSP'
                var cTipoId = verifyCpfCnpj(hAPI.getCardValue('cpf'))
                var cpf = hAPI.getCardValue('cpf').split('-')
                var cNumid = cpf[0].replace('.', '').replace('/', '')
                var cDvid = cpf[1]
                var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'))
                var cDataVencimento = returnData(hAPI.getCardValue('dataPrevistaPagamento'))
                var cHistorico = "Reembolso de itens variados"
                var cNumDocto = ""
                var cCentroCusto = hAPI.getCardValue('codCentroCusto')
                var cCodEstado = "SP"
                var nValorObrigacao = ("-" + realToNumber(hAPI.getCardValue('valorJustificado')));
                var cCodUsr = "ACSEL"


                var cEmiteCheque = ""; //novo serviço
                var cTipo_Pago = ""; //novo serviço
                var cCodEntFinan = ""; //novo serviço
                var cAgencia = ""; //novo serviço
                var cDVAgencia = ""; //novo serviço
                var cCuentaCor = ""; //novo serviço
                var cDVCuentaCor = ""; //novo serviço
                var cTipo_Conta = ""; //novo serviço
                var cLinhaDigit = ""; //novo serviço
                var cNumDoctoBanco = ""; //novo serviço
                var cCodWorkflow = "F"; //novo serviço

                var obj = {
                    cChaveAutent: cChaveAutent,
                    cIdSolicitacao: cIdSolicitacao.toString(),
                    cTipoOblig: cTipoOblig,
                    cTipoId: cTipoId,
                    cNumid: cNumid,
                    cDvid: cDvid,
                    cDataEmissao: cDataEmissao,
                    cDataVencimento: cDataVencimento,
                    cHistorico: cHistorico,
                    cNumDocto: cNumDocto,
                    cCentroCusto: cCentroCusto,
                    cCodEstado: cCodEstado,
                    nValorObrigacao: nValorObrigacao,
                    cCodUsr: cCodUsr,
                    cEmiteCheque: cEmiteCheque,
                    cTipo_Pago: cTipo_Pago,
                    cCodEntFinan: cCodEntFinan,
                    cAgencia: cAgencia,
                    cDVAgencia: cDVAgencia,
                    cCuentaCor: cCuentaCor,
                    cDVCuentaCor: cDVCuentaCor,
                    cTipo_Conta: cTipo_Conta,
                    cLinhaDigit: cLinhaDigit,
                    cNumDoctoBanco: cNumDoctoBanco,
                    cCodWorkflow: cCodWorkflow
                }
                var numObrigacao = webserviceUse(obj, true)

                if (numObrigacao == undefined) {
                    log.info('Erro -> Problema na integração de gravar obrigação no servidor');
                    log.dir(obj);
                    throw "Erro na execução do Webservice"
                }

                var result = numObrigacao + '.0'

                var campos = hAPI.getCardData(processo);
                var contador = campos.keySet().iterator();
                while (contador.hasNext()) {
                    var id = contador.next();
                    if (id.toLowerCase().indexOf('taxa___') > -1) {
                        var seq = id.split("___")[1];
                        var valor = ((hAPI.getCardValue('distancia___' + seq) == 'true') ? (hAPI.getCardValue('valorKm___' + seq)) : ((hAPI.getCardValue('politica___' + seq) == "NACIONAL") ? (hAPI.getCardValue('valorReal___' + seq)) : (hAPI.getCardValue('valorFinal___' + seq))))
                        var conta = retornaCodContaContabil(hAPI.getCardValue('codAcsel___' + seq));
                        var cClaFluxo = "";
                        var cNatCPTOEgre = "";
                        var cCodWorkflow = "F";

                        log.info('Gravando detalhes da obrigação -> numObrigacao: '+ numObrigacao +', conta["grupo"]: '+ conta["grupo"] +', conta["cod"]: '+ conta["cod"] +', realToNumber(valor): '+ realToNumber(valor) +', cClaFluxo: '+ cClaFluxo +', cNatCPTOEgre: '+ cNatCPTOEgre +', cCodWorkflow: '+ cCodWorkflow +'')
                        gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, conta["grupo"], conta["cod"], realToNumber(valor), cClaFluxo, cNatCPTOEgre, cCodWorkflow, true)

                        var porcentagem = (Number((valor + "").replace(/\./g, '').replace(",", ".")) / Number((obj.nValorObrigacao + "").replace(/\./g, '').replace(",", "."))) * 100;
                        var centroCusto = hAPI.getCardValue("codCentroCustoResp1___" + seq);

                        log.info('Gravando centro de custo da obrigação -> numObrigacao: '+ numObrigacao +', centroCusto: '+ centroCusto +', realToNumber(valor): '+ realToNumber(valor) +', realToNumber(porcentagem): '+ realToNumber(porcentagem) +'')
                        webserviceGravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, realToNumber(valor), realToNumber(porcentagem), "F", true);
                    }
                }
                var cClaFluxo = "";
                var cNatCPTOEgre = "";
                var cCodWorkflow = "F";
                gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, 'DSPADM', 'OTRDSP', ("-" + realToNumber(hAPI.getCardValue("valorAdiantado"))), cClaFluxo, cNatCPTOEgre, cCodWorkflow, true)

                webserviceFinalizaObrigacao(obj.cChaveAutent, numObrigacao)
                hAPI.setCardValue('num_obrigacao', result)
            }
        }
    }

    return true;
}

function returnData(data) {
    var newData = data.split('/')
    var newString = "" + newData[2] + newData[1] + newData[0] + ""
    return newString
}

function realToNumber(numero) {
    if(!isNaN(numero)){
       return numero
    }
    var result = (numero + "").replace(/\./g, '').replace(',','.');

    return result
}

function verifyCpfCnpj(cpfCnpj) {
    if (cpfCnpj.length() == 14) {
        return 'CPF'
    } else {
        return 'CNPJ'
    }
}

function webserviceUse(obj, restart) {
    log.info('=========== Entrou em gavar obrigação ===========')
    log.dir(obj)

    var properties = {};
    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    obj.nValorObrigacao = obj.nValorObrigacao.replace(".", ",");
    var RetornoGravaObrigacao = customClient.gravaObrigacao(obj.cChaveAutent, obj.cIdSolicitacao, obj.cTipoOblig, obj.cTipoId,
        obj.cNumid, obj.cDvid, obj.cDataEmissao, obj.cDataVencimento, obj.cHistorico, obj.cNumDocto, obj.cCentroCusto, obj.cCodEstado,
        obj.nValorObrigacao, obj.cCodUsr, obj.cEmiteCheque, obj.cTipo_Pago, obj.cCodEntFinan, obj.cAgencia, obj.cDVAgencia, obj.cCuentaCor,
        obj.cDVCuentaCor, obj.cTipo_Conta, obj.cLinhaDigit, obj.cNumDoctoBanco, obj.cCodWorkflow);

    if (RetornoGravaObrigacao.getNUMOBRIGACAO() == undefined) {
        if (restart) {
            log.info('==== restart - entrou no if -------  ')
            obj.nValorObrigacao = obj.nValorObrigacao.replace(".", ",");
            webserviceUse(obj, false);
        }
        log.info('NumObrigação = Undefined | Webservice Error -------  ')
        log.dir(RetornoGravaObrigacao)
    }

    return RetornoGravaObrigacao.getNUMOBRIGACAO();

}

function gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow, restart) {
    log.info('=========== Entrou em gavar detalhes ===========')
    log.dir(aut)
    log.dir(obrig)
    log.dir(cDesp)
    log.dir(typeDesp)
    log.dir(val)
    log.dir(cClaFluxo)
    log.dir(cNatCPTOEgre)
    log.dir(cCodWorkflow)

    var properties = {};
    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    
    log.info('==== Antes try - gravaDetalheObrigacao ====');
    val = val.toString();
    val = val.replace(".", ",");
    log.dir(val);

    try {
        log.info('==== Entrou no try - gravaDetalheObrigacao ====');
        log.dir(val);

        var RetornoGravaDetalheObrigacao = customClient.gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow);
    } catch (e) {
        log.info('==== Entrou no catch - gravaDetalheObrigacao ====');
        log.dir(RetornoGravaDetalheObrigacao);
        throw e.toString()
    }

    if (RetornoGravaDetalheObrigacao.getRetorno() != 0) {
        log.info("==== restart entrou no if retorno != 0 - gravaDetalheObrigacao");
        log.dir(RetornoGravaDetalheObrigacao);

        if (restart) {
            log.info("==== restart entrou no if restart - gravaDetalheObrigacao");
            val = val.replace(",", ".");
            log.dir(val);
            
            gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow, false);
        }
        throw 'Erro: na gravação do detalhe da obrigação (Webservice retorno o valor ' + RetornoGravaDetalheObrigacao.getRetorno()
    }

}

function webserviceFinalizaObrigacao(autenticacao, num, cCodWorkflow) {
    log.info('=========== Entrou em gavar detalhes ===========')
    log.dir(autenticacao)
    log.dir(num)
    log.dir(cCodWorkflow)

    var properties = {};
    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    try {
        var Retorno = customClient.finalizaObrigacao(autenticacao, num, 'S', cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        throw 'Erro na finalização da obrigação. (webservice retornou o valor ' + Retorno.getRetorno() + ")"
    }

}

function retornaCodContaContabil(descricao) {
    var conta = {};
    var c1 = DatasetFactory.createConstraint('grupo', 'DSPREL', 'DSPREL', ConstraintType.MUST);
    var dataset = DatasetFactory.getDataset('ds_retornaConceitoAdmRel', null, [c1], null)
    for (var i = 0; i < dataset.rowsCount; i++) {
        if (dataset.getValue(i, "descConceito") == descricao) {
            conta["cod"] = dataset.getValue(i, "codConceito");
            conta["grupo"] = dataset.getValue(i, "grupo");
        }
    }
    return conta;
}

function webserviceGravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow, restart) {
    log.info('============== Entrou no para gravar o centro de custo ================');
    log.dir({'Autenticacao':autenticacao, 'numObrig':numObrig,'centroCusto':centroCusto,'montante':montante,'porcentagem':porcentagem,'cCodWorkflow':cCodWorkflow,'restart':restart});
    var properties = {};
    properties["receive.timeout"] = "100000000";
    
    porcentagem = porcentagem.toString();
    porcentagem = porcentagem.replace(".", ",");
    log.dir(porcentagem);
    
    var supplierService = ServiceManager.getService('Acsel');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);

    log.info('==== Antes try - webserviceGravaCentroCusto ====');
    montante = montante.toString();
    montante = montante.replace(".", ",");
    log.dir(montante);

    try {
        log.info('==== Entrou no try - webserviceGravaCentroCusto ====');
        log.dir(montante);
        var Retorno = customClient.gravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow);
    } catch (e) {
        log.info('==== Entrou no catch - webserviceGravaCentroCusto ====');
        log.dir(Retorno);
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        
        log.info("==== restart entrou no if retorno != 0 - webserviceGravaCentroCusto");
        log.dir(Retorno);

        if (restart) {
            log.info("==== restart entrou no if restart - webserviceGravaCentroCusto");
            montante = montante.replace(",", ".");
            log.dir(montante);
            webserviceGravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow, false);
        }
        throw 'Erro na inclusão do valor para o centro de custo. (Webservice retornou o valor ' + Retorno.getRetorno() + ")";
    }
}

function retornaTipoPago(cChaveAutent, cTipoId, cNumId, cDvid, cCodWorkflow) {
    var properties = {};

    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    try {
        var Retorno = customClient.retornaTipoPago(cChaveAutent, cTipoId, cNumId, cDvid, cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (!Retorno.getTipoPagoList()) {
        throw 'Método de pagamento do solicitante não encontrado';
    } else {
        return Retorno.getTipoPagoList().getTipoPago();
    }
}