function beforeTaskSave(colleagueId,nextSequenceId,userList){ 
	
	var anexos   = hAPI.listAttachments();
	var numState = getValue("WKNumState");
	var nextState = getValue("WKNextState");
    var process = getValue("WKNumProces");

	
	if (numState == 125 || numState == 106 || numState == 122 || 
		numState == 107 || numState == 112 || numState == 117 || numState == 121 || 
		numState == 104 || numState == 114 || numState == 171 || numState == 170 || 
		numState == 176 || numState == 177 || numState == 178){
        if (temAnexo() == false) {        
        	throw "É preciso anexar o documento para continuar!";
        }
    }
	if ((numState == 124 || numState == 111 || numState == 109) && hAPI.getCardValue("radiotypes") == "sim"){
        if (temAnexo() == false) {        
        	throw "É preciso anexar o documento para continuar!";
        }
    }
	
	function temAnexo(){        
        var constraintProcessAttachment = DatasetFactory.createConstraint('processAttachmentPK.processInstanceId', process, process, ConstraintType.MUST);
        var datasetProcessAttachment = DatasetFactory.getDataset('processAttachment', null, new Array(constraintProcessAttachment), null);

        for(var i = 0; i < datasetProcessAttachment.rowsCount; i++) {
            var constraintProcessHistory1 = DatasetFactory.createConstraint('processHistoryPK.movementSequence', datasetProcessAttachment.getValue(i, "originalMovementSequence"), datasetProcessAttachment.getValue(i, "originalMovementSequence"), ConstraintType.MUST);
            var constraintProcessHistory2 = DatasetFactory.createConstraint('processHistoryPK.processInstanceId', process, process, ConstraintType.MUST);
            var constraintProcessHistory3 = DatasetFactory.createConstraint('processHistoryPK.companyId', datasetProcessAttachment.getValue(i, "processAttachmentPK.companyId"), datasetProcessAttachment.getValue(i, "processAttachmentPK.companyId"), ConstraintType.MUST);
            var constraintProcessHistory4 = DatasetFactory.createConstraint('stateSequence', numState, numState, ConstraintType.MUST);
            var datasetProcessHistory = DatasetFactory.getDataset('processHistory', null, new Array(constraintProcessHistory1, constraintProcessHistory2, constraintProcessHistory3, constraintProcessHistory4), null);
            for(var j = 0; j < datasetProcessHistory.rowsCount; j++) {                
                return true;            
            }    
        }
        return false;    
    }    

}
