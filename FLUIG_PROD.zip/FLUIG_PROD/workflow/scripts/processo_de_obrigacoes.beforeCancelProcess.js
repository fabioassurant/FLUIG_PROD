function beforeCancelProcess(colleagueId, processId) {

    log.info('######## libera obrigação COM LIM');
    var listarobrigacoes = hAPI.getCardValue('listarobrigacoes');
    
    log.dir(listarobrigacoes);

    if(listarobrigacoes == "true"){
        log.info('######## Entrou libera obrigação COM LIM');
        unlinkOblig((hAPI.getCardValue('num_obrigacao')).replace(".0", ""));
        log.info('######## Finalizou libera obrigação COM LIM');
    }

    log.info('######## verifica cancela PO');
    var temPO = hAPI.getCardValue("temPOHidden");
    log.dir(temPO);

    if(temPO == "sim" ){
        var cs = DatasetFactory.createConstraint("nNumOblig", (hAPI.getCardValue('num_obrigacao')).replace(".0", ""), (hAPI.getCardValue('num_obrigacao')).replace(".0", ""), ConstraintType.MUST);
        var cs2 = DatasetFactory.createConstraint("cCodWorkFlow", "F", "F", ConstraintType.MUST);
        var ds = DatasetFactory.getDataset("ds_anula_solic_obrig", null, [cs, cs2], null);
    
        log.info('---- Volta Valor PO')
        var valorOBG = "-" + hAPI.getCardValue("valorTotal");
        var cs2 = []
        cs2.push(DatasetFactory.createConstraint('solicitacao', hAPI.getCardValue("POhidden"), hAPI.getCardValue("POhidden"), ConstraintType.MUST));
        cs2.push(DatasetFactory.createConstraint('valorObg', valorOBG, valorOBG, ConstraintType.MUST));
        log.dir(cs2)
        var ds = DatasetFactory.getDataset('ds_update_po_value', null, cs2, null);
    } else {
        if(hAPI.getCardValue('tipoObrigacaohidden') != 'COM' && hAPI.getCardValue('tipoObrigacaohidden') != 'LIM'){
            var cs = DatasetFactory.createConstraint("nNumOblig", (hAPI.getCardValue('num_obrigacao')).replace(".0", ""), (hAPI.getCardValue('num_obrigacao')).replace(".0", ""), ConstraintType.MUST);
            var cs2 = DatasetFactory.createConstraint("cCodWorkFlow", "F", "F", ConstraintType.MUST);
            var ds = DatasetFactory.getDataset("ds_anula_solic_obrig", null, [cs, cs2], null);
        }
    }
    
}

function unlinkOblig(obrig){
    log.info('============== Entrou no desvincula solicitacao da obrigacao ================');
    log.dir(obrig);
    var processo = getValue("WKNumProces");
    var retornoAttrSolic = DatasetFactory.getDataset("ds_limpa_solic_obrig",
                                null, 
                                [
                                    DatasetFactory.createConstraint('nNumOblig', obrig, obrig, ConstraintType.MUST) 
                                ], 
                                null
                            );
    log.info('Retorno do dataset WS desvincula solicitacao a obrigacao -------  ');
    log.dir(retornoAttrSolic);


    if (retornoAttrSolic.getValue(0, 'retorno') != 0 ) {
        log.info('Retorno do unlink solic | Webservice Error -------  ')
       
        throw 'Erro para Desvincular Obrigação '+ obrig +' Solicitação '+ processo +' : webservice retornou o valor ' + retornoAttrSolic.getValue(0, 'retorno') + " - " + retornoAttrSolic.getValue(0, 'descricaoErro') + "."
    }
    
}