function servicetask44(attempt, message) {
	log.info('============== Entrou Atividade Serviço Gravar Fornecedor ================');
	
	var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
	var cCodeProveedor = "";
	var cTipoId = hAPI.getCardValue("tipoFornecedorHidden");
	var cNumId = hAPI.getCardValue("documentoHidden");;
	var cDvId = hAPI.getCardValue("fimDocumentoHidden");;
	var cNomeTer = hAPI.getCardValue("razaoSocial");
	var cApeTer = hAPI.getCardValue("nmFantasia");
	var cDirec = hAPI.getCardValue("endereco").split(",")[0];
	var cNumero = hAPI.getCardValue("numero");
	var cCodPais = "BRA";
	var cCodEstado = hAPI.getCardValue("ufHidden");
	var cCodCiudad = hAPI.getCardValue("cidadeHidden");
	var cBairro = hAPI.getCardValue("bairro");
	var cZip = hAPI.getCardValue("cep").replace("-", "");
	var cEmiteNota = hAPI.getCardValue("emiteNFHidden");
	var cTelex = hAPI.getCardValue("email");
	var cDdd1 = hAPI.getCardValue("telefone").split(" ")[0].replace("(","").replace(")","");	
	var cTelef1 = hAPI.getCardValue("telefone").split(" ")[1].replace("-","");
	var cDdd2 = "";	
	var cTelef2 = "";
	var cDdd3 = "";	
	var cTelef3 = "";
	var cFax = "";
	var cTipoPago = "071";
	var cBanco = hAPI.getCardValue("bancoHidden");
	var cAgencia = hAPI.getCardValue("agencia");
	var cDAgencia = "";
	var cConta = "";
	var cDConta = "";
	if(hAPI.getCardValue("conta") != ""){
		cConta = hAPI.getCardValue("conta").split("-")[0];
		cDConta = hAPI.getCardValue("conta").split("-")[1];
	}else{
		cConta = "";
		cDConta = "";
	}
	var cTipoConta = hAPI.getCardValue("tipoHidden");
	var cCodWorkflow = "F";
	var cDatVigencContr = hAPI.getCardValue("dataContrato").split("/")[2] + hAPI.getCardValue("dataContrato").split("/")[1] + hAPI.getCardValue("dataContrato").split("/")[0];
	
	gravaFornecedor(cChaveAutent+ "", cCodeProveedor+ "", cTipoId+ "", cNumId+ "", cDvId+ "", 
			 cNomeTer+ "", cApeTer+ "", cDirec+ "", cNumero+ "", cCodPais+ "", cCodEstado+ "",
			 cCodCiudad+ "", cBairro+ "", cZip+ "", cEmiteNota+ "", cTelex+ "", cDdd1+ "",
			 cTelef1+ "", cDdd2+ "", cTelef2+ "", cDdd3+ "", cTelef3+ "", cFax+ "", cTipoPago+ "",
			 cBanco+ "", cAgencia+ "", cDAgencia+ "", cConta+ "", cDConta+ "", cTipoConta+ "",
			 cDatVigencContr+ "", cCodWorkflow+ "");
	 
	function gravaFornecedor(cChaveAutent, cCodeProveedor, cTipoId, cNumId, cDvId, 
							 cNomeTer, cApeTer, cDirec, cNumero, cCodPais, cCodEstado,
							 cCodCiudad, cBairro, cZip, cEmiteNota, cTelex, cDdd1,
							 cTelef1, cDdd2, cTelef2, cDdd3, cTelef3, cFax, cTipoPago,
							 cBanco, cAgencia, cDAgencia, cConta, cDConta, cTipoConta,
							 cDatVigencContr, cCodWorkflow) {
	    log.info('============== Chamando API Gravar Fornecedor ================');
	    log.dir({
	        'Chave': cChaveAutent,
	        'Código do PROVEEDOR': cCodeProveedor,
	        'Tipo Fornecedor': cTipoId,
	        'Nº de identificação': cNumId,
	        'Digito de identificação': cDvId,
	        'Nome': cNomeTer,
	        'Nome Fantasia': cApeTer,
	        'Endereço': cDirec,
	        'Nº Endereço': cNumero,
	        'Código do País': cCodPais,
	        'Código do Estado': cCodEstado,
	        'Código da Cidade': cCodCiudad,
	        'Bairro': cBairro,
	        'CEP': cZip,
	        'Emite Nota Fiscal': cEmiteNota,
	        'E-mail': cTelex,
	        'DDD': cDdd1,
	        'Contato': cTelef1,
	        'Tipo Pagamento': cTipoPago,
	        'Código do Banco': cBanco,
	        'Código da Agência': cAgencia,
	        'Código da Conta': cConta,
	        'Dígito da Conta': cDConta,
	        'Tipo de Conta': cTipoConta,
	        'Data Contrato': cDatVigencContr,
	        'Código Gravação': cCodWorkflow,
	    });

	    var properties = {};

	    properties["receive.timeout"] = "100000000";

	    var supplierService = ServiceManager.getService('Acsel_8');
	    var serviceHelper = supplierService.getBean();
	    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
	    var service = serviceLocator.getServicosWebServicePort();
	    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
	    try {
	        var retorno = customClient.gravaFornecedor(cChaveAutent, cCodeProveedor, cTipoId, cNumId, cDvId, 
													   cNomeTer, cApeTer, cDirec, cNumero, cCodPais, cCodEstado,
													   cCodCiudad, cBairro, cZip, cEmiteNota, cTelex, cDdd1,
													   cTelef1, cDdd2, cTelef2, cDdd3, cTelef3, cFax, cTipoPago,
													   cBanco, cAgencia, cDAgencia, cConta, cDConta, cTipoConta,
													   cDatVigencContr, cCodWorkflow);
	        log.info('============== Service task 44 - Retorno Grava Fornecedor')
	        log.dir(retorno)
	        
	        if(retorno['retorno'] != 0){
	        	throw "Erro retorno: " + retorno['descricaoErro']
	        }
	    } catch (e) {
	        throw e.toString();
	    }
	}
}