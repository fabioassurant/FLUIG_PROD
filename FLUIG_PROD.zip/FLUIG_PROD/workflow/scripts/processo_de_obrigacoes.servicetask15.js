function servicetask15(attempt, message) {
    var processo = getValue("WKNumProces");
    var tipoAcerto = hAPI.getCardValue('tipoAcerto');
    if (tipoAcerto) {
        var campoTipoAdiantamento = hAPI.getCardValue('tipoAcertoHidden_1')
        var campoTipoDespesaNF = hAPI.getCardValue('tipoAcertoHidden_2')
        var campoTipoRH = hAPI.getCardValue('tipoAcertoHidden_3')
        var campoTipoOuvidoria = hAPI.getCardValue('tipoAcertoHidden_4')
        var campoTipoComissao = hAPI.getCardValue('tipoAcertoHidden_5')
        var campoTipoImposto = hAPI.getCardValue('tipoAcertoHidden_6')
        var campoTipoPresConta = hAPI.getCardValue('tipoAcertoHidden_7')
        var campoTipoCosseguro = hAPI.getCardValue('tipoAcertoHidden_8')
        var campoTipoFranquia = hAPI.getCardValue('tipoAcertoHidden_9')
        var campoTipoApolice = hAPI.getCardValue('tipoAcertoHidden_10')
        
        
        if (campoTipoAdiantamento != "") {

            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo;
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_1'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_1')));
            
            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF1");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP'
            var nValorObrigacao = hAPI.getCardValue('valorAdiantamento');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_1");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                // cTipo_Pago = "";
                cNumDoctoBanco = hAPI.getCardValue("codBarras_1");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_2");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.info(' ===> service task 15 - ObjAdiantamento')
            log.dir(obj)

            numObrigacao = gravaObrigacao(obj, true)

            if (numObrigacao == undefined) {
                throw "Erro na execução do Webservice"
            }

            if (numObrigacao != "ERRO VALIDA BOLETO"){

                var campos = hAPI.getCardData(processo);
                var contador = campos.keySet().iterator();
                gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                while (contador.hasNext()) {
                    var id = contador.next();

                    if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                        var seq = id.split("___")[1];
                        var valor =hAPI.getCardValue('valorRateio___' + seq);
                        var cClaFluxo = ""; //novo serviço 
                        var cNatCPTOEgre = ""; //novo serviço
                        var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100;
                        var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                        gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                    }
                }

                gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);

                var result = numObrigacao + '.0';
                hAPI.setCardValue('num_obrigacao', result);
                hAPI.setCardValue("numObligationAdiantamento", result);

                if(cTipo_Pago == '081'){
                    
                    log.info(' ===> service task 15 - ObjAdiantamento c tipo pago == 81')
                    log.dir(cTipo_Pago)

                    // teste carregar imposto e verificar validação de Boleto
                    // imposto
                    var type = '1';
                    var nValorLiquidobrig = '';

                    retTaxas(result,type, campoTipoAdiantamento);
                    nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoAdiantamento);
                    // valida boleto
                    var objBol = {
                        cIdSolicitacao: cIdSolicitacao.toString(),
                        cCodUsr: cCodUsr,
                        cTipo_Pago: cTipo_Pago,
                        cLinhaDigit: cLinhaDigit,
                        nNumOblig: result,
                        cNumDoctoBanco: cNumDoctoBanco,
                        cDataVencimento: cDataVencimento,
                        nValorLiquidobrig: nValorLiquidobrig                
                    }

                    log.info(' ===> service task 15 - ObjBolAdiantamento validaBoleto')
                    log.dir(objBol)

                    var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
            
                    log.info("Retorno do boleto teste de movimentação");
                    log.dir(retornoBoleto);
                    if(retornoBoleto == "false"){
                        log.info(' ===> finaliza validação de boleto teste OK');
                    }
                    if(retornoBoleto == "true"){
                        log.info(' ===> finaliza valida��ão de boleto teste Nao é válido');
                    }

                }
            }
        }
        if(campoTipoDespesaNF != "") {
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo;
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_2'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_2')));

            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF2");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP';
            var nValorObrigacao = hAPI.getCardValue('valorDespesa');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_2");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_2");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_2");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.info(' ===>  service task 15 - ObjDespesa')
            log.dir(obj)

            numObrigacao = gravaObrigacao(obj, true)

            if (numObrigacao == undefined) {
                throw "Erro na execução do Webservice"
            }
           
            if (numObrigacao != "ERRO VALIDA BOLETO"){

                var campos = hAPI.getCardData(processo);
                var contador = campos.keySet().iterator();
                gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                while (contador.hasNext()) {
                    var id = contador.next();
                    if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                        var seq = id.split("___")[1];
                        var valor = hAPI.getCardValue('valorRateio___' + seq);
                        var cClaFluxo = ""; //novo serviço
                        var cNatCPTOEgre = ""; //novo serviço
                        var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                        var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                        gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                    }
                }

                gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                var result = numObrigacao + '.0';
                hAPI.setCardValue('num_obrigacao', result);
                hAPI.setCardValue("numObligationDespesaNF", result);
                
                if(cTipo_Pago == '081'){
                    
                    log.info(' ===> service task 15 - ObjDespesa c tipo pago == 81')
                    log.dir(cTipo_Pago)

                    // teste carregar imposto e verificar validação de Boleto
                    // imposto
                    var type = '2';
                    var nValorLiquidobrig = '';

                    retTaxas(result,type, campoTipoDespesaNF);
                    nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoDespesaNF);
                    // valida boleto
                    var objBol = {
                        cIdSolicitacao: cIdSolicitacao.toString(),
                        cCodUsr: cCodUsr,
                        cTipo_Pago: cTipo_Pago,
                        cLinhaDigit: cLinhaDigit,
                        nNumOblig: result,
                        cNumDoctoBanco: cNumDoctoBanco,
                        cDataVencimento: cDataVencimento,
                        nValorLiquidobrig: nValorLiquidobrig                
                    }

                    log.info(' ===> service task 15 - ObjBolDespesa validaBoleto')
                    log.dir(objBol)

                    var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
            
                    log.info("Retorno do boleto teste de movimentação");
                    log.dir(retornoBoleto);
                    if(retornoBoleto == "false"){
                        log.info(' ===> finaliza validação de boleto teste OK');
                    }
                    if(retornoBoleto == "true"){
                        log.info(' ===> finaliza validação de boleto teste Nao é válido');
                    }

                }
            }
        }
        if(campoTipoRH != "") {
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo;
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_3'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_3')));

            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF3");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP';
            var nValorObrigacao = hAPI.getCardValue('valorRH');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_3");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_3");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_3");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            numObrigacao = gravaObrigacao(obj, true)

            if (numObrigacao == undefined) {
                throw "Erro na execução do Webservice"
            }
            
            if (numObrigacao != "ERRO VALIDA BOLETO"){

                var campos = hAPI.getCardData(processo);
                var contador = campos.keySet().iterator();
                gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                while (contador.hasNext()) {
                    var id = contador.next();

                    if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                        var seq = id.split("___")[1];
                        var valor = hAPI.getCardValue('valorRateio___' + seq);
                        var cClaFluxo = ""; //novo serviço
                        var cNatCPTOEgre = ""; //novo serviço
                        var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                        var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                        gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                    }
                }

                gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                var result = numObrigacao + '.0'
                hAPI.setCardValue('num_obrigacao', result)
                hAPI.setCardValue("numObligationRH", result);
                
                if(cTipo_Pago == '081'){
                    
                    log.info(' ===> service task 15 - ObjRH c tipo pago == 81')
                    log.dir(cTipo_Pago)

                    // teste carregar imposto e verificar validação de Boleto
                    // imposto
                    var type = '3';
                    var nValorLiquidobrig = '';

                    retTaxas(result,type, campoTipoRH);
                    nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoRH);
                    // valida boleto
                    var objBol = {
                        cIdSolicitacao: cIdSolicitacao.toString(),
                        cCodUsr: cCodUsr,
                        cTipo_Pago: cTipo_Pago,
                        cLinhaDigit: cLinhaDigit,
                        nNumOblig: result,
                        cNumDoctoBanco: cNumDoctoBanco,
                        cDataVencimento: cDataVencimento,
                        nValorLiquidobrig: nValorLiquidobrig                
                    }

                    log.info(' ===> service task 15 - ObjBolRH validaBoleto')
                    log.dir(objBol)

                    var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
            
                    log.info("Retorno do boleto teste de movimentação");
                    log.dir(retornoBoleto);
                    if(retornoBoleto == "false"){
                        log.info(' ===> finaliza validação de boleto teste OK');
                    }
                    if(retornoBoleto == "true"){
                        log.info(' ===> finaliza validação de boleto teste Nao é válido');
                    }

                }
            }
        }
        if(campoTipoOuvidoria != "") {
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo;
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_4'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_4')));

            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF4");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP'
            // var nValorObrigacao = realToNumber(hAPI.getCardValue('valorOuvidoria'));
            var nValorObrigacao = hAPI.getCardValue('valorOuvidoria');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_4");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_4");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;

            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_4");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            numObrigacao = gravaObrigacao(obj, true)

            if (numObrigacao == undefined) {
                throw "Erro na execução do Webservice"
            }
            
            if (numObrigacao != "ERRO VALIDA BOLETO"){

                var campos = hAPI.getCardData(processo);
                var contador = campos.keySet().iterator();
                gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                while (contador.hasNext()) {
                    var id = contador.next();

                    if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                        var seq = id.split("___")[1];
                        var valor = hAPI.getCardValue('valorRateio___' + seq);
                        var cClaFluxo = ""; //novo serviço
                        var cNatCPTOEgre = ""; //novo serviço
                        var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                        var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                        gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                    }
                }

                gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                var result = numObrigacao + '.0'
                hAPI.setCardValue('num_obrigacao', result)
                hAPI.setCardValue("numObligationOuvidoria", result);
                
                if(cTipo_Pago == '081'){
                    
                    log.info(' ===> service task 15 - ObjOuvidoria c tipo pago == 81')
                    log.dir(cTipo_Pago)

                    // teste carregar imposto e verificar validação de Boleto
                    // imposto
                    var type = '4';
                    var nValorLiquidobrig = '';

                    retTaxas(result,type, campoTipoOuvidoria);
                    nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoOuvidoria);
                    // valida boleto
                    var objBol = {
                        cIdSolicitacao: cIdSolicitacao.toString(),
                        cCodUsr: cCodUsr,
                        cTipo_Pago: cTipo_Pago,
                        cLinhaDigit: cLinhaDigit,
                        nNumOblig: result,
                        cNumDoctoBanco: cNumDoctoBanco,
                        cDataVencimento: cDataVencimento,
                        nValorLiquidobrig: nValorLiquidobrig                
                    }

                    log.info(' ===> service task 15 - ObjBolOuvidoria validaBoleto')
                    log.dir(objBol)

                    var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
            
                    log.info("Retorno do boleto teste de movimentação");
                    log.dir(retornoBoleto);
                    if(retornoBoleto == "false"){
                        log.info(' ===> finaliza validação de boleto teste OK');
                    }
                    if(retornoBoleto == "true"){
                        log.info(' ===> finaliza validação de boleto teste Nao é válido');
                    }

                }
            }
        }
        if(campoTipoComissao != "") {
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo.toString();
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_5'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_5')));


            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF5");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP';
            var nValorObrigacao = hAPI.getCardValue('valorComissao');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_5");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_5")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_5")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.info(' ===> Service Task 15 - Obj COM')
            log.dir(obj)

            var listarobrigacoes = hAPI.getCardValue('listarobrigacoes');
            var statusobrigacao = hAPI.getCardValue('statusoblig');
            var numObrigacao;

            if(listarobrigacoes == "true" && (statusobrigacao == "ACT" || statusobrigacao == "PAG")){
                log.info("Entrou no if do atribui obrigacao Comissao");
                log.dir(cIdSolicitacao);
                numObrigacao = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
                log.dir(numObrigacao);
                atribuiSolicObrigacao(numObrigacao, cIdSolicitacao);
                hAPI.setCardValue('ativboletovalido', 'false');
            }else{
                numObrigacao = gravaObrigacao(obj, true)

                if (numObrigacao == undefined) {
                    throw "Erro na execução do Webservice"
                }
            
                if (numObrigacao != "ERRO VALIDA BOLETO"){

                    var campos = hAPI.getCardData(processo);
                    var contador = campos.keySet().iterator();
                    gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                    while (contador.hasNext()) {
                        var id = contador.next();

                        if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                            var seq = id.split("___")[1];
                            var valor = hAPI.getCardValue('valorRateio___' + seq);
                            var cClaFluxo = ""; //novo serviço
                            var cNatCPTOEgre = ""; //novo serviço
                            var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                            var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                            gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                        }
                    }

                    gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                    var result = numObrigacao + '.0'
                    hAPI.setCardValue('num_obrigacao', result)
                    hAPI.setCardValue("numObligationComissao", result);

                    if(cTipo_Pago == '081'){
                    
                        log.info(' ===> service task 15 - ObjComissao c tipo pago == 81')
                        log.dir(cTipo_Pago)
        
                        // teste carregar imposto e verificar validação de Boleto
                        // imposto
                        var type = '5';
                        var nValorLiquidobrig = '';
        
                        retTaxas(result,type, campoTipoComissao);
                        nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoComissao);
                        // valida boleto
                        var objBol = {
                            cIdSolicitacao: cIdSolicitacao.toString(),
                            cCodUsr: cCodUsr,
                            cTipo_Pago: cTipo_Pago,
                            cLinhaDigit: cLinhaDigit,
                            nNumOblig: result,
                            cNumDoctoBanco: cNumDoctoBanco,
                            cDataVencimento: cDataVencimento,
                            nValorLiquidobrig: nValorLiquidobrig                
                        }
        
                        log.info(' ===> service task 15 - ObjBolComissao validaBoleto')
                        log.dir(objBol)
        
                        var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
                
                        log.info("Retorno do boleto teste de movimentação");
                        log.dir(retornoBoleto);
                        if(retornoBoleto == "false"){
                            log.info(' ===> finaliza validação de boleto teste OK');
                        }
                        if(retornoBoleto == "true"){
                            log.info(' ===> finaliza validação de boleto teste Nao é válido');
                        }
        
                    }
                }
            }
        }
        if(campoTipoImposto != "") {
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo.toString();
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_6'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_6')));


            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF6");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP'
            var nValorObrigacao = hAPI.getCardValue('valorImposto');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_6");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_6");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_6");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.info(' ===> Service Task 15 - Obj LIM');
            log.dir(obj);

            var listarobrigacoes = hAPI.getCardValue('listarobrigacoes');
            var statusobrigacao = hAPI.getCardValue('statusoblig');
            var numObrigacao;

            if(listarobrigacoes == "true" && statusobrigacao == "ACT"){
                log.info("Entrou no if do atribui obrigacao Imposto");
                log.dir(cIdSolicitacao);
                numObrigacao = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
                log.dir(numObrigacao);
                atribuiSolicObrigacao(numObrigacao, cIdSolicitacao);
                hAPI.setCardValue('ativboletovalido', 'false');
            }else{
                numObrigacao = gravaObrigacao(obj, true)

                if (numObrigacao == undefined) {
                    throw "Erro na execução do Webservice"
                }

                if (numObrigacao != "ERRO VALIDA BOLETO"){

                    var campos = hAPI.getCardData(processo);
                    var contador = campos.keySet().iterator();
                    gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);
        
                    while (contador.hasNext()) {
                        var id = contador.next();
                        if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                            var seq = id.split("___")[1];
                            var valor = hAPI.getCardValue('valorRateio___' + seq);
                            var cClaFluxo = ""; //novo serviço
                            var cNatCPTOEgre = ""; //novo serviço
                            var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                            var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                            gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                        }
                    }
                    gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                    var result = numObrigacao + '.0'
                    hAPI.setCardValue('num_obrigacao', result)
                    hAPI.setCardValue("numObligationImposto", result);

                    if(cTipo_Pago == '081'){
                    
                        log.info(' ===> service task 15 - ObjImposto c tipo pago == 81')
                        log.dir(cTipo_Pago)
        
                        // teste carregar imposto e verificar validação de Boleto
                        // imposto
                        var type = '6';
                        var nValorLiquidobrig = '';
        
                        retTaxas(result,type, campoTipoImposto);
                        nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoImposto);
                        // valida boleto
                        var objBol = {
                            cIdSolicitacao: cIdSolicitacao.toString(),
                            cCodUsr: cCodUsr,
                            cTipo_Pago: cTipo_Pago,
                            cLinhaDigit: cLinhaDigit,
                            nNumOblig: result,
                            cNumDoctoBanco: cNumDoctoBanco,
                            cDataVencimento: cDataVencimento,
                            nValorLiquidobrig: nValorLiquidobrig                
                        }
        
                        log.info(' ===> service task 15 - ObjBolImposto validaBoleto')
                        log.dir(objBol)
        
                        var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
                
                        log.info("Retorno do boleto teste de movimentação");
                        log.dir(retornoBoleto);
                        if(retornoBoleto == "false"){
                            log.info(' ===> finaliza validação de boleto teste OK');
                        }
                        if(retornoBoleto == "true"){
                            log.info(' ===> finaliza validação de boleto teste Nao é válido');
                        }
        
                    }
                }
            }
        }
        if(campoTipoPresConta != "") {
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo;
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_7'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_7')));


            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF7");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('centroCustoPresHidden');
            var cCodEstado = 'SP';
            var nValorObrigacao = hAPI.getCardValue('valorPresConta');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = '';     //hAPI.getCardValue('codPoliticaPres');
            var grupoConceito = '';     //hAPI.getCardValue('idGrupoContPres');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_7");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_7");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_7");
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            var numObrigacao = gravaObrigacao(obj, true)

            if (numObrigacao == undefined) {
                throw "Erro na execução do Webservice"
            }

            if (numObrigacao != "ERRO VALIDA BOLETO"){

                var campos = hAPI.getCardData(processo);
                var contador = campos.keySet().iterator();
                // Loop para iterar grava detalhe Obrigação
                while (contador.hasNext()) {
                    var id = contador.next();

                    if (id.toLowerCase().indexOf('grupocontacontabilpres___') > -1) {
                        var seq = id.split("___")[1];
                        var valor = hAPI.getCardValue('valorGCContabil___' + seq);
                        valor = valor.replace(".", "");
                        grupoConceito = hAPI.getCardValue('idGrupoContPres___' + seq);
                        contaContabil = hAPI.getCardValue('contaContabilPres___' + seq);
                        gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, valor, "", "", cCodWorkflow, true);
                    }
                }
                //Loop para iterar Grava centro de custo
                contador = campos.keySet().iterator();
                while (contador.hasNext()) {
                    var id = contador.next();
                    if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                        var seq = id.split("___")[1];
                        // log.info(' ===> grava rateio seq ============> ' +  seq);
                        var valor = hAPI.getCardValue('valorRateio___' + seq).replace(".", "");
                        // log.info(' ===> grava rateio valor ==========> ' +  valor);
                        var cClaFluxo = ""; //novo serviço
                        // log.info(' ===> grava rateio cClaFluxo ======> ' +  cClaFluxo);
                        var cNatCPTOEgre = ""; //novo serviço
                        // log.info(' ===> grava rateio cNatCPTOEgre ===> ' +  cNatCPTOEgre);
                        var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100;
                        // log.info(' ===> grava rateio porcentagem ====> ' +  porcentagem);
                        var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                        // log.info(' ===> grava rateio centroCusto ====> ' +  centroCusto);
                        gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor, porcentagem.toFixed(6).replace(".", ","), cCodWorkflow, true);
                    }
                }

                var valorNF =  obj.nValorObrigacao;
                valorNF = valorNF.replace('.','');
                gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, valorNF, cCodWorkflow, true);
                log.info(' ===> grava detalhe final');
                var result = numObrigacao + '.0'
                hAPI.setCardValue('num_obrigacao', result)
                hAPI.setCardValue("numObligationPresConta", result);

                if(cTipo_Pago == '081'){
                    
                    log.info(' ===> service task 15 - ObjPresConta c tipo pago == 81')
                    log.dir(cTipo_Pago)

                    // teste carregar imposto e verificar validação de Boleto
                    // imposto
                    var type = '7';
                    var nValorLiquidobrig = '';

                    retTaxas(result,type, campoTipoPresConta);
                    nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoPresConta);
                    // valida boleto
                    var objBol = {
                        cIdSolicitacao: cIdSolicitacao.toString(),
                        cCodUsr: cCodUsr,
                        cTipo_Pago: cTipo_Pago,
                        cLinhaDigit: cLinhaDigit,
                        nNumOblig: result,
                        cNumDoctoBanco: cNumDoctoBanco,
                        cDataVencimento: cDataVencimento,
                        nValorLiquidobrig: nValorLiquidobrig                
                    }

                    log.info(' ===> service task 15 - ObjBolPresConta validaBoleto')
                    log.dir(objBol)

                    var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
            
                    log.info("Retorno do boleto teste de movimentação");
                    log.dir(retornoBoleto);
                    if(retornoBoleto == "false"){
                        log.info(' ===> finaliza validação de boleto teste OK');
                    }
                    if(retornoBoleto == "true"){
                        log.info(' ===> finaliza validação de boleto teste Nao é válido');
                    }

                }
            }
        }
        //Adicionando melhorias do chamado 1854726
        
        if(campoTipoCosseguro != "") { //chamado 1854726
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo.toString();
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_8'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_8')));


            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF8");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP';
            var nValorObrigacao = hAPI.getCardValue('valorCosseguro');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_8");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_8")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_8")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.info(' ===> Service Task 15 - Obj COA')
            log.dir(obj)

            var listarobrigacoes = hAPI.getCardValue('listarobrigacoes');
            var statusobrigacao = hAPI.getCardValue('statusoblig');
            var numObrigacao;

            if(listarobrigacoes == "true" && statusobrigacao == "ACT"){
                log.info("Entrou no if do atribui obrigacao Cosseguro");
                log.dir(cIdSolicitacao);
                numObrigacao = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
                log.dir(numObrigacao);
                atribuiSolicObrigacao(numObrigacao, cIdSolicitacao);
                hAPI.setCardValue('ativboletovalido', 'false');
            }else{
                numObrigacao = gravaObrigacao(obj, true)

                if (numObrigacao == undefined) {
                    throw "Erro na execução do Webservice"
                }
            
                if (numObrigacao != "ERRO VALIDA BOLETO"){

                    var campos = hAPI.getCardData(processo);
                    var contador = campos.keySet().iterator();
                    gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                    while (contador.hasNext()) {
                        var id = contador.next();

                        if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                            var seq = id.split("___")[1];
                            var valor = hAPI.getCardValue('valorRateio___' + seq);
                            var cClaFluxo = ""; //novo serviço
                            var cNatCPTOEgre = ""; //novo serviço
                            var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                            var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                            gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                        }
                    }

                    gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                    var result = numObrigacao + '.0'
                    hAPI.setCardValue('num_obrigacao', result)
                    hAPI.setCardValue("numObligationCosseguro", result);

                    if(cTipo_Pago == '081'){
                    
                        log.info(' ===> service task 15 - ObjCosseguro c tipo pago == 81')
                        log.dir(cTipo_Pago)
        
                        // teste carregar imposto e verificar validação de Boleto
                        // imposto
                        var type = '5';
                        var nValorLiquidobrig = '';
        
                        retTaxas(result,type, campoTipoComissao);
                        nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoComissao);
                        // valida boleto
                        var objBol = {
                            cIdSolicitacao: cIdSolicitacao.toString(),
                            cCodUsr: cCodUsr,
                            cTipo_Pago: cTipo_Pago,
                            cLinhaDigit: cLinhaDigit,
                            nNumOblig: result,
                            cNumDoctoBanco: cNumDoctoBanco,
                            cDataVencimento: cDataVencimento,
                            nValorLiquidobrig: nValorLiquidobrig                
                        }
        
                        log.info(' ===> service task 15 - ObjBolCosseguro validaBoleto')
                        log.dir(objBol)
        
                        var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
                
                        log.info("Retorno do boleto teste de movimentação");
                        log.dir(retornoBoleto);
                        if(retornoBoleto == "false"){
                            log.info(' ===> finaliza validação de boleto teste OK');
                        }
                        if(retornoBoleto == "true"){
                            log.info(' ===> finaliza validação de boleto teste Nao é válido');
                        }
        
                    }
                }
            }
        } 
           
        if(campoTipoFranquia != "") { //chamado 1854726
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo.toString();
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_9'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_9')));


            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF9");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP';
            var nValorObrigacao = hAPI.getCardValue('valorDevFranquia');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_9");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_9")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_9")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.info(' ===> Service Task 15 - Obj DSF')
            log.dir(obj)

            var listarobrigacoes = hAPI.getCardValue('listarobrigacoes');
            var statusobrigacao = hAPI.getCardValue('statusoblig');
            var numObrigacao;

            if(listarobrigacoes == "true" && statusobrigacao == "ACT"){
                log.info("Entrou no if do atribui obrigacao Franquia");
                log.dir(cIdSolicitacao);
                numObrigacao = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
                log.dir(numObrigacao);
                atribuiSolicObrigacao(numObrigacao, cIdSolicitacao);
                hAPI.setCardValue('ativboletovalido', 'false');
            }else{
                numObrigacao = gravaObrigacao(obj, true)

                if (numObrigacao == undefined) {
                    throw "Erro na execução do Webservice"
                }
            
                if (numObrigacao != "ERRO VALIDA BOLETO"){

                    var campos = hAPI.getCardData(processo);
                    var contador = campos.keySet().iterator();
                    gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                    while (contador.hasNext()) {
                        var id = contador.next();

                        if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                            var seq = id.split("___")[1];
                            var valor = hAPI.getCardValue('valorRateio___' + seq);
                            var cClaFluxo = ""; //novo serviço
                            var cNatCPTOEgre = ""; //novo serviço
                            var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                            var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                            gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                        }
                    }

                    gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                    var result = numObrigacao + '.0'
                    hAPI.setCardValue('num_obrigacao', result)
                    hAPI.setCardValue("numObligationDevFranquia", result);

                    if(cTipo_Pago == '081'){
                    
                        log.info(' ===> service task 15 - ObjFranquia c tipo pago == 81')
                        log.dir(cTipo_Pago)
        
                        // teste carregar imposto e verificar validação de Boleto
                        // imposto
                        var type = '5';
                        var nValorLiquidobrig = '';
        
                        retTaxas(result,type, campoTipoComissao);
                        nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoComissao);
                        // valida boleto
                        var objBol = {
                            cIdSolicitacao: cIdSolicitacao.toString(),
                            cCodUsr: cCodUsr,
                            cTipo_Pago: cTipo_Pago,
                            cLinhaDigit: cLinhaDigit,
                            nNumOblig: result,
                            cNumDoctoBanco: cNumDoctoBanco,
                            cDataVencimento: cDataVencimento,
                            nValorLiquidobrig: nValorLiquidobrig                
                        }
        
                        log.info(' ===> service task 15 - ObjBolFranquia validaBoleto')
                        log.dir(objBol)
        
                        var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
                
                        log.info("Retorno do boleto teste de movimentação");
                        log.dir(retornoBoleto);
                        if(retornoBoleto == "false"){
                            log.info(' ===> finaliza validação de boleto teste OK');
                        }
                        if(retornoBoleto == "true"){
                            log.info(' ===> finaliza validação de boleto teste Nao é válido');
                        }
        
                    }
                }
            }
        }
        
        if(campoTipoApolice != "") { //chamado 1854726
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = processo.toString();
            var cTipoOblig = hAPI.getCardValue("tipoObrigacao");
            var respFormPag = verifyCpfCnpj(hAPI.getCardValue('fornecedorHidden'));
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(hAPI.getCardValue('dataAbertura'));
            var cDataVencimento = returnData(hAPI.getCardValue('dataVencimento_10'));

            hAPI.setCardValue('h_dataVencimento', formatData(hAPI.getCardValue('dataVencimento_10')));


            var cHistorico = hAPI.getCardValue("historico");
            var notaFiscal = hAPI.getCardValue("numeroNF10");
            var cNumDocto = notaFiscal;
            var cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            var cCodEstado = 'SP';
            var nValorObrigacao = hAPI.getCardValue('valorDespesaApolice');
            nValorObrigacao = nValorObrigacao.replace('.','');
            var cCodUsr = 'ACSEL';
            var contaContabil = hAPI.getCardValue('codPolitica');
            var grupoConceito = hAPI.getCardValue('idGrupoCont');
            var cEmiteCheque = "S";
            var cCodWorkflow = "F";
            var cTipo_Pago = hAPI.getCardValue("formaPagamentohidden_10");
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                var gson = new com.google.gson.Gson();
                var objTipoPago = retornaTipoPago(cChaveAutent, cTipoId, cNumid.replaceAll(' ', ''), cDvid, cCodWorkflow);
                objTipoPago = JSON.parse(gson.toJson(objTipoPago));
                cTipo_Pago = objTipoPago[0]["tipopago"];
                cCodEntFinan = objTipoPago[0]["codentfinan"];
                cAgencia = objTipoPago[0]["agencia"];
                cDVAgencia = objTipoPago[0]["dvagencia"];
                cCuentaCor = objTipoPago[0]["cuentacor"];
                cDVCuentaCor = objTipoPago[0]["dvcuentacor"];
                cTipo_Conta = objTipoPago[0]["tipoconta"];

            } else if (cTipo_Pago == '081') {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_10")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                cNumDoctoBanco = hAPI.getCardValue("codBarras_10")
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }

            log.info(' ===> Service Task 15 - Obj DSA')
            log.dir(obj)

            var listarobrigacoes = hAPI.getCardValue('listarobrigacoes');
            var statusobrigacao = hAPI.getCardValue('statusoblig');
            var numObrigacao;

            if(listarobrigacoes == "true" && statusobrigacao == "ACT"){
                log.info("Entrou no if do atribui obrigacao Franquia");
                log.dir(cIdSolicitacao);
                numObrigacao = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
                log.dir(numObrigacao);
                atribuiSolicObrigacao(numObrigacao, cIdSolicitacao);
                hAPI.setCardValue('ativboletovalido', 'false');
            }else{
                numObrigacao = gravaObrigacao(obj, true)

                if (numObrigacao == undefined) {
                    throw "Erro na execução do Webservice"
                }
            
                if (numObrigacao != "ERRO VALIDA BOLETO"){

                    var campos = hAPI.getCardData(processo);
                    var contador = campos.keySet().iterator();
                    gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, obj.nValorObrigacao, "", "", cCodWorkflow, true);

                    while (contador.hasNext()) {
                        var id = contador.next();

                        if (id.toLowerCase().indexOf('idcencusresprateio___') > -1) {
                            var seq = id.split("___")[1];
                            var valor = hAPI.getCardValue('valorRateio___' + seq);
                            var cClaFluxo = ""; //novo serviço
                            var cNatCPTOEgre = ""; //novo serviço
                            var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao)) * 100
                            var centroCusto = hAPI.getCardValue("idCenCusRespRateio___" + seq);
                            gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                        }
                    }

                    gravaNotaFiscal(obj.cChaveAutent, numObrigacao, notaFiscal, obj.nValorObrigacao, cCodWorkflow, true);
                    var result = numObrigacao + '.0'
                    hAPI.setCardValue('num_obrigacao', result)
                    hAPI.setCardValue("numObligationDesApolice", result); // melhoria COA - DSA

                    if(cTipo_Pago == '081'){
                    
                        log.info(' ===> service task 15 - ObjApolice c tipo pago == 81')
                        log.dir(cTipo_Pago)
        
                        // teste carregar imposto e verificar validação de Boleto
                        // imposto
                        var type = '5';
                        var nValorLiquidobrig = '';
        
                        retTaxas(result,type, campoTipoComissao);
                        nValorLiquidobrig = setTaxas(nValorObrigacao, type, campoTipoComissao);
                        // valida boleto
                        var objBol = {
                            cIdSolicitacao: cIdSolicitacao.toString(),
                            cCodUsr: cCodUsr,
                            cTipo_Pago: cTipo_Pago,
                            cLinhaDigit: cLinhaDigit,
                            nNumOblig: result,
                            cNumDoctoBanco: cNumDoctoBanco,
                            cDataVencimento: cDataVencimento,
                            nValorLiquidobrig: nValorLiquidobrig                
                        }
        
                        log.info(' ===> service task 15 - ObjBolApolice validaBoleto')
                        log.dir(objBol)
        
                        var retornoBoleto = retornaValidaBoleto(objBol.cIdSolicitacao, objBol.cCodUsr, objBol.cTipo_Pago, objBol.cLinhaDigit, objBol.nNumOblig, objBol.cNumDoctoBanco, objBol.cDataVencimento, objBol.nValorLiquidobrig );
                
                        log.info("Retorno do boleto teste de movimentação");
                        log.dir(retornoBoleto);
                        if(retornoBoleto == "false"){
                            log.info(' ===> finaliza validação de boleto teste OK');
                        }
                        if(retornoBoleto == "true"){
                            log.info(' ===> finaliza validação de boleto teste Nao é válido');
                        }
        
                    }
                }
            }
        }
        //Adicionando melhorias do chamado 
    }
}

function returnData(data) {
    log.info("Data Vencimento ==> " + data);
    if (data.indexOf('/') > -1) {
        var newData = data.split('/')
        var newString = "" + newData[2] + newData[1] + newData[0] + ""
    } else {
        var newData = data.split('-')
        var newString = "" + newData[0] + newData[1] + newData[2] + ""
    }
    log.info("Return Data ==> " + data);
    return newString
}

function formatData(data) {
    log.info("Data Vencimento - formatData==> " + data);
    if (data.indexOf('/') <= -1) {
        var newData = data.split('-')
        var newString = "" + newData[2] + '/' + newData[1]  + '/' + newData[0] + ""
    }

    log.info("Return Data - formatData ==> " + data);
    return newString
}

function realToNumber(numero) {
    log.info(' ===> Entrou no Real to number: ');
    log.dir(numero);
    var result = '';
    if(numero.indexOf('-') > -1){
        log.info(' ===> Entrou no indexof 0: ');
        numero = numero.substring(1);
        log.dir(numero);
        result = parseFloat((numero + "").replace(/\./g, '').replace(',', '.'));
        result = result * -1;
    }else if(numero.indexOf('-') < 0){
        log.info(' ===> Entrou no indexof -1: ');
        result = parseFloat((numero + "").replace(/\./g, '').replace(',', '.'));
    }
    
    // var result = numero
    log.info(' ===> Result real to number: ');
    log.dir(result);
    return result
}

function verifyCpfCnpj(cpfCnpj) {
    // if (cpfCnpj.length() == 14) {
    //     return 'CPF'
    // } else {
    //     return 'CNPJ'
    // }
    
    return DatasetFactory.getDataset("ds_forma_pagamento", null, [ DatasetFactory.createConstraint('cnpj', cpfCnpj, cpfCnpj, ConstraintType.MUST) ], null);
}

function atribuiSolicObrigacao(obrig, idSolic){
    log.info('===========> Entrou no atribui solicitacao a obrigacao ================');
    log.dir(obrig);
    log.dir(idSolic);

    var retornoAttrSolic = DatasetFactory.getDataset("ds_atribui_solic_obrig",
                                null, 
                                [
                                    DatasetFactory.createConstraint('nIdSolicitacao', idSolic, idSolic, ConstraintType.MUST), 
                                    DatasetFactory.createConstraint('nNumOblig', obrig, obrig, ConstraintType.MUST) 
                                ], 
                                null
                            );
    log.info(' ===> Retorno do dataset WS atribui solicitacao a obrigacao -------  ');
    log.dir(retornoAttrSolic);

    if (retornoAttrSolic.getValue(0, 'retorno') != 0 ) {
        log.info(' ===> Retorno do Attr solic | Webservice Error -------  ')
       
        throw 'Erro para Atribuir Obrigação a uma Solicitação: webservice retornou o valor ' + retornoAttrSolic.getValue(0, 'retorno') + " - " + retornoAttrSolic.getValue(0, 'descricaoErro') + "."
    }
}

function gravaObrigacao(obj, restart) {
    log.info('=========> Entrou no para gravar obrigacao ==============');
    log.dir(obj);

    var properties = {};
    properties["receive.timeout"] = "100000000";
    var supplierService = ServiceManager.getService('Acsel_7');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);

    var RetornoGravaObrigacao = customClient.gravaObrigacao(obj.cChaveAutent, obj.cIdSolicitacao, obj.cTipoOblig, obj.cTipoId,
        obj.cNumid, obj.cDvid, obj.cDataEmissao, obj.cDataVencimento, obj.cHistorico, obj.cNumDocto, obj.cCentroCusto, obj.cCodEstado,
        realToNumber(obj.nValorObrigacao), obj.cCodUsr, obj.cEmiteCheque, obj.cTipo_Pago, obj.cCodEntFinan, obj.cAgencia, obj.cDVAgencia, obj.cCuentaCor,
        obj.cDVCuentaCor, obj.cTipo_Conta, obj.cLinhaDigit, obj.cNumDoctoBanco, obj.cCodWorkflow);
    log.info(' ===>  Retorno do WS Grava Obrigação -------  ')
    log.dir(RetornoGravaObrigacao)
    if(RetornoGravaObrigacao.getRetorno() == "99"){
        if((RetornoGravaObrigacao.getDescricaoErro()).indexOf('Vencimento digitado') > -1 || (RetornoGravaObrigacao.getDescricaoErro()).indexOf('O valor do boleto bancário') > -1){
            log.info(' ===>  Retorno do valida boleto no Grava Obrigacao| Webservice Error -------  ');

            hAPI.setCardValue('boletovalido', RetornoGravaObrigacao.getDescricaoErro());
            hAPI.setCardValue('ativboletovalido', 'true');
            return "ERRO VALIDA BOLETO";
        }
    }
    if (RetornoGravaObrigacao.getNUMOBRIGACAO() == undefined) {
        log.info(' ===>  NumObrigação = Undefined | Webservice Error -------  ')
        log.dir(RetornoGravaObrigacao)
        if (restart) {
            obj.nValorObrigacao = (obj.nValorObrigacao + "").replace(".", ",");
            gravaObrigacao(obj, false);
        }
        else{
            throw 'Erro Grava Obrigação: webservice retornou o valor ' + RetornoGravaObrigacao.getRetorno() + " - " + RetornoGravaObrigacao.getDescricaoErro() + "."
        }
    }

    return RetornoGravaObrigacao.getNUMOBRIGACAO();
}

function gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow, restart) {
    log.info('==========> Entrou no para gravar detalhes obrigacao ===============');
    log.dir({
        'aut': aut,
        'obrig': obrig,
        'cDesp': cDesp,
        'typeDesp': typeDesp,
        'val': val,
        'cClaFluxo': cClaFluxo,
        'cNatCPTOEgre': cNatCPTOEgre,
        'cCodWorkflow': cCodWorkflow,
        'restart': restart
    });

    var properties = {};
    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel_7');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
    try {
        var RetornoGravaDetalheObrigacao = customClient.gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow);
        log.info(' ===>  service task 15 - retorno grava detalhe@@@@@')
        log.dir(RetornoGravaDetalheObrigacao)
    } catch (e) {
        throw e.toString()
    }

    if (RetornoGravaDetalheObrigacao.getRetorno() != 0) {
        if (restart) {
            log.info(' ===>  Erro Grava Detalhe Obrigação: webservice retornou o valor ' + RetornoGravaDetalheObrigacao.getRetorno() + " - " + RetornoGravaDetalheObrigacao.getDescricaoErro() + ".")
            val = (val + "").replace(",", ".");
            gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow, false);
        }
        throw 'Erro Grava Detalhe Obrigação: webservice retornou o valor ' + RetornoGravaDetalheObrigacao.getRetorno() + " - " + RetornoGravaDetalheObrigacao.getDescricaoErro() + "."
    }

}

function gravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow, restart) {
    log.info('=========> Entrou no para gravar o centro de custo ==============');
    log.dir({
        'Autenticacao': autenticacao,
        'numObrig': numObrig,
        'centroCusto': centroCusto,
        'montante': montante,
        'porcentagem': porcentagem,
        'cCodWorkflow': cCodWorkflow,
        'restart': restart
    });

    var properties = {};
    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel_7');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
    try {
        var Retorno = customClient.gravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow);
        log.info(' ===> service task - retorno centro custo FSN')
        log.dir(Retorno)
    } catch (e) {
        log.info(' ===>  Dentro do cacth grava centro de custo')
        log.dir(e.toString())
        throw e.toString()
        
    }
    if (Retorno.getRetorno() != "0") {
        if (restart) {
            montante = (montante + "").replace(".", ",");
            gravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow, false);
        }
        throw 'Erro grava centro de custo: webservice retornou o valor ' + Retorno.getRetorno() + " - " + Retorno.getDescricaoErro() + "."
    }
}

function gravaNotaFiscal(autenticacao, numOblig, cNumNF, nValorNF, cCodWorkflow, restart) {
    log.info(' ===========> Entrou no para gravar nota fiscal================');
    log.dir({
        'Autenticacao': autenticacao,
        'numOblig': numOblig,
        'cNumNF': cNumNF,
        'nValorNF': nValorNF,
        'cCodWorkflow': cCodWorkflow,
        'restart': restart,
    });

    var properties = {};

    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel_7');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
    try {
        var Retorno = customClient.gravaNF(autenticacao, numOblig, cNumNF, nValorNF.replace(',','.'), '', cCodWorkflow);
        log.info(' ===>  service task 15 - retorno grava NF######')
        log.dir(Retorno)
    } catch (e) {
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        if (restart) {
            nValorNF = (nValorNF + "").replace(",", ".");
            gravaNotaFiscal(autenticacao, numOblig, cNumNF, nValorNF, cCodWorkflow, false);
        }
        throw 'Erro Grava Detalhe Obrigação: webservice retornou o valor ' + Retorno.getRetorno() + " - " + Retorno.getDescricaoErro() + "."
    }

}

function retornaTipoPago(cChaveAutent, cTipoId, cNumId, cDvid, cCodWorkflow) {

    var properties = {};

    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel_7');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
    try {
        var Retorno = customClient.retornaTipoPago(cChaveAutent, cTipoId, cNumId, cDvid, cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (!Retorno.getTipoPagoList()) {
        throw 'Erro: Usuário não possui método de pagamento'
    } else {
        return Retorno.getTipoPagoList().getTipoPago();
    }
}

function retornaValidaBoleto(cIdSolicitacao, cCodUsr, cTipoPago, cLinhaDigit, nNumOblig, cNumDoctoBanco, cDataVencimento, nValorObrigacao){
    log.info(' ===========> Entrou no valida boleto ================');
    log.dir(cIdSolicitacao);
    log.dir(cCodUsr);
    log.dir(cTipoPago);
    log.dir(cLinhaDigit);
    log.dir(nNumOblig);
    log.dir(cNumDoctoBanco);
    log.dir(cDataVencimento);
    log.dir(nValorObrigacao);

    try {
        var retornoDsValidaBoleto = DatasetFactory.getDataset("ds_validaCodigoBarras_2",
                                null, 
                                [
                                    DatasetFactory.createConstraint('cIdSolicitacao', cIdSolicitacao, cIdSolicitacao, ConstraintType.MUST), 
                                    DatasetFactory.createConstraint('cCodUsr', cCodUsr, cCodUsr, ConstraintType.MUST),
                                    DatasetFactory.createConstraint('cTipoPago', cTipoPago, cTipoPago, ConstraintType.MUST),
                                    DatasetFactory.createConstraint('cLinhaDigit', cLinhaDigit, cLinhaDigit, ConstraintType.MUST),
                                    DatasetFactory.createConstraint('nNumOblig', nNumOblig, nNumOblig, ConstraintType.MUST),
                                    DatasetFactory.createConstraint('cNumDoctoBanco', cNumDoctoBanco, cNumDoctoBanco, ConstraintType.MUST),
                                    DatasetFactory.createConstraint('cDataVencimento', cDataVencimento, cDataVencimento, ConstraintType.MUST),
                                    DatasetFactory.createConstraint('nValorObrigacao', realToNumber(nValorObrigacao), realToNumber(nValorObrigacao), ConstraintType.MUST)
                                ], 
                                null
                            );
        log.info(' ===> Retorno do dataset WS valida boleto try-------  ');
        log.dir(retornoDsValidaBoleto);
    } catch (error) {
        log.info(' ===> Retorno do dataset WS valida boleto catch-------  ');
        log.dir(error);
        throw error
    }
    
    if (retornoDsValidaBoleto.getValue(0, 'RETORNO') != 0 ) {
        log.info(' ===> Retorno do valida boleto | Webservice Error -------  ');

        hAPI.setCardValue('boletovalido', retornoDsValidaBoleto.getValue(0, 'DESCRICAO'));
        hAPI.setCardValue('ativboletovalido', 'true');
        return 'true';
    }
    if (retornoDsValidaBoleto.getValue(0, 'RETORNO') == 0 ) {
        log.info(' ===> Retorno do valida boleto | Webservice Success -------  ');
        
        hAPI.setCardValue('boletovalido', 'VALIDO');
        hAPI.setCardValue('ativboletovalido', 'false');
        return 'false';
    }

}

function retTaxas(obrigacao,type, campoTipo){
    log.info('===========> Entrou no valida boleto ================');
    log.dir(obrigacao);
    log.dir(type);
    log.dir(campoTipo);

    hAPI.setCardValue('valor_ir' + type, '');
    hAPI.setCardValue('valor_iss' + type, '');
    hAPI.setCardValue('valor_csrf' + type, '');
    hAPI.setCardValue('valor_inss' + type, '');

    var retornoDsGetImpostos = DatasetFactory.getDataset("ds_get_impostos",
                                null, 
                                [
                                    DatasetFactory.createConstraint('obligacion', obrigacao, obrigacao, ConstraintType.MUST)
                                ], 
                                null
                            );
    log.info(' ===> Retorno do dataset WS get impostos -------  ');
    log.dir(retornoDsGetImpostos);
    // var ds = retornoDsGetImpostos.values;
    for (var i = 0; i < retornoDsGetImpostos.rowsCount; i++) {
    
        var taxValue = 0;
        var regexIR = 'IR';
        var regexISS = 'ISS';
        var regexRT = 'RT';
        var regexINSS = 'INS';

        log.info(' ===> Verificando retorno do ds:  ');
        log.dir(retornoDsGetImpostos['map']);
        log.dir(retornoDsGetImpostos['values'][i]);
        log.dir(retornoDsGetImpostos.getValue(i,'MTODETOBLIGLOCAL'));
        var mtoOblig = retornoDsGetImpostos.getValue(i,'MTODETOBLIGLOCAL');
        log.info(' ===> Retorno mtoOblig:  ');
        log.dir(mtoOblig);
        if (mtoOblig) {
            mtoOblig = Number(mtoOblig);
            taxValue = (mtoOblig * -1);
        }
        var codcpto = retornoDsGetImpostos.getValue(i,'CODCPTOEGRE');
        log.info(' ===> Retorno typeI:  ');
        log.dir(codcpto);

        if (codcpto.indexOf(regexIR) > -1) {
            hAPI.setCardValue('valor_ir' + type, "-" + numberToReal(taxValue));
        } else if (codcpto.indexOf(regexISS) > -1) {
            hAPI.setCardValue('valor_iss' + type, "-" + numberToReal(taxValue));
        } else if (codcpto.indexOf(regexRT) > -1) {
            hAPI.setCardValue('valor_csrf' + type, "-" + numberToReal(taxValue));
        } else if (codcpto.indexOf(regexINSS) > -1) {
            hAPI.setCardValue('valor_inss' + type, "-" + numberToReal(taxValue));
        }
    }
    log.info(' ===> get impostos inseridos no form -------  ');
    log.dir(hAPI.getCardValue('valor_ir' + type));
    log.dir(hAPI.getCardValue('valor_iss' + type));
    log.dir(hAPI.getCardValue('valor_csrf' + type));
    log.dir(hAPI.getCardValue('valor_inss' + type));
    
}

function setTaxas(valorTotal, type, campoTipo){
    var valorT = realToNumber(valorTotal);
    var impIR = "0";
    var impISS = "0";
    var impCSRF = "0";
    var impINSS = "0";
    if(hAPI.getCardValue('valor_ir' + type)){
        impIR = hAPI.getCardValue('valor_ir' + type);
        if(impIR == ""){
            impIR = "0";
        }
    }
    if(impISS = hAPI.getCardValue('valor_iss' + type)){
        impISS = hAPI.getCardValue('valor_iss' + type);
        if(impISS == ""){
            impISS = "0";
        }
    }
    if(impCSRF = hAPI.getCardValue('valor_csrf' + type)){
        impCSRF = hAPI.getCardValue('valor_csrf' + type);
        if(impCSRF == ""){
            impCSRF = "0";
        }
    }
    if(impINSS = hAPI.getCardValue('valor_inss' + type)){
        impINSS = hAPI.getCardValue('valor_inss' + type);
        if(impINSS == ""){
            impINSS = "0";
        }
    }

    log.info(' ===> set impostos inseridos no form -------  ');
    log.dir(valorT);
    log.dir(impIR);
    log.dir(impISS);
    log.dir(impCSRF);
    log.dir(impINSS);


    var taxSum = (realToNumber(impIR)) + (realToNumber(impISS)) + (realToNumber(impCSRF)) + (realToNumber(impINSS));
    log.info(' ===> set impostos soma impostos -------  ');
    log.dir(valorT);
    log.dir(taxSum);
    var valorLiq = valorT + taxSum;
    log.info(' ===> set impostos result valor liquido -------  ');
    log.dir(valorLiq);
    var valorLiqGeral = '';
    if(type == '1'){
        valorLiqGeral = 'valorLiqAdiantamento';
    }
    if(type == '2'){
        valorLiqGeral = 'valorLiqDespesa';
    }
    if(type == '3'){
        valorLiqGeral = 'valorLiqRH';
    }
    if(type == '4'){
        valorLiqGeral = 'valorLiqOuvidoria';
    }
    if(type == '5'){
        valorLiqGeral = 'valorLiqComissao';
    }
    if(type == '6'){
        valorLiqGeral = 'valorLiqImposto';
    }
    if(type == '7'){
        valorLiqGeral = 'valorLiqPresConta';
    }
    hAPI.setCardValue(valorLiqGeral, numberToReal(valorLiq));
    
    return numberToReal(valorLiq);
}

function numberToReal(numero) {
    var result = '';
    log.info(' ===> Number To Real:  ');
    log.dir(numero);
    numero = numero.toFixed(2);
    var prov = numero.replace('.', ',');
    log.info(' ===> Number string:  ');
    log.dir(prov);
    result = prov;
    log.info(' ===> return Number string:  ');
    log.dir(result);
    return result
}