function beforeTaskComplete(colleagueId,nextSequenceId,userList){
    var atividadeAtual = hAPI.getCardValue('stateAtual')
}