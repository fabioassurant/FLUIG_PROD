function servicetask65(attempt, message) {
    var num = (hAPI.getCardValue("num_obrigacao")).replace(".0", "");
    var autenticacao = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
    var cCodWorkflow = "F";
    var listarobrigacoes = hAPI.getCardValue('listarobrigacoes');
    var properties = {};
    properties["receive.timeout"] = "100000000";

    log.info(" Entrou no ativa e atualiza  obrigação");
    log.dir(listarobrigacoes);

    if(listarobrigacoes == "true"){
        log.info('######## atualiza obrigação COM LIM');
        updateOblig();
        log.info('######## Finalizou atualiza libera obrigação COM LIM');
    }

    if(listarobrigacoes == "false"){
        log.info('properties');
        log.dir(properties);
        log.info('Finaliza Ativar obrigação');
        log.dir(num);

        var supplierService = ServiceManager.getService('Acsel_7');
        var serviceHelper = supplierService.getBean();
        var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
        var service = serviceLocator.getServicosWebServicePort();
        var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
        try {
            var Retorno = customClient.finalizaObrigacao(autenticacao, num, 'S', cCodWorkflow);
        } catch (e) {
            throw e.toString()
        }
    
        if (Retorno.getRetorno() != 0) {
            throw 'Erro: webservice retornou o valor ' + Retorno.getRetorno() + " - " + Retorno.getDescricaoErro() + "."
        }
        // return true;
    }
}

function finalizaObrigacao(autenticacao, num, cCodWorkflow) {
    var properties = {};
    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel_7');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
    try {
        var Retorno = customClient.finalizaObrigacao(autenticacao, num, 'S', cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        throw 'Erro: webservice retornou o valor ' + Retorno.getRetorno() + " - " + Retorno.getDescricaoErro() + "."
    }
}

function updateOblig(){
    log.info('============== Entrou no atualiza obrigacao ================');
    
    var processo = getValue("WKNumProces");
    var tipoAcerto = hAPI.getCardValue('tipoAcerto');

    // variaveis constraint
    var nNumOblig               = "";
    var cNumNF                  = "";
    var cOpcaoPAG               = "";
    var cTextoOblig             = "";
    var nMtoBrutoObligLocal     = "";
    var cMesAnoRef              = "";
    var nCodTributo             = "";
    var cLinhaDigit             = "";
    var cFecGTiaPago            = "";
    var cCodEstadoDPVAT         = "";
    var cCompINSS               = "";
    var cTipoPago              = "";
    var nNumParcela             = "";
    var cTipoSerieNF            = "";
    var cPerApuracao            = "";
    var cCodMunicGARE           = "";
    var cPlaca                  = "";
    var nCodMunicDPVAT          = "";
    var nCodPagINSS             = "";
    var nCodPagRec              = "";
    var cCentroCusto            = "";
    var nExercicio              = "";
    var nNumEtiqueta            = "";
    var nRenavam                = "";
    var cHistorico              = "";
    var nMtoNetoObligLocal      = "";
    var nValorBoleto            = "";

    //Teste NumDocto
    var cNumDocto               = "";

    if (tipoAcerto) {
        var campoTipoComissao = hAPI.getCardValue('tipoAcertoHidden_5')
        var campoTipoImposto = hAPI.getCardValue('tipoAcertoHidden_6')
        var campoTipoCosseguro = hAPI.getCardValue('tipoAcertoHidden_8')
        var campoTipoFranquia = hAPI.getCardValue('tipoAcertoHidden_9')
        var campoTipoApolice = hAPI.getCardValue('tipoAcertoHidden_10')

        if (campoTipoComissao != "") {
            nNumOblig = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
            cNumNF = hAPI.getCardValue('numeroNF5');
            cNumDocto = hAPI.getCardValue('numeroNF5');
            nMtoBrutoObligLocal = hAPI.getCardValue('valorComissao');
            nMtoBrutoObligLocal = nMtoBrutoObligLocal.replace('.','');
            nMtoNetoObligLocal = hAPI.getCardValue('valorLiqComissao');
            nMtoNetoObligLocal = nMtoNetoObligLocal.replace('.','');
            cFecGTiaPago = returnData(hAPI.getCardValue('dataVencimento_5'));
            cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            cTipoPago = hAPI.getCardValue("formaPagamentohidden_5");
            cHistorico = hAPI.getCardValue("historico");
            cOpcaoPAG = "";
            cTextoOblig = "";
            cMesAnoRef = "";
            nCodTributo = "";
            cCodEstadoDPVAT = "";
            cCompINSS = "";
            nNumParcela = "";
            cTipoSerieNF = "";
            cPerApuracao = "";
            cCodMunicGARE = "";
            cPlaca = "";
            nCodMunicDPVAT = "";
            nCodPagINSS = "";
            nCodPagRec = "";
            nExercicio = "";
            nNumEtiqueta = "";
            nRenavam = "";
            cCodWorkFlow = "F";
            if(cTipoPago == "071" || cTipoPago == "073"){
                nValorBoleto = "";
                cLinhaDigit = "";
            }
            if(cTipoPago == "081" || cTipoPago == "091"){
                // nValorBoleto = hAPI.getCardValue("valorComissao");
                // cLinhaDigit = hAPI.getCardValue("codBarras_5");
                 //Enviar vazio conforme alinhado com a Delphos
                 nValorBoleto = "";
                 cLinhaDigit = "";
            }
        }

        if (campoTipoImposto != "") {
            nNumOblig = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
            cNumNF = hAPI.getCardValue('numeroNF6');
            cNumDocto = hAPI.getCardValue('numeroNF6');
            nMtoBrutoObligLocal = hAPI.getCardValue('valorImposto');
            nMtoBrutoObligLocal = nMtoBrutoObligLocal.replace('.','');
            nMtoNetoObligLocal = hAPI.getCardValue('valorLiqImposto');
            nMtoNetoObligLocal = nMtoNetoObligLocal.replace('.','');
            cFecGTiaPago = returnData(hAPI.getCardValue('dataVencimento_6'));
            cCentroCusto = hAPI.getCardValue('idCenCusSolic');
            cTipoPago = hAPI.getCardValue("formaPagamentohidden_6");
            cHistorico = hAPI.getCardValue("historico");
            cOpcaoPAG = "";
            cTextoOblig = "";
            cMesAnoRef = "";
            nCodTributo = "";
            cCodEstadoDPVAT = "";
            cCompINSS = "";
            nNumParcela = "";
            cTipoSerieNF = "";
            cPerApuracao = "";
            cCodMunicGARE = "";
            cPlaca = "";
            nCodMunicDPVAT = "";
            nCodPagINSS = "";
            nCodPagRec = "";
            nExercicio = "";
            nNumEtiqueta = "";
            nRenavam = "";
            cCodWorkFlow = "F";
            if(cTipoPago == "071" || cTipoPago == "073"){
                nValorBoleto = "";
                cLinhaDigit = "";
            }
            if(cTipoPago == "081" || cTipoPago == "091"){
                // nValorBoleto = hAPI.getCardValue("valorImposto");
                // cLinhaDigit = hAPI.getCardValue("codBarras_6");
                //Enviar vazio conforme alinhado com a Delphos
                nValorBoleto = "";
                cLinhaDigit = "";
            }
        }
        
        //Adicionando melhorias do chamado 1854726
        if (campoTipoCosseguro != "") {
	        nNumOblig = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
	        cNumNF = hAPI.getCardValue('numeroNF8');
	        cNumDocto = hAPI.getCardValue('numeroNF8');
	        nMtoBrutoObligLocal = hAPI.getCardValue('valorCosseguro');
	        nMtoBrutoObligLocal = nMtoBrutoObligLocal.replace('.','');
	        nMtoNetoObligLocal = hAPI.getCardValue('valorLiqCosseguro');
	        nMtoNetoObligLocal = nMtoNetoObligLocal.replace('.','');
	        cFecGTiaPago = returnData(hAPI.getCardValue('dataVencimento_8'));
	        cCentroCusto = hAPI.getCardValue('idCenCusSolic');
	        cTipoPago = hAPI.getCardValue("formaPagamentohidden_8");
	        cHistorico = hAPI.getCardValue("historico");
	        cOpcaoPAG = "";
	        cTextoOblig = "";
	        cMesAnoRef = "";
	        nCodTributo = "";
	        cCodEstadoDPVAT = "";
	        cCompINSS = "";
	        nNumParcela = "";
	        cTipoSerieNF = "";
	        cPerApuracao = "";
	        cCodMunicGARE = "";
	        cPlaca = "";
	        nCodMunicDPVAT = "";
	        nCodPagINSS = "";
	        nCodPagRec = "";
	        nExercicio = "";
	        nNumEtiqueta = "";
	        nRenavam = "";
	        cCodWorkFlow = "F";
	        if(cTipoPago == "071" || cTipoPago == "073"){
	            nValorBoleto = "";
	            cLinhaDigit = "";
	        }
	        if(cTipoPago == "081" || cTipoPago == "091"){
	            // nValorBoleto = hAPI.getCardValue("valorImposto");
	            // cLinhaDigit = hAPI.getCardValue("codBarras_6");
	            //Enviar vazio conforme alinhado com a Delphos
	            nValorBoleto = "";
	            cLinhaDigit = "";
	        }
    	}
    

		if (campoTipoFranquia != "") {
		    nNumOblig = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
		    cNumNF = hAPI.getCardValue('numeroNF9');
		    cNumDocto = hAPI.getCardValue('numeroNF9');
		    nMtoBrutoObligLocal = hAPI.getCardValue('valorDevFranquia');
		    nMtoBrutoObligLocal = nMtoBrutoObligLocal.replace('.','');
		    nMtoNetoObligLocal = hAPI.getCardValue('valorLiqDevFranquia');
		    nMtoNetoObligLocal = nMtoNetoObligLocal.replace('.','');
		    cFecGTiaPago = returnData(hAPI.getCardValue('dataVencimento_9'));
		    cCentroCusto = hAPI.getCardValue('idCenCusSolic');
		    cTipoPago = hAPI.getCardValue("formaPagamentohidden_9");
		    cHistorico = hAPI.getCardValue("historico");
		    cOpcaoPAG = "";
		    cTextoOblig = "";
		    cMesAnoRef = "";
		    nCodTributo = "";
		    cCodEstadoDPVAT = "";
		    cCompINSS = "";
		    nNumParcela = "";
		    cTipoSerieNF = "";
		    cPerApuracao = "";
		    cCodMunicGARE = "";
		    cPlaca = "";
		    nCodMunicDPVAT = "";
		    nCodPagINSS = "";
		    nCodPagRec = "";
		    nExercicio = "";
		    nNumEtiqueta = "";
		    nRenavam = "";
		    cCodWorkFlow = "F";
		    if(cTipoPago == "071" || cTipoPago == "073"){
		        nValorBoleto = "";
		        cLinhaDigit = "";
		    }
		    if(cTipoPago == "081" || cTipoPago == "091"){
		        // nValorBoleto = hAPI.getCardValue("valorImposto");
		        // cLinhaDigit = hAPI.getCardValue("codBarras_6");
		        //Enviar vazio conforme alinhado com a Delphos
		        nValorBoleto = "";
		        cLinhaDigit = "";
		    }
		}
		
		if (campoTipoApolice != "") {
		    nNumOblig = (hAPI.getCardValue('num_obrigacao')).replace(".0", "");
		    cNumNF = hAPI.getCardValue('numeroNF10');
		    cNumDocto = hAPI.getCardValue('numeroNF10');
		    nMtoBrutoObligLocal = hAPI.getCardValue('valorDespesaApolice');
		    nMtoBrutoObligLocal = nMtoBrutoObligLocal.replace('.','');
		    nMtoNetoObligLocal = hAPI.getCardValue('valorLiqDespesaApolice');
		    nMtoNetoObligLocal = nMtoNetoObligLocal.replace('.','');
		    cFecGTiaPago = returnData(hAPI.getCardValue('dataVencimento_10'));
		    cCentroCusto = hAPI.getCardValue('idCenCusSolic');
		    cTipoPago = hAPI.getCardValue("formaPagamentohidden_10");
		    cHistorico = hAPI.getCardValue("historico");
		    cOpcaoPAG = "";
		    cTextoOblig = "";
		    cMesAnoRef = "";
		    nCodTributo = "";
		    cCodEstadoDPVAT = "";
		    cCompINSS = "";
		    nNumParcela = "";
		    cTipoSerieNF = "";
		    cPerApuracao = "";
		    cCodMunicGARE = "";
		    cPlaca = "";
		    nCodMunicDPVAT = "";
		    nCodPagINSS = "";
		    nCodPagRec = "";
		    nExercicio = "";
		    nNumEtiqueta = "";
		    nRenavam = "";
		    cCodWorkFlow = "F";
		    if(cTipoPago == "071" || cTipoPago == "073"){
		        nValorBoleto = "";
		        cLinhaDigit = "";
		    }
		    if(cTipoPago == "081" || cTipoPago == "091"){
		        // nValorBoleto = hAPI.getCardValue("valorImposto");
		        // cLinhaDigit = hAPI.getCardValue("codBarras_6");
		        //Enviar vazio conforme alinhado com a Delphos
		        nValorBoleto = "";
		        cLinhaDigit = "";
		    }
		}
		
        //Adicionando melhorias do chamado 1854726
        
    }
    
    
    var c1 = DatasetFactory.createConstraint('nNumOblig', nNumOblig, nNumOblig, ConstraintType.MUST);
    var c2 = DatasetFactory.createConstraint('cNumNF', cNumNF, cNumNF, ConstraintType.MUST);
    var c3 = DatasetFactory.createConstraint('cOpcaoPAG', cOpcaoPAG, cOpcaoPAG, ConstraintType.MUST);
    var c4 = DatasetFactory.createConstraint('cTextoOblig', cTextoOblig, cTextoOblig, ConstraintType.MUST);
    var c5 = DatasetFactory.createConstraint('nMtoBrutoObligLocal', nMtoBrutoObligLocal, nMtoBrutoObligLocal, ConstraintType.MUST);
    var c6 = DatasetFactory.createConstraint('cMesAnoRef', cMesAnoRef, cMesAnoRef, ConstraintType.MUST);
    var c7 = DatasetFactory.createConstraint('nCodTributo', nCodTributo, nCodTributo, ConstraintType.MUST);
    var c8 = DatasetFactory.createConstraint('cLinhaDigit', cLinhaDigit, cLinhaDigit, ConstraintType.MUST);
    var c9 = DatasetFactory.createConstraint('cFecGTiaPago', cFecGTiaPago, cFecGTiaPago, ConstraintType.MUST);
    var c10 = DatasetFactory.createConstraint('cCodEstadoDPVAT', cCodEstadoDPVAT, cCodEstadoDPVAT, ConstraintType.MUST);
    var c11 = DatasetFactory.createConstraint('cCompINSS', cCompINSS, cCompINSS, ConstraintType.MUST);
    var c12 = DatasetFactory.createConstraint('cTipoPago', cTipoPago, cTipoPago, ConstraintType.MUST);
    var c13 = DatasetFactory.createConstraint('nNumParcela', nNumParcela, nNumParcela, ConstraintType.MUST);
    var c14 = DatasetFactory.createConstraint('cTipoSerieNF', cTipoSerieNF, cTipoSerieNF, ConstraintType.MUST);
    var c15 = DatasetFactory.createConstraint('cCodWorkFlow', cCodWorkFlow, cCodWorkFlow, ConstraintType.MUST);
    var c16 = DatasetFactory.createConstraint('cPerApuracao', cPerApuracao, cPerApuracao, ConstraintType.MUST);
    var c17 = DatasetFactory.createConstraint('cCodMunicGARE', cCodMunicGARE, cCodMunicGARE, ConstraintType.MUST);
    var c18 = DatasetFactory.createConstraint('cPlaca', cPlaca, cPlaca, ConstraintType.MUST);
    var c19 = DatasetFactory.createConstraint('nCodMunicDPVAT', nCodMunicDPVAT, nCodMunicDPVAT, ConstraintType.MUST);
    var c20 = DatasetFactory.createConstraint('nCodPagINSS', nCodPagINSS, nCodPagINSS, ConstraintType.MUST);
    var c21 = DatasetFactory.createConstraint('nCodPagRec', nCodPagRec, nCodPagRec, ConstraintType.MUST);
    var c22 = DatasetFactory.createConstraint('cCentroCusto', cCentroCusto, cCentroCusto, ConstraintType.MUST);
    var c23 = DatasetFactory.createConstraint('nExercicio', nExercicio, nExercicio, ConstraintType.MUST);
    var c24 = DatasetFactory.createConstraint('nNumEtiqueta', nNumEtiqueta, nNumEtiqueta, ConstraintType.MUST);
    var c25 = DatasetFactory.createConstraint('nRenavam', nRenavam, nRenavam, ConstraintType.MUST);
    var c26 = DatasetFactory.createConstraint('cHistorico', cHistorico, cHistorico, ConstraintType.MUST);
    var c27 = DatasetFactory.createConstraint('nMtoNetoObligLocal', nMtoNetoObligLocal, nMtoNetoObligLocal, ConstraintType.MUST);
    var c28 = DatasetFactory.createConstraint('nValorBoleto', nValorBoleto, nValorBoleto, ConstraintType.MUST);
    // teste cNumDocto
    var c29 = DatasetFactory.createConstraint('cNumDocto', cNumDocto, cNumDocto, ConstraintType.MUST);

    var retornoAttrSolic = DatasetFactory.getDataset("ds_atualiza_solic_obrig_6",
                                null, 
                                [
                                    c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22,c23,c24,c25,c26,c27,c28,c29
                                ], 
                                null
                            );
    log.info('Retorno do dataset WS  atualiza obrigacao -------  ');
    log.dir(retornoAttrSolic);

    if (retornoAttrSolic.getValue(0, 'retorno') != 0 ) {
        log.info('Retorno do  atualiza obrigacao | Webservice Error -------  ')
       
        throw 'Erro para Atualizar Obrigação '+ nNumOblig +'da Solicitação '+ processo +' : webservice retornou o valor ' + retornoAttrSolic.getValue(0, 'retorno') + " - " + retornoAttrSolic.getValue(0, 'descricaoErro') + "."
    }
}

function returnData(data) {
    log.info("Data Vencimento ==> " + data);
    if (data.indexOf('/') > -1) {
        var newData = data.split('/')
        var newString = "" + newData[2] + newData[1] + newData[0] + ""
    } else {
        var newData = data.split('-')
        var newString = "" + newData[0] + newData[1] + newData[2] + ""
    }
    log.info("Return Data ==> " + data);
    return newString
}