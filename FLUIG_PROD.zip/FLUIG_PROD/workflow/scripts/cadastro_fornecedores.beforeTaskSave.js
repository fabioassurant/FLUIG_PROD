function beforeTaskSave(colleagueId,nextSequenceId,userList){ 
	
	var anexos   = hAPI.listAttachments();
	var atividade = getValue("WKNumState");
	var tipo = hAPI.getCardValue("tipoCadastroHidden");
	
	if (atividade == INICIO || atividade == INICIO_SOL){
        if (anexos.size() == 0 && tipo == "novo") {        
        	throw "É obrigatório anexar a documentação societária!";
        }
    } 
}
