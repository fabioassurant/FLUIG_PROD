function servicetask49(attempt, message) {
    log.info("---------------------SERVICETASK49---------------------")
    var obj = {
        "NTN": NTN(attempt, message),
        "NFPS": NFPS(attempt, message),
        "AFPS": AFPS(attempt, message),
        "DIS": DIS(attempt, message),
        "PROC": PROC(attempt, message),
        "NOT": NOT(attempt, message),
        "CES": CES(attempt, message)
    }

    var prefixo = hAPI.getCardValue('prefixo')
    obj[prefixo]
}

function NTN(attempt, message) {
    //Integração com o Acsel
}

function NFPS(attempt, message) {
    //Integração com o Acsel
}

function AFPS(attempt, message) {
    var cardServiceProvider = ServiceManager.getServiceInstance("ECMCardService");
    var cardServiceLocator = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.ECMCardServiceService");
    var cardService = cardServiceLocator.getCardServicePort();

    var cardFieldDtoArray = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDtoArray");

    var vetCardFields = [];

    var tipo = '';

    if (hAPI.getCardValue('tipoContrato') == 'forncedorPrestadorServico') {
        tipo = 'NFPS';
    } else {
        tipo = 'NTN';
    }

    var campos = hAPI.getCardData(hAPI.getCardValue('WKNumProces'));
    log.info('Campos do formulário');
    log.dir(campos);
    var i = 0;
    var contador = campos.keySet().iterator();
    var valContrato = false;
    log.info('vai entrar no while');
    while (contador.hasNext()) {
        var id = contador.next();
        if (id.match('AFPS')) {
            if (id.match('AFPStituloContrato')) {
                valContrato = true;
                log.info('Tranformou em True o ValContrato')
            }
            if (valContrato) {
                var cardField = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDto");
                log.info('----------------Valores dos campos')
                log.dir(tipo + '' + id.split('AFPS')[1]) // pega nome do campo
                log.dir(campos.get(id))
                log.info('-----------------------------------')
                cardField.setField(tipo + '' + id.split('AFPS')[1]);
                cardField.setValue(campos.get(id));
                log.info("cardfielddd");
                log.dir(cardField);
                vetCardFields.push(cardField);
            }
        }
    }

    log.info("dataalt");
    var dataAlt = new Date();
    log.info('dataaltdeclarada');
    var tipoAlt = hAPI.getCardValue("servicoJuridico");
    var arqAlt = hAPI.getCardValue("AFPScontrato");

    var constraintsFilhos = new Array();
    constraintsFilhos.push(DatasetFactory.createConstraint("tablename", "historico", "historico", ConstraintType.MUST));
    constraintsFilhos.push(DatasetFactory.createConstraint("documentid", arqAlt, arqAlt, ConstraintType.MUST));
    //Busca o dataset
    var datasetFilhos = DatasetFactory.getDataset("ds_processo_contrato", null, constraintsFilhos, null);
    var indice = datasetFilhos.values.length + 1;
    hAPI.setCardValue('AFPSidentifAditivo', ' ' + indice + ' - ' + hAPI.getCardValue('WKNumProces'))
    var arrCampos = [
        { "campo": "dataAlt___" + indice, "valor": dataAlt },
        { "campo": "tipoAlt___" + indice, "valor": tipoAlt },
        { "campo": "arqAlt___" + indice, "valor": arqAlt }
    ];

    for (var i = 0; i < arrCampos.length; i++) {
        var cardField = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDto");
        log.info('-----------------------------------')
        cardField.setField(arrCampos[i].campo);
        cardField.setValue(arrCampos[i].valor);
        log.info("cardfielddd");
        log.dir(cardField);
        vetCardFields.push(cardField);
    }
    log.info('Array CardField')
    log.dir(vetCardFields)

    cardFieldDtoArray.getItem().addAll(vetCardFields);

    var codRegistroForm = hAPI.getCardValue('AFPScontrato');
    try {
        log.info('cardservice');
        cardService.updateCardData(1, "admin", "adm", arqAlt, cardFieldDtoArray);
    } catch (e) {
        log.dir(e);
    }
}

function DIS(attempt, message) {
    var cardServiceProvider = ServiceManager.getServiceInstance("ECMCardService");
    var cardServiceLocator = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.ECMCardServiceService");
    var cardService = cardServiceLocator.getCardServicePort();
    var cardFieldDtoArray = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDtoArray");
    var vetCardFields = [];
    var tipo = '';
    if (hAPI.getCardValue('tipoContrato') == 'forncedorPrestadorServico') {
        tipo = 'NFPS';
    } else {
        tipo = 'NTN';
    }

    var campos = hAPI.getCardData(hAPI.getCardValue('WKNumProces'));
    log.info('Campos do formulário');
    log.dir(campos);
    var i = 0;
    var contador = campos.keySet().iterator();
    var valContrato = false;
    log.info('vai entrar no while');
    while (contador.hasNext()) {
        var id = contador.next();
        if (id.match('DIS')) {
            var cardField = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDto");
            log.info('----------------Valores dos campos')
            log.dir(tipo + '' + id.split('DIS')[1]) // pega nome do campo
            log.dir(campos.get(id))
            log.info('-----------------------------------')
            cardField.setField(tipo + '' + id.split('DIS')[1]);
            cardField.setValue(campos.get(id));
            log.info("cardfielddd");
            log.dir(cardField);
            vetCardFields.push(cardField);
        }
    }
    cardFieldDtoArray.getItem().addAll(vetCardFields);

    var codRegistroForm = hAPI.getCardValue('DIScontrato');
    try {
        log.info('cardservice');
        cardService.updateCardData(1, "admin", "adm", codRegistroForm, cardFieldDtoArray);
    } catch (e) {
        log.dir(e);
    }
}

function PROC(attempt, message) {

}

function NOT(attempt, message) {}

function CES(attempt, message) {
    var idForm = hAPI.getCardValue("CEScontrato");
    var tipo = hAPI.getCardValue('tipoContrato');
    log.info("campoooss");
    var campos = "[";
    log.info("totallinhaaaas");
    var totalLinhasCessionario = hAPI.getChildrenIndexes('CEStabelaCessionario');
    log.dir(totalLinhasCessionario);
    log.info("forr");
    if (hAPI.getCardValue('CEScedente') == 'Contratado') {
        for (var index = 1; index <= totalLinhasCessionario.length; index++) {
            campos += '{' +
                '"NomeCedente":"' + hAPI.getCardValue("CESlistaCedente") + '",' +
                '"NFPSinicioVigencia":"' + hAPI.getCardValue('CESdataCessao') + '",' +
                '"NFPSrazaoSocial":"' + hAPI.getCardValue("CESrazaoSocial___" + index) + '",' +
                '"NFPSnomeFantasia":"' + hAPI.getCardValue("CESnomefantasia___" + index) + '",' +
                '"NFPScpfCnpj":"' + hAPI.getCardValue("CEScpfCnpj___" + index) + '",' +
                '"NFPSemail":"' + hAPI.getCardValue("CESemail___" + index) + '",' +
                '"NFPStelefone":"' + hAPI.getCardValue("CEStelefone___" + index) + '",' +
                '"NFPSendereco":"' + hAPI.getCardValue("CESendereco___" + index) + '",' +
                '"NFPScep":"' + hAPI.getCardValue("CEScep___" + index) + '",' +
                '"NFPSbairro":"' + hAPI.getCardValue("CESbairro___" + index) + '",' +
                '"NFPScidade":"' + hAPI.getCardValue("CEScidade___" + index) + '",' +
                '"NFPSuf":"' + hAPI.getCardValue("CESuf___" + index) + '",' +
                '"NFPSpais":"' + hAPI.getCardValue("CESpais___" + index) + '",' +
                '"NFPSbanco":"' + hAPI.getCardValue("CESbanco___" + index) + '",' +
                '"NFPSagencia":"' + hAPI.getCardValue("CESagencia___" + index) + '",' +
                '"NFPSconta":"' + hAPI.getCardValue("CESconta___" + index) + '",' +
                '"NFPSnacionalEstrangeira":"' + hAPI.getCardValue("CESnacionalEstrangeira___" + index) + '",' +
                '"NFPStipo":"' + hAPI.getCardValue("CEStipo___" + index) + '"' +
                '},'
        }
        log.info("campusss");
        log.dir(campos);
        campos += "]"
        campos = campos.replace(',]', ']');
        var constraints = [];
        constraints.push(DatasetFactory.createConstraint("idContrato", idForm, idForm, ConstraintType.MUST));
        constraints.push(DatasetFactory.createConstraint("usuarioSolicitante", "admin", "admin", ConstraintType.MUST));
        constraints.push(DatasetFactory.createConstraint("tipo", tipo, tipo, ConstraintType.MUST));
        constraints.push(DatasetFactory.createConstraint("jsonCessionario", campos, campos, ConstraintType.MUST));
        var ds = DatasetFactory.getDataset('dsCriaNovaPO', null, constraints, null);
    }
}