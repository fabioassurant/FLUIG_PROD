function beforeStateEntry(sequenceId) {
    if (sequenceId == 38) { //verificando onde está
        log.info("if do before");
        var idUser = "" + getValue("WKUser");
        var nome = "" + hAPI.getCardValue("para_nome");
        var solicitacao = "" + getValue("WKNumProces");
        var estado = hAPI.getCardValue("botaoAprovacao");
        var email_requester_sol = hAPI.getCardValue("requester"); //quem abriu
        var email_requester = hAPI.getCardValue("para_email"); //pra quem se destina
        log.info("variaveis declaradas");
        var acesso = "LIBERADO";

        log.info("acessoss");
        var parametrosEmail = new java.util.HashMap(); //parametros do email
        parametrosEmail.put("nomePessoa", nome); //passando parametros email
        parametrosEmail.put("numProcesso", solicitacao);
        parametrosEmail.put("estadoSol", "APROVADO");
        parametrosEmail.put("acessoConcedido", acesso);
        parametrosEmail.put("subject", "Solicitação de Liberação de Acesso/Equipamento");
        log.info("parametrooosss")
        var destinatarios = new java.util.ArrayList();
        destinatarios.add("" + email_requester_sol);
        destinatarios.add("" + email_requester);
        log.info("destinatariosss");
        notifier.notify(idUser, "email_acesso_assurant", parametrosEmail, destinatarios, "text/html"); //função que envia email
        //padrao//função//remetente//template//parametrosDasVariaveis//listaDestinatarios//tipoTextoDoEmail
    }

}