function intermediateconditional37() {
    var numerosObrigacoes = hAPI.getCardValue('num_obrigacao') + ""
    if (numerosObrigacoes == "justificando") {
        setDate()
        var attHistorico = hAPI.getCardValue("historico") + '-> Justificativa Pagamento -> Concluido'
        hAPI.setCardValue("historico", attHistorico)
        return true;
    } else {
        var numeroObrigacao = numerosObrigacoes.split('.')[0]
        var pagamento = numerosObrigacoes.split('.')[1]

        var status = verificaPagamento(numeroObrigacao, pagamento)

        switch (status) {

            case '1':

                numerosObrigacoes = numeroObrigacao + '.1'

                break;

            case '2':
                setDate()

                return true;

            default:

                numerosObrigacoes = numeroObrigacao + '.0'

                break;


        }

        hAPI.setCardValue('num_obrigacao', (numerosObrigacoes))

    }

}

function setDate() {
    var date = new Date();

    var stringDate = ""

    stringDate = '' + ((date.getDate() < 10) ? "0" + date.getDate() : date.getDate()) + '/' + (((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + date.getFullYear()

    hAPI.setCardValue('dataPagamento', stringDate)

    hAPI.setCardValue("pagamentoConlcuido", "Sim.")
}

function verificaPagamento(numObrig, pagStat) {
    var cCodWorkflow = "";
    var resultado = consultaStatus(numObrig, cCodWorkflow)

    if (resultado == "VAL") {

        var attHistorico = hAPI.getCardValue('historico') + '-> Em Validação';
        hAPI.setCardValue("historico", attHistorico)

        log.info('Adiciona Campo e retornando')

        return '0'
    } else if (resultado == "ACT") {

        var attHistorico = hAPI.getCardValue('historico') + '-> Pendente de pagamento';
        hAPI.setCardValue("historico", attHistorico)

        log.info('Adiciona Campo e retornando')

        return '0'
    } else if (resultado == "PAG") {
        var attHistorico = hAPI.getCardValue('historico') + ((pagStat == '0') ? '-> Validando Pagamento' : (pagStat == '2') ? '' : '-> Pago')
        hAPI.setCardValue("historico", attHistorico)

        // if (pagStat == '0') {
        //     log.info('Retorna 1')
        //     return '1'
        // } else if (pagStat == '1') {
        //     log.info('Retorna 2')
        return '2'
            // }
    } else if (resultado == 'ANU') {

        var attHistorico = hAPI.getCardValue('historico') + '-> Pagamento anulado';
        hAPI.setCardValue("historico", attHistorico)

        cancelProcess()
    }
}

function consultaStatus(numObrig, cCodWorkflow) {
    var chave = DatasetFactory.getDataset('ds_getToken', null, null, null).getValue(0, 'token');

    var properties = {};
    properties["receive.timeout"] = "180000";

    var supplierService = ServiceManager.getService('Acsel');

    var serviceHelper = supplierService.getBean();

    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');

    var service = serviceLocator.getServicosWebServicePort();

    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);

    var retorno = customClient.consultaStatusObrigacao(chave, numObrig, cCodWorkflow);


    // return 'PAG';
    return retorno.getSTATUS();
}

function cancelProcess() {
    var processo = getValue("WKNumProces");

    var workflowEngineServiceProvider = ServiceManager.getServiceInstance("ECMWorkflowEngineService");
    var workflowServiceLocator = workflowEngineServiceProvider.instantiate("com.totvs.technology.ecm.workflow.ws.ECMWorkflowEngineServiceService");
    var workflowService = workflowServiceLocator.getWorkflowEngineServicePort();

    var cancelamentoProcesso = workflowService.cancelInstance('admin', 'adm', 1, processo, 'admin', 'Cancelado por conta de anulação do pagamento no serviço web.');

    if (cancelamentoProcesso.equals("OK")) {
        log.info('Processo ' + processo + " cancelado por conta de anulação do pagamento serviço web.");
    }
}