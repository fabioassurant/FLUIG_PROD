function servicetask117(attempt, message) {

    try {
        var tipoAcerto = hAPI.getCardValue("tipoAcerto");
        var cnpj_cpf = hAPI.getCardValue("cpfCnpj");
        cnpj_cpf = cnpj_cpf.replaceAll(" ", "").replaceAll("/", "").replaceAll("-", "");
        var nomeFornec = hAPI.getCardValue("nomeFornecedorHidden");
        var valLiq = '';
        var valTotal = hAPI.getCardValue("valorTotal");
        var numNF = '';
        var dtEmissao = '';
        var dtX04 = '';
        var valIR = '', valINSS = '', valISS = '', valCSRF = '';
        var alqIR = '', alqINSS = '', alqISS = '', alqCSRF = '';

        //log.info("nomeFornec.length ===> " + nomeFornec.length());
        if(nomeFornec.length() > 70){
            //log.info("nomeFornec.length ===> entrou");
            //log.info("nomeFornec.substring(0, 67) ===> " + nomeFornec.substring(0, 67));
            nomeFornec = nomeFornec.substring(0, 67) + '...';
        }

        if(tipoAcerto == "adiantamento"){
            valLiq = hAPI.getCardValue("valorLiqAdiantamento");
            numNF = hAPI.getCardValue("numeroNF1");
            dtEmissao = hAPI.getCardValue("dataEmissao_1");
            valIR = hAPI.getCardValue("valor_ir1");
            valINSS = hAPI.getCardValue("valor_inss1");
            valISS = hAPI.getCardValue("valor_iss1");
            valCSRF = hAPI.getCardValue("valor_csrf1");
        }
        else if(tipoAcerto == "despesaNF"){
            valLiq = hAPI.getCardValue("valorLiqDespesa");
            numNF = hAPI.getCardValue("numeroNF2");
            dtEmissao = hAPI.getCardValue("dataEmissao_2");
            valIR = hAPI.getCardValue("valor_ir2");
            valINSS = hAPI.getCardValue("valor_inss2");
            valISS = hAPI.getCardValue("valor_iss2");
            valCSRF = hAPI.getCardValue("valor_csrf2");
        }
        else if(tipoAcerto == "RH"){
            valLiq = hAPI.getCardValue("valorLiqRH");
            numNF = hAPI.getCardValue("numeroNF3");
            dtEmissao = hAPI.getCardValue("dataEmissao_3");
            valIR = hAPI.getCardValue("valor_ir3");
            valINSS = hAPI.getCardValue("valor_inss3");
            valISS = hAPI.getCardValue("valor_iss3");
            valCSRF = hAPI.getCardValue("valor_csrf3");
        }
        else if(tipoAcerto == "ovidoria"){
            valLiq = hAPI.getCardValue("valorLiqOuvidoria");
            numNF = hAPI.getCardValue("numeroNF4");
            dtEmissao = hAPI.getCardValue("dataEmissao_4");
            valIR = hAPI.getCardValue("valor_ir4");
            valINSS = hAPI.getCardValue("valor_inss4");
            valISS = hAPI.getCardValue("valor_iss4");
            valCSRF = hAPI.getCardValue("valor_csrf4");
        }
        else if(tipoAcerto == "comissao"){
            valLiq = hAPI.getCardValue("valorLiqComissao");
            numNF = hAPI.getCardValue("numeroNF5");
            dtEmissao = hAPI.getCardValue("dataEmissao_5");
            valIR = hAPI.getCardValue("valor_ir5");
            valINSS = hAPI.getCardValue("valor_inss5");
            valISS = hAPI.getCardValue("valor_iss5");
            valCSRF = hAPI.getCardValue("valor_csrf5");
        }
        else if(tipoAcerto == "imposto"){
            valLiq = hAPI.getCardValue("valorLiqImposto");
            numNF = hAPI.getCardValue("numeroNF6");
            dtEmissao = hAPI.getCardValue("dataEmissao_6");
            valIR = hAPI.getCardValue("valor_ir6");
            valINSS = hAPI.getCardValue("valor_inss6");
            valISS = hAPI.getCardValue("valor_iss6");
            valCSRF = hAPI.getCardValue("valor_csrf6");
        }
        else if(tipoAcerto == "presConta"){
            valLiq = hAPI.getCardValue("valorLiqPresConta");
            numNF = hAPI.getCardValue("numeroNF7");
            dtEmissao = hAPI.getCardValue("dataEmissao_7");
            valIR = hAPI.getCardValue("valor_ir7");
            valINSS = hAPI.getCardValue("valor_inss7");
            valISS = hAPI.getCardValue("valor_iss7");
            valCSRF = hAPI.getCardValue("valor_csrf7");
        }
        else if(tipoAcerto == "cosseguro"){
            valLiq = hAPI.getCardValue("valorLiqCosseguro");
            numNF = hAPI.getCardValue("numeroNF8");
            dtEmissao = hAPI.getCardValue("dataEmissao_8");
            valIR = hAPI.getCardValue("valor_ir8");
            valINSS = hAPI.getCardValue("valor_inss8");
            valISS = hAPI.getCardValue("valor_iss8");
            valCSRF = hAPI.getCardValue("valor_csrf8");
        }
        else if(tipoAcerto == "devolucao_franquia"){
            valLiq = hAPI.getCardValue("valorLiqDevFranquia");
            numNF = hAPI.getCardValue("numeroNF9");
            dtEmissao = hAPI.getCardValue("dataEmissao_9");
            valIR = hAPI.getCardValue("valor_ir9");
            valINSS = hAPI.getCardValue("valor_inss9");
            valISS = hAPI.getCardValue("valor_iss9");
            valCSRF = hAPI.getCardValue("valor_csrf9");
        }
        else if(tipoAcerto == "despesa_apolice"){
            valLiq = hAPI.getCardValue("valorLiqDespesaApolice");
            numNF = hAPI.getCardValue("numeroNF10");
            dtEmissao = hAPI.getCardValue("dataEmissao_10");
            valIR = hAPI.getCardValue("valor_ir10");
            valINSS = hAPI.getCardValue("valor_inss10");
            valISS = hAPI.getCardValue("valor_iss10");
            valCSRF = hAPI.getCardValue("valor_csrf10");
        }

        if(dtEmissao != ""){
            var dtAnterior = new Date(dtEmissao);
            dtAnterior.setDate(dtAnterior.getDate()-1);
            dtX04 = dtAnterior.getFullYear() + "";
            dtX04 += ((dtAnterior.getMonth() + 1)).toString().length > 1? dtAnterior.getMonth() + 1 : "0" + (dtAnterior.getMonth() + 1); 
            dtX04 += ((dtAnterior.getDate()+"").length > 1 ? dtAnterior.getDate() : "0" + dtAnterior.getDate());
            dtEmissao = dtEmissao.replaceAll("-","");
        }

        valTotal = valTotal.replaceAll("\\.", "").replace(",",".");
        //log.info("alqIR ===>" + alqIR);
        //log.info("valIR ===>" + valIR);
        if(valIR != ""){
            //log.info("valIR ===> " + valIR);
            valIR    = valIR.replaceAll('-','').replaceAll("\\.",'').replaceAll(",",'.');
            alqIR    = calcularAliquota(parseFloat(valTotal), parseFloat(valIR));
            alqIR    = alqIR.toFixed(2);
            alqIR    = alqIR + '';
        }
        if(valINSS != ""){
            valINSS    = valINSS.replaceAll('-','').replaceAll("\\.",'').replaceAll(",",'.');
            alqINSS    = calcularAliquota(parseFloat(valTotal), parseFloat(valINSS));
            alqINSS    = alqINSS.toFixed(2);
            alqINSS    = alqINSS + '';
        }
        if(valISS != ""){
            valISS    = valISS.replaceAll('-','').replaceAll("\\.",'').replaceAll(",",'.');
            alqISS    = calcularAliquota(parseFloat(valTotal), parseFloat(valISS));
            alqISS    = alqISS.toFixed(2);
            alqISS    = alqISS + '';
        }
        if(valCSRF != ""){
            valCSRF    = valCSRF.replaceAll('-','').replaceAll("\\.",'').replaceAll(",",'.');
            alqCSRF    = calcularAliquota(parseFloat(valTotal), parseFloat(valCSRF));
            alqCSRF    = alqCSRF.toFixed(2);
            alqCSRF    = alqCSRF + '';
        }

        valLiq = valLiq.replaceAll("\\.", "").replace(",","");
        valTotal = valTotal.replaceAll("\\.", "").replace(",","");
        valIR    = valIR.replaceAll("\\.", "").replaceAll(",","").replaceAll('-','');
        valINSS  = valINSS.replaceAll("\\.", "").replaceAll(",","").replaceAll('-','');
        valISS   = valISS.replaceAll("\\.", "").replaceAll(",","").replaceAll('-','');
        valCSRF  = valCSRF.replaceAll("\\.", "").replaceAll(",","").replaceAll('-','');
        if(alqIR != ""){
            alqIR = alqIR.replace(".", "");
        }
        if(alqINSS != ""){
            alqINSS  = alqINSS.replace(".", "");
        }
        if(alqISS != ""){
            alqISS   = alqISS.replace(".", "");
        }
        if(alqCSRF != ""){
            alqCSRF  = alqCSRF.replace(".", "");
        }

        var objParams04 = {
            "IND_FIS_JUR"    : "1",
            "COD_FIS_JUR"    : cnpj_cpf,
            "IND_CONTEM_COD" : "1",
            "RAZAO_SOCIAL"   : nomeFornec,
            "CPF_CGC"        : cnpj_cpf,
            "DATA_X04"       : formatarDataAtual() // dtX04
        }

        var cCParams04 = DatasetFactory.createConstraint("SAFX04", JSONUtil.toJSON(objParams04), JSONUtil.toJSON(objParams04), ConstraintType.MUST);

        log.info("objParams04  ==> " + JSONUtil.toJSON(objParams04));
        
        var objParams07 = {
            "COD_EMPRESA"    : "001",
            "COD_ESTAB"      : "0001",
            "MOVTO_E_S"      : "1",
            "NORM_DEV"       : "1",
            "COD_DOCTO"      : "NFSE",
            "IDENT_FIS_JUR"  : "1",
            "COD_FIS_JUR"    : cnpj_cpf,
            "NUM_DOCFIS"     : numNF,
            "DATA_EMISSAO"   : dtEmissao,
            "COD_CLASS_DOC_FIS" : "2",
            "COD_MODELO"     : "55",
            "SITUACAO"       : "S",
            "DATA_SAIDA_REC" : formatarDataAtual(),
            "VLR_IR"         : valIR,
            "VLR_ISS"        : valISS,
            "VLR_INSS_RETIDO": valINSS,
            "VLR_PIS"        : valCSRF,
            "VLR_COFINS"     : valCSRF,
            "VLR_CSLL"       : valCSRF,
            "VLR_ALIQ_IR"    : alqIR,
            "VLR_ALIQ_ISS"   : alqISS,
            "VLR_ALIQ_INSS"  : alqINSS,
            "VLR_ALIQ_PIS"   : alqCSRF,
            "VLR_ALIQ_COFINS": alqCSRF,
            "VLR_ALIQ_CSLL"  : alqCSRF
        }
        
        var cCParams07 = DatasetFactory.createConstraint("SAFX07", JSONUtil.toJSON(objParams07), JSONUtil.toJSON(objParams07), ConstraintType.MUST);
        log.info("objParams07  ==> " + JSONUtil.toJSON(objParams07));
        var objParams09 = {
            "COD_EMPRESA"    : "001",
            "COD_ESTAB"      : "0001",
            "DATA_FISCAL"    : formatarDataAtual(),
            "MOVTO_E_S"      : "1",
            "NORM_DEV"       : "1",
            "COD_DOCTO"      : "NFSE",
            "IND_FIS_JUR"  : "1",
            "COD_FIS_JUR"    : cnpj_cpf,
            "NUM_DOCFIS"     : numNF,
            "COD_SERVICO"    : "SV",
            "NUM_ITEM"       : "1",
            "VLR_SERVICO"    : valLiq,
            "VLR_TOT"        : valTotal,
            "VLR_IR"         : valIR,
            "VLR_ISS"        : valISS,
            "VLR_INSS_RETIDO": valINSS,
            "VLR_PIS"        : valCSRF,
            "VLR_COFINS"     : valCSRF,
            "VLR_CSLL"       : valCSRF,
            "VLR_ALIQ_IR"    : alqIR,
            "VLR_ALIQ_ISS"   : alqISS,
            "VLR_ALIQ_INSS"  : alqINSS,
            "VLR_ALIQ_PIS"   : alqCSRF,
            "VLR_ALIQ_COFINS": alqCSRF,
            "VLR_ALIQ_CSLL"  : alqCSRF
        }
        log.info("objParams09  ==> " + JSONUtil.toJSON(objParams09));
        var cCParams09 = DatasetFactory.createConstraint("SAFX09", JSONUtil.toJSON(objParams09), JSONUtil.toJSON(objParams09), ConstraintType.MUST);
        
        var dts_integracao = DatasetFactory.getDataset("dts_setMastersafDW_MFX", null, [cCParams04, cCParams07, cCParams09], null);
        //log.info("dts_integracao rrtornado com dados ===> " + dts_integracao);
        //log.info("dts_integracao rrtornado com dados 2 ===> " + JSONUtil.toJSON(dts_integracao));
        if(dts_integracao.values.length > 0){
            log.info("dts_integracao rrtornado com dados 3 ===> " + dts_integracao);
            for(var i=0; i < dts_integracao.values.length; i++){
                log.info("Item integração ===> " + dts_integracao.getValue(i, "Status"));
                if(dts_integracao.getValue(i, "Status") != "Sucess"){
                    log.info("resposta da integração ===> " + dts_integracao.getValue(i, "Response"));
                    log.info("tabela da resposta da integração ===> " + dts_integracao.getValue(i, "Response"));
                    throw "Erro para realização das integrações - status: " + dts_integracao.getValue(i, "Status") + " - " + dts_integracao.getValue(i, "Response") + " - " + dts_integracao.getValue(i, "Table");
                }
            }
        }
    } catch (e) {
        throw e.toString()
    }
}

function formatarDataAtual(){
    var obj = new Date();

    var dia = obj.getDate().toString();      dia = (dia.length > 1)? dia : "0"+dia;
    var mes = (obj.getMonth()+1).toString(); mes = (mes.length > 1)? mes : "0"+mes;
    var ano = obj.getFullYear();

    return ano + "" + mes + "" + dia;
}

function calcularAliquota(valorTotal, valorImposto){
    var valTot = parseFloat(valorTotal);
    var valImp = parseFloat(valorImposto);

    return (valImp * 100) / valTot;
}