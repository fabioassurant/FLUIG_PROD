function intermediateconditional95() {
    var request = getValue("WKNumProces");
    var contractType = hAPI.getCardValue("tipoContrato");
    var tipoContrato = ""
    var requester = "";

    try {
        var params = new java.util.HashMap();

        if (contractType == "forncedorPrestadorServico") {
            tipoContrato = "Fornecedor/Prestador de Serviço"
        } else {
            tipoContrato = "Negócios"
        }
        params.put("num_Solicita", request);
        params.put("tipoContrato", tipoContrato);


        var recipients = new java.util.ArrayList()
        var csProcessId = DatasetFactory.createConstraint("workflowProcessPK.processInstanceId", request, request, ConstraintType.MUST);
        var dsWorkflowProcess = DatasetFactory.getDataset("workflowProcess", null, [csProcessId], null);
        if (dsWorkflowProcess) {
            requester = dsWorkflowProcess.getValue(0, "requesterId");
        } else {
            throw "Requester not Found";
        }

        var csGroupId = DatasetFactory.createConstraint("colleagueGroupPK.groupId", "ADMINISTRATIVO", "ADMINISTRATIVO", ConstraintType.MUST);
        var dsColleagueGroup = DatasetFactory.getDataset("colleagueGroup", null, [csGroupId], null);
        log.info("## ds");
        log.dir(dsColleagueGroup)
        for (var i = 0; i < dsColleagueGroup.rowsCount; i++) {
            recipients.add(dsColleagueGroup.getValue(i, "colleagueGroupPK.colleagueId"));
        }

        recipients.add(requester);

        log.info('intermadiate 95 - Params e Recipients')
        log.dir(params)
        log.dir(recipients)


        notifier.notify("admin", "templateNotificaFim", params, recipients, "text/html");
        return true;

    } catch (e) {
        log.info("ERROR INTERMEDIATE CONDITIONAL 95 - REQUEST " + request + " =====> " + e.message);
        return false;
    }

    // try {
    //     var currentDate = dateNow()
    //     var finalDate = hAPI.getCardValue('dataNotificacaoSolicitante')
    //     log.info("finalDate#####");
    //     log.dir(finalDate);
    //     log.info("currentDate#####");
    //     log.dir(currentDate);
    //     log.info('Request#######')
    //     log.dir(request)
    //     // if (currentDate == finalDate) {
    //         // log.info("entrou no if")
    //         var contractType = hAPI.getCardValue("tipoContrato");
    //         var contractTitle = "";
    //         var startTerm = "";
    //         var finalTerm = "";
    //         var requester = "";
    //         if (contractType == "forncedorPrestadorServico") {
    //             contractTitle = hAPI.getCardValue("NFPStituloContrato");
    //             startTerm = hAPI.getCardValue("NFPSinicioVigencia");
    //             finalTerm = hAPI.getCardValue("NFPSfimVigencia");

    //         } else if (contractType == "negocios") {
    //             contractTitle = hAPI.getCardValue("NTNtituloContrato");
    //             startTerm = hAPI.getCardValue("NTNinicioVigencia");
    //             finalTerm = hAPI.getCardValue("NTNfimVigencia");

    //         } else {
    //             throw "Tipo de Contrato não informado";
    //         }

    //         log.info('intermadiate 95 - Contratos - Var Title, start, final')
    //         log.dir(contractTitle)
    //         log.dir(startTerm)
    //         log.dir(finalTerm)

    //         requestLink = "http://atl0wwbsm101:8080/portal/p/ASSURANT/pageworkflowview?app_ecm_workflowview_detailsProcessInstanceID=" + request;
    //         var tableLine = "<tr> \
    //             <td bgcolor='#E3D8D3' width='15%'><p align='left'  ><font size='2' face='Tahoma' align='right' >\
    //             <a target='_blank' href='" + requestLink + "'>" + request + "</a></font></td>\
    //             <td bgcolor='#E3D8D3' width='15%'><p align='left'  ><font size='2' face='Tahoma' align='right' >" + contractTitle + "</font></td>\
    //             <td bgcolor='#E3D8D3' width='15%'><p align='left'  ><font size='2' face='Tahoma' align='right' >" + startTerm + "</font></td>\
    //             <td bgcolor='#E3D8D3' width='15%'><p align='left'  ><font size='2' face='Tahoma' align='right' >" + finalTerm + "</font></td>\
    //         </tr>";

    //         var params = new java.util.HashMap();
    //         params.put("TABLE_LINE", tableLine);
    //         params.put("LOGO", "");

    //         var recipients = new java.util.ArrayList();

    //         var csProcessId = DatasetFactory.createConstraint("workflowProcessPK.processInstanceId", request, request, ConstraintType.MUST);
    //         var dsWorkflowProcess = DatasetFactory.getDataset("workflowProcess", null, [csProcessId], null);
    //         if (dsWorkflowProcess) {
    //             requester = dsWorkflowProcess.getValue(0, "requesterId");
    //         } else {
    //             throw "Requester not Found";
    //         }

    //         var csGroupId = DatasetFactory.createConstraint("colleagueGroupPK.groupId", "ADMINISTRATIVO", "ADMINISTRATIVO", ConstraintType.MUST);
    //         var dsColleagueGroup = DatasetFactory.getDataset("colleagueGroup", null, [csGroupId], null);
    //         log.info("## ds");
    //         log.dir(dsColleagueGroup)
    //         for (var i = 0; i < dsColleagueGroup.rowsCount; i++) {
    //             recipients.add(dsColleagueGroup.getValue(i, "colleagueGroupPK.colleagueId"));
    //         }

    //         recipients.add(requester);
    //         log.info("### recipients");
    //         log.dir(recipients)
    //         log.info("### params");
    //         log.dir(params)
    //         notifier.notify("admin", "tpl_aviso_contrato", params, recipients, "text/html");
    //         return true;
    //     // }
    // } catch (e) {
    //     log.info("ERROR INTERMEDIATE CONDITIONAL 95 - REQUEST " + request + " =====> " + e.message);
    //     return false;
    // }

    // return true;

}

function dateNow() {
    var formato = new java.text.SimpleDateFormat('dd/MM/yyyy');
    return formato.format(new java.util.Date());
}