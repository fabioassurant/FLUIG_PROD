function beforeTaskComplete(colleagueId, nextSequenceId, userList) {
    if (nextSequenceId == 7) {
        if (hAPI.getCardValue('vincularAdiantamento') == 'SIM') {
            var cardServiceProvider = ServiceManager.getServiceInstance("ECMCardService");
            var cardServiceLocator = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.ECMCardServiceService");
            var cardService = cardServiceLocator.getCardServicePort();

            var cardFieldDtoArray = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDtoArray");

            var cardField = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDto");

            cardField.setField("reembolsado");
            cardField.setValue("aguardando");

            var vetCardFields = new Array();

            vetCardFields.push(cardField);

            cardFieldDtoArray.getItem().addAll(vetCardFields);

            var codRegistroForm = hAPI.getCardValue('codRegistroAlterar')

            cardService.updateCardData(1, "admin", "adm", codRegistroForm, cardFieldDtoArray);

        } else if (hAPI.getCardValue('tipoAcerto') == 'ADIANTAMENTO') {
            hAPI.setCardValue('reembolsado', 'aguardando')
        }
    } else if (nextSequenceId == 39) {
        if (hAPI.getCardValue('tipoAcerto') == 'ADIANTAMENTO') {
            hAPI.setCardValue('reembolsado', 'false')
        } else if (hAPI.getCardValue('vincularAdiantamento') == 'SIM') {
            var cardServiceProvider = ServiceManager.getServiceInstance("ECMCardService");
            var cardServiceLocator = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.ECMCardServiceService");
            var cardService = cardServiceLocator.getCardServicePort();
            var cardFieldDtoArray = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDtoArray");
            var cardField = cardServiceProvider.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDto");
            cardField.setField("reembolsado");
            cardField.setValue("true");
            var vetCardFields = new Array();
            vetCardFields.push(cardField);
            cardFieldDtoArray.getItem().addAll(vetCardFields);
            var codRegistroForm = hAPI.getCardValue('codRegistroAlterar')
            cardService.updateCardData(1, "admin", "adm", codRegistroForm, cardFieldDtoArray);
        }
    }

    if (hAPI.getCardValue('stateAtual') == 20) {
        var date = new Date();

        var dataset = DatasetFactory.getDataset('ds_paifilho_datas_vencimento', null, null, null);

        var stringDate = ""

        for (var i = 0; i < dataset.rowsCount; i++) {
            if (date.getDate() >= dataset.getValue(i, "diaInicio") && date.getDate() <= dataset.getValue(i, "diaFim")) {
                if (date.getDate() > dataset.getValue(i, "diaVencimento")) {
                    stringDate = '' + ((dataset.getValue(i, "diaVencimento") < 10) ? "0" + dataset.getValue(i, "diaVencimento") : dataset.getValue(i, "diaVencimento")) + '/' + (((date.getMonth() + 2) < 10) ? "0" + (date.getMonth() + 2) : ((date.getMonth() + 2) == 13) ? "01" : (date.getMonth() + 2)) + "/" + date.getFullYear();
                } else {
                    if (date.getMonth() + 1 == 2){
                        var ultimoDia = new Date(date.getFullYear(), date.getMonth() + 1, 0);
                        stringDate = '' + ultimoDia.getDate() + '/' + (((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + date.getFullYear();
                    } else {
                        stringDate = '' + ((dataset.getValue(i, "diaVencimento") < 10) ? "0" + dataset.getValue(i, "diaVencimento") : dataset.getValue(i, "diaVencimento")) + '/' + (((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + date.getFullYear()
                    }
                }
            }
        }


        hAPI.setCardValue('dataPrevistaPagamento', stringDate)
    }
}