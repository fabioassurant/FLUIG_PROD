$(document).ready(function(){

    FLUIGC.popover('.bs-docs-popover-hover',{trigger: 'hover', placement: 'auto'});

    if(getWKNumState() == 0 || getWKNumState() == 4){
        $('#novoFornecedor').parent().hide()
    }

    if(getWKNumState() == 103 || getWKNumState() == 106 ){
        $('#alert').show()
        $('#alert').text($("#motivo").val())
    }

    const inputRadio = $('input:radio[name^=aprovado]:checked').val()

    if(getWKNumState() == 19 || getWKNumState() == 86){
        $('input:radio[name^=aprovado]').prop("checked",false)
        $("#motivo").val("")
    }
    
    $('input[name^=aprovado]').change(function(){
        if(this.value == "ENCERRAR" || this.value == "REPROVADO"){
            $('#motivo').parent().show()
        }else{
            $('#motivo').parent().hide()
        }
    });

})



function addItens(){
    const index = wdkAddChild("pedidos").toString().trim()

    $('#item___' + index).val(index)
    $("#valor___" + index).mask("#00,##0.00",{reverse:true})
    $("#frete___" + index).mask("#00,##0.00",{reverse:true})
   $('#selecionado___' + index).parent()[0].childNodes[3].attributes[0].value = 'selecionado___' + index
}

function fnCustomDelete(oElement){
    fnWdkRemoveChild(oElement)
}

function selectItem(item){
    const { checked,id } = item
    const camposPaiXFilho = $('input[name^="selecionado___"]')

    for (let campoPaiXFilho of camposPaiXFilho ) {
        campoPaiXFilho.checked = false
    }

    item.checked = checked


}

function setSelectedZoomItem(selectedItem) {
    $('#idGestor').val(selectedItem['colleagueId'])
}

function somaValores(input){
    const { id } = input
    const [idCurrent, numberLine] = id.split("___")
    const quantidade = $('#quantidade___' + numberLine).val() == "" ? 0 : $('#quantidade___' + numberLine).val() 
    const valor =  $('#valor___' + numberLine).val() == "" ? '0' : $('#valor___' + numberLine).val() 
    const frete = $('#frete___' + numberLine).val() == "" ? '0' : $('#frete___' + numberLine).val() 
    const soma = (parseInt(quantidade)  * parseFloat(valor.replace(",","")))  + parseFloat(frete.replace(",","")) 

    $('#vlrTotal___' + numberLine).val(soma.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }))
}