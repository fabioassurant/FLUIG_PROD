function displayFields(form,customHTML){ 
    var usuarioAtual = fluigAPI.getUserService().getCurrent()
    var nome = usuarioAtual.getFullName()
    var atividade = getValue("WKNumState")
    var processo = getValue("WKNumProces")
    
   
    customHTML.append("<script>")
    customHTML.append("function  getWKNumState(){ return "+ getValue("WKNumState") + "}")

    

    if(atividade == 4 || atividade == 0){
        var dateAndHour = getDateAndHour()
        
        form.setValue("solicitante",nome)
        form.setValue("dataAtual",dateAndHour.currentDate)
        form.setValue("hora",dateAndHour.currentHour)
    }

    if(atividade == 11){
        form.setVisibleById("ADICIONARITEM",true)
        form.setVisibleById("boxJustificativa",true)
        form.setValue("solicitacao",processo)
        
    }
    
    if(atividade != 11){
        customHTML.append("$('.bpm-mobile-trash-column').hide()")
    }
    

    if(atividade != 19 && atividade != 86){
        form.setVisibleById("aprovacao",false)
    }

    customHTML.append("</script>")
    form.setShowDisabledFields(true)

}

function getDateAndHour(){
    var today = new Date();
    var year = today.getFullYear();
    var month = (today.getMonth() +1 ) < 10 ? '0' + (today.getMonth() +1 )  : (today.getMonth() +1 ) 
    var day = today.getDate() < 10 ? '0' + today.getDate()  : today.getDate()
    
    var hour = today.getHours() < 10 ? '0' + today.getHours()  : today.getHours()
    var minute = today.getMinutes() < 10 ? '0' + today.getMinutes()  : today.getMinutes()
    var second = today.getSeconds() < 10 ? '0' + today.getSeconds()  : today.getSeconds()

    var currentDate = day + "/" + month  + "/" + year
    var currentHour = hour + ":" + minute  + ":" + second

    return {
        currentDate:currentDate,
        currentHour:currentHour
    }
}