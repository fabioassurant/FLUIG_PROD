function validateForm(form){
    var arrError = []
    var indexes = form.getChildrenIndexes("pedidos") 

    form.setShowDisabledFields(true);

    if(atividade == 0 || atividade == 4){
        if(form.getValue("centroCusto") == ""){
            arrError.push("Campo Centro de Custo deve ser preenchido.")
        }
        if(form.getValue("categoriaCompra") == null){
            arrError.push("Campo Categoria de Compra deve ser preenchido.")
        }
        if(form.getValue("tipoProduto") == ""){
            arrError.push("Campo Tipo de Produto deve ser preenchido.")
        }
        if(form.getValue("localSolicitante") == ""){
            arrError.push("Campo Local deve ser preenchido.")
            
        }
        if(form.getValue("dadosSensiveis") == null){
            arrError.push("Campo Tratar dados sensíveis? deve ser preenchido.")
        }
        if(form.getValue("tipoServicos") == null){
            arrError.push("Campo Tipo de serviços? deve ser preenchido.")
        }
        if(form.getValue("descricao") == ""){
            arrError.push("Campo Descrição deve ser preenchido.")
        }
    }

    if(atividade == 11){
        var controler = true;

        if(form.getValue("novoFornecedor") == null){
            arrError.push("Campo Novo Fornecedor? deve ser preenchido.")
        }
        if(indexes.length == 0){
            arrError.push("Deve ser adicionaro itens na solicitação.")
        }

	    for (var index = 0; index < indexes.length; index++) {
            var item = form.getValue('item___' + indexes[index])

            if(form.getValue('selecionado___' + indexes[index]) == 'checked'){
                controler = false;

                if(form.getValue('quantidade___' + indexes[index]) == ""){
                    arrError.push("Campo Quantidade do Item:" + item +" deve ser preenchido.")
                }
    
                if(form.getValue('descricaoProduto___' + indexes[index]) == ""){
                    arrError.push("Campo Descrição Produto do Item:" + item +" deve ser preenchido.")
                    
                }
    
                if(form.getValue('nomeFornecedor___' + indexes[index]) == ""){
                    arrError.push("Campo Nome Fornecedor do Item:" + item +" deve ser preenchido.")
                    
                }
    
                if(form.getValue('valor___' + indexes[index]) == ""){
                    arrError.push("Campo Valor do Item:" + item +" deve ser preenchido.")
                    
                }
    
                if(form.getValue('frete___' + indexes[index]) == ""){
                    arrError.push("Campo Frete do Item:" + item +" deve ser preenchido.")
                    
                }
    
                if(form.getValue('condicaoPagamento___' + indexes[index]) == ""){
                    arrError.push("Campo Condição de Pagamento do Item:" + item +" deve ser preenchido.")
                    
                }
    
                if(form.getValue('prazoEntrega___' + indexes[index]) == ""){
                    arrError.push("Campo Prazo Entrega do Item:" + item +" deve ser preenchido.")
                    
                }
    
                if(form.getValue('justificativa___' + indexes[index]) == ""){
                    arrError.push("Campo Justificativa do Item:" + item +" deve ser preenchido.")
                }
            }  

			

           
		}

        if(controler){
            arrError.push("Para avançar para a proxima etapa deve ser selecionado um produto.") 
        }
    }

    if(atividade == 19 || atividade == 86){
        if(form.getValue('aprovado') == null){
            arrError.push("Para avançar com a solicitação deve ser selecionado uma opção.")
        }

        if((form.getValue('aprovado') == 'REPROVADO' || form.getValue('aprovado') == 'ENCERRAR') && form.getValue('motivo') == ""){
            arrError.push("Campo Motivo da Rejeição deve ser preenchido.")
        }  
    }


    
    if(arrError.length > 0){
        var error = loadErros(arrError)
        throw error
    }
}

function loadErros(arrError){
    var error = "<br><br> Por favor, verifique os campos abaixos. <br><br>"
    for (var index = 0; index < arrError.length; index++) {
        var count = parseInt(index + 1)
        if(index > 0){
            arrError[index]  = "<br><strong>" + count + "</strong> - " + arrError[index]
        }else{
            arrError[index]  = "<strong>" + count + "</strong> - " + arrError[index]
        }
        error += arrError[index]   
    }

    return error
}