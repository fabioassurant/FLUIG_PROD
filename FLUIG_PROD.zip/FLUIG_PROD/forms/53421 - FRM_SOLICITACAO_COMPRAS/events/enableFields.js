function enableFields(form){ 
	var atividade = getValue("WKNumState")
	var indexes = form.getChildrenIndexes("pedidos") 
	//form.setEnabled('juridico',true)
	//form.setEnabled('ADICIONARITEM',true)
	
	if(atividade != 0 && atividade != 4){

		 form.setEnabled('centroCusto',false)
		 form.setEnabled("categoriaCompra",false)
         form.setEnabled("tipoProduto",false)
         form.setEnabled("localSolicitante",false)
         form.setEnabled("dadosSensiveis",false)
         form.setEnabled("tipoServicos",false)
         form.setEnabled("descricao",false)
         form.setEnabled("gestor",false)

		 if(atividade != 11){
			form.setEnabled("novoFornecedor",false)
		}
		 
	}

	
	
	

	if(atividade == 103 || atividade == 106){
		form.setEnabled("descricao",true)
		
	}

	if(atividade != 0 && atividade != 4 && atividade != 11 ){
		for (var index = 0; index < indexes.length; index++) {
			form.setEnabled('quantidade___' + indexes[index],false)
			form.setEnabled('descricaoProduto___' + indexes[index],false)
			form.setEnabled('nomeFornecedor___' + indexes[index],false)
			form.setEnabled('valor___' + indexes[index],false)
			form.setEnabled('frete___' + indexes[index],false)
			form.setEnabled('vlrTotal___' + indexes[index],false)
			form.setEnabled('condicaoPagamento___' + indexes[index],false)
			form.setEnabled('prazoEntrega___' + indexes[index],false)	
			
			if(atividade != 15){
				form.setEnabled('justificativa___' + indexes[index],false)	
				form.setEnabled('selecionado___' + indexes[index],false)	
			}
		}
	}
	


	
}