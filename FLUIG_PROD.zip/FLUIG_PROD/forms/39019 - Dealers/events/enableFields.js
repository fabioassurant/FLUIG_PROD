function enableFields(form) {
    var ativAtual = getValue("WKNumState");

    if (ativAtual == 106){
    	form.setEnabled("area_juridico", false)
    }

    if (ativAtual == 0 || ativAtual == 4 || ativAtual == 33 || ativAtual == 12 || ativAtual == 13 || ativAtual == 14 || 
		ativAtual == 15 || ativAtual == 16 || ativAtual == 17 || ativAtual == 125 || ativAtual == 106 || ativAtual == 123 || 
		ativAtual == 122 || ativAtual == 127 || ativAtual == 107 || ativAtual == 112 || ativAtual == 117 || ativAtual == 121 || 
		ativAtual == 104 || ativAtual == 114 || ativAtual == 118 || ativAtual == 115 || ativAtual == 113 || ativAtual == 120 ||
		ativAtual == 171 || ativAtual == 170 || ativAtual == 176 || ativAtual == 177 || ativAtual == 178) {

        form.setEnabled("radiotypes", false)
    }

    if (ativAtual == 24 || ativAtual == 35 || ativAtual == 36 || ativAtual == 120 || ativAtual == 124 || ativAtual == 111 || 
		ativAtual == 109) {
        form.setEnabled("radiotypes", true)
    }


    if (ativAtual == 37 || ativAtual == 38) {
        form.setEnabled("txaObservacao", false)
    }

    if (ativAtual != 123 && ativAtual != 192) {
        form.setEnabled("nr_solic_juridico", false)
    }
    
    if (ativAtual == 4 || ativAtual == 0) {
        form.setEnabled("titulo", true)
        //form.setEnabled("fdAnexo", false);
    	//form.setEnabled("fnAnexo", false);
    }/* else {
        form.setEnabled("titulo", false)
        form.setEnabled("inputNmRepresentante", false)
        form.setEnabled("novaImplantacao", false)
        form.setEnabled("inputProdImplantacao", false)
        form.setEnabled("inputTempoContrato", false)
        form.setEnabled("inputGWP", false)
        form.setEnabled("inputDataInicio", false)
        form.setEnabled("inputNmCRM", false)
    }*/

}