function displayFields(form, customHTML) {

    var numProcesso = getValue("WKNumProces");
    var ativAtual = getValue("WKNumState");
    var MODE = form.getFormMode();
    var customJS = "<script>";

    form.setValue("idSolic", numProcesso);

    customHTML.append("<script>var ativAtual = " + ativAtual + ", numProcess = " + numProcesso + "</script>");

    if(MODE == "ADD"){
		
		/**
		 * Os campos que armazenam as descrições dos anexos, deverão ter seus valores setados no modo ADD caso estejam bloqueados pelo enableFields em ADD.
		 * Caso contrário, terão seus valores zerados e as funções para anexos não funcionarão como esperado.
	     * Isso não se aplica as tabelas pai e filho, pois a descrição do anexo é gravada no campo mo momento em que é adicionada uam nova linha
		 */ 
	
    	form.setValue("fdAnexo", "Cronograma");
	} 
    
	customJS += "function getMode(){ return '" + MODE + "'};";
	customJS += "displayBtnFiles();";
	customJS += "</script>"	
	customHTML.append(customJS);
	
	if (ativAtual == 125 || ativAtual == 106 || ativAtual == 123 || ativAtual == 122 || ativAtual == 107 || ativAtual == 112 || 
		ativAtual == 117 || ativAtual == 121 || ativAtual == 104 || ativAtual == 114 || ativAtual == 124 || ativAtual == 111 || 
		ativAtual == 109 || ativAtual == 171 || ativAtual == 170 || ativAtual == 176 || ativAtual == 177 || ativAtual == 178){
		form.setVisibleById("div-Alerta", true);
	} else {
        form.setVisibleById("div-Alerta", false);
    }

    if (ativAtual == 24 || ativAtual == 35 || ativAtual == 36 || ativAtual == 120 || ativAtual == 124 || ativAtual == 111 || 
		ativAtual == 109) {
        form.setVisibleById("painel-Aprovacao", true);
    } else {
        form.setVisibleById("painel-Aprovacao", false);
    }
    
    if (ativAtual == 106) {
        form.setVisibleById("painel-Areas", true);
    }
    
    if (ativAtual == 106 || ativAtual == 120 || ativAtual == 109 || ativAtual == 122 || ativAtual == 109 || ativAtual == 127 || 
		ativAtual == 107 || ativAtual == 112 || ativAtual == 117 || ativAtual == 121 || ativAtual == 104 || ativAtual == 114 || 
		ativAtual == 118 || ativAtual == 115 || ativAtual == 113 || ativAtual == 124 || ativAtual == 111 || ativAtual == 171 || 
		ativAtual == 170 || ativAtual == 176 || ativAtual == 177 || ativAtual == 178) {
        form.setVisibleById("painel-Cronograma", true);
    } else {
        form.setVisibleById("painel-Cronograma", false)
    }
    
    if (ativAtual != 0 && ativAtual != 4 && ativAtual != 12 && ativAtual != 14 && ativAtual != 16 && ativAtual != 15 && ativAtual != 13 && 
		ativAtual != 17 && ativAtual != 24 && ativAtual != 35 && ativAtual != 36 && ativAtual != 38) {
        form.setVisibleById("campos-Parte1", true);
        form.setVisibleById("campos-Parte2", true);
    }else{
    	form.setVisibleById("campos-Parte1", false);
        form.setVisibleById("campos-Parte2", false);
    }
}