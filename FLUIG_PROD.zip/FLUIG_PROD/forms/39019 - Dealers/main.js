$(document).ready(function() {

	$("#controle_linha_hist").val("")
	
    //PRIMEIRA TELA SOLICITANTE
    if (ativAtual == 0 || ativAtual == 4) {    	
        setData();
        //pegarNome();	
    }
	pegarNome();
	
	if (ativAtual == 123 || ativAtual == 120 || ativAtual == 124 || ativAtual == 111 || ativAtual == 109 || ativAtual == 37) {
        $("#div_nr_juridico").css("display", "block");
	}else{
		$("#div_nr_juridico").css("display", "none");
	}
	
	if (ativAtual != 0 && ativAtual != 4 && ativAtual != 12 && ativAtual != 14 && ativAtual != 16 && ativAtual != 15 && ativAtual != 13 && 
		ativAtual != 17 && ativAtual != 24 && ativAtual != 35 && ativAtual != 36){
	    FLUIGC.calendar(".campoData",{
			pickDate: true,
			pickTime: false,
			sideBySide: true
		});
    }
	
	if (ativAtual != 13 && ativAtual != 106 && ativAtual != 109 && ativAtual != 120) {
		//Para ocultar o botão de upload/delete
        invisibleBtnUpload("fnAnexo")
	}
	
	if (ativAtual == 120 || ativAtual == 124 || ativAtual == 111 || ativAtual == 109) {
		setRadiosAcordo();
	}
	

    if (ativAtual == 36) {
        $("#Riscos").css("display", "block");

        setTimeout(() => {
            window["selectAreaDevolucao"].disable(true);
        }, 500);

    }

    if (ativAtual == 24 || ativAtual == 35 || ativAtual == 36) {
        setRadiosAcordo();

        setTimeout(() => {
            window['selectAreaDevolucao'].clear();
        }, 500);

        if (ativAtual == 35 || ativAtual == 36) {
            $('[name=selectAreaDevolucao]').parent().hide()
        }
    }else{
    	$("#campo-Devolucao").css("display", "none");
    }

    if (!ativAtual == 24) {

        setTimeout(() => {
            window["selectAreaDevolucao"].disable(true);
        }, 500);

    }

    if (ativAtual == 12 || ativAtual == 14 || ativAtual == 16 || ativAtual == 15 || ativAtual == 13 || ativAtual == 17 || 
		ativAtual == 24 || ativAtual == 35 || ativAtual == 36 || ativAtual == 125 || ativAtual == 106 || ativAtual == 123 ||	
		ativAtual == 122 || ativAtual == 127 || ativAtual == 107 || ativAtual == 112 || ativAtual == 117 || ativAtual == 121 || 
		ativAtual == 104 || ativAtual == 114 || ativAtual == 118 || ativAtual == 115 || ativAtual == 113 || ativAtual == 120 || 
		ativAtual == 124 || ativAtual == 111 || ativAtual == 109 || ativAtual == 171 || ativAtual == 170 || ativAtual == 176 || 
		ativAtual == 177 || ativAtual == 178){
        $("#txaObservacao").val('');
    }

    if (ativAtual == 106){
		$('#hid_area_juridico').val("sim");
    }
    
    if (ativAtual == 120){
	    $('#area_juridico').prop('checked', true);
    }
    
    if (ativAtual == 106 || ativAtual == 120){
    	//Verificando as áreas pra onde a implantação enviará
	    $('#area_produtos').click(function() {
	        if(this.checked) {
	        	$('#hid_area_produtos').val("sim");
	        }else{
	        	$('#hid_area_produtos').val("");
	        }                
	    });
	    $('#area_ti_projetos').click(function() {
	        if(this.checked) {
	        	$('#hid_area_ti_projetos').val("sim");
	        }else{
	        	$('#hid_area_ti_projetos').val("");
	        }                
	    });
	    $('#area_ti_infra').click(function() {
	        if(this.checked) {
	        	$('#hid_area_ti_infra').val("sim");
	        }else{
	        	$('#hid_area_ti_infra').val("");
	        }                
	    });
	    $('#area_atuarial').click(function() {
	        if(this.checked) {
	        	$('#hid_area_atuarial').val("sim");
	        }else{
	        	$('#hid_area_atuarial').val("");
	        }                
	    });
	    $('#area_tax').click(function() {
	        if(this.checked) {
	        	$('#hid_area_tax').val("sim");
	        }else{
	        	$('#hid_area_tax').val("");
	        }                
	    });
	    $('#area_sinistros').click(function() {
	        if(this.checked) {
	        	$('#hid_area_sinistros').val("sim");
	        }else{
	        	$('#hid_area_sinistros').val("");
	        }                
	    });
	    $('#area_crm').click(function() {
	        if(this.checked) {
	        	$('#hid_area_crm').val("sim");
	        }else{
	        	$('#hid_area_crm').val("");
	        }                
	    });
	    $('#area_call_center').click(function() {
	        if(this.checked) {
	        	$('#hid_area_call_center').val("sim");
	        }else{
	        	$('#hid_area_call_center').val("");
	        }                
	    });
	    $('#area_treinamento').click(function() {
	        if(this.checked) {
	        	$('#hid_area_treinamento').val("sim");
	        }else{
	        	$('#hid_area_treinamento').val("");
	        }                
	    });
	    $('#area_marketing').click(function() {
	        if(this.checked) {
	        	$('#hid_area_marketing').val("sim");
	        }else{
	        	$('#hid_area_marketing').val("");
	        }                
	    });
	    $('#area_cx').click(function() {
	        if(this.checked) {
	        	$('#hid_area_cx').val("sim");
	        }else{
	        	$('#hid_area_cx').val("");
	        }                
	    });
	    $('#area_digital').click(function() {
	        if(this.checked) {
	        	$('#hid_area_digital').val("sim");
	        }else{
	        	$('#hid_area_digital').val("");
	        }                
	    });
	    $('#area_compliance').click(function() {
	        if(this.checked) {
	        	$('#hid_area_compliance').val("sim");
	        }else{
	        	$('#hid_area_compliance').val("");
	        }                
	    });
	    $('#area_juridico').click(function() {
	        if(this.checked) {
	        	$('#hid_area_juridico').val("sim");
	        }else{
	        	$('#hid_area_juridico').val("");
	        }                
	    });
	    $('#area_contas').click(function() {
	        if(this.checked) {
	        	$('#hid_area_contas').val("sim");
	        }else{
	        	$('#hid_area_contas').val("");
	        }                
	    });
	    $('#area_supply').click(function() {
	        if(this.checked) {
	        	$('#hid_area_supply').val("sim");
	        }else{
	        	$('#hid_area_supply').val("");
	        }                
	    });
	    $('#area_riscos').click(function() {
	        if(this.checked) {
	        	$('#hid_area_riscos').val("sim");
	        }else{
	        	$('#hid_area_riscos').val("");
	        }                
	    });
    }
    
    //Alteração no texto do alerta
    if(ativAtual == 125){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento do Comercial Kickoff";
    }
    if(ativAtual == 106){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento da Implantação";
    }
    if(ativAtual == 123){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento do Jurídico";
    }
    if(ativAtual == 122){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Produtos";
    }
    if(ativAtual == 107){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de TI Infra";
    }
    if(ativAtual == 112){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento do Atuarial";
    }
    if(ativAtual == 117){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento do Tax/Contábil";
    }
    if(ativAtual == 121){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Sinistros";
    }
    if(ativAtual == 104){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento do CRM";
    }
    if(ativAtual == 114){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento do Call Center";
    }
    if(ativAtual == 124){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Liberação Compliance";
    }
    if(ativAtual == 111){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Liberação Produtos";
    }
    if(ativAtual == 109){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Liberação Implantação";
    }
    if(ativAtual == 171){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Digital";
    }
    if(ativAtual == 170){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Compliance";
    }
    if(ativAtual == 176){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Contas à Receber/Pagar";
    }
    if(ativAtual == 177){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Supply Chain";
    }
    if(ativAtual == 178){
    	document.getElementsByClassName("alert-info")[0].innerText = "É necessário anexar o documento de Riscos";
    }
});

function validaSim(inpt) {

    if (ativAtual == 24) {
        if (inpt.value == 'sim' && inpt.checked == true) {
            window["selectAreaDevolucao"].disable(true);
            console.log("Sim");
        } else if (inpt.value == 'nao' && inpt.checked == true) {
            window["selectAreaDevolucao"].disable(false);
            console.log("Nao");
        }
    }
    
    if (ativAtual == 120) {
    	if (inpt.value == 'sim' && inpt.checked == true) {
    		$("#painel-Areas").hide();
        } else if (inpt.value == 'nao' && inpt.checked == true) {
        	$("#painel-Areas").show();
        }
    }

}


function setSelectedZoomItem(selectedItem) {
    var validacao = $("#hid_Validacao"); // value = 1
    var atuarialApproval = $("#hid_atuarialApproval");
    var toolKitMarketing = $("#hid_toolKitMarketing");
    var toolKitProduto = $("#hid_toolKitProduto");
    var toolKitAtuarial = $("#hid_toolKitAtuarial");
    var toolKitImplantacao = $("#hid_toolKitImplantacao");
    var compliance = $("#hid_compliance");

    if (ativAtual == 24) {
        atuarialApproval[0].value = '0';
        toolKitMarketing[0].value = '0';
        toolKitProduto[0].value = '0';
        toolKitAtuarial[0].value = '0';
        toolKitImplantacao[0].value = '0';
        compliance[0].value = '0';

        var valores = [];
        $('#selectAreaDevolucao').each(function() {
            var valor = $(this).val();
            if (valor != "")
                valores.push(valor);
        });
        console.log(valores);

        if (valores.length > 0) {
            validacao[0].value = '0';

            valores[0].forEach(item => {
                if (item == "Atuarial Approval") {
                    atuarialApproval[0].value = '1';
                } else if (item == "ToolKit Marketing") {
                    toolKitMarketing[0].value = '1';
                } else if (item == "ToolKit Produto") {
                    toolKitProduto[0].value = '1';
                } else if (item == "ToolKit Atuarial") {
                    toolKitAtuarial[0].value = '1';
                } else if (item == "ToolKit Implantacao") {
                    toolKitImplantacao[0].value = '1';
                } else if (item == "Compliance") {
                    compliance[0].value = '1';
                }
            })
        }
    }


}

var beforeSendValidate = function(ativAtual, nextState) {

    var msg = "";
    
    if (ativAtual == 106 || ativAtual == 109 || ativAtual == 120) {
    	//Validar anexo
    	if (invalidFile("fnAnexo")) {
    		msg += "Anexo não encontrado. \n";
    	}
    	if (document.getElementById("fnAnexo").value == "") {
            msg += "O cronograma não foi anexado. \n";
        }
	}
    
    if (ativAtual == 123){
    	if (document.getElementById("nr_solic_juridico").value == "") {
            msg += "É obrigatório preencher o campo Nº Solicitação Jurídico. \n";
        }
    }
    		
    if (ativAtual != 0 && ativAtual != 4 && ativAtual != 12 && ativAtual != 14 && ativAtual != 16 && ativAtual != 15 && ativAtual != 13 && 
		ativAtual != 17 && ativAtual != 24 && ativAtual != 35 && ativAtual != 36){
    	if (document.getElementById("inputNmRepresentante").value == "") {
            msg += "É obrigatório preencher o campo Representante/Estipulante. \n";
        }
    	if (document.getElementById("inputProdImplantacao").value == "") {
            msg += "É obrigatório preencher o campo Produto a ser implantado. \n";
        }
    	if (document.getElementById("inputTempoContrato").value == "") {
            msg += "É obrigatório preencher o campo Tempo de Contrato. \n";
        }
    	if (document.getElementById("inputGWP").value == "") {
            msg += "É obrigatório preencher o campo GWP. \n";
        }
    	if (document.getElementById("inputNmCRM").value == "") {
            msg += "É obrigatório preencher o campo Nome do CRM. \n";
        }
    }
    
    if (ativAtual == 0 || ativAtual == 4 || ativAtual == 12 || ativAtual == 14 || ativAtual == 16 || ativAtual == 15 || 
		ativAtual == 13 || ativAtual == 17 || ativAtual == 24 || ativAtual == 35 || ativAtual == 36 || ativAtual == 125 || 
		ativAtual == 106 || ativAtual == 123 ||	ativAtual == 122 || ativAtual == 127 || ativAtual == 107 || ativAtual == 112 || 
		ativAtual == 117 || ativAtual == 121 || ativAtual == 104 || ativAtual == 114 || ativAtual == 118 || ativAtual == 115 || 
		ativAtual == 113 || ativAtual == 120 || ativAtual == 124 || ativAtual == 111 || ativAtual == 109 || ativAtual == 171 || 
		ativAtual == 170 || ativAtual == 176 || ativAtual == 177 || ativAtual == 178) {
        // pega sempre pelo name
        if (document.getElementById("txaObservacao").value == "") {
            msg += "É obrigatório preencher o campo Observação. \n";
        }
    }

    if (ativAtual == 24) {
        var valorRadio = document.getElementsByName("radiotypes")

        if (valorRadio[0].checked == '' && valorRadio[1].checked == '') {
            msg += "É obrigatório selecionar o De Acordo. \n";
        } else if (valorRadio[1].checked == true && document.getElementById("selectAreaDevolucao").value == "") {
            msg += "É obrigatório selecionar a área para devolução. \n";
        }
    }

    if (ativAtual == 36 || ativAtual == 35 || ativAtual == 120 || ativAtual == 124 || ativAtual == 111 || ativAtual == 109) {
        var valorRadio = document.getElementsByName("radiotypes")

        if (valorRadio[0].checked == '' && valorRadio[1].checked == '' && valorRadio[2].checked == '') {
            msg += "É obrigatório selecionar o De Acordo. \n";
        }
    }
    
    if (ativAtual == 106) {  	
        if (document.getElementById("area_produtos").checked == false && document.getElementById("area_ti_projetos").checked == false &&
    		document.getElementById("area_ti_infra").checked == false && document.getElementById("area_atuarial").checked == false &&
    		document.getElementById("area_tax").checked == false && document.getElementById("area_sinistros").checked == false &&
    		document.getElementById("area_crm").checked == false && document.getElementById("area_call_center").checked == false &&
    		document.getElementById("area_treinamento").checked == false && document.getElementById("area_marketing").checked == false &&
    		document.getElementById("area_cx").checked == false && document.getElementById("area_digital").checked == false && 
    		document.getElementById("area_contas").checked == false && document.getElementById("area_compliance").checked == false && 
    		document.getElementById("area_riscos").checked == false && document.getElementById("area_supply").checked == false) {
            msg += "É obrigatório selecionar pelo menos uma área. \n";
        }
    }

    if (msg !== "") {
        throw (msg);
    }


    if (ativAtual == 12 || ativAtual == 14 || ativAtual == 16 || ativAtual == 15 || ativAtual == 13 || ativAtual == 17 || 
		ativAtual == 24 || ativAtual == 35 || ativAtual == 36 || ativAtual == 125 || ativAtual == 106 || ativAtual == 123 || 
		ativAtual == 122 || ativAtual == 127 || ativAtual == 107 || ativAtual == 112 || ativAtual == 117 || ativAtual == 121 || 
		ativAtual == 104 || ativAtual == 114 || ativAtual == 118 || ativAtual == 115 || ativAtual == 113 || ativAtual == 120 || 
		ativAtual == 124 || ativAtual == 111 || ativAtual == 109 || ativAtual == 171 ||	ativAtual == 170 || ativAtual == 176 || 
		ativAtual == 177 || ativAtual == 178) {
        // só cria um historico se estiver tudo ok/ ou passar p/ proxima atividade

        // pega todos os valores dos campos
        var UsuarioAtual = $("[id='inputUsuarioAtual']").val()
        var DataAtual = $("[id='inputDataAtual']").val()
        var txaObservacao = $("[id='txaObservacao']").val()
        let valRadioAcordo = $('input[name=radiotypes]:checked').val()
        
        if($("#controle_linha_hist").val() == ""){
        	// cria uma nova linha dentro da outra tabela p/ setar os valores
            let id = wdkAddChild("tabelaAddHistorico")
            $("#UsuarioAtualHistorico___" + id).val(UsuarioAtual)
            $("#DataAtualHistorico___" + id).val(DataAtual)
            $("#DeAcordoHistorico___" + id).val(valRadioAcordo)
            if (ativAtual == 12) { $("#EtapaFluxoHistorico___" + id).val('Atuarial Approval') }
            if (ativAtual == 14) { $("#EtapaFluxoHistorico___" + id).val('ToolKit Marketing') }
            if (ativAtual == 16) { $("#EtapaFluxoHistorico___" + id).val('ToolKit Produto') }
            if (ativAtual == 15) { $("#EtapaFluxoHistorico___" + id).val('ToolKit Atuarial') }
            if (ativAtual == 13) { $("#EtapaFluxoHistorico___" + id).val('ToolKit Implantação') }
            if (ativAtual == 17) { $("#EtapaFluxoHistorico___" + id).val('Compliance') }
            if (ativAtual == 24) { $("#EtapaFluxoHistorico___" + id).val('Comercial confere') }
            if (ativAtual == 35) { $("#EtapaFluxoHistorico___" + id).val('Riscos') }
            if (ativAtual == 36) { $("#EtapaFluxoHistorico___" + id).val('Aprovação Externa') }
            if (ativAtual == 125) { $("#EtapaFluxoHistorico___" + id).val('Comercial KickOff') }
            if (ativAtual == 106) { $("#EtapaFluxoHistorico___" + id).val('Implantação') }
            if (ativAtual == 123) { $("#EtapaFluxoHistorico___" + id).val('Jurídico') }
            if (ativAtual == 122) { $("#EtapaFluxoHistorico___" + id).val('Produtos') }
            if (ativAtual == 127) { $("#EtapaFluxoHistorico___" + id).val('TI Projetos') }
            if (ativAtual == 107) { $("#EtapaFluxoHistorico___" + id).val('TI Infra') }
            if (ativAtual == 112) { $("#EtapaFluxoHistorico___" + id).val('Atuarial') }
            if (ativAtual == 117) { $("#EtapaFluxoHistorico___" + id).val('Tax/Contábil') }
            if (ativAtual == 121) { $("#EtapaFluxoHistorico___" + id).val('Sinistros') }
            if (ativAtual == 104) { $("#EtapaFluxoHistorico___" + id).val('CRM') }
            if (ativAtual == 114) { $("#EtapaFluxoHistorico___" + id).val('Call Center') }
            if (ativAtual == 118) { $("#EtapaFluxoHistorico___" + id).val('Treinamento') }
            if (ativAtual == 115) { $("#EtapaFluxoHistorico___" + id).val('Marketing') }
            if (ativAtual == 113) { $("#EtapaFluxoHistorico___" + id).val('CX') }
            if (ativAtual == 120) { $("#EtapaFluxoHistorico___" + id).val('Aprovação Dealers') }
            if (ativAtual == 124) { $("#EtapaFluxoHistorico___" + id).val('Liberação Compliance') }
            if (ativAtual == 111) { $("#EtapaFluxoHistorico___" + id).val('Liberação Produtos') }
            if (ativAtual == 109) { $("#EtapaFluxoHistorico___" + id).val('Liberação Implantação') }
            if (ativAtual == 171) { $("#EtapaFluxoHistorico___" + id).val('Digital') }
            if (ativAtual == 170) { $("#EtapaFluxoHistorico___" + id).val('Compliance') }
            if (ativAtual == 176) { $("#EtapaFluxoHistorico___" + id).val('Contas à Receber/Pagar') }
            if (ativAtual == 177) { $("#EtapaFluxoHistorico___" + id).val('Supply Chain') }
            if (ativAtual == 178) { $("#EtapaFluxoHistorico___" + id).val('Riscos') }
            $("#ObservacaoHistorico___" + id).val(txaObservacao)
            
            $("#controle_linha_hist").val("criada")
        }
    }
}

function setRadiosAcordo(params) {
    let valRadioAcordo = document.querySelectorAll("input[name=radiotypes]");
    valRadioAcordo.forEach(item => {
        item.checked = false
    })
}

function pegarNome() {
    var usuario = parent.WCMAPI.user;

    return document.getElementById('inputUsuarioAtual').value = usuario;
}

function setData(params) {
    let dataAtual = new Date().toLocaleDateString();
    return document.getElementById('inputDataAtual').value = dataAtual;
}