var results = []
const PARENTIDCONTRATO = "99";
const PARENTIDANEXOS = "100";
const TOAST = (message, type) => {
    FLUIGC.toast({
        title: '',
        message: message,
        type: type
    });
}

$(document).ready(() => {
    setaSelectContabil()
    // hideShowParecer()
    let state = stateAtual.value;
    uploadDocument();
    getFornecedores('fornecedor');
    $(".aprovGrupo").hide();
    if ($("[name^='aprovOutroGrupo']:checked").val() == 'nao' || $("[name^='aprovOutroGrupo']:checked").val() == '') {
        $(".divGrupo").hide();
    } else {
        $(".divGrupo").show();
    }
    if (state == ABERTURA) {
        setTimeout(() => {
            usuarioInicial()
        }, 1200)

        $("#divConta").hide();
        dataAbertura.value = getTodayDate()
        getPreviousContracts('contratos');
        //getFornecedores('fornecedor');
    } else {
        if ($("#idAnexo").val()) {
            $("#ver_arquivo").show();
            $("#anexo").hide();
            if (state == INICIO) {
                $("#deletar_arquivo").show()
            }
        }
        $('[name^="upFile___"]').attr('disabled', true)
        $('[name^="upFile___"]').parent().attr('disabled', true)
        if (state == INICIO) {
            alcadaPorGrupo()
        }
        if ($('#tipoVisualizacao').val() != 'VIEW') {
            // $('#_saldo').val($('#valorPO').val())
            // $('#saldo').val($('#valorPO').val())
        }
    }
    if (state == AVALIACAO_FINANCEIRO) {
        $(".aprovGrupo").show();
        if ($("#selGrupoHidden").val()) {
            $("#divBotoesAprovacao").css("pointer-events", "none");
            $('.aprovGrupo').css("pointer-events", "none");
        }
        $('[name="responsavelFinanceiro"]').val(idToUserName($('[name="usuarioAtual"]').val()));
    }
    if ($('#temContratoSim').prop('checked') || $('#_temContratoSim').prop('checked')) {
        $('.divContratoInput').show()
        if ($('#_temContratoSim').prop('checked')) {
            $('#_contratos').text($('[name=nameContrato]').val())
        } else if ($('#tipoVisualizacao').val() == 'VIEW') {
            $('#contratos').text($('[name=nameContrato]').val())
        }
    } else {
        $('.divContratoInput').hide()
    }

    if ($('#poMaiorTres').val() == 'true') {
        $('#alert').show()
    }

    if (APROVACAO_RESPONSAVEL == state) {
        $("#aprovacaoContestado").parent().hide();
    }

    events()

    $('.valor').mask("#.##0,00", {
        reverse: true
    });

    document.getElementById('inicioPO').max = new Date().toISOString().split("T")[0];
    $('#inicioPO').on('change', (element) => {
        var value = element.target.value
        var date = new Date().toISOString().split("T")[0]
        if (value > date) {
            element.target.value = date
        }
    })

    document.getElementById('fimPO').min = new Date().toISOString().split("T")[0];
    $('#fimPO').on('change', (element) => {
        var value = element.target.value
        var date = new Date().toISOString().split("T")[0]
        if (value < date) {
            element.target.value = date
        }
    })

    // if ($('#tipoVisualizacao').val() != 'VIEW') {
    //     let SupSubSoli = $('#optionsSupSubSoli').val()
    //     let SupSubResp = $('#optionsSupSubResp').val()
    //     let ApSubSoli = $('#optionsApSubSoli').val()
    //     let ApSubResp = $('#optionsApSubResp').val()

    //     SupSubSoli = JSON.parse(SupSubSoli)
    //     SupSubResp = JSON.parse(SupSubResp)
    //     ApSubSoli = JSON.parse(ApSubSoli)
    //     ApSubResp = JSON.parse(ApSubResp)

    //     let valSupSubSoli = SupSubSoli.find(e => e.id == $("#valSupSubSoli").val())
    //     let valSupSubResp = SupSubResp.find(e => e.id == $("#valSupSubResp").val())
    //     let valApSubSoli = ApSubSoli.find(e => e.id == $("#valApSubSoli").val())
    //     let valApSubResp = ApSubResp.find(e => e.id == $("#valApSubResp").val())

    //     if ($('[name="supSubSoli"]')[0].type == 'hidden') {
    //         $('[name="_supSubSoli"]').text(valSupSubSoli.text)

    //     } else {
    //         $('[name="supSubSoli"]').select2({
    //             data: SupSubSoli,
    //             theme: "bootstrap",
    //             language: "pt-BR"
    //         }).on("select2:select", (e) => {
    //             $("[name=valSupSubSoli]").val(e.currentTarget.value)
    //         })

    //         $('[name="supSubSoli"]').on("select2:unselect", (e) => {
    //             $("[name=valSupSubSoli]").val('')
    //         });

    //         $('[name="supSubSoli"]').val(valSupSubSoli.id).change()
    //     }


    //     if ($('[name="supSubResp"]')[0].type == 'hidden') {

    //         $('[name="_supSubResp"]').text(valSupSubResp.text)

    //     } else {
    //         $('[name="supSubResp"]').select2({
    //             data: SupSubResp,
    //             theme: "bootstrap",
    //             language: "pt-BR"
    //         }).on("select2:select", (e) => {
    //             $("[name=valSupSubResp]").val(e.currentTarget.value)
    //         })

    //         $('[name="supSubResp"]').on("select2:unselect", (e) => {
    //             $("[name=valSupSubResp]").val('')
    //         });

    //         $('[name="supSubResp"]').val(valSupSubResp.id).change()
    //     }

    //     if ($('[name="apSubSoli"]')[0].type == 'hidden') {

    //         $('[name="_apSubSoli"]').text(valApSubSoli.text)

    //     } else {
    //         $('[name="apSubSoli"]').select2({
    //             data: ApSubSoli,
    //             theme: "bootstrap",
    //             language: "pt-BR"
    //         }).on("select2:select", (e) => {
    //             $("[name=valApSubSoli]").val(e.currentTarget.value)
    //         })

    //         $('[name="apSubSoli"]').on("select2:unselect", (e) => {
    //             $("[name=valApSubSoli]").val('')
    //         });

    //         $('[name="apSubSoli"]').val(valApSubSoli.id).change()
    //     }

    //     if ($('[name="apSubResp"]')[0].type == 'hidden') {

    //         $('[name="_apSubResp"]').text(valApSubResp.text)

    //     } else {
    //         $('[name="apSubResp"]').select2({
    //             data: ApSubResp,
    //             theme: "bootstrap",
    //             language: "pt-BR"
    //         }).on("select2:select", (e) => {
    //             $("[name=valApSubResp]").val(e.currentTarget.value)
    //         })

    //         $('[name="apSubResp"]').on("select2:unselect", (e) => {
    //             $("[name=valApSubResp]").val('')
    //         });

    //         $('[name="apSubResp"]').val(valApSubResp.id).change()
    //     }

    // } else {

    //     let SupSubSoli = $('[name=optionsSupSubSoli]').val()
    //     let SupSubResp = $('[name=optionsSupSubResp]').val()
    //     let ApSubSoli = $('[name=optionsApSubSoli]').val()
    //     let ApSubResp = $('[name=optionsApSubResp]').val()

    //     SupSubSoli = JSON.parse(SupSubSoli)
    //     SupSubResp = JSON.parse(SupSubResp)
    //     ApSubSoli = JSON.parse(ApSubSoli)
    //     ApSubResp = JSON.parse(ApSubResp)

    //     let valSupSubSoli = SupSubSoli.find(e => e.id == $("#valSupSubSoli").val())
    //     let valSupSubResp = SupSubResp.find(e => e.id == $("#valSupSubResp").val())
    //     let valApSubSoli = ApSubSoli.find(e => e.id == $("#valApSubSoli").val())
    //     let valApSubResp = ApSubResp.find(e => e.id == $("#valApSubResp").val())

    //     $('[name=supSubSoli]').text(valSupSubSoli.text)
    //     $('[name=supSubResp]').text(valSupSubResp.text)
    //     $('[name=apSubSoli]').text(valApSubSoli.text)
    //     $('[name=apSubResp]').text(valApSubResp.text)
    // }



});

function getTodayDate() {
    let data = new Date;
    var dataString = "" + ((parseInt(data.getDate()) < 10) ? "0" + data.getDate() : data.getDate()) + "/" + (((parseInt(data.getMonth()) + 1) < 10) ? "0" + (parseInt(data.getMonth()) + 1) : data.getMonth() + 1) + "/" + data.getFullYear() + ""
    return dataString
}

function usuarioInicial() {
    /*Table no formulario do homolog está com um X na table, ja no prod nao. Descomentar quando for usar no homolog
    let constraintUserCPF = DatasetFactory.createConstraint('tablename', 'tabelaUserXCpf', 'tabelaUserXCpf', ConstraintType.MUST);
    */

    let constraintUserCPF = DatasetFactory.createConstraint('tablename', 'tabelaUserCpf', 'tabelaUserCpf', ConstraintType.MUST);

    var datasetGrupo = DatasetFactory.getDataset("ds_usuario_cpf", null, [constraintUserCPF], null);
    let centroCusto = "";
    let idCentroCusto = "";
    let user = parent.WCMAPI.userCode
    datasetGrupo.values.forEach((e) => {
        if (e.userId == user) {
            centroCusto = e.centroCusto;
            idCentroCusto = e.centroCustoId;
        }
    })

    window["centCusSolic"].setValue(centroCusto);
    $("#idCenCusSolic").val(idCentroCusto);
    window["cenCustResp"].setValue(centroCusto);
    $("#idCenCusResp").val(idCentroCusto);
}

// function alcadaAprovacao(codCentroCusto, type) {
//     // let c1 = DatasetFactory.createConstraint('tablename', 'tabelaUserXCpf', 'tabelaUserXCpf', ConstraintType.MUST);
//     // let c2 = DatasetFactory.createConstraint('version', 1000, 1000, ConstraintType.MUST);
//     // var datasetCentroCusto = DatasetFactory.getDataset("ds_usuario_cpf", null, [c1, c2], null);
//     // let codCentroCusto = "";
//     // datasetCentroCusto.values.forEach((e)=>{
//     //     if(e.zoomColleague.indexOf(user) > -1){
//     //         codCentroCusto = e.centroCustoId;
//     //     }
//     // })

//     // c1 = DatasetFactory.createConstraint('codCentroCusto', codCentroCusto, codCentroCusto, ConstraintType.MUST);
//     // let c2 = DatasetFactory.createConstraint('codCentroCusto', codCentroCusto, codCentroCusto, ConstraintType.MUST);
//     // var dataset = DatasetFactory.getDataset('ds_alcada_assurant', null, [c1], null);

//     // console.table(dataset.values, ['index', 'codCentroCusto', 'documentid'])
//     // if(dataset.values.length == 0){
//     //     $("#alertAlcada").show();
//     // }else{
//     //     $("#alertAlcada").hide();
//     // }
//     c1 = DatasetFactory.createConstraint('tablename', 'tableCadastroAlcada', 'tableCadastroAlcada', ConstraintType.MUST);
//     let c2 = DatasetFactory.createConstraint('codCentroCusto', codCentroCusto, codCentroCusto, ConstraintType.MUST);
//     dataset = DatasetFactory.getDataset('ds_alcada_assurant', null, [c1], ['prioridade']);

//     console.table(dataset.values, ['index', 'documentid', 'usuario', 'substitutos'])
//     let users_processos_po = []

//     dataset.values.forEach((e) => {
//         if (e.hiddenProcesso.indexOf('processo_po') > -1 && e.codCentroCusto == codCentroCusto) {
//             users_processos_po.push(e);
//         }
//     })
//     dataset.values = users_processos_po
//     console.table(users_processos_po)
//     for (i in type) {

//         if (type[i].split('_')[0] == "SUPERIOR") {

//             if (type[i].split('_')[1] == "SOLICITANTE") {

//                 $('[name="supSoli"]').val(dataset.values[0].usuario);
//                 $('[name="idUsersupSoli"]').val(usernameToId(dataset.values[0].usuario));
//                 $('[name="aprovador"]').val(usernameToId(dataset.values[0].usuario))

//                 let subs = dataset.values[0].substitutos.split('');
//                 let options = [];
//                 for (index in subs) {
//                     let nomeUser = (subs[index]);
//                     if (nomeUser != 0 || nomeUser == '' || nomeUser == null) {
//                         options.push({ id: usernameToId(subs[index]), text: nomeUser });
//                     } else {
//                         console.error('Erro ao recuperar o nome de Usuário na linha 31')
//                     }
//                 }

//                 options.unshift({ id: 'NS', text: 'Escolha um Substituto' })

//                 $('[name="supSubSoli"]').empty();

//                 $('[name="supSubSoli"]').select2({
//                     data: options,
//                     theme: "bootstrap",
//                     language: "pt-BR"
//                 }).on("select2:select", (e) => {
//                     $("[name=valSupSubSoli]").val(e.currentTarget.value)
//                 })

//                 $('[name="supSubSoli"]').on("select2:unselect", (e) => {
//                     $("[name=valSupSubSoli]").val('')
//                 });

//                 $('#optionsSupSubSoli').val(JSON.stringify(options))


//             } else {

//                 $('[name="supResp"]').val(dataset.values[0].usuario)
//                 $('[name="idUsersupResp"]').val(usernameToId(dataset.values[0].usuario))

//                 let subs = dataset.values[0].substitutos.split('')
//                 let options = [];

//                 for (index in subs) {
//                     let nomeUser = (subs[index])
//                     if (nomeUser != 0 || nomeUser != '' || nomeUser != null) {
//                         options.push({ id: usernameToId(subs[index]), text: nomeUser });
//                     } else {
//                         console.error('Erro ao recuperar o nome de Usuário na linha 46')
//                     }
//                 }

//                 options.unshift({ id: 'NS', text: 'Escolha um Substituto' })

//                 $('[name="supSubResp"]').empty();

//                 $('[name="supSubResp"]').select2({
//                     data: options,
//                     theme: "bootstrap",
//                     language: "pt-BR"
//                 }).on("select2:select", (e) => {
//                     $("[name=valSupSubResp]").val(e.currentTarget.value)
//                 })

//                 $('[name="supSubResp"]').on("select2:unselect", (e) => {
//                     $("[name=valSupSubResp]").val('')
//                 });

//                 $('#optionsSupSubResp').val(JSON.stringify(options))

//             }

//         } else {

//             if (type[i].split('_')[1] == "SOLICITANTE") {
//                 let valor = realToNumber(($('[name=valorPO]').val()) ? $('[name=valorPO]').val() : '0,00')
//                 for (i in dataset.values) {
//                     if ((realToNumber(dataset.values[i].valorInicial) <= valor && realToNumber(dataset.values[i].valorFinal) > valor) || i == (dataset.values.length - 1)) {
//                         $('[name="apSoli"]').val(dataset.values[i].usuario);
//                         $('[name="idUserapSoli"]').val(usernameToId(dataset.values[i].usuario));
//                         $('[name="valorAprov"]').val(realToNumber(dataset.values[i].valorFinal))

//                         let subs = dataset.values[i].substitutos.split('');
//                         let options = [];

//                         for (index in subs) {
//                             let nomeUser = (subs[index]);
//                             if (nomeUser != 0 || nomeUser != '' || nomeUser != null) {
//                                 options.push({ id: usernameToId(subs[index]), text: nomeUser });
//                             } else {
//                                 console.error('Erro ao recuperar o nome de Usuário na linha 31')
//                             }
//                         }

//                         options.unshift({ id: 'NS', text: 'Escolha um Substituto' })

//                         $('[name="apSubSoli"]').empty();

//                         $('[name="apSubSoli"]').select2({
//                             data: options,
//                             theme: "bootstrap",
//                             language: "pt-BR"
//                         }).on("select2:select", (e) => {
//                             $("[name=valApSubSoli]").val(e.currentTarget.value)
//                         })

//                         $('[name="apSubSoli"]').on("select2:unselect", (e) => {
//                             $("[name=valApSubSoli]").val('')
//                         });

//                         $('#optionsApSubSoli').val(JSON.stringify(options))


//                         break;
//                     }
//                 }


//             } else {

//                 let valor = realToNumber(($('[name=valorPO]').val()) ? $('[name=valorPO]').val() : '0,00')
//                 for (i in dataset.values) {
//                     if ((realToNumber(dataset.values[i].valorInicial) <= valor && realToNumber(dataset.values[i].valorFinal) > valor) || i == (dataset.values.length - 1)) {
//                         $('[name="apResp"]').val(dataset.values[i].usuario)
//                         $('[name="idUserapResp"]').val(usernameToId(dataset.values[i].usuario))

//                         let subs = dataset.values[i].substitutos.split('')
//                         let options = [];

//                         for (index in subs) {
//                             let nomeUser = (subs[index])
//                             if (nomeUser != 0 || nomeUser != '' || nomeUser != null) {
//                                 options.push({ id: usernameToId(subs[index]), text: nomeUser });
//                             } else {
//                                 console.error('Erro ao recuperar o nome de Usuário na linha 46')
//                             }
//                         }

//                         options.unshift({ id: 'NS', text: 'Escolha um Substituto' })

//                         $('[name="apSubResp"]').empty();

//                         $('[name="apSubResp"]').select2({
//                             data: options,
//                             theme: "bootstrap",
//                             language: "pt-BR"
//                         }).on("select2:select", (e) => {
//                             $("[name=valApSubResp]").val(e.currentTarget.value)
//                         })

//                         $('[name="apSubResp"]').on("select2:unselect", (e) => {
//                             $("[name=valApSubResp]").val('')
//                         });

//                         $('#optionsApSubResp').val(JSON.stringify(options))

//                         break;
//                     }
//                 }
//             }
//         }

//     }

//     return dataset
// }

function alcadaPorGrupo() {
    let user = parent.WCMAPI.userCode;
    let state = stateAtual.value;
    let valor = Number($("#valorPO").val().replace(/\./g, "").replace(",", "."));
    if (user != '' && valor != undefined) {
        $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
        let codCentroCusto = $("#codCentroCusto").val();
       /*Na table do homolog, tem um X no nome, ja no produção não. Descomentar ao usar no homolog
        let constraintUserCPF = DatasetFactory.createConstraint('tablename', 'tabelaUserXCpf', 'tabelaUserXCpf', ConstraintType.MUST);
        */
        let constraintUserCPF = DatasetFactory.createConstraint('tablename', 'tabelaUserCpf', 'tabelaUserCpf', ConstraintType.MUST);

        var datasetGrupo = DatasetFactory.getDataset("ds_usuario_cpf", null, [constraintUserCPF], null);
        let grupo = "";
        datasetGrupo.values.forEach((e) => {
            if (e.userId == user) {
                grupo = e.grupo;
            }
        })

        c1 = DatasetFactory.createConstraint('tablename', 'tableCadastroAlcada', 'tableCadastroAlcada', ConstraintType.MUST);
        //let c2 = DatasetFactory.createConstraint('grupo', grupo, grupo, ConstraintType.MUST);
        datasetAprovadores = DatasetFactory.getDataset('ds_alcada_assurant', null, [c1], ['prioridade']);

        console.table(datasetAprovadores.values, ['index', 'documentid', 'usuario', 'substitutos'])
        let users_processo_po = []

        datasetAprovadores.values.forEach((e) => {
            let aprovers = e.grupo.split('\u0018').map(s => s.trim())
            //if (e.hiddenProcesso.indexOf('processo_po') > -1 && e.grupo.indexOf(grupo) > -1) {
            if (e.hiddenProcesso.indexOf('processo_po') > -1 && aprovers.includes(grupo.trim())) {
                users_processo_po.push(e);
            }
        })

        datasetAprovadores.values = users_processo_po;
        if (users_processo_po.length == 0) {
            $("#alertAlcada").show();
        } else {
            $("#alertAlcada").hide();
        }
        let prioridadeUsuario = datasetAprovadores.values.find((element) => {
            return element.idUsuario === user
        })
        prioridadeUsuario = (!prioridadeUsuario) ? {
            prioridade: 0
        } : prioridadeUsuario;
        for (let x = 0; x < datasetAprovadores.values.length; x++) {
            if (!(prioridadeUsuario.prioridade >= datasetAprovadores.values[x].prioridade) || x == datasetAprovadores.values.length - 1) {
                let valorFinal = realToNumber(datasetAprovadores.values[x].valorFinal);
                let idUser = usernameToId(datasetAprovadores.values[x].usuario);
                if ((state == '4' || state == '0') && valor <= valorFinal) {
                    $('#superiorImediato').val(datasetAprovadores.values[x].usuario)
                    $('#superiorId').val(idUser)
                    $('#proximoAprovador').val(idUser)
                    let subs = datasetAprovadores.values[x].substitutos.split('')
                    $('#subSuperiorImediato').html('');
                    $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
                    subs.forEach(element => {
                        $('#subSuperiorImediato').append(`<option value="${usernameToId(element)}">${element}</option>`)
                    })
                    $(".alertAlcada").addClass("fs-display-none");
                    break;
                } else {
                    if (state == 4 || state == 0) {
                        $(".alertAlcada").removeClass("fs-display-none");
                        $('#superiorImediato').val('')
                        $('#superiorId').val('')
                        $('#proximoAprovador').val('')
                    }
                }
            }
        }
    } else {
        // $('#aprovadorAlcada').val("")
        // $('#aprovadorId').val("")
        $('#superiorImediato').val("")
        $('#superiorId').val("")
    }
    hideDuplicateAprover()
    ajusteSubAprovadores()
    $('[role="log"]').hide()
}

function ajusteSubAprovadores() {
    $('[name="subSuperiorImediato"]').val($('#idSubSuperior').val())
    //$('[name="subAprovadorAlcada"]').val($('#idSubAprovador').val())
}

function hideDuplicateAprover() {
    if ($('#superiorId').val() === $('#aprovadorId').val()) {
        $('#div_subSuperiorImediato').hide()
    } else {
        $('#div_subSuperiorImediato').show()
    }
}

function idToUserName(id) {
    try {
        var constraintColleague1 = DatasetFactory.createConstraint('colleaguePK.colleagueId', id, id, ConstraintType.MUST);
        var datasetColleague = DatasetFactory.getDataset('colleague', null, new Array(constraintColleague1), null);
        return datasetColleague.values[0].colleagueName
    } catch (e) {
        console.error('Erro ao trazer nome de Usuario ( ' + e + ' )')
        return 0
    }
}

function usernameToId(id) {
    try {
        var constraintColleague1 = DatasetFactory.createConstraint('colleagueName', id, id, ConstraintType.MUST);
        var datasetColleague = DatasetFactory.getDataset('colleague', null, new Array(constraintColleague1), null);
        return datasetColleague.values[0]["colleaguePK.colleagueId"]
    } catch (e) {
        console.error('Erro ao trazer nome de Usuario ( ' + e + ' )')
        return 0
    }
}

function realToNumber(numero) {
    return parseFloat(numero.replace(/\./g, '').replace(',', '.'))
}

function setSelectedZoomItem(selectedItem) {
    switch (selectedItem.inputName) {
        case 'cenCustResp':
            //alcadaAprovacao(selectedItem.cODCENTROCUSTO, ['SUPERIOR_RESPONSAVEL', 'APROVADOR_RESPONSAVEL'])
            $('#idCenCusResp').val(selectedItem.cODCENTROCUSTO)
            break;
        case 'centCusSolic':
            //alcadaAprovacao(selectedItem.cODCENTROCUSTO, ['SUPERIOR_SOLICITANTE', 'APROVADOR_SOLICITANTE'])
            $('#idCenCusSolic').val(selectedItem.cODCENTROCUSTO)
            break;
        case 'grupoContaContabil':
            $("#idGrupoCont").val(selectedItem.cODGRUPOCONCEITO);
            $("#divConta").show();
            // if ($('#contaContabil').hasClass("select2-hidden-accessible")) {
            //     $("#contaContabil").select2('destroy');
            // }
            setSelects2('contaContabil', $("#idContCont").val(), false, 'ds_retornaConceitoPorGrupo', 'codConceito', 'descConceito', '', [{
                    "_field": "grupo_conceito",
                    "_initialValue": $("#idGrupoCont").val(),
                    "_type": 1
                }], false,
                (dataselected) => {
                    $('#codPolitica').val(dataselected.target.value.split(' - ')[0])
                }, () => {
                    $('#codPolitica').val('')
                }
            )
            break;
        case 'selGrupo':
            $("#selGrupoHidden").val("Pool:Group:" + selectedItem.id);
            break

    }
}

function setaSelectContabil() {

    $("#contaContabil").on('focus', () => {
        console.log('Entrou no event focus')
        setSelects2('contaContabil', $("#idContCont").val(), false, 'ds_retornaConceitoPorGrupo', 'codConceito', 'descConceito', '', [{
                "_field": "grupo_conceito",
                "_initialValue": $("#idGrupoCont").val(),
                "_type": 1
            }], false,
            (dataselected) => {
                $('#codPolitica').val(dataselected.target.value.split(' - ')[0])
            }, () => {
                $('#codPolitica').val('')
            }
        )
    })

}

const setSelects2 = (fieldName = '', inicialValue = '', multipleSel = '', dataset = '', shownField1 = '', shownField2 = '', tablename = '', filter = [], async = true, selectFunction = () => {}, unselectFunction = () => {}) => {
    if (dataset != '') {
        consultDataset(dataset, tablename, filter, async).success((data) => {
            let dataSelect = [];
            let results = data.content.values;
            if (results) {
                results = results.map(function (el) {
                    dataSelect.push({
                        id: el[shownField1],
                        text: el[shownField1] + " - " + el[shownField2]
                    });

                });
            }

            dataSelect.unshift({
                id: '',
                text: ''
            })

            $(`#${fieldName}`).empty();

            $(`#${fieldName}`).select2({
                data: dataSelect,
                allowClear: true,
                placeholder: "",
                theme: "bootstrap",
                multiple: multipleSel,
                language: "pt-BR"
            }).on('select2:select', selectFunction);

            $(`#${fieldName}`).on("select2:unselect", unselectFunction);

            $(`#${fieldName}`).val(inicialValue).change()
        })
    } else {
        $(`#${fieldName}`).select2({
            allowClear: true,
            placeholder: "",
            theme: "bootstrap",
            multiple: multipleSel,
            language: "pt-BR"
        }).on('select2:select', selectFunction);

        $(`#${fieldName}`).on("select2:unselect", unselectFunction);

        $(`#${fieldName}`).val(inicialValue).change()
    }
}

function events() {
    $("#ver_arquivo").on('click', (element) => {
        openDocument($("#idAnexo").val(), 1000);
    })
    $('[name^=upbtnVisualizar]').on('click', (element) => {
        if (element.currentTarget.parentElement.childNodes[5].value) {
            openDocument(element.currentTarget.parentElement.childNodes[5].value, 1000)
        } else {
            TOAST('Nenhum arquivo adicionado!', 'warning');
        }
    });
    $("#deletar_arquivo").on('click', (element) => {
        deleteDocument($("#idAnexo").val())
    })

    $("#alertAlcada").hide();
    $('[name=temContrato]').on('change', (e) => {
        if (e.currentTarget.id == 'temContratoSim') {
            $('.divContratoInput').show()
        } else {
            $('.divContratoInput').hide()

        }
    });
    $("[name^='aprovOutroGrupo']").on('change', (e) => {
        if (e.currentTarget.value == 'nao') {
            $(".divGrupo").hide();
        } else {
            $(".divGrupo").show();
        }
    })
    $(".addButton").on('click', () => {
        addChildTables("tabelaUploadFiles");
    })

    $('[name=valorPO]').on('change', () => {
        // if ($('#idCenCusSolic').val()) { alcadaAprovacao($('#idCenCusSolic').val(), ['SUPERIOR_SOLICITANTE', 'APROVADOR_SOLICITANTE']) }
        // if ($('#idCenCusResp').val()) { alcadaAprovacao($('#idCenCusResp').val(), ['SUPERIOR_RESPONSAVEL', 'APROVADOR_RESPONSAVEL']) }
    });

    $('[name="valorPO"]').on('blur', () => {
        $('#saldo').val($('#valorPO').val());
        alcadaPorGrupo();
    })

    $('#subSuperiorImediato').on('change', (e) => {
        $('#idSubSuperior').val(e.currentTarget.selectedOptions[0].value)
        $('#nameSubSuperior').val(e.currentTarget.selectedOptions[0].text)
    })

    $('[name=aprovacao]').on('click', (e) => {
        var valueAprov = e.target.defaultValue

        if (valueAprov == "CONTESTADO") {
            $('#div_parecerFinanceiro').show()
        } else {
            $('#div_parecerFinanceiro').hide()
        }
    })


}

function removedZoomItem(removedItem) {
    let options = [];

    options.unshift({
        id: 'NS',
        text: 'Escolha um Substituto'
    })

    switch (removedItem.inputName) {
        case 'cenCustResp':

            $('#idCenCusResp').val('')
            $('[name=supResp]').val('')
            $('[name=idUsersupResp]').val('')
            $('[name="supSubResp"]').empty();

            $('[name="supSubResp"]').select2({
                data: options,

                theme: "bootstrap",
                language: "pt-BR"
            })

            $('[name=apResp]').val('')
            $('[name=idUserapResp]').val('')
            $('[name="apSubResp"]').empty();

            $('[name="apSubResp"]').select2({
                data: options,

                theme: "bootstrap",
                language: "pt-BR"
            })

            break;
        case 'centCusSolic':

            $('#idCenCusSolic').val('')
            $('[name=supSoli]').val('')
            $('[name=idUsersupSoli]').val('')
            $('[name="supSubSoli"]').empty();

            $('[name="supSubSoli"]').select2({
                data: options,

                theme: "bootstrap",
                language: "pt-BR"
            })

            $('[name=apSoli]').val('')
            $('[name=idUserapSoli]').val('')
            $('[name="apSubSoli"]').empty();

            $('[name="apSubSoli"]').select2({
                data: options,

                theme: "bootstrap",
                language: "pt-BR"
            })

            break;
    }
}

const getPreviousContracts = (nameCampo) => {
    consultDataset('ds_processo_contrato', null, [{
        "_field": "servicoJuridico",
        "_initialValue": 'novoContrato',
        "_type": 1
    }]).success((data) => {
        let dataSelect = [];
        let item = {}
        var results = data.content.values;
        results.forEach(function (el) {
            item = {
                id: el["documentid"],
                text: (el["NFPStituloContrato"] != '') ? el["NFPStituloContrato"] : el["NTNtituloContrato"] + " - " + (el["NFPScontratante"] != '') ? el["NFPScontratante"] : el["NTNempPartNeg"]
            };
            (item.text != null) ? ((item.text.trim() != "") ? dataSelect.push(item) : {}) : {};
        });

        dataSelect.unshift({
            id: '',
            text: ''
        })

        $(`#${nameCampo}`).empty();

        $(`#${nameCampo}`).select2({
            data: dataSelect,
            allowClear: true,
            placeholder: "Selecione...",
            theme: "bootstrap",
            language: "pt-BR"
        }).on('select2:select', (dataChange) => {
            let po = results.find(e => e["documentid"] == dataChange.currentTarget.value)

            if (po.prefixo == 'NFPS') {
                let {
                    NFPSinicioVigencia,
                    NFPSfimVigencia,
                    NFPSvalorTotal,
                    NFPStituloContrato
                } = po
                $('#inicioPO').val(NFPSinicioVigencia)
                $('#fimPO').val(NFPSfimVigencia)
                $('#valorPO').val(NFPSvalorTotal)
                $('#nameContrato').val(NFPStituloContrato)
            } else if (po.prefixo == 'NTN') {
                let {
                    NTNinicioVigencia,
                    NTNfimVigencia,
                    NTNvalorTotal,
                    NTNtituloContrato
                } = po;
                $('#inicioPO').val(NTNinicioVigencia)
                $('#fimPO').val(NTNfimVigencia)
                $('#valorPO').val(NTNvalorTotal)
                $('#nameContrato').val(NTNtituloContrato)
            } else {
                $('#inicioPO').val('')
                $('#fimPO').val('')
                $('#valorPO').val('')
                $('#nameContrato').val('')
            }
        })

        $(`#${nameCampo}`).on("select2:unselect", () => {
            $('#inicioPO').val('')
            $('#fimPO').val('')
            $('#valorPO').val('')
            $('#nameContrato').val('')

            document.getElementById('inicioPO').max = new Date().toISOString().split("T")[0];
            $('#inicioPO').on('change', (element) => {
                var value = element.target.value
                var date = new Date().toISOString().split("T")[0]
                if (value > date) {
                    element.target.value = date
                }
            })

            document.getElementById('fimPO').min = new Date().toISOString().split("T")[0];
            $('#fimPO').on('change', (element) => {
                var value = element.target.value
                var date = new Date().toISOString().split("T")[0]
                if (value < date) {
                    element.target.value = date
                }
            })
        })

        $(`#${nameCampo}`).val('').change()
    })
}

const getFornecedores = (nameCampo) => {
    consultDataset('ds_busca_fornecedores').success((data) => {
        let dataSelect = [];
        let item = {}
        results = data.content.values;
        results.forEach(function (el) {
            item = {
                id: el["CNPJ"],
                text: el["CNPJ"] + " - " + el["NOME"]
            };
            (item.text.trim() != "") ? dataSelect.push(item): {};
        });

        dataSelect.unshift({
            id: '',
            text: ''
        })

        $(`#${nameCampo}`).empty();

        $(`#${nameCampo}`).select2({
            data: dataSelect,
            allowClear: true,
            placeholder: "Selecione...",
            theme: "bootstrap",
            language: "pt-BR"
        }).on('select2:select', (dataChange) => {
            let fornecedor = results.find(e => e['CNPJ'] == dataChange.currentTarget.value)
            $("#fornecedorHidden").val(fornecedor["CNPJ"])
            var cnpj = fornecedor['CNPJ'];
            if (fornecedor['CNPJ'].length > 11 && fornecedor['CNPJ'].length < 14) {
                cnpj = "0" + fornecedor['CNPJ']
            }
            cnpj = converteCpfCnpj(cnpj, fornecedor['TIPOID']);
            let endereco = " " + fornecedor['ENDERECO'] + " - " + fornecedor['CIDADE'] + "(" + fornecedor['CEP'] + ")"
            $('[name="cpfCnpj"]').val(cnpj)
            $('[name="endereco"]').val(endereco)
        })

        $(`#${nameCampo}`).on("select2:unselect", () => {
            $("#fornecedorHidden").val('');
            $('[name="cpfCnpj"]').val('')
            $('[name="endereco"]').val('')
        })

        $(`#${nameCampo}`).val('').change()

        if (stateAtual.value != ABERTURA) {
            let valor = $("#fornecedorHidden").val();
            $(`#${nameCampo}`).val(valor).change()
            $(`#${nameCampo}`).prop('disabled', true);
        }
    })
}

var converteCpfCnpj = (cnpjForn, tipo) => {
    try {
        if (tipo == "CPF" && cnpjForn.length != 11) {
            for (var i = cnpjForn.length; i < 11; i++) {
                cnpjForn = "0" + cnpjForn
            }
        } else if (tipo == "CNPJ" && cnpjForn.length != 14) {
            for (var i = cnpjForn.length; i < 14; i++) {
                cnpjForn = "0" + cnpjForn
            }
        }
        if (cnpjForn.length == 11) {
            cnpjForn = cnpjForn.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})/, "$1 $2 $3-$4")
        } else {
            cnpjForn = cnpjForn.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1 $2 $3/$4-$5")
        }
        return cnpjForn;
    } catch (e) {
        console.log("erro ====> " + e.message);
    }
}

const consultDataset = (dataset, tabela, constraints) => {
    var cst = constraints != null ? constraints : []
    if (tabela != null) cst.push({
        "_field": "tablename",
        "_initialValue": tabela,
        "_finalValue": tabela,
        "_type": 1
    })

    return $.ajax({
        url: '/api/public/ecm/dataset/datasets',
        type: 'post',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({
            "name": dataset,
            "constraints": cst
        }),
        success: function (data) {}
    });
}

var setAprovador = () => {
    let state = stateAtual.value
    if (state == INICIO || state == ABERTURA) {
        if ($('[name="idSubSuperior"]').val() == 'manter') {
            $('#aprovador').val($('#superiorId').val())
        } else {
            $('#aprovador').val($('[name=idSubSuperior]').val())
        }
    } else if (state == 5) {
        if ($('[name=apSubSoli]').val() == 'NS') {
            $('#aprovador').val($('#idUserapSoli').val())
        } else {
            $('#aprovador').val($('[name=apSubSoli]').val())
        }
        if ($('#aprovador').val() == $('#usuarioAtual').val()) {
            if (parseInt($('#valorAprov').val()) < realToNumber($('[name=valorPO]').val())) {
                if ($('[name=idUsersupResp]').val() == 'NS') {
                    $('#aprovador').val($('#idUsersupResp').val())
                } else {
                    $('#aprovador').val($('[name=supSubResp]').val())
                }
                $('#enviaResp').val('true')
            } else {
                $('#aprovador').val('NENHUM')
            }
        }
    } else if (state = 12) {
        if ($('[name=apSubSoli]').val() == 'NS') {
            $('#aprovador').val($('#idUserapSoli').val())
        } else {
            $('#aprovador').val($('[name=apSubSoli]').val())
        }
        if ($('#aprovador').val() == $('#usuarioAtual').val()) {
            $('#aprovador').val('NENHUM')
        }
    } else {
        $('#aprovador').val('NENHUM')
    }
}

// function hideShowParecer() {

// }

var beforeSendValidate = function (numState, nextState) {
    let msg = "";
    let state = stateAtual.value;
    if (APROVACAO_RESPONSAVEL == numState) {
        if ($("[name^=aprovacao]:checked").val() == "APROVADO") {
            $("#selGrupoHidden").val("aprovado");
        } else {
            $("#selGrupoHidden").val("reprovado");
        }
    }
    $(".obrigatorio:visible:not([readonly])").each((index, element) => {
        if (element.tagName != 'SPAN') {
            msg += validateEmptyFields(element, msg);
        }
    })
    if ($("#temContratoSim").prop("checked")) {
        if (!$("#idAnexo").val()) {
            msg += "É necessário Anexar o Contrato <br>";
        }
    }
    //     if(rowIndex.tabelaUploadFiles == 0|| $("#upId___1").val() == ""){
    //         msg  += "É necessário anexar ao menos um Documento! <br>";
    //    }
    if (state == INICIO || state == ABERTURA) {

        let c1 = DatasetFactory.createConstraint('temContrato', 'NAO', 'NAO', ConstraintType.MUST);
        let c2 = DatasetFactory.createConstraint('cpfCnpj', $('#cpfCnpj').val(), $('#cpfCnpj').val(), ConstraintType.MUST);
        let dataset = DatasetFactory.getDataset('ds_processo_po_assurant', null, [c1, c2], null);
        //let dataset = DatasetFactory.getDataset('ds_processo_po_assurant', null, [c1], null);

        dataset = dataset.values.filter(e => {
            let data1 = e['dataAbertura'].split('/')[2];
            let data2 = $("[name=dataAbertura]").val().split('/')[2];
            return data1 == data2;
        });

        if (dataset.length > 3) {
            $('#poMaiorTres').val('true')
        }
    }

    setAprovador()

    if (msg != "") {
        throw msg;
    }
}

var validateEmptyFields = (campo, msg) => {

    var lineBreaker = "<br>";

    if ($(campo).val() == "" || $(campo).val() == undefined || $(campo).val() == null || $(campo).val() == "R$ 0,00" || $(campo).val() == "0,00" || $(campo).val() == "R$ NaN") {

        msg += "Campo '" + $(campo).siblings("label").text() + "' é obrigatório!" + lineBreaker;

    }

    return msg;
}

function uploadDocument(linha = "") {
    $('.upload').fileupload({
        dataType: 'json',
        start: () => FLUIGC.loading(window).show,
        done: (e, data) => {
            let file = data.result.files[0];
            if (e.target.id = "botaoAdicionarContrato") {
                $("#ver_arquivo").on('click', (element) => {
                    openDocument($("#idAnexo").val(), 1000);
                })
                $("#deletar_arquivo").on('click', (element) => {
                    deleteDocument($("#idAnexo").val())
                })
                saveDocuments(file, PARENTIDCONTRATO);
            } else {
                $('#upbtnVisualizar___' + linha).on('click', (element) => {
                    if (element.currentTarget.parentElement.childNodes[5].value) {
                        openDocument(element.currentTarget.parentElement.childNodes[5].value, 1000)
                    } else {
                        TOAST('Nenhum arquivo adicionado!', 'warning');
                    }
                });
                saveDocuments(file, PARENTIDANEXOS, linha);
            }
            // blockUploadsButtons('upFile___' + linha, true)
        },
        fail: (e, data) => {
            console.log("Falha no fileupload", data);
            TOAST('Não foi possivel publicar o arquivo.', 'danger');
        },
        stop: () => FLUIGC.loading(window).hide()

    });
}

const deleteDocument = (documentId, clearAll = false) => {
    let urldel = parent.WCMAPI.getServerURL() + '/api/public/2.0/documents/deleteDocument/' + documentId;
    top.WCMAPI.Create({
        url: urldel,
        method: "POST",
        success: e => {
            if (!clearAll) {

                $("#anexo").show();
                $('#ver_arquivo').hide();
                $("#deletar_arquivo").hide();
                $('[name="idAnexo"]').val('')
                TOAST("Arquivo deletado com sucesso.", "success")
            } else {
                console.log('Arquivo apagado :' + documentId)
            }
        },
        error: e => {
            console.log("Falha ao deletar o arquivo", e);
            TOAST("Falha ao deletar o arquivo.", "danger");
        }
    });

}

function openDocument(docId, docVersion) {
    var parentOBJ;

    if (window.opener) {
        parentOBJ = window.opener.parent;
    } else {
        parentOBJ = parent;
    }

    var cfg = {
        url: "/ecm_documentview/documentView.ftl",
        maximized: true,
        title: "Visualizador de Documentos",
        callBack: function () {
            parentOBJ.ECM.documentView.getDocument(docId, docVersion);
        },
        customButtons: []
    };
    parentOBJ.ECM.documentView.panel = parentOBJ.WCMC.panel(cfg);
}

function saveDocuments(file, PARENTID, linha = '') {
    $.ajax({
        url: '/api/public/ecm/document/createDocument',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            "description": file.name,
            "parentId": PARENTID,
            "attachments": [{
                "fileName": file.name
            }]
        })
    }).done((result) => {
        let documentId = result.content.id;

        $('[name="idAnexo"]').val(documentId);
        $("#anexo").hide();
        $('#ver_arquivo').show();
        $("#deletar_arquivo").show();
        if (linha) {
            $('[name="upFile___' + linha + '"]').parent().attr('disabled', true)
            $('[name="upFile___' + linha + '"]').attr('disabled', true)
            $('[name="upId___' + linha + '"]').val(documentId);
            $('[name="upName___' + linha + '"]').val(file.name);
        }
        TOAST('Arquivo ' + file.name + ' publicado com sucesso.', 'success');
    }).fail((result) => {
        TOAST('Não foi possivel publicar o arquivo.', 'danger');
        console.log("Falha", result);
    });
}

const addChildTables = (tableName) => {
    let linha = wdkAddChild(tableName);
    if (tableName.includes('UploadFiles')) {
        $(".addFilePaiFilho").each((index, element) => {
            $(element.childNodes[1]).fileupload({
                dataType: 'json',
                start: () => FLUIGC.loading(window).show,
                done: (e, data) => {

                    let file = data.result.files[0];

                    saveDocuments(file, PARENTIDANEXOS, linha);

                    // blockUploadsButtons('upFile___' + linha, true)
                },
                fail: (e, data) => {
                    console.log("Falha no fileupload", data);
                    TOAST('Não foi possivel publicar o arquivo.', 'danger');
                },
                stop: () => FLUIGC.loading(window).hide()
            });
        });

        $('#upbtnVisualizar___' + linha).on('click', (element) => {
            if (element.currentTarget.parentElement.childNodes[5].value) {
                openDocument(element.currentTarget.parentElement.childNodes[5].value, 1000)
            } else {
                TOAST('Nenhum arquivo adicionado!', 'warning');
            }
        });
    }
    addDeleteLineEvent(tableName);
}

const addDeleteLineEvent = (tableName) => {
    $('.delLine').on('click', (element) => {
        if (tableName.includes('UploadFiles')) {
            if (element.currentTarget.parentElement.childNodes[5].value) deleteDocument(element.currentTarget.parentElement.childNodes[5].value);
            fnWdkRemoveChild(element.currentTarget.parentElement.childNodes[3])
        } else {
            fnWdkRemoveChild(element.currentTarget.parentElement.parentElement.childNodes[5].childNodes[3])
        }
    })
}