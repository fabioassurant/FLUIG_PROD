function displayFields(form, customHTML) {
    var user = getValue("WKUser");
    var state = getValue("WKNumState");
    var mode = form.getFormMode();

    form.setValue('tipoVisualizacao', mode)
    form.setValue('stateAtual', state)
    form.setValue('usuarioAtual', user)
    form.setValue('tipoVisualizacao', mode)
    form.setHidePrintLink(true);

    if (mode == "ADD") {
        form.setValue('iniciador', user);
        form.setVisibleById("div_parecerSuperior", false);

    } else if (state == AVALIACAO_FINANCEIRO) {
        form.setEnabled("aprovOutroGrupo", true);
        form.setEnabled("selGrupo", true);
        form.setEnabled("parecerSuperior", false);
        form.setEnabled('apSoli', false)
        form.setEnabled('apSubSoli', false)
        form.setEnabled('apResp', false)
        form.setEnabled('apSubResp', false)
        form.setEnabled('supSoli', false)
        form.setEnabled('supSubSoli', false)
        form.setEnabled('supResp', false)
        form.setEnabled('supSubResp', false)
        form.setEnabled('fornecedor', false)
        form.setEnabled('temContrato', false)
        form.setEnabled('inicioPO', false)
        form.setEnabled('fimPO', false)
        form.setEnabled('valorPO', false)
        form.setEnabled('saldo', false)
        form.setEnabled('centroCustoSolic', false)
        form.setEnabled('centroCustoResp', false)
        form.setEnabled('historico', false)
        // form.setEnabled('contaContabil', false)
        form.setEnabled('contratos', false)
    }

    if (state == ABERTURA || state == INICIO) {
        form.setVisibleById('divBotoesAprovacao', false)
        form.setEnabled("parecerSuperior", false);

        if (form.getValue('parecerContestar') != '') {
            form.setVisibleById('div_parecerFinanceiro', true)
            form.setEnabled('parecerContestar', false)
        }
    } else {
        log.info('log info ---------- 1')
        //form.setEnabled('fornecedor', false)
        form.setVisibleById("nameSubSuperior", true)
        form.setVisibleById("subSuperiorImediato", false)
        form.setEnabled('temContrato', false)
        form.setEnabled('contratos', false)
        form.setEnabled('inicioPO', false)
        form.setEnabled('fimPO', false)
        form.setEnabled('valorPO', false)
        form.setEnabled('saldo', false)
        form.setEnabled('centroCustoSolic', false)
        form.setEnabled('centroCustoResp', false)
        form.setEnabled('historico', false)
        form.setEnabled('grupoContaContabil', false)
        form.setEnabled('centCusSolic', false)
        form.setEnabled('cenCustResp', false)
        log.info('log info ---------- 2')

        var solicitante = form.getValue('iniciador')
        var usuarioAtual = form.getValue('usuarioAtual')

        if(solicitante == usuarioAtual) {
        form.setEnabled('contaContabil', true)
        }else {
        form.setEnabled('contaContabil', false)
        }


        if (state == APROVACAO_SOLICITANTE) {
            form.setEnabled('supSubSoli', false)

            log.info('log info ---------- 3')

            if (form.getValue('valApSubSoli') == 'NS') {
                if (user == form.getValue('idUserapSoli')) {
                    log.info('log info ---------- 3')
                    form.setEnabled('apSubSoli', false)
                }
            } else {
                if (user == form.getValue('valApSubSoli')) {
                    log.info('log info ---------- 4')

                    form.setEnabled('apSubSoli', false)
                }
            }
        }
        if (state == APROVACAO_RESPONSAVEL) {
            form.setEnabled("parecerSuperior", false);
            form.setEnabled("subSuperiorImediato", false);
            form.setEnabled('apSubSoli', false)
            form.setEnabled('supSubSoli', false)
            form.setEnabled('supSubResp', false)
            if (form.getValue('valApSubResp') == 'NS') {
                if (user == form.getValue('idUserapSoli')) {
                    form.setEnabled('apSubResp', false)
                }
            } else {
                if (user == form.getValue('valApSubResp')) {
                    form.setEnabled('apSubResp', false)
                }
            }
        }
    }

    if (state > 16) {
        form.setVisibleById('divBotoesAprovacao', true)
        form.setVisibleById('divContesta', false)
    }

    if (state < AVALIACAO_FINANCEIRO) {
        form.setVisibleById('divRespFin', false)
    }

}