function validateForm(form){

    var atv = getValue("WKNumState");
    atv = returnActivities(atv);

    var msg = "";

    if(atv == 'APROVACAO'){
        if(form.getValue('botaoAprovacao') == '' || form.getValue('botaoAprovacao') == null){
            msg += '<br/>Campo <b>"Aprovação"</b> não selecionado';
        }
    }else if(atv == 'AVALIACAO_FINANCEIRO'){
        if(form.getValue('botaoAprovacao') == '' || form.getValue('botaoAprovacao') == null){
            msg += '<br/>Campo <b>"Aprovação"</b> não selecionado';
        }
    }

    if(msg != ""){
        throw msg
    }
}