function enableFields(form) {
    var atv = getValue("WKNumState");
    atv = returnActivities(atv);
    if ("INICIO" == atv) {
        form.setEnabled("parecerTaxes", false);
        form.setEnabled("parecerFinanceiro", false);
        form.setEnabled("parecerSuperior", false);
    } else if ("APROVACAO" == atv) {
        habilitaCampoAprovacao(form)
        form.setEnabled('botaoAprovacao', true);
        form.setEnabled("parecerSuperior", true);
        form.setEnabled('slc_revisao_opcao', true);
        form.setEnabled("contaContabil", false);
    } else if (atv == "AVALIACAO_GRUPO_RESPONSAVEL") {
        habilitaCampoAprovacao(form);
        form.setEnabled('botaoAprovacao', true);
    } else if (atv == "AVALIACAO_FINANCEIRO") {
        habilitaCampoAprovacao(form);
        form.setEnabled("aprovOutroGrupo", true);
        form.setEnabled("selGrupo", true);
        form.setEnabled('botaoAprovacao', true);
        form.setEnabled("parecerFinanceiro", true);
        form.setEnabled("parecerSuperior", false);
        form.setEnabled("parecerTaxes", false);

        form.setEnabled('grupoContaContabil', false);
        form.setEnabled('centCusSolic', false);
        form.setEnabled('slc_revisao_opcao', true);
        form.setEnabled('tabelasPadroes', true); // adicionado

        form.setEnabled('cenCustRespRateio', true);
        form.setEnabled('valorRateio', true);

        var indexes = form.getChildrenIndexes("tabelaRateio");
        for (var i = 0; i < indexes.length; i++) {
            var index = indexes[i];
            form.setEnabled("cenCustRespRateio___" + index, true);
            form.setEnabled("valorRateio___" + index, true);
        }
    }
    else if (atv == 'VALIDACAO_ADM') {  // atv == "REVISAO_ADM"
        habilitaCampoAprovacao(form);
        form.setEnabled("grupoContaContabil", true);
        form.setEnabled("contaContabil", true);
        form.setEnabled('centCusSolic', true);
        form.setEnabled('tabelasPadroes', true);
        form.setEnabled('tabelaUploadFiles', true);
        form.setEnabled('slc_revisao_opcao', true);

        form.setEnabled('cenCustRespRateio', true);
        form.setEnabled('valorRateio', true);
        form.setEnabled("parecerTaxes", false);
        form.setEnabled("parecerFinanceiro", false);

        var indexes = form.getChildrenIndexes("tabelaRateio");
        for (var i = 0; i < indexes.length; i++) {
            var index = indexes[i];
            form.setEnabled("cenCustRespRateio___" + index, true);
            form.setEnabled("valorRateio___" + index, true);
        }
    }
    else if (atv == "REVISAO_ADM" || atv == "REVISAO_SOLICITANTE") {
        form.setEnabled("fornecedor", true);
        form.setEnabled("parecerFinanceiro", false);
        form.setEnabled("parecerSuperior", true);
    }
    else if(atv == "ANALISE_FALHA_GRAVACAO_OBR" || atv == "ANALISE_FALHA_ATIVACAO_OBR" || atv == "ANALISE_FALHA_GRAVACAO_NF"){
        form.setEnabled("parecerTaxes", false);
        form.setEnabled("parecerFinanceiro", false);
        form.setEnabled("parecerSuperior", false);
    }
}

function habilitaCampoAprovacao(form) {
    var habilitar = false; // Informe True para Habilitar ou False para Desabilitar os campos
    var mapaForm = new java.util.HashMap();
    mapaForm = form.getCardData();
    var it = mapaForm.keySet().iterator();

    var indexes = form.getChildrenIndexes("tabelaRespCentroCusto");

    while (it.hasNext()) { // Laço de repetição para habilitar/desabilitar os campos
        var key = it.next();
        var key = key.toLocaleLowerCase();
        if (key.indexOf("botao") > -1 || key.indexOf("Grupo") > -1 || key.indexOf("parecer") > -1 || key.indexOf("num_obrigacao") > -1 || key.indexOf("fornecedor") > -1  || key.indexOf("hd_chat_") > -1 || key.indexOf("chk_solicitacao") > -1 || key.indexOf("historico") > -1  || key.indexOf("txta_chat_observacao_") > -1 || key.indexOf("upId___") > -1) {
            habilitar = true;
        } else {
            habilitar = false;
        }

        form.setEnabled(key, habilitar);
    }
    form.setEnabled("parecerSup", true);
    form.setEnabled("parecerAlcada", true);
    for (var i = 0; i < indexes.length; i++) {
        var index = indexes[i];
        form.setEnabled("parecerSol___" + index, true);
        form.setEnabled("parecerAp___" + index, true);
    }
    form.setEnabled("aprovador", true);
    form.setEnabled('txta_chat_observacao', true);

    var indexesChat = form.getChildrenIndexes("tblChat");
    for (var i = 0; i < indexesChat.length; i++) {
        var index = indexesChat[i];
        form.setEnabled("txta_chat_observacao___" + index, true);;
    }

    var indexesUploads = form.getChildrenIndexes("tabelaUploadFiles");
    for (var i = 0; i < indexesUploads.length; i++) {
        var index = indexesUploads[i];
        form.setEnabled("upId___" + index, true);;
    }
}