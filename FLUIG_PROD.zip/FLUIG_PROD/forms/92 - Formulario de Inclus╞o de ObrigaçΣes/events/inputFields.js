function inputFields(form){
    if(getValue("WKCompletTask").equals("true")){
        var indexesChat = form.getChildrenIndexes("tblChat");

        if(indexesChat.length > 0){
            if(form.getValue("hd_chat_status___"+indexesChat[indexesChat.length-1]) == "EDIT"){
                form.setValue("hd_chat_status___"+indexesChat[indexesChat.length-1], "VIEW");
            }
        }
    }
}