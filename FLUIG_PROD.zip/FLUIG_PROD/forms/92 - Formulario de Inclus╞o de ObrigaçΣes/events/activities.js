function returnActivities(activityNumber) {
    let objActivities = {
        "0": "ABERTURA",
        "4": "INICIO",
        "21": "APROVACAO",
        "15": "GRAVA_OBRIGACAO_NO_ACSEL",
        "46": "AVALIACAO_GRUPO_RESPONSAVEL",
        "38": "VERIFICA_PAGAMENTO_NO_ACSEL",
        "49": "AVALIACAO_FINANCEIRO",
        "99": "REVISAO_SOLICITANTE",
        '92': 'VALIDACAO_ADM',
        "100": "REVISAO_ADM",
        "18": "ANALISE_FALHA_GRAVACAO_OBR",
        "69": "ANALISE_FALHA_ATIVACAO_OBR",
        "121": "ANALISE_FALHA_GRAVACAO_NF"
    }

    return objActivities[activityNumber];
}