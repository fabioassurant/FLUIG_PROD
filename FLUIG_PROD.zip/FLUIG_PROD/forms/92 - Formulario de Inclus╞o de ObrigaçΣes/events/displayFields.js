function displayFields(form, customHTML) {
    // log.info("####### Inclusão de Obrigação - DISPLAY FIELDS ######");
    var atv = getValue("WKNumState");
    form.setValue('stateAtual', atv);
    atv = returnActivities(atv);
    form.setShowDisabledFields(true);
    form.setHidePrintLink(true);

    var formMode = form.getFormMode();
    var mobile = form.getMobile();
    var user = getValue("WKUser");
    var processo = getValue("WKNumProces");
    var numObligAdiantamento = form.getValue('numObligationAdiantamento')
    var numObligDespesa = form.getValue('numObligationDespesaNF')
    var numObligRH = form.getValue('numObligationRH')
    var numObligOuvidoria = form.getValue('numObligationOuvidoria')
    var NumObligComissao = form.getValue('numObligationComissao')
    var numObligImposto = form.getValue('numObligationImposto')
    var numObligPresConta = form.getValue('numObligationPresConta')
    var numObligCosseguro = form.getValue('numObligationCosseguro')
    var numObligDesApolice = form.getValue('numObligationDesApolice')
    var tipoAcerto = form.getValue('tipoAcertohidden')
    var dataPagamento = form.getValue('dataPagamento')

    if (numObligAdiantamento != "") {
        form.setVisibleById("divNumObligAdiantamento", true)
    }
    if (numObligDespesa != "") {
        form.setVisibleById('divNumObligDespesa', true)
    }
    if (numObligRH != "") {
        form.setVisibleById('divNumObligRH', true)

    }
    if (numObligOuvidoria != "") {
        form.setVisibleById('divNumObligOuvidoria', true)

    }
    if (NumObligComissao != "") {
        form.setVisibleById('divNumObligComissao', true)

    }
    if (numObligImposto != "") {
        form.setVisibleById('divNumObligImposto', true)

    }
    if (numObligPresConta != "") {
        form.setVisibleById('divNumObligPresConta', true)

    }
    if (numObligCosseguro != "") {
        form.setVisibleById('divNumObligationCosseguro', true)

    }
    if (numObligDesApolice != "") {
        form.setVisibleById('divNumObligationDesApolice', true)

    }
    if(tipoAcerto != "") {
        if(tipoAcerto == "presConta"){
            // form.setVisibleById('divPresConta', false)
            // form.setVisibleById('divCenCustoPres', false)
            // form.setVisibleById('divGrupoPres', false)
            // form.setVisibleById('divGrupoConta', true)
        }else{
            // form.setVisibleById('divPresConta', true)
            // form.setVisibleById('divCenCustoPres', true)
            // form.setVisibleById('divGrupoPres', true)
            // form.setVisibleById('divGrupoConta', false)
        }       
    }
    if(dataPagamento != "") {
        form.setVisibleById('divDataPagamento', true)
    }

    form.setValue("num_processo", processo);
    form.setValue('tipoVisualizacao', formMode);
    form.setValue('usuarioAtual', user);

    if ("ABERTURA" == atv) {
        form.setValue('iniciador', user);
        form.setVisibleById("divPO", false);
        //Retirar esse campo depois
        var arrayCampos = [];
        var campos = form.getCardData();
        campos = campos.keySet().iterator();
        while (campos.hasNext()) {
            arrayCampos.push("'" + campos.next() + "'");
        }
        customHTML.append("<script>		function returnCardData(){ return [" + arrayCampos + "]}; </script>");
    } else if (atv == "AVALIACAO_FINANCEIRO") {
        form.setValue("financeiro", user);
        form.setValue('botaoAprovacao', '');

        var arrayCampos = [];
        var campos = form.getCardData();
        campos = campos.keySet().iterator();
        while (campos.hasNext()) {
            arrayCampos.push("'" + campos.next() + "'");
        }
        customHTML.append("<script>		function returnCardData(){ return [" + arrayCampos + "]}; </script>");
    }else if(atv == "VERIFICA_PAGAMENTO_NO_ACSEL") {
        form.setVisibleById("divDataPagamento", true)
    }else if(atv == 'APROVACAO'){
        form.setValue('botaoAprovacao', '');
    }

    if (atv != "ABERTURA") {
        form.setEnabled("fornecedor", true)
    }
    if (atv != "ABERTURA" && atv != "INICIO" && atv != "REVISAO_SOLICITANTE" && atv != "REVISAO_ADM") {
        var adiantamento = form.getValue('tipoAcertoHidden_1')
        var despesasNF = form.getValue('tipoAcertoHidden_2')
        var RH = form.getValue('tipoAcertoHidden_3')
        var ouvidoria = form.getValue('tipoAcertoHidden_4')
        var comissao = form.getValue('tipoAcertoHidden_5')
        var imposto = form.getValue('tipoAcertoHidden_6')
        var presConta = form.getValue('tipoAcertoHidden_7')
        var cosseguro = form.getValue('tipoAcertoHidden_8')
        var devFranquia = form.getValue('tipoAcertoHidden_9')
        var despesaApolice = form.getValue('tipoAcertoHidden_10')
       
        form.setVisibleById("subSuperiorImediato", false)
        form.setVisibleById("nameSubSuperior", true)
        form.setVisibleById("_subSuperiorImediato", false)
        form.setVisibleById("_nameSubSuperior", true)

        if (adiantamento != "") {
            form.setVisibleById("divAdiantamento", true)
            form.setVisibleById("divGrupoConta", true)
            form.setVisibleById("divCenCustoPres", false)
            form.setVisibleById("divGrupoPres", false)
        }
        if (despesasNF != "") {
            form.setVisibleById("divDespesaNF", true)
            form.setVisibleById("divGrupoConta", true)
            form.setVisibleById("divCenCustoPres", false)
            form.setVisibleById("divGrupoPres", false)
        }
        if (RH != "") {
            form.setVisibleById("divRH", true)
            form.setVisibleById("divGrupoConta", true)
            form.setVisibleById("divCenCustoPres", false)
            form.setVisibleById("divGrupoPres", false)
        }
        if (ouvidoria != "") {
            form.setVisibleById("divOvidoria", true)
            form.setVisibleById("divGrupoConta", true)
            form.setVisibleById("divCenCustoPres", false)
            form.setVisibleById("divGrupoPres", false)
        }
        if (comissao != "") {
            form.setVisibleById("divComissao", true)
            form.setVisibleById("divGrupoConta", true)
            form.setVisibleById("divCenCustoPres", false)
            form.setVisibleById("divGrupoPres", false)
        }
        if (imposto != "") {
            form.setVisibleById("divdoImposto", true)
            form.setVisibleById("divGrupoConta", true)
            form.setVisibleById("divCenCustoPres", false)
            form.setVisibleById("divGrupoPres", false)
        }
        if (presConta != "") {
            form.setVisibleById('divPresConta', true)
            form.setVisibleById('divCenCustoPres', true)
            form.setVisibleById('divGrupoPres', true)
            form.setVisibleById('divGrupoConta', false)
        }
        if (cosseguro != "") {
            form.setVisibleById('divCosseguro', true)
            form.setVisibleById('divCenCustoPres', true)
            form.setVisibleById('divGrupoPres', true)
            form.setVisibleById('divGrupoConta', false)
        }
        if (devFranquia != "") {
            form.setVisibleById('divDevFranquia', true)
            form.setVisibleById('divCenCustoPres', true)
            form.setVisibleById('divGrupoPres', true)
            form.setVisibleById('divGrupoConta', false)
        }
        if (despesaApolice != "") {
            form.setVisibleById('divDespesaApolice', true)
            form.setVisibleById('divCenCustoPres', true)
            form.setVisibleById('divGrupoPres', true)
            form.setVisibleById('divGrupoConta', false)
        }

    }
    if(atv == "REVISAO_ADM" || atv == 'VALIDACAO_ADM'){
        form.setVisibleById('divTabelasPadroes', true);
        form.setVisibleById('divTabelasPadroes', true);
    } 
    else {
        form.setVisible("subSuperiorImediato", true)
        form.setVisible("nameSubSuperior", false);
        form.setVisibleById('divTabelasPadroes', true);
    }

    customHTML.append("<script>");
    customHTML.append("		function getFormMode(){ return '" + formMode + "'};");
    customHTML.append("		function getMobile(){ return '" + mobile + "'};");
    customHTML.append("		function getWKNumState(){ return " + getValue("WKNumState") + "};");
    customHTML.append("		function getWKUser(){ return '" + user + "'};");
    customHTML.append("		function getWKNumProces(){ return " + processo + "};");
    customHTML.append("		displayFields();");
    customHTML.append("</script>");
}