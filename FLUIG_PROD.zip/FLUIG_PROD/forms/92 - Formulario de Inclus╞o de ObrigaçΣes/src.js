const PARENTID = "91"; // PROD E DEV
// const PARENTID = "208"; // MODEL

var aprovadores = [];

// ==================== Funções revitalização

function ativarAnexo(that) {
    if ($(that).parents('.areaAnexo').find('.addFilePaiFilho').hasClass("anexoInserido") ||
        $(that).parents('.areaAnexo').find('.addFilePaiFilho').hasClass("anexoVisualizar")) {
        $(that).parents('.areaAnexo').find('input[id*="upbtnVisualizar"]').click();
    }
    else {
        $(that).parents('.areaAnexo').find('input[type="file"]').click();
    }
}

function deletarAnexo(that) {
    $(that).parents('.areaAnexo').find('input[id*="upbtnDeletar___"]').click()
}



function definirEstadoAnexos() {
    let atividadeAtual = $('#stateAtual').val();
    tarefasSolicitantes = ["0"];
    if ($.inArray(atividadeAtual, tarefasSolicitantes) == -1) {
        $("#adicionar-anexo, .btn-exclusao-anexo").hide();
        $(".btn-exclusao-anexo").parent().hide();

        if (atividadeAtual != "99") {
            $(".addFilePaiFilho").css({ "background-color": "#FFF", "border-color": "#06C", "color": "#06C", "display": "flex" }).removeClass("anexoInserido").addClass("anexoVisualizar");
            $(".areaAnexo a.btn-download").show();
        }

        let anexosTime = setInterval(function () {
            $("#tabelaUploadFiles .areaAnexo:visible").each(function () {
                $(this).find(".divNomesAnexo h4").text($(this).find(`input[id*=upDescricao___]`).val());
                $(this).find(".divNomesAnexo p").text($(this).find(`input[id*=upName___]`).val());
                $(this).find(".divNomesAnexo").show();
                $(this).find(`input[id*=upDescricao___]`).hide();

                if (atividadeAtual == "99" || atividadeAtual == "4") {
                    $(this).find(".btn-exclusao-anexo").show();
                    $(`#tabelaUploadFiles tr:visible .btn-exclusao-anexo:first`).hide();
                    $(`#tabelaUploadFiles tr:visible .addFilePaiFilho:first`).removeClass("anexoInserido");
                    $("#btnAddtabelaUploadFile").parent().show();
                }


                let linhaAnexo = $(this).find("input[id*=upId___]").attr('id').split("___")[1];
                let codigo = $(this).find("input[id*=upId___]").val();
                Archive.download(codigo, linhaAnexo);
            });

            if ($(".divNomesAnexo").is(':visible')) {
                clearInterval(anexosTime);
            }
        }, 2000);

    }
    else if (tarefasSolicitantes == "0") {
        let anexosTime = setInterval(function () {
            $("#btnAddtabelaUploadFile").click();
            $(`#tabelaUploadFiles input[id*=upDescricao___]:last`).val("Nota Fiscal");
            $(`#tabelaUploadFiles input[id*=upDescricao___]:last, #tabelaUploadFiles .btn-exclusao-anexo:last`).hide();
            $("#tabelaUploadFiles .divNomesAnexo:last h4").text($(`#tabelaUploadFiles input[id*=upDescricao___]:last`).val());
            $("#tabelaUploadFiles .divNomesAnexo:last, #tabelaUploadFiles .flaticon-done:last").show();

            if ($(`#tabelaUploadFiles input[id*=upDescricao___]:last`).val() == 'Nota Fiscal') {
                clearInterval(anexosTime);
            }
        }, 2000);
    }
}

function updateProgressBar(numTask) {
    let progresso = [
        ["0", "4", "18", "99"],
        ["21", "46", "49", "69", '92', '100'],
        ["35", "-1", "26", "57", "106"]
    ];
    let etapaAtinigida = true;
    let barra = `<div class='progress-bar' style='width:33.3%'></div>`;

    for (let i = 0; i < progresso.length; i++) {
        if (etapaAtinigida) {
            $('#progress-bar-etapas').append(barra);
            $("#progress-bar-etapas .progress-bar:last").addClass('progress-bar-success');
            $(".etapa-nome:first").show();
            $(".etapa-nome:first").removeClass("etapa-nome");
        }

        if ($.inArray(numTask, progresso[i]) > -1) {
            //$("#progress-bar-etapas .progress-bar:last").addClass('progress-bar-success');
            $("#progress-bar-etapas .progress-bar:last").removeClass('progress-bar-success').addClass('progress-bar-warning');
            etapaAtinigida = false;

            if ($.inArray(numTask, progresso[0]) > -1) {
                let texto = "Solicitação Manual"

                if ($("#tipoObrigacaohidden").val() == "COM") {
                    texto += " - Comissão";
                }
                else if ($("#tipoObrigacaohidden").val() != "") {
                    texto += " - Despesas";
                }

                $(".atividade-abertura p").text(texto);
            }
            else if ($.inArray(numTask, progresso[1]) > -1) {
                var atv = new Map([
                    ['92', "Validação ADM"],
                    ["100", 'Revisão - ADM da área'],
                    ["21", "Aprovação superior imediato"],
                    ["49", "Aprovação Financeira/Fiscal"],
                    ["46", "Aprovação - " + $("#selGrupoHidden").val().split("Pool:Group:")[1]],
                ]);

                $(".atividade-aprovacao p").text(atv.get(numTask));
            } else if ($.inArray(numTask, progresso[2]) > -1) {
                if ($.inArray(numTask, ["35"]) > -1) {
                    $("#progress-bar-etapas .progress-bar:last").removeClass('progress-bar-warning').addClass('progress-bar-success');
                }
                else if ($.inArray(numTask, ["26", "57", "106"]) > -1) {
                    $("#progress-bar-etapas .progress-bar").removeClass('progress-bar-warning').addClass('progress-bar-danger');
                }
            }

        }
        else if ($.inArray(numTask, progresso[i]) <= -1 && etapaAtinigida) {
            //$("#progress-bar-etapas .progress-bar:last").addClass('progress-bar-warning');
        }
    }
}

// =============================================

const TOAST = (message, type) => {
    FLUIGC.toast({
        title: '',
        message: message,
        type: type
    });
}

const Utils = {
    formatReal() {
        try {
            var tmp = num;
            tmp = tmp.replace(/([0-9]{2})$/g, ",$1");
            if (tmp.length > 6)
                tmp = tmp.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
            return tmp;
        } catch (e) {
            console.log("erro ===> " + e.message);
        }
    },
    formatFloat(value) {
        return parseFloat(value.replace(/\./g, '').replace(',', '.'))
    },
    usernameToId(id) {
        try {
            var constraintColleague1 = DatasetFactory.createConstraint('colleagueName', id, id, ConstraintType.MUST);
            var datasetColleague = DatasetFactory.getDataset('colleague', null, new Array(constraintColleague1), null);
            return datasetColleague.values[0]["colleaguePK.colleagueId"]
        } catch (e) {
            console.error('Erro ao trazer nome de Usuario ( ' + e + ' )')
            return 0
        }
    },
    idToUserName(id) {
        try {
            var constraintColleague1 = DatasetFactory.createConstraint('colleaguePK.colleagueId', id, id, ConstraintType.MUST);
            var datasetColleague = DatasetFactory.getDataset('colleague', null, new Array(constraintColleague1), null);
            return datasetColleague.values[0].colleagueName
        } catch (e) {
            console.error('Erro ao trazer nome de Usuario ( ' + e + ' )')
            return 0
        }
    },
    stringToFloat(value) {
        value = value.replace(/\./g, "").replace(",", ".");
        return Number(value);
    },
    convertCpfCnpj(cnpjForn, tipo) {
        try {
            if (tipo == "CPF" && cnpjForn.length != 11) {
                for (var i = cnpjForn.length; i < 11; i++) {
                    cnpjForn = "0" + cnpjForn
                }
            } else if (tipo == "CNPJ" && cnpjForn.length != 14) {
                for (var i = cnpjForn.length; i < 14; i++) {
                    cnpjForn = "0" + cnpjForn
                }
            }
            if (cnpjForn.length == 11) {
                cnpjForn = cnpjForn.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})/, "$1 $2 $3-$4")
            } else {
                cnpjForn = cnpjForn.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1 $2 $3/$4-$5")
            }
            return cnpjForn;
        } catch (e) {
            console.log("erro ====> " + e.message);
        }
    },
    addMaskInputs() {
        $('.valor').mask("#.##0,00", {
            reverse: true
        });
        $('.valorRat').mask("#.##0,00", {
            reverse: true
        });

        $(document).on('keydown change', '.cpfCnpj', function (e) {

            var digit = e.key.replace(/\D/g, '');

            var value = $(this).val().replace(/\D/g, '');

            var size = value.concat(digit).length;

            $(this).mask((size <= 11) ? '000.000.000-00' : '00.000.000/0000-00');
        });

        $('.phone').mask('(00) 0000-00009');
        $("input[name^='numeroNF']").mask('000000000000'); // mascara original => 00000000000000 - 14 digitos

        $(document).on("keydown blur", '.email', (element) => {
            if ((element.key == ';' || element.type == "focusout") && element.currentTarget.value != "") {
                let email = element.currentTarget.value.split(';').filter((e, index) => {
                    e = e.trim();
                    if (!(e.includes('@') && e.includes('.'))) {
                        TOAST('Email invalido retirado do campo!', 'danger');
                    } else {
                        return e
                    }
                });
                element.currentTarget.value = email.join('; ')
            }
        });

        $(".cep").mask("99.999-999");

        $(".agencia").mask("9999", {
            reverse: true
        });

        $(".contacorrente").mask("9999999999-9", {
            reverse: true
        })

        $(".uf").mask("AA");

        $(document).on("blur", '.uf', e => {
            e.currentTarget.value = e.currentTarget.value.toUpperCase()
        })
    },
    consultDataset(dataset, tabela, constraints, async) {
        var cst = constraints != null ? constraints : []
        if (tabela) cst.push({
            "_field": "tablename",
            "_initialValue": tabela,
            "_finalValue": tabela,
            "_type": 1
        })
        return $.ajax({
            url: '/api/public/ecm/dataset/datasets',
            type: 'post',
            async: async,
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                "name": dataset,
                "constraints": cst
            }),
            success: function (data) { }
        });
    },
    setSelects2(fieldName = '', inicialValue = '', multipleSel = '', dataset = '', shownField1 = '', shownField2 = '', tablename = '', filter = [], async = true, selectFunction = () => { }, unselectFunction = () => { }) {
        try {
            if (dataset != '') {

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: async,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": dataset,
                        "constraints": filter
                    }),
                    success: function (data) {
                        let dataSelect = [];
                        if (data.content) {
                            let results = data.content.values;
                            if (results != "" && results != undefined) {
                                if (!results[0].hasOwnProperty("ERRO")) {

                                    if (fieldName == "PO") {
                                        PO.all = results;
                                        results = results.map(function (el) {
                                            if (el[shownField2] != "0,00") {
                                                dataSelect.push({
                                                    id: el[shownField1],
                                                    text: el[shownField1] + " - " + el[shownField2]
                                                });
                                            }
                                        });
                                    } else {
                                        results = results.map(function (el) {
                                            dataSelect.push({
                                                id: el[shownField1],
                                                text: el[shownField1] + " - " + el[shownField2]
                                            });
                                        });
                                    }
                                }
                            }
                        }

                        dataSelect.unshift({
                            id: '',
                            text: ''
                        })

                        $(`#${fieldName}`).empty();

                        $(`#${fieldName}`).select2({
                            data: dataSelect,
                            allowClear: true,
                            placeholder: "",
                            theme: "bootstrap",
                            multiple: multipleSel,
                            language: "pt-BR"
                        }).on('select2:select', selectFunction);

                        $(`#${fieldName}`).on("select2:unselect", unselectFunction);

                        $(`#${fieldName}`).val(inicialValue).change()
                    }
                })

                // Utils.consultDataset(dataset, tablename, filter, async).then((data) => {
                //     let dataSelect = [];
                //     let results = data.content.values;
                //     if (results != "" && results != undefined) {
                //         if (!results[0].hasOwnProperty("ERRO")) {

                //             if (fieldName == "PO") {
                //                 PO.all = results;
                //                 results = results.map(function (el) {
                //                     if (el[shownField2] != "0,00") {
                //                         dataSelect.push({
                //                             id: el[shownField1],
                //                             text: el[shownField1] + " - " + el[shownField2]
                //                         });
                //                     }
                //                 });
                //             } else {
                //                 results = results.map(function (el) {
                //                     dataSelect.push({
                //                         id: el[shownField1],
                //                         text: el[shownField1] + " - " + el[shownField2]
                //                     });
                //                 });
                //             }
                //         }
                //     }

                //     dataSelect.unshift({
                //         id: '',
                //         text: ''
                //     })

                //     $(`#${fieldName}`).empty();

                //     $(`#${fieldName}`).select2({
                //         data: dataSelect,
                //         allowClear: true,
                //         placeholder: "",
                //         theme: "bootstrap",
                //         multiple: multipleSel,
                //         language: "pt-BR"
                //     }).on('select2:select', selectFunction);

                //     $(`#${fieldName}`).on("select2:unselect", unselectFunction);

                //     $(`#${fieldName}`).val(inicialValue).change()
                // })
            } else {
                $(`#${fieldName}`).select2({
                    allowClear: true,
                    placeholder: "",
                    theme: "bootstrap",
                    multiple: multipleSel,
                    language: "pt-BR"
                }).on('select2:select', selectFunction);

                $(`#${fieldName}`).on("select2:unselect", unselectFunction);

                $(`#${fieldName}`).val(inicialValue).change()
            }
        } catch (e) {
            console.log("erro ===> " + e.message);
        }
    },
    setZoomData(instance, value) {
        try {
            window[instance].setValue(value);
        } catch (e) {
            console.log("erro ===> " + e.message);
        }
    },
    addSelect2() {
        //Select com valores bloqueados
        $('.fixedOptions').each((index, element) => {
            if (element.tagName != 'SPAN') {
                $(element).select2({
                    width: '100%',
                    allowClear: true,
                    theme: "bootstrap",
                    language: "pt-BR"
                });
            }
        })
    }
}

const PO = {
    all: [],
    get() {
        return $("#POhidden").val();
    },
    select() {
        Utils.setSelects2('PO', this.get(), false, 'ds_po_inclusao', 'solicitacao', 'saldo', '', [{
            "_field": "cpfCnpj",
            "_initialValue": $("#cpfCnpj").val(),
            "_type": 1
        }], false, (dataselected) => {
            $("#POhidden").val(dataselected.target.value);
            if(getWKNumState() == ABERTURA){
                FLUIGC.switcher.setTrue("#chk_solicitacao_padroes");
            }
            let dadosPOSelected = PO.all.find(x => x.solicitacao == $("#POhidden").val());
            Utils.setZoomData("grupoContaContabil", dadosPOSelected.grupoContaContabil);
            $("#codPolitica").val(dadosPOSelected.contaContabil);
            AccountConcept.set();
            Utils.setZoomData("centCusSolic", dadosPOSelected.centroCustoSolicitante);
            $('#idCenCusSolic').val(dadosPOSelected.idCentroCustoSolicitante)
            let index = 0;
            if ($("[tablename=tabelaRateio] tr:not(:first-child)").length == 0) {
                index = wdkAddChild('tabelaRateio');
            } else {
                $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                    fnWdkRemoveChild(e)
                })
                index = wdkAddChild('tabelaRateio');
            }

            Utils.setZoomData("cenCustRespRateio___" + index, dadosPOSelected.centroCustoResponsavel)
            $("#idCenCusRespRateio___" + index).val(dadosPOSelected.idCentroCustoResponsavel);
            /*$("#valorRateio___" + index).val(dadosPOSelected.saldo);
            $("#totalRateio").val(dadosPOSelected.saldo);
            $("#valor").val(dadosPOSelected.saldo);
            $("#valor_liquido").val(dadosPOSelected.saldo);*/
            Approver.byGroup();
            Apportionment.childEvents();
        }, () => { })
    },
    reload() {
        Utils.setSelects2('PO', $("#POhidden").val(), false, 'ds_po_inclusao', 'solicitacao', 'saldo', '', [{
            "_field": "cpfCnpj",
            "_initialValue": $("#cpfCnpj").val(),
            "_type": 1
        }], false, (dataselected) => {
            $("#POhidden").val(dataselected.target.value);
        }, () => { })
    },
    count() {
        if ($("[name=temPO]").val() == 'sim') {
            $("#POhidden").val('')
            $("#PO :selected").map(function (i, el) {
                $("#POhidden").val($("#POhidden").val() + $(el).val() + ",");
            })
            let a = $("#POhidden").val().split(",");
            a.pop();
            a.join();
            $("#POhidden").val(a);
            let c1 = DatasetFactory.createConstraint('temContrato', 'NAO', 'NAO', ConstraintType.MUST);
            let c2 = DatasetFactory.createConstraint('cpfCnpj', $('#cpfCnpj').val(), $('#cpfCnpj').val(), ConstraintType.MUST);
            let dataset = DatasetFactory.getDataset('ds_processo_po_assurant', null, [c1, c2], null);
            //let dataset = DatasetFactory.getDataset('ds_processo_po_assurant', null, [c1], null);

            dataset = dataset.values.filter(e => {
                let data1 = e['dataAbertura'].split('/')[2];
                let data2 = $("[name=dataAbertura]").val().split('/')[2];
                return data1 == data2;
            });

            if (dataset.length >= 3) {
                $('#poMaiorTres').val('true')
            }
            $('#temPOHidden').val('sim');
        } else {
            $('#temPOHidden').val('nao');
        }
    },
    getConditionalAlert() {
        if ($('#poMaiorTres').val() == 'true') {
            $('#alert').show()
        }
    },
    discount() {
        let POs = this.get();
        const valorOBG = Obligacion.getValue();
        POs = POs.split(",");
        let cs = []
        for (let i = 0; i < POs.length; i++) {
            cs.push(DatasetFactory.createConstraint('solicitacao', POs[i], POs[i], ConstraintType.MUST));
        }
        cs.push(DatasetFactory.createConstraint('valorObg', valorOBG, valorOBG, ConstraintType.MUST));
        const ds = DatasetFactory.getDataset('ds_update_po_value', null, cs, null);
    },
    sum() {
        let POs = this.get();
        const valorOBG = Utils.stringToFloat(Obligacion.getValue()) * -1;
        POs = POs.split(",");
        let cs = []
        for (let i = 0; i < POs.length; i++) {
            cs.push(DatasetFactory.createConstraint('solicitacao', POs[i], POs[i], ConstraintType.MUST));
        }
        cs.push(DatasetFactory.createConstraint('valorObg', valorOBG, valorOBG, ConstraintType.MUST));
        const ds = DatasetFactory.getDataset('ds_update_po_value', null, cs, null);
    },
    events() {
        $("[name=temPO]").on('change', (e) => {
            if (e.target.value == "nao") {
                Field.toggle('divPO', 'hide');
                $("#PO").removeClass("obrigatorio");
            } else {
                Field.toggle('divPO', 'show');
                $("#PO").addClass("obrigatorio");
            }
        })
    },
    setView() {
        if ($("[name=temPO]:checked").val() == "sim" || $("[name=_temPO]:checked").val() == "sim") {
            $("#divPO").show()
        }
    }

}

let providerEvents = () => {
    $('[name^=formaPagamento]').on('change', (e) => {
        var idFormPagamento = e.target.id
        idFormPagamento = idFormPagamento.split('_')
        var index = idFormPagamento[1]

        $("#formaPagamentohidden_" + index).val($("#formaPagamento_" + index).val());
        if ($("#formaPagamento_" + index).val() == '081' || $("#formaPagamento_" + index).val() == '091') {
            $("#divContaAtiva" + index).hide();
            $("#divCodBarras" + index).show();
            $("#divValidaBoleto_" + index).show();
            // $("#botaoValidaCDB_" + index).attr('disabled',true);

            // Field.toggle(`#divCodBarras${ index }`, 'show');
            // Field.toggle('creditoConta', 'hide');
        } else if ($("#formaPagamento_" + index).val() == '071' || $("#formaPagamento_" + index).val() == '073') {
            $("#divContaAtiva" + index).show();
            $("#divCodBarras" + index).hide();
            $("#divValidaBoleto_" + index).hide();
            // Field.toggle('boleto', 'hide');
            // Field.toggle('creditoConta', 'show');

            let cnpj = $("#fornecedor").val();
            if (cnpj) {
                let formaPagamento = Provider.getFormOfPayment(cnpj);
                if (formaPagamento.length > 0) {
                    let agencia = formaPagamento[0].AGENCIA;
                    let cCorrente = formaPagamento[0].CUENTACOR;
                    let formPag = formaPagamento[0].DVCUENTACOR;

                    if (agencia && cCorrente && formPag) {
                        $("#contAtivForn" + index).val(agencia + " " + cCorrente + "-" + formPag);
                    }
                    if (!agencia || !cCorrente || !formPag) {
                        TOAST('Verifique a forma de pagamento cadastrada, ou insira uma válida', 'danger');
                    }
                } else {
                    TOAST('Verifique a forma de pagamento cadastrada, ou insira uma válida', 'danger');
                    $("#divContaAtiva" + index).show();
                    $("#formaPagamento_" + index).attr('readonly', false);
                }
            }

            $("#divContaAtiva" + index).show();
            $("#formaPagamento_" + index).attr('readonly', true);
        }
    });
    Apportionment.childEvents();
    blurCodbarras();
}

const Provider = {
    get() {
        let dataProvider = [];

        const ds = $.ajax({
            url: '/api/public/ecm/dataset/datasets',
            type: 'post',
            async: false,
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                "name": "ds_lista_fornecedor_onSync",
                "constraints": []
            }),
            success: function (data) {
                console.log(data);
            }
        });

        if (ds.responseJSON) {
            dataProvider = ds.responseJSON.content.values;
        }

        // Utils.consultDataset("ds_lista_fornecedor_onSync", null, [], false).then(data => {
        //     dataProvider = data.content.values;
        // });

        console.log("Retorno do ds fornecedores get");
        console.log(dataProvider);
        return dataProvider;
    },
    select() {
        Utils.setSelects2("fornecedor", $("#fornecedorHidden").val(), "", "ds_lista_fornecedor_onSync", "CNPJ", "NOME", "", [], true, (dataChange) => {
            if (getWKNumState() == ABERTURA) {
                $("#imposto").html("");
                $("#tipoObrigacao").val("").change();
                $("#divImposto").hide()
            }
            const results = this.get();
            const inicioR = new Date().getTime();

            let provider = results.find(e => e['CNPJ'] == dataChange.currentTarget.value);
            const totalR = new Date().getTime() - inicioR;
            console.log('Foi executado em:', totalR)
            console.log("Retorno do ds fornecedores select");
            console.log(provider);
            $("#fornecedorHidden").val(provider["CNPJ"])
            $("#nomeFornecedorHidden").val(provider["NOME"])
            var cnpj = provider['CNPJ'];
            if (provider['CNPJ'].length > 11 && provider['CNPJ'].length < 14) {
                cnpj = "0" + provider['CNPJ']
            }
            cnpj = Utils.convertCpfCnpj(cnpj, provider.TIPOID);
            BillOfSale.get(provider['CNPJ'])
            let formaPagamento = this.getFormOfPayment(provider["CNPJ"]);
            if (formaPagamento && formaPagamento.length > 0) {
                $("#formaPagamento").val(formaPagamento[0].TIPO_PAGO);
            } else {
                $("#formaPagamento").val("");
            }
            let endereco = " " + provider['ENDERECO'] + " - " + provider['CIDADE'] + "(" + provider['CEP'] + ")"
            $('[name="cpfCnpj"]').val(cnpj)
            $('[name="endereco"]').val(endereco)
            PO.select();
            $("#fornecedor").attr('readonly', true);

            let cCod = DatasetFactory.createConstraint("c_cnpj_cpf", provider['CNPJ'], provider['CNPJ'], ConstraintType.MUST);
            let dts_acessos_forn = DatasetFactory.getDataset("dts_acessosPortalNotas_MFX", null, [cCod], null).values;
            if(dts_acessos_forn.length > 0){
                $("#hd_cod_grupoAdm").val("Pool:Group:" + dts_acessos_forn[0]['GRUPO_ADM']);

                let grupo = DatasetFactory.createConstraint('colleagueGroupPK.groupId', dts_acessos_forn[0]['GRUPO_ADM'], dts_acessos_forn[0]['GRUPO_ADM'], ConstraintType.MUST);
                let user  = DatasetFactory.createConstraint('colleagueGroupPK.colleagueId', $('#iniciador').val(), $('#iniciador').val(), ConstraintType.MUST);
                let dts_membro_grupo = DatasetFactory.getDataset("colleagueGroup", null, [grupo, user], null).values;

                if(dts_membro_grupo.length > 0){
                    $("#hd_membro_grupoAdm").val("SIM");
                }
                else{
                    $("#hd_membro_grupoAdm").val("NAO");
                }
            }
            else{
                FLUIGC.toast({
                    title: 'Aviso:',
                    message: 'Fornecedor sem grupo de ADM definido , é necessário realizar esta parametrização para casos de abertura pelo portal.', // para proseguir, deve ser realizado a parametrização para continuação do fluxo
                    type: 'warning'
                });
                $("#hd_cod_grupoAdm").val("");
                $("#hd_membro_grupoAdm").val("NAO");
            }
        }, () => {
            $("#formaPagamento").val("");
            $("#contAtivForn").val('');
            $("#fornecedorHidden").val('');
            $("#nomeFornecedorHidden").val('');
            $('[name="cpfCnpj"]').val('');
            $('[name="endereco"]').val('');

            $("#hd_cod_grupoAdm").val("");
        })
    },
    reload() {
        //Utils.setSelects2("fornecedor", $("#fornecedorHidden").val(), "", "ds_busca_fornecedores", "CNPJ", "NOME", "", [], true, (dataChange) => {}, () => {})
        $("#fornecedor").val($("#fornecedorHidden").val()).change();
        //$("#fornecedor").attr('readonly', true);
        PO.reload();
    },
    getFormOfPayment(cpfCnpj) {
        try {
            let cs = [{
                _field: "cnpj",
                _initialValue: cpfCnpj,
                _type: 1
            }]
            let ds = "";

            const dataset = $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_forma_pagamento",
                    "constraints": cs
                }),
                success: function (data) {
                    console.log(data);
                }
            });

            if (dataset.responseJSON) {
                ds = dataset.responseJSON.content.values;
            }

            // Utils.consultDataset("ds_forma_pagamento", null, cs, false).then(data => {
            //     ds = data.content.values;
            // })

            return ds;
        } catch (e) {
            console.log("erro ====> " + e.message);
        }
    },
    events() {
        // $('[name^=formaPagamento]').on('change', (e) => {
        //     var idFormPagamento = e.target.id
        //     idFormPagamento = idFormPagamento.split('_')
        //     var index = idFormPagamento[1]

        //     $("#formaPagamentohidden_" + index).val($("#formaPagamento_" + index).val());
        //     if ($("#formaPagamento_" + index).val() == '081' || $("#formaPagamento_" + index).val() == '091') {
        //         $("#divContaAtiva" + index).hide();
        //         $("#divCodBarras" + index).show();
        //         $("#divValidaBoleto_" + index).show();
        //         // $("#botaoValidaCDB_" + index).attr('disabled',true);

        //         // Field.toggle(`#divCodBarras${ index }`, 'show');
        //         // Field.toggle('creditoConta', 'hide');
        //     } else if ($("#formaPagamento_" + index).val() == '071' || $("#formaPagamento_" + index).val() == '073') {
        //         $("#divContaAtiva" + index).show();
        //         $("#divCodBarras" + index).hide();
        //         $("#divValidaBoleto_" + index).hide();
        //         // Field.toggle('boleto', 'hide');
        //         // Field.toggle('creditoConta', 'show');

        //         let cnpj = $("#fornecedor").val();
        //         if (cnpj) {
        //             let formaPagamento =  this.getFormOfPayment(cnpj) ;
        //             console.log(formaPagamento);
        //             if(formaPagamento[0]){
        //                 $("#contAtivForn" + index).val(formaPagamento[0].AGENCIA + " " + formaPagamento[0].CUENTACOR + "-" + formaPagamento[0].DVCUENTACOR);
        //             }

        //         }

        //         $("#divContaAtiva" + index).show();
        //         $("#formaPagamento_" + index).attr('readonly', true);
        //     }
        // })
        // Apportionment.childEvents();
        // blurCodbarras();
        // $("#formaPagamento1").on('change', () => {
        //     $("#formaPagamentohidden").val($("#formaPagamento").val());
        //     if ($("#formaPagamento").val() == '081' || $("#formaPagamento").val() == '091') {
        //         Field.toggle('boleto', 'show');
        //         Field.toggle('creditoConta', 'hide');
        //     } else if ($("#formaPagamento").val() == '071' || $("#formaPagamento").val() == '073') {
        //         Field.toggle('boleto', 'hide');
        //         Field.toggle('creditoConta', 'show');
        //         let cnpj = $("#fornecedor").val();
        //         if (cnpj) {
        //             let formaPagamento = this.getFormOfPayment(cnpj);

        //             $("#contAtivForn").val(formaPagamento[0].AGENCIA + " " + formaPagamento[0].CUENTACOR)
        //         }

        //         $(".divContaAtiva").show();
        //         $("#formaPagamento").attr('readonly', true);
        //     }
        // })
    },
    setView() {
        if ($("#formaPagamento").val() != '') {
            let typeAct = verificaTipoAcerto();

            $("#formaPagamento_" + typeAct.id).val($("#formaPagamento").val()).change()
            $("#_formaPagamento_" + typeAct.id).val($("#formaPagamento").val()).change()
        }
        if ($("#formaPagamento").val() == "071" || $("#formaPagamento").val() == "073") {
            Field.toggle('boleto', 'hide');
            Field.toggle('creditoConta', 'show');
        }
        if ($("#formaPagamento").val() == "081" || $("#formaPagamento").val() == "091") {
            Field.toggle('boleto', 'show');
            Field.toggle('creditoConta', 'hide');
        }
    },
    init() {
        Utils.setSelects2('formaPagamento', $('#formaPagamentohidden').val(), false, '', '', '', '', [], true, (dataselected) => {
            $('#formaPagamentohidden').val(dataselected.target.value);
        }, () => {
            $('#formaPagamentohidden').val('')
        })
        // $("#formaPagamento").select2({ disabled: 'readonly' });
    }
}

const Obligacion = {
    get() {
        return $("#num_obrigacao").val();
    },
    set(num_oblig) {
        $("#num_obrigacao").val(num_oblig);
    },
    getType() {
        return $("#tipoObrigacao").val();
    },
    create() {
        var numObligAdiantamento = $('#numObligationAdiantamento').val()
        var numObligDespesa = $('#numObligationDespesaNF').val()
        var numObligRH = $('#numObligationRH').val()
        var numObligOuvidoria = $('#numObligationOuvidoria').val()
        var numObligComissao = $('#numObligationComissao').val()
        var numObligImposto = $('#numObligationImposto').val()
        var numObligPresConta = $('#numObligationPresConta').val()
        var numObligCosseguro = $('#numObligationCosseguro').val()// melhoria COA - DSA adição de busca de taxas
        var numObligDesApolice = $('#numObligationDesApolice').val()// melhoria COA - DSA adição de busca de taxas

        if (numObligAdiantamento != "") {
            let cardData = returnCardData();

            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_1").val(),
                _finalValue: $("#dataVencimento_1").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#idCenCusSolic").val(),
                _finalValue: $("#idCenCusSolic").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorAdiantamento").val(),
                _finalValue: $("#_valorAdiantamento").val(),
                _type: 1
            },
            {
                _field: "codPolitica",
                _initialValue: $("#codPolitica").val(),
                _finalValue: $("#codPolitica").val(),
                _type: 1
            },
            {
                _field: "idGrupoCont",
                _initialValue: $("#idGrupoCont").val(),
                _finalValue: $("#idGrupoCont").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF1").val(),
                _finalValue: $("#numeroNF1").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_1").val(),
                _finalValue: $("#formaPagamentohidden_1").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_1").val(),
                _finalValue: $("#codBarras_1").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log('reprocessamento finalizado')
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationAdiantamento").val(newNumObrigacao);
                        $("#numObligationAdiantamento").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationAdiantamento").val(numObrigacaoAtual);
                        $("#numObligationAdiantamento").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });

            // Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
            //     console.log('reprocessamento finalizado')
            //     let newNumObrigacao = data.content.values[0].NumObrigacao;
            //     let numObrigacaoAtual = $("#num_obrigacao").val();
            //     let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
            //     let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
            //     if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
            //         $("#num_obrigacao").val(newNumObrigacao);
            //         $("#_numObligationAdiantamento").val(newNumObrigacao);
            //         $("#numObligationAdiantamento").val(newNumObrigacao);
            //         TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
            //     } else {
            //         $("#_numObligationAdiantamento").val(numObrigacaoAtual);
            //         $("#numObligationAdiantamento").val(numObrigacaoAtual);
            //         $("#num_obrigacao").val(numObrigacaoAtual);
            //         TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
            //     }
            // })
        }
        if (numObligDespesa != "") {
            let cardData = returnCardData();

            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_2").val(),
                _finalValue: $("#dataVencimento_2").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#idCenCusSolic").val(),
                _finalValue: $("#idCenCusSolic").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#valorDespesa").val(),
                _finalValue: $("#valorDespesa").val(),
                _type: 1
            },
            {
                _field: "codPolitica",
                _initialValue: $("#codPolitica").val(),
                _finalValue: $("#codPolitica").val(),
                _type: 1
            },
            {
                _field: "idGrupoCont",
                _initialValue: $("#idGrupoCont").val(),
                _finalValue: $("#idGrupoCont").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF2").val(),
                _finalValue: $("#numeroNF2").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_2").val(),
                _finalValue: $("#formaPagamentohidden_2").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_2").val(),
                _finalValue: $("#codBarras_2").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })
            console.log('Constraint grava obrigação');
            console.log(constraint);

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(data);
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationDespesaNF").val(newNumObrigacao);
                        $("#numObligationDespesaNF").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationDespesaNF").val(numObrigacaoAtual);
                        $("#numObligationDespesaNF").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });

            // Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
            //     let newNumObrigacao = data.content.values[0].NumObrigacao;
            //     let numObrigacaoAtual = $("#num_obrigacao").val();
            //     let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
            //     let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
            //     if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
            //         $("#num_obrigacao").val(newNumObrigacao);
            //         $("#_numObligationDespesaNF").val(newNumObrigacao);
            //         $("#numObligationDespesaNF").val(newNumObrigacao);
            //         TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
            //     } else {
            //         $("#_numObligationDespesaNF").val(numObrigacaoAtual);
            //         $("#numObligationDespesaNF").val(numObrigacaoAtual);
            //         $("#num_obrigacao").val(numObrigacaoAtual);
            //         TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
            //     }
            // });
        }
        if (numObligRH != "") {
            console.log('Entrou no Obligacion Create - RH')
            let cardData = returnCardData();

            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_3").val(),
                _finalValue: $("#dataVencimento_3").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#idCenCusSolic").val(),
                _finalValue: $("#idCenCusSolic").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorRH").val(),
                _finalValue: $("#_valorRH").val(),
                _type: 1
            },
            {
                _field: "codPolitica",
                _initialValue: $("#codPolitica").val(),
                _finalValue: $("#codPolitica").val(),
                _type: 1
            },
            {
                _field: "idGrupoCont",
                _initialValue: $("#idGrupoCont").val(),
                _finalValue: $("#idGrupoCont").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF3").val(),
                _finalValue: $("#numeroNF3").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_3").val(),
                _finalValue: $("#formaPagamentohidden_3").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_3").val(),
                _finalValue: $("#codBarras_3").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(data);
                    Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
                        let newNumObrigacao = data.content.values[0].NumObrigacao;
                        let numObrigacaoAtual = $("#num_obrigacao").val();
                        let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                        let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                        if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                            $("#num_obrigacao").val(newNumObrigacao);
                            $("#_numObligationRH").val(newNumObrigacao);
                            $("#numObligationRH").val(newNumObrigacao);
                            TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                        } else {
                            $("#_numObligationRH").val(numObrigacaoAtual);
                            $("#numObligationRH").val(numObrigacaoAtual);
                            $("#num_obrigacao").val(numObrigacaoAtual);
                            TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                        }
                    })
                }
            });

            // Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
            //     let newNumObrigacao = data.content.values[0].NumObrigacao;
            //     let numObrigacaoAtual = $("#num_obrigacao").val();
            //     let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
            //     let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
            //     if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
            //         $("#num_obrigacao").val(newNumObrigacao);
            //         $("#_numObligationRH").val(newNumObrigacao);
            //         $("#numObligationRH").val(newNumObrigacao);
            //         TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
            //     } else {
            //         $("#_numObligationRH").val(numObrigacaoAtual);
            //         $("#numObligationRH").val(numObrigacaoAtual);
            //         $("#num_obrigacao").val(numObrigacaoAtual);
            //         TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
            //     }
            // })
        }
        if (numObligOuvidoria != "") {
            console.log('Entrou no Obligacion Create - Ouvidoria')
            let cardData = returnCardData();

            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_4").val(),
                _finalValue: $("#dataVencimento_4").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#idCenCusSolic").val(),
                _finalValue: $("#idCenCusSolic").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorOuvidoria").val(),
                _finalValue: $("#_valorOuvidoria").val(),
                _type: 1
            },
            {
                _field: "codPolitica",
                _initialValue: $("#codPolitica").val(),
                _finalValue: $("#codPolitica").val(),
                _type: 1
            },
            {
                _field: "idGrupoCont",
                _initialValue: $("#idGrupoCont").val(),
                _finalValue: $("#idGrupoCont").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF4").val(),
                _finalValue: $("#numeroNF4").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_4").val(),
                _finalValue: $("#formaPagamentohidden_4").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_4").val(),
                _finalValue: $("#codBarras_4").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(data);
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationOuvidoria").val(newNumObrigacao);
                        $("#numObligationOuvidoria").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationOuvidoria").val(numObrigacaoAtual);
                        $("#numObligationOuvidoria").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });

            // Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
            //     let newNumObrigacao = data.content.values[0].NumObrigacao;
            //     let numObrigacaoAtual = $("#num_obrigacao").val();
            //     let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
            //     let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
            //     if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
            //         $("#num_obrigacao").val(newNumObrigacao);
            //         $("#_numObligationOuvidoria").val(newNumObrigacao);
            //         $("#numObligationOuvidoria").val(newNumObrigacao);
            //         TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
            //     } else {
            //         $("#_numObligationOuvidoria").val(numObrigacaoAtual);
            //         $("#numObligationOuvidoria").val(numObrigacaoAtual);
            //         $("#num_obrigacao").val(numObrigacaoAtual);
            //         TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
            //     }
            // })
        }
        if (numObligComissao != "") {
            console.log('Entrou no Obligacion Create - Comissao')
            let cardData = returnCardData();

            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("dataVencimento_5").val(),
                _finalValue: $("dataVencimento_5").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#idCenCusSolic").val(),
                _finalValue: $("#idCenCusSolic").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorComissao").val(),
                _finalValue: $("#_valorComissao").val(),
                _type: 1
            },
            {
                _field: "codPolitica",
                _initialValue: $("#codPolitica").val(),
                _finalValue: $("#codPolitica").val(),
                _type: 1
            },
            {
                _field: "idGrupoCont",
                _initialValue: $("#idGrupoCont").val(),
                _finalValue: $("#idGrupoCont").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF5").val(),
                _finalValue: $("#numeroNF5").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_5").val(),
                _finalValue: $("#formaPagamentohidden_5").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_5").val(),
                _finalValue: $("#codBarras_5").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(data);
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationComissao").val(newNumObrigacao);
                        $("#numObligationComissao").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationComissao").val(numObrigacaoAtual);
                        $("#numObligationComissao").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });

            // Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
            //     let newNumObrigacao = data.content.values[0].NumObrigacao;
            //     let numObrigacaoAtual = $("#num_obrigacao").val();
            //     let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
            //     let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
            //     if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
            //         $("#num_obrigacao").val(newNumObrigacao);
            //         $("#_numObligationComissao").val(newNumObrigacao);
            //         $("#numObligationComissao").val(newNumObrigacao);
            //         TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
            //     } else {
            //         $("#_numObligationComissao").val(numObrigacaoAtual);
            //         $("#numObligationComissao").val(numObrigacaoAtual);
            //         $("#num_obrigacao").val(numObrigacaoAtual);
            //         TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
            //     }
            // })
        }
        if (numObligImposto != "") {
            let cardData = returnCardData();

            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_6").val(),
                _finalValue: $("#dataVencimento_6").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#idCenCusSolic").val(),
                _finalValue: $("#idCenCusSolic").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorImposto").val(),
                _finalValue: $("#_valorImposto").val(),
                _type: 1
            },
            {
                _field: "codPolitica",
                _initialValue: $("#codPolitica").val(),
                _finalValue: $("#codPolitica").val(),
                _type: 1
            },
            {
                _field: "idGrupoCont",
                _initialValue: $("#idGrupoCont").val(),
                _finalValue: $("#idGrupoCont").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF6").val(),
                _finalValue: $("#numeroNF6").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_6").val(),
                _finalValue: $("#formaPagamentohidden_6").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_6").val(),
                _finalValue: $("#codBarras_6").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(data);
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationImposto").val(newNumObrigacao);
                        $("#numObligationImposto").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationImposto").val(numObrigacaoAtual);
                        $("#numObligationImposto").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });

            // Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
            //     let newNumObrigacao = data.content.values[0].NumObrigacao;
            //     let numObrigacaoAtual = $("#num_obrigacao").val();
            //     let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
            //     let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
            //     if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
            //         $("#num_obrigacao").val(newNumObrigacao);
            //         $("#_numObligationImposto").val(newNumObrigacao);
            //         $("#numObligationImposto").val(newNumObrigacao);
            //         TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
            //     } else {
            //         $("#_numObligationImposto").val(numObrigacaoAtual);
            //         $("#numObligationImposto").val(numObrigacaoAtual);
            //         $("#num_obrigacao").val(numObrigacaoAtual);
            //         TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
            //     }
            // })
        }
        if (numObligPresConta != "") {
            let cardData = returnCardData();
            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_7").val(),
                _finalValue: $("#dataVencimento_7").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#centroCustoPresHidden").val(),
                _finalValue: $("#centroCustoPresHidden").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorPresConta").val(),
                _finalValue: $("#_valorPresConta").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF7").val(),
                _finalValue: $("#numeroNF7").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_7").val(),
                _finalValue: $("#formaPagamentohidden_7").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_7").val(),
                _finalValue: $("#codBarras_7").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            // array
            $("[tablename=tabelaGrupoContaContabil] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "contaContabilPres___" + seq,
                    _initialValue: $("#contaContabilPres___" + seq).val(),
                    _finalValue: $("#contaContabilPres___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idGrupoContPres___" + seq,
                    _initialValue: $("#idGrupoContPres___" + seq).val(),
                    _finalValue: $("#idGrupoContPres___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "valorGCContabil___" + seq,
                    _initialValue: $("#valorGCContabil___" + seq).val(),
                    _finalValue: $("#valorGCContabil___" + seq).val(),
                    _type: 1
                })
            })

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationImposto").val(newNumObrigacao);
                        $("#numObligationImposto").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationImposto").val(numObrigacaoAtual);
                        $("#numObligationImposto").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });

            // Utils.consultDataset("ds_grava_obrigacao", null, constraint, false).success(data => {
            //     let newNumObrigacao = data.content.values[0].NumObrigacao;
            //     let numObrigacaoAtual = $("#num_obrigacao").val();
            //     let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
            //     let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
            //     if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
            //         $("#num_obrigacao").val(newNumObrigacao);
            //         $("#_numObligationImposto").val(newNumObrigacao);
            //         $("#numObligationImposto").val(newNumObrigacao);
            //         TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
            //     } else {
            //         $("#_numObligationImposto").val(numObrigacaoAtual);
            //         $("#numObligationImposto").val(numObrigacaoAtual);
            //         $("#num_obrigacao").val(numObrigacaoAtual);
            //         TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
            //     }
            // });
        }
        if (numObligCosseguro != "") {
            let cardData = returnCardData();
            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_8").val(),
                _finalValue: $("#dataVencimento_8").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#centroCustoPresHidden").val(),
                _finalValue: $("#centroCustoPresHidden").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorCosseguro").val(),
                _finalValue: $("#_valorCosseguro").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF8").val(),
                _finalValue: $("#numeroNF8").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_8").val(),
                _finalValue: $("#formaPagamentohidden_8").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_8").val(),
                _finalValue: $("#codBarras_8").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            // array
            $("[tablename=tabelaGrupoContaContabil] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "contaContabilPres___" + seq,
                    _initialValue: $("#contaContabilPres___" + seq).val(),
                    _finalValue: $("#contaContabilPres___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idGrupoContPres___" + seq,
                    _initialValue: $("#idGrupoContPres___" + seq).val(),
                    _finalValue: $("#idGrupoContPres___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "valorGCContabil___" + seq,
                    _initialValue: $("#valorGCContabil___" + seq).val(),
                    _finalValue: $("#valorGCContabil___" + seq).val(),
                    _type: 1
                })
            })

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationCosseguro").val(newNumObrigacao);
                        $("#numObligationCosseguro").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationCosseguro").val(numObrigacaoAtual);
                        $("#numObligationCosseguro").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });
        }
        if (numObligDesApolice != "") {
            let cardData = returnCardData();
            let constraint = [{
                _field: "tipoAcerto",
                _initialValue: $("#tipoAcerto").val(),
                _finalValue: $("#tipoAcerto").val(),
                _type: 1
            },
            {
                _field: "processo",
                _initialValue: getWKNumProces(),
                _finalValue: getWKNumProces(),
                _type: 1
            },
            {
                _field: "tipoObrigacao",
                _initialValue: this.getType(),
                _finalValue: this.getType(),
                _type: 1
            },
            {
                _field: "cpfCnpj",
                _initialValue: $("#fornecedorHidden").val(),
                _finalValue: $("#fornecedorHidden").val(),
                _type: 1
            },
            {
                _field: "dataAbertura",
                _initialValue: $("#dataAbertura").val(),
                _finalValue: $("#dataAbertura").val(),
                _type: 1
            },
            {
                _field: "dataVencimento",
                _initialValue: $("#dataVencimento_10").val(),
                _finalValue: $("#dataVencimento_10").val(),
                _type: 1
            },
            {
                _field: "idCenCusSolic",
                _initialValue: $("#centroCustoPresHidden").val(),
                _finalValue: $("#centroCustoPresHidden").val(),
                _type: 1
            },
            {
                _field: "valor",
                _initialValue: $("#_valorDespesaApolice").val(),
                _finalValue: $("#_valorDespesaApolice").val(),
                _type: 1
            },
            {
                _field: "numeroNF",
                _initialValue: $("#numeroNF10").val(),
                _finalValue: $("#numeroNF10").val(),
                _type: 1
            },
            {
                _field: "tipoPagamento",
                _initialValue: $("#formaPagamentohidden_10").val(),
                _finalValue: $("#formaPagamentohidden_10").val(),
                _type: 1
            },
            {
                _field: "codBarras",
                _initialValue: $("#codBarras_10").val(),
                _finalValue: $("#codBarras_10").val(),
                _type: 1
            },
            {
                _field: "campos",
                _initialValue: JSON.stringify(cardData),
                _finalValue: JSON.stringify(cardData),
                _type: 1
            }
            ];

            // array
            $("[tablename=tabelaGrupoContaContabil] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "contaContabilPres___" + seq,
                    _initialValue: $("#contaContabilPres___" + seq).val(),
                    _finalValue: $("#contaContabilPres___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idGrupoContPres___" + seq,
                    _initialValue: $("#idGrupoContPres___" + seq).val(),
                    _finalValue: $("#idGrupoContPres___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "valorGCContabil___" + seq,
                    _initialValue: $("#valorGCContabil___" + seq).val(),
                    _finalValue: $("#valorGCContabil___" + seq).val(),
                    _type: 1
                })
            })

            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let seq = i + 1;
                constraint.push({
                    _field: "valorRateio___" + seq,
                    _initialValue: $("#valorRateio___" + seq).val(),
                    _finalValue: $("#valorRateio___" + seq).val(),
                    _type: 1
                })

                constraint.push({
                    _field: "idCenCusRespRateio___" + seq,
                    _initialValue: $("#idCenCusRespRateio___" + seq).val(),
                    _finalValue: $("#idCenCusRespRateio___" + seq).val(),
                    _type: 1
                })
            })

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_grava_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    let newNumObrigacao = data.content.values[0].NumObrigacao;
                    let numObrigacaoAtual = $("#num_obrigacao").val();
                    let numObrigacaoInit = newNumObrigacao[0] + newNumObrigacao[1] + newNumObrigacao[2];
                    let numObrigacaoAtualinit = numObrigacaoAtual[0] + numObrigacaoAtual[1] + numObrigacaoAtual[2];
                    if (newNumObrigacao != numObrigacaoAtual && numObrigacaoInit === numObrigacaoAtualinit) {
                        $("#num_obrigacao").val(newNumObrigacao);
                        $("#_numObligationDesApolice").val(newNumObrigacao);
                        $("#numObligationDesApolice").val(newNumObrigacao);
                        TOAST('A Obrigação ' + newNumObrigacao + ' foi gravada com sucesso! ', 'success');
                    } else {
                        $("#_numObligationDesApolice").val(numObrigacaoAtual);
                        $("#numObligationDesApolice").val(numObrigacaoAtual);
                        $("#num_obrigacao").val(numObrigacaoAtual);
                        TOAST('Gravar Reprocessar Obrigação falhou! ', 'warning');
                    }
                }
            });
        }
    },
    finaliza() {
        console.log('Entrou no Obligacion Finaliza')
        var numObligAdiantamento = $('#numObligationAdiantamento').val()
        var numObligDespesa = $('#numObligationDespesaNF').val()
        var numObligRH = $('#numObligationRH').val()
        var numObligOuvidoria = $('#numObligationOuvidoria').val()
        var numObligComissao = $('#numObligationComissao').val()
        var numObligImposto = $('#numObligationImposto').val()
        var numObligPresConta = $('#numObligationPresConta').val()
        var numObligCosseguro = $('#numObligationCosseguro').val()// melhoria COA - DSA adição de busca de taxas
        var numObligDesApolice = $('#numObligationDesApolice').val()// melhoria COA - DSA adição de busca de taxas

        if (numObligAdiantamento != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligAdiantamento.replace('.0', ''),
                _finalValue: numObligAdiantamento.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligAdiantamento + " finalizada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_finaliza_obrigacao", null, constraint, false).success(data => {
            //     console.log(numObligAdiantamento + " finalizada")
            //     console.log(data)
            // });
        }
        if (numObligDespesa != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligDespesa.replace('.0', ''),
                _finalValue: numObligDespesa.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_retornaCentroCusto",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligDespesa + " finalizada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_finaliza_obrigacao", null, constraint, false).success(data => {
            //     console.log(numObligDespesa + " finalizada")
            //     console.log(data)
            // });
        }
        if (numObligRH != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligRH.replace('.0', ''),
                _finalValue: numObligRH.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligRH + " finalizada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_finaliza_obrigacao", null, constraint, false).success(data => {
            //     console.log(numObligRH + " finalizada")
            //     console.log(data)
            // });
        }
        if (numObligOuvidoria != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligOuvidoria.replace('.0', ''),
                _finalValue: numObligOuvidoria.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligOuvidoria + " finalizada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_finaliza_obrigacao", null, constraint, false).success(data => {
            //     console.log(numObligOuvidoria + " finalizada")
            //     console.log(data)
            // });
        }
        if (numObligComissao != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligComissao.replace('.0', ''),
                _finalValue: numObligComissao.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligComissao + " finalizada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_finaliza_obrigacao", null, constraint, false).success(data => {
            //     console.log(numObligComissao + " finalizada")
            //     console.log(data)
            // });
        }
        if (numObligImposto != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligImposto.replace('.0', ''),
                _finalValue: numObligImposto.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligImposto + " finalizada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_finaliza_obrigacao", null, constraint, false).success(data => {
            //     console.log(numObligImposto + " finalizada")
            //     console.log(data)
            // });
        }
        if (numObligPresConta != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligPresConta.replace('.0', ''),
                _finalValue: numObligPresConta.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligPresConta + " finalizada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_finaliza_obrigacao", null, constraint, false).success(data => {
            //     console.log(numObligPresConta + " finalizada")
            //     console.log(data)
            // });
        }
        if (numObligCosseguro != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligCosseguro.replace('.0', ''),
                _finalValue: numObligCosseguro.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligCosseguro + " finalizada")
                    console.log(data)
                }
            });
        }
        if (numObligDesApolice != "") {
            let constraint = [{
                _field: "obligacion",
                _initialValue: numObligDesApolice.replace('.0', ''),
                _finalValue: numObligDesApolice.replace('.0', ''),
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_finaliza_obrigacao",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligDesApolice + " finalizada")
                    console.log(data)
                }
            });
        }
    },
    cancel() {
        console.log('Entrou no Obligacion Cancel')
        var numObligAdiantamento = $('#numObligationAdiantamento').val()
        var numObligDespesa = $('#numObligationDespesaNF').val()
        var numObligRH = $('#numObligationRH').val()
        var numObligOuvidoria = $('#numObligationOuvidoria').val()
        var numObligComissao = $('#numObligationComissao').val()
        var numObligImposto = $('#numObligationImposto').val()
        var numObligPresConta = $('#numObligationPresConta').val()
        var numObligCosseguro = $('#numObligationCosseguro').val()// melhoria COA - DSA adição de busca de taxas
        var numObligDesApolice = $('#numObligationDesApolice').val()// melhoria COA - DSA adição de busca de taxas

        if (numObligAdiantamento != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligAdiantamento.replace('.0', ''),
                _finalValue: numObligAdiantamento.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligAdiantamento + " cancelada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_anula_solic_obrig", null, constraint, false).success(data => {
            //     console.log(numObligAdiantamento + " cancelada")
            //     console.log(data)
            // });
        }
        if (numObligDespesa != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligDespesa.replace('.0', ''),
                _finalValue: numObligDespesa.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligDespesa + " cancelada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_anula_solic_obrig", null, constraint, false).success(data => {
            //     console.log(numObligDespesa + " cancelada")
            //     console.log(data)
            // });
        }
        if (numObligRH != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligRH.replace('.0', ''),
                _finalValue: numObligRH.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligRH + " cancelada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_anula_solic_obrig", null, constraint, false).success(data => {
            //     console.log(numObligRH + " cancelada")
            //     console.log(data)
            // });
        }
        if (numObligOuvidoria != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligOuvidoria.replace('.0', ''),
                _finalValue: numObligOuvidoria.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligOuvidoria + " cancelada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_anula_solic_obrig", null, constraint, false).success(data => {
            //     console.log(numObligOuvidoria + " cancelada")
            //     console.log(data)
            // });
        }
        if (numObligComissao != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligComissao.replace('.0', ''),
                _finalValue: numObligComissao.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligComissao + " cancelada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_anula_solic_obrig", null, constraint, false).success(data => {
            //     console.log(numObligComissao + " cancelada")
            //     console.log(data)
            // });
        }
        if (numObligImposto != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligImposto.replace('.0', ''),
                _finalValue: numObligImposto.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligImposto + " cancelada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_anula_solic_obrig", null, constraint, false).success(data => {
            //     console.log(numObligImposto + " cancelada")
            //     console.log(data)
            // });
        }
        if (numObligPresConta != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligPresConta.replace('.0', ''),
                _finalValue: numObligPresConta.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligPresConta + " cancelada")
                    console.log(data)
                }
            });

            // Utils.consultDataset("ds_anula_solic_obrig", null, constraint, false).success(data => {
            //     console.log(numObligPresConta + " cancelada")
            //     console.log(data)
            // });
        }
        if (numObligCosseguro != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligCosseguro.replace('.0', ''),
                _finalValue: numObligCosseguro.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligCosseguro + " cancelada")
                    console.log(data)
                }
            });
        }
        if (numObligDesApolice != "") {
            let constraint = [{
                _field: "nNumOblig",
                _initialValue: numObligDesApolice.replace('.0', ''),
                _finalValue: numObligDesApolice.replace('.0', ''),
                _type: 1
            }, {
                _field: "cCodWorkFlow",
                _initialValue: "F",
                _finalValue: "F",
                _type: 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_anula_solic_obrig",
                    "constraints": constraint
                }),
                success: function (data) {
                    console.log(numObligDesApolice + " cancelada")
                    console.log(data)
                }
            });
        }
    },
    getValue() {
        var valorReplace = $("#valorTotal").val()

        return valorReplace
    },
    events() {
        $('[name^=upbtnVisualizar]').on('click', (element) => {
            console.log('entrou no click visualizar')
            if (element.currentTarget.parentElement.childNodes[5].value) {
                Archive.open(element.currentTarget.parentElement.childNodes[5].value, 1000)
            } else {
                TOAST('Nenhum arquivo adicionado!', 'warning');
            }
        });

        $('[name^=dataEmissao]').on('blur', (e) => {
            try {

                var valorId = e.target.id
                valorId = valorId.split("_")
                var index = valorId[1]
                if ($("#tipoAcerto").val() != "RH") {

                    const cst = [
                        {
                            "_field": "tablename",
                            "_initialValue": "ds_cadastro_datas_vencimento",
                            "_finalValue": "ds_cadastro_datas_vencimento",
                            "_type": 1
                        }
                    ]

                    $.ajax({
                        url: '/api/public/ecm/dataset/datasets',
                        type: 'post',
                        async: true,
                        dataType: 'json',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            "name": "ds_cadastro_datas_vencimento",
                            "constraints": cst
                        }),
                        success: function (data) {
                            console.log(data);
                            let datavenc = $("#dataVencimento").val();
                            let dia = datavenc ? parseInt(datavenc.split('-')[2]) : '';
                            if (getWKNumState() == 0) {
                                // var dataEmissao = new Date($("#dataEmissao").val().split('-')[0], parseInt($("#dataEmissao").val().split('-')[1]) - 1, $("#dataEmissao").val().split('-')[2]);
                                var dataEmissao = new Date();
                                $('[name="date_startprocess"]').val(dataEmissao)
                            } else {
                                var dataEmissao = new Date($('[name="date_startprocess"]').val());
                            }
                            // var dataVencimento = new Date($("#dataVencimento").val().split('-')[0], parseInt($("#dataVencimento").val().split('-')[1]) - 1, $("#dataVencimento").val().split('-')[2]);

                            if (data) {
                                var dataConsulta = data.content.values;
                                let vencimento = "";
                                diaEmissao = dataEmissao.getDate();

                                for (let i = 0; i < dataConsulta.length; i++) {
                                    if (diaEmissao >= parseInt(dataConsulta[i].inicio) && diaEmissao < parseInt(dataConsulta[i].fim)) {
                                        vencimento = dataConsulta[i].vencimento;
                                        break;
                                    }
                                }
                                var dataVencimentoFormulario = dataEmissao;
                                if (vencimento && vencimento < dataVencimentoFormulario.getDate()) {
                                    dataVencimentoFormulario.setMonth(dataVencimentoFormulario.getMonth() + 1);
                                }
                                if (vencimento && vencimento != '') {
                                    dataVencimentoFormulario.setDate(parseInt(vencimento));
                                    document.getElementById('dataVencimento_' + index).min = dataVencimentoFormulario.toISOString().split("T")[0]
                                }
                            }
                        }
                    });

                    // Utils.consultDataset("ds_cadastro_datas_vencimento", "tableCadastroDatasVencimento", null, true).success((data) => {
                    //     let datavenc = $("#dataVencimento").val();
                    //     let dia = datavenc ? parseInt(datavenc.split('-')[2]) : '';
                    //     if (getWKNumState() == 0) {
                    //         // var dataEmissao = new Date($("#dataEmissao").val().split('-')[0], parseInt($("#dataEmissao").val().split('-')[1]) - 1, $("#dataEmissao").val().split('-')[2]);
                    //         var dataEmissao = new Date();
                    //         $('[name="date_startprocess"]').val(dataEmissao)
                    //     } else {
                    //         var dataEmissao = new Date($('[name="date_startprocess"]').val());
                    //     }
                    //     // var dataVencimento = new Date($("#dataVencimento").val().split('-')[0], parseInt($("#dataVencimento").val().split('-')[1]) - 1, $("#dataVencimento").val().split('-')[2]);
                    //     var dataConsulta = data.content.values;
                    //     let vencimento = "";
                    //     diaEmissao = dataEmissao.getDate();

                    //     for (let i = 0; i < dataConsulta.length; i++) {
                    //         if (diaEmissao >= parseInt(dataConsulta[i].inicio) && diaEmissao < parseInt(dataConsulta[i].fim)) {
                    //             vencimento = dataConsulta[i].vencimento;
                    //             break;
                    //         }
                    //     }

                    //     var dataVencimentoFormulario = dataEmissao;
                    //     if (vencimento && vencimento < dataVencimentoFormulario.getDate()) {
                    //         dataVencimentoFormulario.setMonth(dataVencimentoFormulario.getMonth() + 1);
                    //     }
                    //     if (vencimento && vencimento != '') {
                    //         dataVencimentoFormulario.setDate(parseInt(vencimento));
                    //         document.getElementById('dataVencimento_' + index).min = dataVencimentoFormulario.toISOString().split("T")[0]
                    //     }

                    // })
                }
            } catch (e) {
                console.log("ERRO ====> " + e.message);
            }
        })
        $('[name=valor]').on('change', () => {
            Approver.byGroup();
        });
    },
    count() {
        if ($("[name=temPO]:checked").val() == "sim") {
            const POs = PO.get().split(",");
            let poConstraint = "";
            let qtdPOs = [];
            POs.forEach(e => {
                poConstraint = DatasetFactory.createConstraint("POhidden", e, e, ConstraintType.SHOULD)
                let dsObligacion = DatasetFactory.getDataset("ds_form_inclusao_obrigacoes", null, [poConstraint], null);
                if (dsObligacion.values.length >= 3) {
                    qtdPOs.push(e);
                }
            })

            let poWithoutContract = qtdPOs.filter(e => {
                let documentPO = PO.all.findIndex(po => po.solicitacao == e);
                poConstraint = DatasetFactory.createConstraint("documentId", PO.all[documentPO]["document"], PO.all[documentPO]["document"], ConstraintType.MUST)
                let dataset = DatasetFactory.getDataset('ds_processo_po_assurant', null, [poConstraint], null);
                if (dataset.values[0]["temContrato"] == "NAO") {
                    return e;
                }
            })

            if (poWithoutContract.length > 0) {
                $('#poMaiorTres').val('true')
            }
        }
    },
    init() {
        Utils.setSelects2('tipoObrigacao', $('#tipoObrigacaohidden').val(), false, '', '', '', '', [], true, (dataselected) => {
            let valor = dataselected.target.value;
            var cnpj = $("#cpfCnpj").val();
            var data = [];
            Tax.setComLim(valor, cnpj, data);
        }, (dataUnselected) => {
            if (["DSP", "COM", "LIM", "COA", "DRF", "DSA"].includes(dataUnselected.params.data.id)) { // chamado 1854726
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $('.cleartipoOblig').val('');
            }
            $("#historico, #dataVencimento_5").prop("readonly", false);
            $("#dataVencimento_5").css({"pointer-events":""});
        })
    }
}

function validarBoleto(id) {

    let numObrigacao = $('#num_obrigacao').val();
    let idSolicitacao = getWKNumProces();
    let codLinhaDigit = '';
    let codTipoPago = $('#formaPagamentohidden_' + id).val();
    let codBarras = $('#codBarras_' + id).val();
    let dataVencimentoBoleto = $('#dataVencimento_' + id).val();
    dataVencimentoBoleto = dataVencimentoBoleto != '' ? returnData(dataVencimentoBoleto) : "";
    let valorBoleto = nameValorBoleto(codTipoPago, id);
    //     let idValorBoleto;
    if (codTipoPago == "081" || codTipoPago == "091") {

        if (valorBoleto && dataVencimentoBoleto && codBarras != "") {
            valorBoleto = valorBoleto.replaceAll('.', '').replace(',', '.');
            codBarras = codBarras.replaceAll('.', '').replaceAll(' ', '');
        } else {
            let msg = '';
            if (!valorBoleto) {
                msg += 'Insira um valor no boleto para validar! \n'
            }
            if (!dataVencimentoBoleto) {
                msg += 'Insira uma Data de vencimento para validar o boleto! \n'
            }
            if (!codBarras) {
                msg += 'Insira o código de barras para validar o boleto! \n'
            }
            if (msg != '') {
                if ($('#contamsg').val() == 0) {
                    TOAST(msg, "warning");
                    $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
                }
                setTimeout(() => {
                    $('#contamsg').val("0");
                }, 50);
                return;
            }
        }

        let codUser = getWKUser();

        let constraint = [
            {
                _field: "nNumOblig",
                _initialValue: numObrigacao,
                _finalValue: numObrigacao,
                _type: 1
            },
            {
                _field: "cIdSolicitacao",
                _initialValue: idSolicitacao,
                _finalValue: idSolicitacao,
                _type: 1
            },
            {
                _field: "cNumDoctoBanco",
                _initialValue: codBarras,
                _finalValue: codBarras,
                _type: 1
            },
            {
                _field: "cLinhaDigit",
                _initialValue: codLinhaDigit,
                _finalValue: codLinhaDigit,
                _type: 1
            },
            {
                _field: "cTipoPago",
                _initialValue: codTipoPago,
                _finalValue: codTipoPago,
                _type: 1
            },
            {
                _field: "cDataVencimento",
                _initialValue: dataVencimentoBoleto,
                _finalValue: dataVencimentoBoleto,
                _type: 1
            },
            {
                _field: "nValorObrigacao",
                _initialValue: valorBoleto,
                _finalValue: valorBoleto,
                _type: 1
            },
            {
                _field: "cCodUsr",
                _initialValue: codUser,
                _finalValue: codUser,
                _type: 1
            }
        ]

        $.ajax({
            url: '/api/public/ecm/dataset/datasets',
            type: 'post',
            async: false,
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                "name": "ds_validaCodigoBarras_2",
                "constraints": constraint
            }),
            success: function (data) {
                console.log(data);
                let retornoValidaCodBarras = data.content.values;
                if (retornoValidaCodBarras[0]['RETORNO'] == "0") {
                    let tituloModal = "VALIDA CÓDIGO DE BARRAS";
                    let conteudo = "Boleto valido!";

                    if ($('#contamsg').val() == 0) {
                        TOAST(conteudo, 'success');
                        $('#ativboletovalido').val('false');
                        $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
                        setTimeout(() => {
                            $('#contamsg').val("0");
                        }, 50);
                        return;
                    }
                } else {
                    let tituloModal = "VALIDA CÓDIGO DE BARRAS ";
                    let conteudo = "MENSAGEM DE ERRO: " + retornoValidaCodBarras[0]['DESCRICAO'];

                    if ($('#contamsg').val() == 0) {
                        TOAST(conteudo, 'danger');
                        $('#ativboletovalido').val("true");
                        let typeAct = verificaTipoAcerto();

                        $("#" + typeAct.numObrig).val("");
                        $("#num_obrigacao").val("");
                        if ($("#valor_ir" + typeAct.id).val() != "" && $("#valor_csrf" + typeAct.id).val() != "" && $("#valor_iss" + typeAct.id).val() != "" && $("#valor_inss" + typeAct.id).val() != "") {
                            $("#" + typeAct.valorL).val("");
                        }
                        $("#valor_ir" + typeAct.id).val("");
                        $("#valor_csrf" + typeAct.id).val("");
                        $("#valor_iss" + typeAct.id).val("");
                        $("#valor_inss" + typeAct.id).val("");
                        $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
                        setTimeout(() => {
                            $('#contamsg').val("0");
                        }, 50);
                        return;
                    }
                }
            }
        });

        // Utils.consultDataset("ds_validaCodigoBarras_2", null, constraint, false).success(data => {
        //     let retornoValidaCodBarras = data.content.values;
        //     if (retornoValidaCodBarras[0]['RETORNO'] == "0") {
        //         let tituloModal = "VALIDA CÓDIGO DE BARRAS";
        //         let conteudo = "Boleto valido!";

        //         if ($('#contamsg').val() == 0) {
        //             TOAST(conteudo, 'success');
        //             $('#ativboletovalido').val('false');
        //             $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
        //             setTimeout(() => {
        //                 $('#contamsg').val("0");
        //             }, 50);
        //             return;
        //         }
        //     } else {
        //         let tituloModal = "VALIDA CÓDIGO DE BARRAS ";
        //         let conteudo = "MENSAGEM DE ERRO: " + retornoValidaCodBarras[0]['DESCRICAO'];

        //         if ($('#contamsg').val() == 0) {
        //             TOAST(conteudo, 'danger');
        //             $('#ativboletovalido').val("true");
        //             let typeAct = verificaTipoAcerto();

        //             $("#" + typeAct.numObrig).val("");
        //             $("#num_obrigacao").val("");
        //             if ($("#valor_ir" + typeAct.id).val() != "" && $("#valor_csrf" + typeAct.id).val() != "" && $("#valor_iss" + typeAct.id).val() != "" && $("#valor_inss" + typeAct.id).val() != "") {
        //                 $("#" + typeAct.valorL).val("");
        //             }
        //             $("#valor_ir" + typeAct.id).val("");
        //             $("#valor_csrf" + typeAct.id).val("");
        //             $("#valor_iss" + typeAct.id).val("");
        //             $("#valor_inss" + typeAct.id).val("");
        //             $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
        //             setTimeout(() => {
        //                 $('#contamsg').val("0");
        //             }, 50);
        //             return;
        //         }
        //     }
        // });
    }
}

async function reprocessar() {
    try {
        let load = FLUIGC.loading(window);
        load.show();
        const finaliza = await Obligacion.finaliza();
        const cancel = await Obligacion.cancel();
        const create = await Obligacion.create();
        Tax.get();
        Tax.set();
        load.hide();
    } catch (error) {
        console.log("Error do catch reprocessar" + error);
        TOAST("Erro ao Reprocessar" + error, "warning");
        // load.hide();
    }
}

const Tax = {
    allLIM: [],
    allCOM: [],
    get() {
        try {
            var numObligAdiantamento = $('#numObligationAdiantamento').val()
            var numObligDespesa = $('#numObligationDespesaNF').val()
            var numObligRH = $('#numObligationRH').val()
            var numObligOuvidoria = $('#numObligationOuvidoria').val()
            var numObligComissao = $('#numObligationComissao').val()
            var numObligImposto = $('#numObligationImposto').val()
            var numObligPresConta = $('#numObligationPresConta').val()
            var numObligCosseguro = $('#numObligationCosseguro').val()// melhoria COA - DSA adição de busca de taxas
            var numObligDesApolice = $('#numObligationDesApolice').val()// melhoria COA - DSA adição de busca de taxas

            if (numObligAdiantamento != '') {

                $("#valor_ir1, #_valor_ir1").val("");
                $("#valor_iss1, #_valor_iss1").val("");
                $("#valor_csrf1, #_valor_csrf1").val("");
                $("#valor_inss1, #_valor_inss1").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligAdiantamento,
                    _finalValue: numObligAdiantamento,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir1, #_valor_ir1").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss1, #_valor_iss1").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf1, #_valor_csrf1").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss1, #_valor_inss1").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });

                // Utils.consultDataset("ds_get_impostos", null, cs, false).success(data => {
                //     ds = data.content.values;
                //     let dataTax = ds.map(e => {
                //         let taxValue = 0;

                //         let regexIR = /^IR/;
                //         let regexISS = /^ISS/;
                //         let regexRT = /^RT/;
                //         let regexINSS = /^INS/;

                //         if (e.MTODETOBLIGLOCAL) {
                //             taxValue = (e.MTODETOBLIGLOCAL * -1);
                //         }

                //         if (regexIR.test(e.CODCPTOEGRE)) {
                //             $("#valor_ir1, #_valor_ir1").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexISS.test(e.CODCPTOEGRE)) {
                //             $("#valor_iss1, #_valor_iss1").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexRT.test(e.CODCPTOEGRE)) {
                //             $("#valor_csrf1, #_valor_csrf1").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexINSS.test(e.CODCPTOEGRE)) {
                //             $("#valor_inss1, #_valor_inss1").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         }
                //     })
                // })

            }
            if (numObligDespesa != '') {

                $("#valor_ir2, #_valor_ir2").val("");
                $("#valor_iss2, #_valor_iss2").val("");
                $("#valor_csrf2, #_valor_csrf2").val("");
                $("#valor_inss2, #_valor_inss2").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligDespesa,
                    _finalValue: numObligDespesa,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir2, #_valor_ir2").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss2, #_valor_iss2").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf2, #_valor_csrf2").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss2, #_valor_inss2").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });

                // Utils.consultDataset("ds_get_impostos", null, cs, false).success(data => {
                //     ds = data.content.values;
                //     let dataTax = ds.map(e => {
                //         let taxValue = 0;

                //         let regexIR = /^IR/;
                //         let regexISS = /^ISS/;
                //         let regexRT = /^RT/;
                //         let regexINSS = /^INS/;

                //         if (e.MTODETOBLIGLOCAL) {
                //             taxValue = (e.MTODETOBLIGLOCAL * -1);
                //         }

                //         if (regexIR.test(e.CODCPTOEGRE)) {
                //             $("#valor_ir2, #_valor_ir2").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexISS.test(e.CODCPTOEGRE)) {
                //             $("#valor_iss2, #_valor_iss2").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexRT.test(e.CODCPTOEGRE)) {
                //             $("#valor_csrf2, #_valor_csrf2").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexINSS.test(e.CODCPTOEGRE)) {
                //             $("#valor_inss2, #_valor_inss2").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         }
                //     })
                // })
            }
            if (numObligRH != "") {

                $("#valor_ir3, #_valor_ir3").val("");
                $("#valor_iss3, #_valor_iss3").val("");
                $("#valor_csrf3, #_valor_csrf3").val("");
                $("#valor_inss3, #_valor_inss3").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligRH,
                    _finalValue: numObligRH,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            ds = data.content.values;
                            console.log("Consulta do ds imposto retorno: " + ds)
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir3, #_valor_ir3").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss3, #_valor_iss3").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf3, #_valor_csrf3").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss3, #_valor_inss3").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });

                // Utils.consultDataset("ds_get_impostos", null, cs, false).success(data => {
                //     ds = data.content.values;
                //     console.log("Consulta do ds imposto retorno: " + ds)
                //     let dataTax = ds.map(e => {
                //         let taxValue = 0;

                //         let regexIR = /^IR/;
                //         let regexISS = /^ISS/;
                //         let regexRT = /^RT/;
                //         let regexINSS = /^INS/;

                //         if (e.MTODETOBLIGLOCAL) {
                //             taxValue = (e.MTODETOBLIGLOCAL * -1);
                //         }

                //         if (regexIR.test(e.CODCPTOEGRE)) {
                //             $("#valor_ir3, #_valor_ir3").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexISS.test(e.CODCPTOEGRE)) {
                //             $("#valor_iss3, #_valor_iss3").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexRT.test(e.CODCPTOEGRE)) {
                //             $("#valor_csrf3, #_valor_csrf3").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexINSS.test(e.CODCPTOEGRE)) {
                //             $("#valor_inss3, #_valor_inss3").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         }
                //     })
                // })
            }
            if (numObligOuvidoria != "") {

                $("#valor_ir4, #_valor_ir4").val("");
                $("#valor_iss4, #_valor_iss4").val("");
                $("#valor_csrf4, #_valor_csrf4").val("");
                $("#valor_inss4, #_valor_inss4").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligOuvidoria,
                    _finalValue: numObligOuvidoria,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir4, #_valor_ir4").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss4, #_valor_iss4").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf4, #_valor_csrf4").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss4, #_valor_inss4").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });


                // Utils.consultDataset("ds_get_impostos", null, cs, false).success(data => {
                //     ds = data.content.values;
                //     let dataTax = ds.map(e => {
                //         let taxValue = 0;

                //         let regexIR = /^IR/;
                //         let regexISS = /^ISS/;
                //         let regexRT = /^RT/;
                //         let regexINSS = /^INS/;

                //         if (e.MTODETOBLIGLOCAL) {
                //             taxValue = (e.MTODETOBLIGLOCAL * -1);
                //         }

                //         if (regexIR.test(e.CODCPTOEGRE)) {
                //             $("#valor_ir4, #_valor_ir4").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexISS.test(e.CODCPTOEGRE)) {
                //             $("#valor_iss4, #_valor_iss4").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexRT.test(e.CODCPTOEGRE)) {
                //             $("#valor_csrf4, #_valor_csrf4").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexINSS.test(e.CODCPTOEGRE)) {
                //             $("#valor_inss4, #_valor_inss4").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         }
                //     })
                // })
            }
            if (numObligComissao != "") {

                $("#valor_ir5, #_valor_ir5").val("");
                $("#valor_iss5, #_valor_iss5").val("");
                $("#valor_csrf5, #_valor_csrf5").val("");
                $("#valor_inss5, #_valor_inss5").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligComissao,
                    _finalValue: numObligComissao,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir5, #_valor_ir5").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss5, #_valor_iss5").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf5, #_valor_csrf5").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss5, #_valor_inss5").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });

                // Utils.consultDataset("ds_get_impostos", null, cs, false).success(data => {
                //     ds = data.content.values;
                //     let dataTax = ds.map(e => {
                //         let taxValue = 0;

                //         let regexIR = /^IR/;
                //         let regexISS = /^ISS/;
                //         let regexRT = /^RT/;
                //         let regexINSS = /^INS/;

                //         if (e.MTODETOBLIGLOCAL) {
                //             taxValue = (e.MTODETOBLIGLOCAL * -1);
                //         }

                //         if (regexIR.test(e.CODCPTOEGRE)) {
                //             $("#valor_ir5, #_valor_ir5").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexISS.test(e.CODCPTOEGRE)) {
                //             $("#valor_iss5, #_valor_iss5").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexRT.test(e.CODCPTOEGRE)) {
                //             $("#valor_csrf5, #_valor_csrf5").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexINSS.test(e.CODCPTOEGRE)) {
                //             $("#valor_inss5, #_valor_inss5").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         }
                //     })
                // })
            }
            if (numObligImposto != "") {

                $("#valor_ir6, #_valor_ir6").val("");
                $("#valor_iss6, #_valor_iss6").val("");
                $("#valor_csrf6, #_valor_csrf6").val("");
                $("#valor_inss6, #_valor_inss6").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligImposto,
                    _finalValue: numObligImposto,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;
                                $("#valor_ir6, #_valor_ir6").val("-" + taxValue.toLocaleString('pt-br', {
                                    minimumFractionDigits: 2
                                }));

                                // let regexIR = /^IR/;
                                // let regexISS = /^ISS/;
                                // let regexRT = /^RT/;
                                // let regexINSS = /^INS/;

                                // if (e.MTODETOBLIGLOCAL) {
                                //     taxValue = (e.MTODETOBLIGLOCAL * -1);
                                // }

                                // if (regexIR.test(e.CODCPTOEGRE)) {
                                //     $("#valor_ir6, #_valor_ir6").val("-" + taxValue.toLocaleString('pt-br', {
                                //         minimumFractionDigits: 2
                                //     }));
                                // } else if (regexISS.test(e.CODCPTOEGRE)) {
                                //     $("#valor_iss___6, #_valor_iss6").val("-" + taxValue.toLocaleString('pt-br', {
                                //         minimumFractionDigits: 2
                                //     }));
                                // } else if (regexRT.test(e.CODCPTOEGRE)) {
                                //     $("#valor_csrf6, #_valor_csrf6").val("-" + taxValue.toLocaleString('pt-br', {
                                //         minimumFractionDigits: 2
                                //     }));
                                // } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                //     $("#valor_inss6, #_valor_inss6").val("-" + taxValue.toLocaleString('pt-br', {
                                //         minimumFractionDigits: 2
                                //     }));
                                // }
                            })
                        }
                    }
                });

                //     Utils.consultDataset("ds_get_impostos", null, cs, false).success(data => {
                //         ds = data.content.values;
                //         let dataTax = ds.map(e => {
                //             let taxValue = 0;
                //             $("#valor_ir6, #_valor_ir6").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));

                //             // let regexIR = /^IR/;
                //             // let regexISS = /^ISS/;
                //             // let regexRT = /^RT/;
                //             // let regexINSS = /^INS/;

                //             // if (e.MTODETOBLIGLOCAL) {
                //             //     taxValue = (e.MTODETOBLIGLOCAL * -1);
                //             // }

                //             // if (regexIR.test(e.CODCPTOEGRE)) {
                //             //     $("#valor_ir6, #_valor_ir6").val("-" + taxValue.toLocaleString('pt-br', {
                //             //         minimumFractionDigits: 2
                //             //     }));
                //             // } else if (regexISS.test(e.CODCPTOEGRE)) {
                //             //     $("#valor_iss___6, #_valor_iss6").val("-" + taxValue.toLocaleString('pt-br', {
                //             //         minimumFractionDigits: 2
                //             //     }));
                //             // } else if (regexRT.test(e.CODCPTOEGRE)) {
                //             //     $("#valor_csrf6, #_valor_csrf6").val("-" + taxValue.toLocaleString('pt-br', {
                //             //         minimumFractionDigits: 2
                //             //     }));
                //             // } else if (regexINSS.test(e.CODCPTOEGRE)) {
                //             //     $("#valor_inss6, #_valor_inss6").val("-" + taxValue.toLocaleString('pt-br', {
                //             //         minimumFractionDigits: 2
                //             //     }));
                //             // }
                //         })
                //     })
            }
            if (numObligPresConta != "") {

                $("#valor_ir7, #_valor_ir7").val("");
                $("#valor_iss7, #_valor_iss7").val("");
                $("#valor_csrf7, #_valor_csrf7").val("");
                $("#valor_inss7, #_valor_inss7").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligPresConta,
                    _finalValue: numObligPresConta,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir7, #_valor_ir7").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss7, #_valor_iss7").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf7, #_valor_csrf7").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss7, #_valor_inss7").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });

                // Utils.consultDataset("ds_get_impostos", null, cs, false).success(data => {
                //     ds = data.content.values;
                //     let dataTax = ds.map(e => {
                //         let taxValue = 0;

                //         let regexIR = /^IR/;
                //         let regexISS = /^ISS/;
                //         let regexRT = /^RT/;
                //         let regexINSS = /^INS/;

                //         if (e.MTODETOBLIGLOCAL) {
                //             taxValue = (e.MTODETOBLIGLOCAL * -1);
                //         }

                //         if (regexIR.test(e.CODCPTOEGRE)) {
                //             $("#valor_ir7, #_valor_ir7").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexISS.test(e.CODCPTOEGRE)) {
                //             $("#valor_iss7, #_valor_iss7").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexRT.test(e.CODCPTOEGRE)) {
                //             $("#valor_csrf7, #_valor_csrf7").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         } else if (regexINSS.test(e.CODCPTOEGRE)) {
                //             $("#valor_inss7, #_valor_inss7").val("-" + taxValue.toLocaleString('pt-br', {
                //                 minimumFractionDigits: 2
                //             }));
                //         }
                //     })
                // })
            }
            if (numObligCosseguro != "") { // melhoria COA - DSA adição de busca de taxas

                $("#valor_ir8, #_valor_ir8").val("");
                $("#valor_iss8, #_valor_iss8").val("");
                $("#valor_csrf8, #_valor_csrf8").val("");
                $("#valor_inss8, #_valor_inss8").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligCosseguro,
                    _finalValue: numObligCosseguro,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir8, #_valor_ir8").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss8, #_valor_iss8").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf8, #_valor_csrf8").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss8, #_valor_inss8").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });
            }
            if (numObligDesApolice != "") { // melhoria COA - DSA adição de busca de taxas

                $("#valor_ir10, #_valor_ir10").val("");
                $("#valor_iss10, #_valor_iss10").val("");
                $("#valor_csrf10, #_valor_csrf10").val("");
                $("#valor_inss10, #_valor_inss10").val("");

                let cs = [{
                    _field: "obligacion",
                    _initialValue: numObligDesApolice,
                    _finalValue: numObligDesApolice,
                    _type: 1
                }]

                let ds = false;

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_get_impostos",
                        "constraints": cs
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            ds = data.content.values;
                            let dataTax = ds.map(e => {
                                let taxValue = 0;

                                let regexIR = /^IR/;
                                let regexISS = /^ISS/;
                                let regexRT = /^RT/;
                                let regexINSS = /^INS/;

                                if (e.MTODETOBLIGLOCAL) {
                                    taxValue = (e.MTODETOBLIGLOCAL * -1);
                                }

                                if (regexIR.test(e.CODCPTOEGRE)) {
                                    $("#valor_ir10, #_valor_ir10").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexISS.test(e.CODCPTOEGRE)) {
                                    $("#valor_iss10, #_valor_iss10").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexRT.test(e.CODCPTOEGRE)) {
                                    $("#valor_csrf10, #_valor_csrf10").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                } else if (regexINSS.test(e.CODCPTOEGRE)) {
                                    $("#valor_inss10, #_valor_inss10").val("-" + taxValue.toLocaleString('pt-br', {
                                        minimumFractionDigits: 2
                                    }));
                                }
                            })
                        }
                    }
                });
            }
        } catch (e) {
            console.log("erro ====> " + e.message);
        }
    },
    set() {
        try {
            let taxSumAdiantamento = $("#_valorAdiantamento").val() == undefined ? Utils.stringToFloat($("#valorAdiantamento").val()) : Utils.stringToFloat($("#_valorAdiantamento").val());
            $(".imposto-adiantamento").each((i, e) => {
                taxSumAdiantamento += Utils.stringToFloat(e.value);
            })
            $("#valorLiqAdiantamento, #_valorLiqAdiantamento").val(taxSumAdiantamento.toLocaleString('pt-br', {
                minimumFractionDigits: 2
            }))

            let taxSumDespesa = $("#_valorDespesa").val() == undefined ? Utils.stringToFloat($("#valorDespesa").val()) : Utils.stringToFloat($("#_valorDespesa").val());
            $(".imposto-despesa").each((i, e) => {
                taxSumDespesa += Utils.stringToFloat(e.value);
            })
            $("#valorLiqDespesa, #_valorLiqDespesa").val(taxSumDespesa.toLocaleString('pt-br', {
                minimumFractionDigits: 2
            }))

            let taxSumRH = $("#_valorRH").val() == undefined ? Utils.stringToFloat($("#valorRH").val()) : Utils.stringToFloat($("#_valorRH").val());
            $(".imposto-RH").each((i, e) => {
                taxSumRH += Utils.stringToFloat(e.value);
            })
            $("#valorLiqRH, #_valorLiqRH").val(taxSumRH.toLocaleString('pt-br', {
                minimumFractionDigits: 2
            }))

            let taxSumOuvidoria = $("#_valorOuvidoria").val() == undefined ? Utils.stringToFloat($("#valorOuvidoria").val()) : Utils.stringToFloat($("#_valorOuvidoria").val());
            $(".imposto-ouvidoria").each((i, e) => {
                taxSumOuvidoria += Utils.stringToFloat(e.value);
            })
            $("#valorLiqOuvidoria, #_valorLiqOuvidoria").val(taxSumOuvidoria.toLocaleString('pt-br', {
                minimumFractionDigits: 2
            }))

            let taxSumComissao = $("#_valorComissao").val() == undefined ? Utils.stringToFloat($("#valorComissao").val()) : Utils.stringToFloat($("#_valorComissao").val());
            $(".imposto-comissao").each((i, e) => {
                taxSumComissao += Utils.stringToFloat(e.value);
            })
            $("#valorLiqComissao, #_valorLiqComissao").val('');
            $("#valorLiqComissao, #_valorLiqComissao").val(taxSumComissao.toLocaleString('pt-br', {
                minimumFractionDigits: 2
            }))

            let taxSumImposto = $("#_valorImposto").val() == undefined ? Utils.stringToFloat($("#valorImposto").val()) : Utils.stringToFloat($("#_valorImposto").val());
            $(".imposto-imposto").each((i, e) => {
                taxSumImposto += Utils.stringToFloat(e.value);
            })
            $("#valorLiqImposto, #_valorLiqImposto").val('');
            $("#valorLiqImposto, #_valorLiqImposto").val(taxSumImposto.toLocaleString('pt-br', {
                minimumFractionDigits: 2
            }))

            let taxSumPresConta = $("#_valorPresConta").val() == undefined ? Utils.stringToFloat($("#valorPresConta").val()) : Utils.stringToFloat($("#_valorPresConta").val());
            $(".imposto-presconta").each((i, e) => {
                taxSumPresConta += Utils.stringToFloat(e.value);
            })
            $("#valorLiqPresConta, #_valorLiqPresConta").val(taxSumPresConta.toLocaleString('pt-br', {
                minimumFractionDigits: 2
            }))
        } catch (e) {
            console.log("ERRO ===> " + e.message);
        }
    },
    setView() {
        if (Obligacion.getType() == "COM" || Obligacion.getType() == "LIM" || Obligacion.getType() == "COA" || Obligacion.getType() == "DSA") {// melhoria COA - DSA
            $("#divImposto").show();
            $(".ComLim").hide();
            $(".temPO").hide();
            $("#imposto option:selected").text($('#impostohidden').val() + " - " + $("#valorTotal").val());
            $("#_imposto option:selected").text($('#impostohidden').val() + " - " + $("#valorTotal").val());
            let tipoAcerto = $('#tipoAcerto').val();
            let typeAct = verificaTipoAcerto()
            let valorField = typeAct.valorT;
            if (tipoAcerto == "comissao") {
                valorField = "valorComissao";
            }
            if (tipoAcerto == "imposto") {
                valorField = "valorImposto";
            }
            if (tipoAcerto == "cosseguro") {
                valorField = "valorCosseguro";
            }
            if (tipoAcerto == "despesa_apolice") {
                valorField = "valorDespesaApolice";
            }
            
            let valorT = $("#valorTotal").val();
            valorT = Number(valorT.replace(',', '.'))
            let valorTMsk = valorT.toLocaleString('pt-br', { minimumFractionDigits: 2 });
            $('#' + valorField).val(valorTMsk);
            $('#_' + valorField).val(valorTMsk);
        }
    },
    setComLim(valor, cnpj, dataResp) {
        try {
            console.log(dataResp);
            $('#tipoObrigacaohidden').val(valor);

            if (valor == "LIM" || valor == "COM" || valor == "COA" || valor == "DSA") {
                if (valor == "LIM") {
                    $("#lblImposto").text("Imposto:");
                }
                if (valor == "COM") {
                    $("#lblImposto").text("Comissão:");
                }
                if(valor == "COA" || valor == "DSA"){
                    $("#lblImposto").text("Obrigação:");
                }
                let respFormPag = Provider.getFormOfPayment($('#fornecedorHidden').val());
                let cTipoId = respFormPag[0]['TIPOID'];
                let cNumid = respFormPag[0]['NUMID'];
                let cDvid = respFormPag[0]['DVID'];

                console.log('cTipoId:' + cTipoId);
                console.log('cNumid:' + cNumid);
                console.log('cDvid:' + cDvid);
                console.log('valor:' + valor);

                let constraint = [
                    {
                        _field: "cTipoOblig",
                        _initialValue: valor,
                        _finalValue: valor,
                        _type: 1
                    },
                    {
                        _field: "cTipoId",
                        _initialValue: cTipoId,
                        _finalValue: cTipoId,
                        _type: 1
                    },
                    {
                        _field: "cNumId",
                        _initialValue: cNumid,
                        _finalValue: cNumid,
                        _type: 1
                    },
                    {
                        _field: "cDvId",
                        _initialValue: cDvid,
                        _finalValue: cDvid,
                        _type: 1
                    }
                ]

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_lista_obrig",
                        "constraints": constraint
                    }),
                    success: function (data) {
                        console.log(data);
                        dataResp = data.content.values;
                        console.log(dataResp);
                    }
                });

                // Utils.consultDataset("ds_lista_obrig", null, constraint, false).success(data => {
                //     dataResp = data.content.values;
                //     console.log(dataResp);
                // })

            } else {
                $("#divImposto").hide();
                $("#imposto").html('');
                $("#lblImposto").text("");
                $('#listarobrigacoes').val(false);
                $('#statusoblig').val("");
                clearformImposto();
                return;
            }
            if (dataResp[0]['Erro'] == "Erro") {
                let conteudo = "O Tipo de Obrigação '" + valor + "' não possui obrigação disponível.";
                TOAST(conteudo, 'danger');
                $("#imposto").html('');
                $("#divImposto").hide();
                return;
            }
            $("#divImposto").show();
            console.log(dataResp);
            var data2 = [];
            for (var i = 0; i < dataResp.length; i++) {
                var obj = {
                    id: i,
                    text: dataResp[i]["numoblig"] + " - " + (Number(dataResp[i]["mtobrutoobliglocal"])).toLocaleString('pt-br', {
                        minimumFractionDigits: 2
                    }) + (dataResp[i]["stsoblig"] == "PAG" ? " - Net" : "")
                }
                data2.push(obj)
            }

            console.log(data2)
            $("#imposto").html('');
            $("#imposto")
                .select2({
                    data: data2,
                    placeholder: "Escolha uma Obrigação",
                    allowClear: true,
                    theme: "bootstrap",
                    multiple: true,
                    language: "pt-BR"
                })
                .on("select2:select", (e) => {
                    let selected = e.target.value;
                    let obligSelected = dataResp[selected];
                    $("#impostohidden").val(obligSelected.numoblig);
                    let typeAct = verificaTipoAcerto();

                    $("#historico").prop("readonly", true);
                    if (typeAct.tipoAcerto == "comissao") {
                        typeAct.numobligField = "numObligationComissao"
                        typeAct.divnumoblig = "divNumObligComissao",
                            typeAct.dataVenc = "dataVencimento_5"

                        if(obligSelected.stsoblig == "PAG"){
                            $("#dataVencimento_5").prop("readonly", true);
                            $("#dataVencimento_5").css({"pointer-events":"none"});
                            $("#imposto_net").val("SIM");
                        }
                        else{
                            $("#imposto_net").val("NAO");
                        }
                    }
                    if (typeAct.tipoAcerto == "imposto") {
                        typeAct.numobligField = "numObligationImposto"
                        typeAct.divnumoblig = "divNumObligImposto",
                            typeAct.dataVenc = "dataVencimento_6"
                    }
                    if (typeAct.tipoAcerto == "cosseguro") { // melhoria COA - DSA adição de estrutura para cosseguro e despesa de apólice
                        typeAct.numobligField = "numObligationCosseguro"
                        typeAct.divnumoblig = "divNumObligCosseguro",
                            typeAct.dataVenc = "dataVencimento_8"
                    }
                    if (typeAct.tipoAcerto == "despesa_apolice") {
                        typeAct.numobligField = "numObligationDesApolice"
                        typeAct.divnumoblig = "divNumObligationDesApolice",
                            typeAct.dataVenc = "dataVencimento_10"
                    }

                    Utils.setZoomData("centCusSolic", obligSelected["centrocusto"]);
                    $('#idCenCusSolic').val(obligSelected["centrocusto"]);

                    $('#' + typeAct.dataVenc).val(obligSelected["fecgtiapago"]);
                    let valBrutooblig = obligSelected["mtobrutoobliglocal"];
                    let valNetooblig = obligSelected["mtonetoobliglocal"] ? obligSelected["mtonetoobliglocal"] : obligSelected["mtobrutoobliglocal"];
                    let valorTotal = Number(valBrutooblig.replace(',', '.'));
                    let valorNetoTotal = Number(valNetooblig.replace(',', '.'));
                    let valotTotalMask = valorTotal.toLocaleString('pt-br', { minimumFractionDigits: 2 });
                    let valotNetoTotalMask = valorNetoTotal.toLocaleString('pt-br', { minimumFractionDigits: 2 });
                    $('#valorTotal').val((valorTotal.toFixed(2)).replace('.', ','));
                    $('#' + typeAct.valorT).val(valotTotalMask);
                    $('#' + typeAct.valorT).attr('readonly', true);
                    $('#' + typeAct.valorT).prop('disabled', true);
                    $("#" + typeAct.valorL).val(valotNetoTotalMask);
                    $('#historico').val(obligSelected["historico"]);
                    $('#' + typeAct.divnumoblig).show();
                    $('#' + typeAct.numobligField).val(obligSelected["numoblig"] + '.0');
                    $('#num_obrigacao').val(obligSelected["numoblig"] + '.0');
                    let tipopagoOblig = obligSelected["tipopago"];
                    let tipopagoForn = $('#formaPagamentohidden_' + typeAct.id).val();
                    if (tipopagoForn != tipopagoOblig) {
                        if (tipopagoOblig != "") {
                            let tituloModal = "VALIDA CÓDIGO DE BARRAS ";
                            let conteudo = "Forma de Pagamento da Obrigação ( " + tipopagoOblig + " )selecionada é diferente da Forma de Pagamento cadastrada para o Fornecedor ( " + tipopagoForn + " ), verifique o cadastrado da Obrigação.";
                            TOAST(conteudo, 'danger');
                        }
                    }
                    $('#listarobrigacoes').val(true);
                    $('#statusoblig').val(obligSelected["stsoblig"]);

                    //Inserindo imposto
                    Provider.select()
                    Tax.get()
                    Tax.set();
                    $(".rowConta").removeClass("col-md-6").addClass("col-md-4");

                    Approver.byGroup();
                    return;
                })
                .on("select2:unselect", () => {
                    $('#listarobrigacoes').val(false);
                    $('#statusoblig').val("");
                    // $('.ComLim').show();
                    clearformImposto();

                    $("#historico, #dataVencimento_5").prop("readonly", false);
                    $("#dataVencimento_5").css({"pointer-events":""});
                    $("#imposto_net").val("");
                    return;
                })
        } catch (e) {
            console.log("erro ===> " + e.message);
        }
    }
}

const Apportionment = {
    sum() {
        let apportionmentTotal = 0;
        $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
            let index = $(e).find('[name^=valorRateio___]').attr('name').split('___')[1];
            apportionmentTotal += $(`[name ^= valorRateio___${index}]`).val() ? Utils.formatFloat($(`[name ^= valorRateio___${index}]`).val()) : 0;
        })
        $("#totalRateio").val(apportionmentTotal.toLocaleString("pt-BR", {
            useGrouping: true,
            minimumFractionDigits: 2
        }))
        let valTot = $("#valorTotal").val();
        valTot = parseFloat(valTot.replaceAll('.', '').replace(',', '.'));
        let totRat = $("#totalRateio").val();
        totRat = parseFloat(totRat.replaceAll('.', '').replace(',', '.'));
        let difVal = valTot - totRat;
        difVal = parseFloat(difVal.toFixed(2));
        if (difVal != 0 && difVal <= 0.10) {
            let lastRowVal = $('[tablename=tabelaRateio]').find('tbody tr').last().find('[name^=valorRateio___]').val();
            lastRowVal = lastRowVal ? lastRowVal : '0'; // evitar retorno de NaN - MFX
            lastRowVal = parseFloat(lastRowVal.replaceAll('.', '').replace(',', '.'));
            let newLastRowVal = lastRowVal + difVal;
            $('[tablename=tabelaRateio]')
                .find('tbody tr')
                .last()
                .find('[name^=valorRateio___]')
                .val(newLastRowVal.toLocaleString("pt-BR", {
                    useGrouping: true,
                    minimumFractionDigits: 2
                })
                );
            let apportionmentTotalDif = 0;
            $("[tablename=tabelaRateio] tr:not(:first-child)").each((i, e) => {
                let index = $(e).find('[name^=valorRateio___]').attr('name').split('___')[1];
                apportionmentTotalDif += $(`[name ^= valorRateio___${index}]`).val() ? Utils.formatFloat($(`[name ^= valorRateio___${index}]`).val()) : 0;
            })
            $("#totalRateio").val(apportionmentTotalDif.toLocaleString("pt-BR", {
                useGrouping: true,
                minimumFractionDigits: 2
            }))
        }
        if ($('#tabelasPadroes').val() != '') {
            $('.addRateio').prop('disabled', true);
            $('[tablename=tabelaRateio]').find('tbody tr').not(':first').css('pointer-events', 'none');
        } else {
            $('.addRateio').prop('disabled', false);
            $('[tablename=tabelaRateio]').find('tbody tr').not(':first').css('pointer-events', 'auto');
        }
    },
    sumContabil() {
        let apportionmentTotalContabil = 0;
        let fieldRow1;
        let fieldRow2;
        $("[tablename=tabelaGrupoContaContabil] tr:not(:first-child)").each((i, e) => {
            let index = $(e).find('[name^=valorGCContabil___]').attr('name').split('___')[1];
            i = i + 1;
            if (i == 1) {
                fieldRow1 = e;
            }
            if (i == 2) {
                fieldRow2 = e;
            }
            if ($("[tablename=tabelaGrupoContaContabil] tr:not(:first-child)").length >= 2) {
                $(".addGCContabil").prop("disabled", true);
            }
            else {
                $(".addGCContabil").prop("disabled", false);
            }
            apportionmentTotalContabil += $(`[name ^= valorGCContabil___${index}]`).val() ? Utils.formatFloat($(`[name ^= valorGCContabil___${index}]`).val()) : 0;
        })
        $("#valorPresConta").val(apportionmentTotalContabil.toLocaleString("pt-BR", {
            useGrouping: true,
            minimumFractionDigits: 2
        }))
        $('#valorTotal').val($("#valorPresConta").val());
        $("#valorLiqPresConta").val($("#valorPresConta").val());
        if (fieldRow1 && fieldRow2) {
            if ($(fieldRow1).find('[name^=valorGCContabil___]').val() < $(fieldRow2).find('[name^=valorGCContabil___]').val()) {
                // console.log("Entrou no inverter linhas maoior vem primeiro");
                let indexRow1 = $(fieldRow1).find('[name^=valorGCContabil___]').attr('name').split('___')[1];

                let gcContabilRow1 = $(fieldRow1).find('[name^=grupoContaContabilPres___]').val();
                let iDGCContabilRow1 = $(fieldRow1).find('[name^=idGrupoContPres___]').val();
                let codPoliticaPresRow1 = $(fieldRow1).find('[name^=codPoliticaPres___]').val();
                let contContabilRow1 = $(fieldRow1).find('[name^=contaContabilPres___]').val();
                let valorContabilRow1 = $(fieldRow1).find('[name^=valorGCContabil___]').val();

                let indexRow2 = $(fieldRow2).find('[name^=valorGCContabil___]').attr('name').split('___')[1];

                let gcContabilRow2 = $(fieldRow2).find('[name^=grupoContaContabilPres___]').val();
                let iDGCContabilRow2 = $(fieldRow2).find('[name^=idGrupoContPres___]').val();
                let codPoliticaPresRow2 = $(fieldRow2).find('[name^=codPoliticaPres___]').val();
                let contContabilRow2 = $(fieldRow2).find('[name^=contaContabilPres___]').val();
                let valorContabilRow2 = $(fieldRow2).find('[name^=valorGCContabil___]').val();

                // invertendo posições linha 1
                window['grupoContaContabilPres___' + indexRow1].setValue(gcContabilRow2);
                $('#idGrupoContPres___' + indexRow1).val(iDGCContabilRow2);
                $('#codPoliticaPres___' + indexRow1).val(codPoliticaPresRow2);
                $('#contaContabilPres___' + indexRow1).val(contContabilRow2).change();
                $('#valorGCContabil___' + indexRow1).val(valorContabilRow2);
                // invertendo posições linha 2
                window['grupoContaContabilPres___' + indexRow2].setValue(gcContabilRow1);
                $('#idGrupoContPres___' + indexRow2).val(iDGCContabilRow1);
                $('#codPoliticaPres___' + indexRow2).val(codPoliticaPresRow1);
                $('#contaContabilPres___' + indexRow2).val(contContabilRow1).change();
                $('#valorGCContabil___' + indexRow2).val(valorContabilRow1);
            }
        }
        Apportionment.setChildValue($("#valorPresConta").val())
        Approver.byGroup();
    },
    setChildValue(value) {
        // if ($("[tablename=tabelaRateio] tr:not(:first-child").length == 1) {
        //     $("#valorRateio___" + rowIndex.tabelaRateio).val(value);
        //     $("#totalRateio").val(value);
        // }
        if ($('#tipoAcerto').val() != 'presConta') {
            if ($("[tablename=tabelaRateio] tr:not(:first-child").length == 0) {
                let index = wdkAddChild("tabelaRateio");
                Utils.addMaskInputs();
                blurValorRat();
                let row = $("[tablename=tabelaRateio] tr:not(:first-child")[0].children[2].children[0].id.split('___')[1]
                $("#valorRateio___" + row).val(value);
                $("#totalRateio").val(value);
                $("#valorRateio___" + row).prop("readonly", true);// - MFX
                // $(".addRateio").prop("disabled", true);// - MFX
            } else if ($("[tablename=tabelaRateio] tr:not(:first-child").length == 1) {
                let row = $("[tablename=tabelaRateio] tr:not(:first-child")[0].children[2].children[0].id.split('___')[1]
                Utils.addMaskInputs();
                blurValorRat();
                $("#valorRateio___" + row).val(value);
                $("#totalRateio").val(value);
            }
        } else {
            if ($("[tablename=tabelaRateio] tr:not(:first-child").length == 0) {
                let index = wdkAddChild("tabelaRateio");
                Utils.addMaskInputs();
                $("#valorRateio___" + rowIndex.tabelaRateio).val('0,01');
                $("#valorRateio___" + rowIndex.tabelaRateio).attr('readonly', true);// - MFX
                $("#totalRateio").val('0,01');
                // $(".addRateio").prop("disabled", true);// - MFX
                $('[tablename=tabelaRateio]').find('tbody tr').not(':first').find('td').not(':nth-child(2)').css('pointer-events', 'none');// - MFX
            }
        }
    },
    setChildValueTableRateo(value) {

        let cs = [{
            _field: "cCodTabRateo",
            _initialValue: value,
            _finalValue: value,
            _type: 1
        }]

        if ($('#tabelasPadroesHidden').val() != '') {
            removeElementsTableRateo();
        }

        $.ajax({
            url: '/api/public/ecm/dataset/datasets',
            type: 'post',
            async: false,
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                "name": "ds_retornaTabelaRateio_2",
                "constraints": cs
            }),
            success: function (data) {
                data = data.content.values;
                let valorprov = $("#valorTotal").val() ? $("#valorTotal").val() : 0;
                valorprov = valorprov.replace('.', '').replace(',', '.');
                let valorTotal = parseFloat(valorprov);
                let maior_valor = { id: 0, valor: 0 };
                let total_sum = 0

                data.forEach(res => {
                    let index = wdkAddChild("tabelaRateio");
                    let porcent = res.pORCENTAJE;
                    porcent = porcent.replace(',', '.');
                    if (porcent[0] == '.') {
                        porcent = '0' + porcent;
                    }
                    porcent = parseFloat(porcent);
                    console.log('porcent: ' + porcent);
                    let percentRat = valorTotal / 100 * porcent;
                    console.log('percentRat: ' + percentRat);
                    //percentRat = parseFloat(percentRat.toFixed(2));
                    let pontoPos = percentRat.toString().indexOf('.');// - MFX
                    percentRat = parseFloat(percentRat.toString().substr(0, pontoPos + 3));// - MFX
                    console.log('percentRat Fixed 2 : ' + percentRat);

                    if (percentRat > maior_valor.valor) {
                        maior_valor.valor = percentRat;
                        maior_valor.id = index;
                    }

                    total_sum += percentRat;

                    let csCentCus = [{
                        _field: "nNumOblig",
                        _initialValue: res.cODCENCOSTO,
                        _finalValue: res.cODCENCOSTO,
                        _type: 1
                    }]

                    let centCus = '';

                    $.ajax({
                        url: '/api/public/ecm/dataset/datasets',
                        type: 'post',
                        async: false,
                        dataType: 'json',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            "name": "ds_retornaCentroCusto",
                            "constraints": csCentCus
                        }),
                        success: function (dt) {
                            console.log(dt);
                            dt = dt.content.values[0];
                            centCus = dt.dESCCENTROCUSTO;
                        }
                    });

                    // Utils.consultDataset("ds_retornaCentroCusto", null, csCentCus, false).success((data) => {
                    //     data = data.content.values[0];
                    //     centCus = data.dESCCENTROCUSTO;
                    // });

                    Utils.setZoomData(`cenCustRespRateio___${index}`, centCus);
                    Apportionment.setChildCC(index, res.cODCENCOSTO);
                    console.log(percentRat);
                    $("#valorRateio___" + index)
                        .val(Number(percentRat)
                            .toLocaleString('pt-br', {
                                minimumFractionDigits: 2
                            }));
                })

                if (total_sum < valorprov) {

                    let diferenca = valorprov - total_sum;
                    let valor_atualizado = maior_valor.valor + diferenca;

                    $("#valorRateio___" + maior_valor.id)
                        .val(Number(valor_atualizado)
                            .toLocaleString('pt-br', {
                                minimumFractionDigits: 2
                            }));

                }
                Apportionment.sum();
            }
        });

        // Utils.consultDataset("ds_retornaTabelaRateio_2", null, cs, false).success((data) => {
        //     data = data.content.values;
        //     let valorprov = $("#valorTotal").val() ? $("#valorTotal").val() : 0;
        //     valorprov = valorprov.replace('.', '').replace(',', '.');
        //     let valorTotal = parseFloat(valorprov);
        //     let maior_valor = { id: 0, valor: 0 };
        //     let total_sum = 0

        //     data.forEach(res => {
        //         let index = wdkAddChild("tabelaRateio");
        //         let porcent = res.pORCENTAJE;
        //         porcent = porcent.replace(',', '.');
        //         if (porcent[0] == '.') {
        //             porcent = '0' + porcent;
        //         }
        //         porcent = parseFloat(porcent);
        //         console.log('porcent: ' + porcent);
        //         let percentRat = valorTotal / 100 * porcent;
        //         console.log('percentRat: ' + percentRat);
        //         percentRat = parseFloat(percentRat.toFixed(2));
        //         console.log('percentRat Fixed 2 : ' + percentRat);

        //         if (percentRat > maior_valor.valor) {
        //             maior_valor.valor = percentRat;
        //             maior_valor.id = index;
        //         }

        //         total_sum += percentRat;

        //         let csCentCus = [{
        //             _field: "nNumOblig",
        //             _initialValue: res.cODCENCOSTO,
        //             _finalValue: res.cODCENCOSTO,
        //             _type: 1
        //         }]

        //         let centCus = '';

        //         $.ajax({
        //             url: '/api/public/ecm/dataset/datasets',
        //             type: 'post',
        //             async: false,
        //             dataType: 'json',
        //             contentType: 'application/json',
        //             data: JSON.stringify({
        //                 "name": "ds_retornaCentroCusto",
        //                 "constraints": csCentCus
        //             }),
        //             success: function (data) {
        //                 console.log(data);
        //                 data = data.responseJSON.content.values[0];
        //                 centCus = data.dESCCENTROCUSTO;
        //             }
        //         });

        //         // Utils.consultDataset("ds_retornaCentroCusto", null, csCentCus, false).success((data) => {
        //         //     data = data.content.values[0];
        //         //     centCus = data.dESCCENTROCUSTO;
        //         // });

        //         Utils.setZoomData(`cenCustRespRateio___${ index } `, centCus);
        //         Apportionment.setChildCC(index, res.cODCENCOSTO);
        //         console.log(percentRat);
        //         $("#valorRateio___" + index)
        //             .val(Number(percentRat)
        //                 .toLocaleString('pt-br', {
        //                     minimumFractionDigits: 2
        //                 }));
        //     })


        //     if (total_sum < valorprov) {

        //         let diferenca = valorprov - total_sum;
        //         let valor_atualizado = maior_valor.valor + diferenca;

        //         $("#valorRateio___" + maior_valor.id)
        //             .val(Number(valor_atualizado)
        //                 .toLocaleString('pt-br', {
        //                     minimumFractionDigits: 2
        //                 }));

        //     }
        //     Apportionment.sum();
        // });

    },
    childEvents() {
        $("[name^=dataVencimento_]").on("input propertychange", (event) => {
            const value = event.target.value;
            const inputid = event.target.id;
            const id = inputid.split('_')[1];
            let numOblig = verificaTipoAcerto();
            if ($('#codBarras_' + id).val() != '' && $('#formaPagamentohidden_' + id).val() == "081") {
                if ($('#ativboletovalido').val() != 'false' || $("[name=botaoAprovacao]:checked").val() == "CONTESTADO") {
                    validarBoleto(id);
                    return;
                }
            }
        })
        $("[name^=codBarras_]").on("input propertychange", (event) => {
            const value = event.target.value;
            const inputid = event.target.id;
            const id = inputid.split('_')[1];
            event.target.value = maskBoleto(value, id);
        })
        $("[name^=valorRateio___]").on("input propertychange", (event) => {
            const value = event.target.value;
            const inputid = event.target.id;
            const id = inputid.split('___')[1];
            event.target.value = maskvalor(value, id, '1');
        })
        $("[name^=valorRateio___]").on("blur", (e) => {
            this.sum();
        })
        $("[name^=valorGCContabil___]").on("input propertychange", (event) => {
            const value = event.target.value;
            const inputid = event.target.id;
            const id = inputid.split('___')[1];
            event.target.value = intPosNeg(value, id);
        })
        $("[name^=valorGCContabil___]").on("blur", (e) => {
            this.sumContabil();
        })
    },
    events() {
        $(".addRateio").on("click", (e) => {
            let index = rowIndex.tabelaRateio;
            // MaskEvent.init();
            this.childEvents();
        })
        $(".addGCContabil").on("click", (e) => {
            let index = rowIndex.tabelaGrupoContaContabil;
            // MaskEvent.init();
            $("#contaContabilPres___" + index).prop('disabled', 'true');
            this.childEvents();
        })
    },
    setChildCC(index, value) {
        $(`#idCenCusRespRateio___${index} `).val(value);
    }
}


function maskBoleto(v, i) {
    if (v[0] != "8") {
        $('#codBarras_' + i).attr('maxLength', '54');
    }
    if (v[0] == "8") {
        $('#codBarras_' + i).attr('maxLength', '55');
    }
    v = v.replace('.', '');
    v = v.replace('-', '');
    v = v.replace(' ', '');
    v = v.replace(/\D/g, '');
    if (v[0] != "8") {
        v = v.replace(/([0-9]{5})([0-9]{5})([0-9]{5})([0-9]{6})([0-9]{5})([0-9]{6})([0-9]{1})([0-9]{14})/g, "$1.$2 $3.$4 $5.$6 $7 $8");
        v = v.replace(/([0-9]{5})([0-9]{5})([0-9]{5})([0-9]{6})([0-9]{5})([0-9]{6})([0-9]{1})/g, "$1.$2 $3.$4 $5.$6 $7");
        v = v.replace(/([0-9]{5})([0-9]{5})([0-9]{5})([0-9]{6})([0-9]{5})([0-9]{6})/g, "$1.$2 $3.$4 $5.$6");
        v = v.replace(/([0-9]{5})([0-9]{5})([0-9]{5})([0-9]{6})([0-9]{5})/g, "$1.$2 $3.$4 $5");
        v = v.replace(/([0-9]{5})([0-9]{5})([0-9]{5})([0-9]{6})/g, "$1.$2 $3.$4");
        v = v.replace(/([0-9]{5})([0-9]{5})([0-9]{5})/g, "$1.$2 $3");
    }
    if (v[0] == "8") {
        v = v.replace(/([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})/g, "$1-$2 $3-$4 $5-$6 $7-$8")
        v = v.replace(/([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})([0-9]{11})/g, "$1-$2 $3-$4 $5-$6 $7")
        v = v.replace(/([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})/g, "$1-$2 $3-$4 $5-$6")
        v = v.replace(/([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})([0-9]{11})/g, "$1-$2 $3-$4 $5")
        v = v.replace(/([0-9]{11})([0-9]{1})([0-9]{11})([0-9]{1})/g, "$1-$2 $3-$4")
        v = v.replace(/([0-9]{11})([0-9]{1})([0-9]{11})/g, "$1-$2 $3")
        v = v.replace(/([0-9]{11})([0-9]{1})/g, "$1-$2")
        v = v.replace(/([0-9]{11})/g, "$1")
    }
    return v;
}

function maskvalor(v, i, type) {
    v = v.replace('.', '').replace(',', '');
    if (type == '1') {
        $('#valorRateio___' + i).attr('maxLength', '18');
    } else if (type == '2') {
        $('#valorBoleto_' + i).attr('maxLength', '18');
    }

    v = v.replace(/\D/g, '');
    v = (v / 100).toFixed(2) + '';
    v = v.replace(".", ",");
    v = v.replace(/([0-9])([0-9]{3})([0-9]{3})([0-9]{3}),/g, "$1.$2.$3.$4,");
    v = v.replace(/([0-9])([0-9]{3})([0-9]{3}),/g, "$1.$2.$3,");
    v = v.replace(/([0-9])([0-9]{3}),/g, "$1.$2,");
    v = v == '0,00' ? '' : v;
    return v;
}

function intPosNeg(v, i) {
    v = v.replace('.', '').replace(',', '');
    if (v[0] != '-') {
        $('#valorGCContabil___' + i).attr('maxLength', '18');
        v = v.replace(/\D/g, '');
        v = (v / 100).toFixed(2) + '';
        v = v.replace(".", ",");
        v = v.replace(/([0-9])([0-9]{3})([0-9]{3})([0-9]{3}),/g, "$1.$2.$3.$4,");
        v = v.replace(/([0-9])([0-9]{3})([0-9]{3}),/g, "$1.$2.$3,");
        v = v.replace(/([0-9])([0-9]{3}),/g, "$1.$2,");
        v = v == '0,00' ? '' : v;
        return v;
    } else {
        $('#valorGCContabil___' + i).attr('maxLength', '19');
        v = v.replace(/[^-0-9]/g, "");
        if (v.length == 1) {
            v = v.replace(/[^-0-9]/g, "");
        } else if (v.length == 2) {
            v = v.replace(/[^0-9]$/g, "");
        } else if (v.length >= 3) {
            v = v.replace(/(([^0-9].)|([^0-9]))$/g, "");
            v = v.replace(/\B[^0-9]{1,}\B/g, "");
            v = v.replace(/\b[^0-9]{1,}\b/g, "");
        }
        v = v.length != 1 ? (v / 100).toFixed(2) + '' : v;
        v = v.replace(".", ",");
        v = v.replace(/([0-9])([0-9]{3})([0-9]{3})([0-9]{3}),/g, "$1.$2.$3.$4,");
        v = v.replace(/([0-9])([0-9]{3})([0-9]{3}),/g, "$1.$2.$3,");
        v = v.replace(/([0-9])([0-9]{3}),/g, "$1.$2,");
        v = v == '0,00' ? '' : v;
        return v;
    }
}

const BillOfSale = {
    all: [],
    get(cpfCnpj) {
        try {
            let cst = [{
                "_field": "cpfCnpj",
                "_initialValue": cpfCnpj,
                "_finalValue": cpfCnpj,
                "_type": 1
            }]

            $.ajax({
                url: '/api/public/ecm/dataset/datasets',
                type: 'post',
                async: false,
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    "name": "ds_consulta_nota_fiscal",
                    "constraints": cst
                }),
                success: function (data) {
                    console.log(data);
                    this.all = [];
                    if (data.content.values) {
                        data = data.content.values;
                        data = data.map(e => this.all.push(e["NUMDOCTO"]))
                    }
                }
            });

            // Utils.consultDataset("ds_consulta_nota_fiscal", null, cst).success((data) => {
            //     this.all = [];
            //     data = data.content.values;
            //     data = data.map(e => this.all.push(e["NUMDOCTO"]))
            // })
        } catch (e) {
            console.log("erro ====> " + e.message);
        }
    },
    isValid(BillOfSale) {
        try {
            if (this.all.indexOf(BillOfSale) > -1) {
                return true;
            }
            return false;
        } catch (e) {
            console.log("erro ====> " + e.message);
        }
    },
    events() {
        $('[name^=numeroNF]').on("blur", (e) => {
            // console.log('entrou no onblur numeroNF')
            let nf = e.target.value;
            BillOfSale.get(nf);
            if (BillOfSale.isValid(nf)) {
                TOAST("NOTA FISCAL EXISTENTE!", "danger");
                $(`#${e.target.id} `).val("");
            }
        })
    }
}

let blurValorRat = () => {
    $(".valorRat").on("blur", e => {
        let load = FLUIGC.loading(window);
        load.show();
        //$("#valorTotal").val(e.target.value); Responsável por erro de cálculo do rateio, alterando o total da nota com os valores do rateio - MFX
        load.hide();
    });
}

let blurValorNF = () => {
    $(".valor").on("blur", e => {
        let load = FLUIGC.loading(window);
        load.show();
        var valorId = e.target.id
        valorId = valorId.split("___")
        var index = valorId[1]
        let impostosComissao = ["COM", "LIM", "COA", "DSA"];
        let valorTotal = 0
        if (impostosComissao.indexOf(Obligacion.getType()) > -1 && $("#imposto").val()) {
            if (Utils.stringToFloat(e.target.value) > Utils.stringToFloat($("#imposto").val().split(" - ")[1])) {
                TOAST("Valor da NF maior que valor da COM/LIM selecionada", "warning");
                $("#" + e.target.id).val("");
                load.hide();
                return;
            }
        } else if ($("[name=temPO]:checked").val() == "sim" && $("#PO").val()) {
            if (Utils.stringToFloat(e.target.value) > Utils.stringToFloat($("#PO option:selected").text().split(" - ")[1])) {
                TOAST("Valor da NF maior que valor da PO selecionada", "warning");
                $("#" + e.target.id).val("");
                load.hide();
                return;
            }
        }
        Apportionment.setChildValue(e.target.value)

        if (e.target.id == "valorAdiantamento") {
            $("#valorLiqAdiantamento").val(e.target.value);
            index = '1';
        } else if (e.target.id == "valorDespesa") {
            $("#valorLiqDespesa").val(e.target.value);
            index = '2';
        } else if (e.target.id == "valorRH") {
            $("#valorLiqRH").val(e.target.value);
            index = '3';
        } else if (e.target.id == "valorOuvidoria") {
            $("#valorLiqOuvidoria").val(e.target.value);
            index = '4';
        } else if (e.target.id == "valorComissao") {
            $("#valorLiqComissao").val(e.target.value);
            index = '5';
        } else if (e.target.id == "valorImposto") {
            $("#valorLiqImposto").val(e.target.value);
            index = '6';
        }

        $('.valor').each((index, element) => {
            let provisorio = Utils.stringToFloat(element.value)
            valorTotal += parseFloat(provisorio)
            $("#valorTotal").val((valorTotal.toFixed(2)).replace('.', ','));
        })

        if ($('#tabelasPadroesHidden').val() != '') {
            console.log("Tabela Rateio foi prenchida automaticamente");
            $("[tablename=tabelaRateio] tr:not(:first-child").each((index, element) => {
                fnWdkRemoveChild(element);
            });
            Apportionment.setChildValueTableRateo($("#tabelasPadroesHidden").val());
        }
        // Tax.get();
        Tax.set();
        Approver.byGroup();
        load.hide();
        if ($('#codBarras_' + index).val() != '' && ($('#formaPagamentohidden_' + index).val() == "081" || $('#formaPagamentohidden_' + index).val() == "091")) {
            let numOblig = verificaTipoAcerto();
            if ($('#ativboletovalido').val() != 'false' || $("[name=botaoAprovacao]:checked").val() == "CONTESTADO") {
                validarBoleto(index);
                return;
            }
        }
    })
}

let blurCodbarras = () => {
    $("[name^=codBarras_]").on('blur', (e) => {
        let boletoValue = e.target.value;
        let boletoID = e.target.id;
        let inputid = boletoID.split('_')[0];
        let inputindex = boletoID.split('_')[1];
        let codTipoPago = $('#formaPagamentohidden_' + inputindex).val();
        let valorBoleto = nameValorBoleto(codTipoPago, inputindex);
        let numOblig = verificaTipoAcerto();
        if (boletoValue.length >= "54") {
            if ($('#dataVencimento_' + inputindex).val() != '' && valorBoleto != '') {
                if ($('#ativboletovalido').val() != 'false' || $("[name=botaoAprovacao]:checked").val() == "CONTESTADO") {
                    validarBoleto(inputindex);
                    return;
                }
            } else if ($('#dataVencimento_' + inputindex).val() == '') {
                if ($('#ativboletovalido').val() != 'false') {
                    if ($('#contamsg').val() == 0) {
                        TOAST("Campo Data de Vencimento está vazio, preencha para continuar.", "danger");
                        $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
                    }

                }

            } else if (valorBoleto == "") {
                if ($('#ativboletovalido').val() != 'false') {
                    if ($('#contamsg').val() == 0) {
                        TOAST("Campo Valor está vazio, preencha para continuar.", "danger");
                        $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
                    }

                }

            }
        }
        if (boletoValue.length > "35" && boletoValue.length < "54") {
            if ($('#contamsg').val() == 0) {
                TOAST("Código de Barras incompleto, verifique e preencha para continuar.", "danger");
                $('#contamsg').val(parseInt($('#contamsg').val()) + 1)
            }
        }
        setTimeout(() => {
            $('#contamsg').val("0");
        }, 50);
    })
}

const Field = {
    release(fieldName) {
        $('[name="' + fieldName + '"]').css('pointer-events', '');
        $('[name="' + fieldName + '"]').attr('readonly', false);
    },
    block(fieldName) {
        $('[name="' + fieldName + '"]').css('pointer-events', 'none');
        $('[name="' + fieldName + '"]').attr('readonly', true);
    },
    hide(showFields = ['']) {
        $('form-mode:visible').parent().hide()
        showFields.forEach(e => $('[name="' + e + '"').parent().show())
    },
    toggle(campo, type) {
        if (type == 'show') {
            $("." + campo).show().removeClass("escondeAbertura");
        } else {
            $("." + campo).hide().addClass("escondeAbertura");
        }
    }
}

const Archive = {
    delete(documentId, clearAll = false) {
        top.WCMAPI.Create({
            url: "https://fluig-dev.assurant.com/api/public/2.0/documents/deleteDocument/" + documentId,
            method: "POST",
            success: e => {
                if (!clearAll) {
                    $('[name="upName"]').val('')
                    $('[name="upId"]').val('')
                    TOAST("Arquivo deletado com sucesso.", "success")
                } else { }
            },
            error: e => {
                console.log("Falha ao deletar o arquivo", e);
            }
        });
    },
    save(file, index) {
        //if ($(`#upDescricao___${index} `).val().trim() != "") {
            $.ajax({
                url: '/api/public/ecm/document/createDocument',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    "description": ($(`#upDescricao___${index} `).val().trim() != "" ? $(`#upDescricao___${index} `).val() : file.name),
                    "parentId": PARENTID,
                    "attachments": [{
                        "fileName": file.name
                    }]
                })
            }).done((result) => {
                let documentId = result.content.id;

                if (index) {
                    $(`#upId___${index} `).val(documentId);
                    $(`#upName___${index} `).val(file.name);

                    $(`#upName___${index} `).parents('.areaAnexo').find('.addFilePaiFilho').addClass("anexoInserido");
                } else {
                    $('[name="upName"]').val(file.name)
                    $('[name="upId"]').val(documentId)
                }

                TOAST('Arquivo ' + file.name + ' publicado com sucesso.', 'success');

                $(`#upId___${index} `).parents(".areaAnexo").find(".divNomesAnexo h4").text($(`#upDescricao___${index} `).val());
                $(`#upId___${index} `).parents(".areaAnexo").find(".divNomesAnexo p").text(file.name);
                $(`#upId___${index} `).parents(".areaAnexo").find(".divNomesAnexo").show();
                $(`#upDescricao___${index} `).hide();

            }).fail((result) => {
                TOAST('Não foi possivel publicar o arquivo.', 'danger');
                // console.log("Falha", result);
            });
        /*}
        else {
            TOAST('Insira uma descrição para o anexo.', 'danger');
        }*/
    },
    open(docId, docVersion) {
        var parentOBJ = (window.opener) ? window.opener.parent : parent;
        var cfg = {
            url: "/ecm_documentview/documentView.ftl",
            maximized: true,
            title: "Visualizador de Documentos",
            callBack: function () {
                parentOBJ.ECM.documentView.getDocument(docId, docVersion);
            },
            customButtons: []
        };
        parentOBJ.ECM.documentView.panel = parentOBJ.WCMC.panel(cfg);
    },
    addChildTable(tableName) {
        let linha = wdkAddChild(tableName);
        if (tableName.includes('UploadFiles')) {
            $("[tablename=tabelaUploadFiles] tr:not(:first-child)").each((index, element) => {
                $('#upFile___' + linha).fileupload({
                    dataType: 'json',
                    start: () => FLUIGC.loading(window).show,
                    done: (e, data) => {
                        let file = data.result.files[0];

                        Archive.save(file, linha);
                    },
                    fail: (e, data) => {
                        console.log("Falha no fileupload", data);
                        TOAST('Não foi possivel publicar o arquivo.', 'danger');
                    },
                    stop: () => FLUIGC.loading(window).hide()
                });
            });

            $('#upbtnVisualizar___' + linha).on('click', (element) => {
                if (element.currentTarget.parentElement.childNodes[5].value) {
                    Archive.open(element.currentTarget.parentElement.childNodes[5].value, 1000)
                } else {
                    TOAST('Nenhum arquivo adicionado!', 'warning');
                }
            });
        }
        this.childEvents(tableName);
    },
    events() {
        $('#ver_arquivo').click((e) => {
            var documentId = $('[name="idAnexo"]').val();
            var versao = 1000
            Archive.open(documentId, versao)
        });

        $('#btnAddtabelaUploadFile').on('click', (element) => {
            this.addChildTable('tabelaUploadFiles');
            $('.areaAnexo:last').find('.addFilePaiFilho').removeClass("anexoInserido");
        })

        this.childEvents();
    },
    childEvents(tableName) {
        $('.delLine').on('click', (element) => {
            if (tableName.includes('UploadFiles')) {
                if (element.currentTarget.parentElement.childNodes[5].value) Archive.delete(element.currentTarget.parentElement.childNodes[5].value);
                fnWdkRemoveChild(element.currentTarget.parentElement.childNodes[3])

            } else {
                fnWdkRemoveChild(element.currentTarget.parentElement.parentElement.childNodes[5].childNodes[3])
            }
        })
    },
    download(codigo, linhaAnexo) {
        $.ajax({
            url: '/api/public/ecm/document/downloadURL/' + codigo,
            method: 'get',
            contentType: 'application/json',
        }).done((result) => {
            let url = result.content;

            $("#upId___" + linhaAnexo).parents(".areaAnexo").find("a.btn-download").attr("href", url)

        }).fail((result) => {
            TOAST('Não foi possivel baixar o arquivo.', 'danger');
        });
    }

}

const Approver = {
    setView() {
        if ($("[name^='aprovOutroGrupo']:checked").val() == 'nao' || $("[name^='aprovOutroGrupo']:checked").val() == '') {
            $(".divGrupo").hide();
        } else {
            $(".divGrupo").show();
        }
    },
    hideDuplicate() {
        if ($('#superiorId').val() === $('#aprovadorId').val()) {
            $('#div_subSuperiorImediato').hide()
        } else {
            $('#div_subSuperiorImediato').show()
        }
    },
    set() {
        let atv = getWKNumState();
        let aprovadores = [];
        aprovadores.push({
            "linha": "superiorImediatoSolicitante-1",
            "centroCusto": $("#centCusSolic").val()[0],
            "idUser": $("#idUsersupSoli").val(),
            "username": $("#supSoli").val(),
            "status": false,
            "observacoes": false
        }, {
            "linha": "alcadaAprovacaoSolicitante-1",
            "centroCusto": $("#centCusSolic").val()[0],
            "idUser": $("#idUserapSoli").val(),
            "username": $("#apSoli").val(),
            "status": false,
            "observacoes": false
        });

        $("#textAprovadores").val(JSON.stringify(aprovadores));
    },
    byGroup() {
        const user = parent.WCMAPI.userCode;
        const state = getWKNumState();
        const valor = Number(parseFloat(Obligacion.getValue()));
        if (user != '' && valor != undefined) {
            //$('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
            $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
            const codCentroCusto = $("#codCentroCusto").val();
            const constraintUserCPF = DatasetFactory.createConstraint("tablename", 'tabelaUserCpf', 'tabelaUserCpf', ConstraintType.MUST)

            let datasetGrupo = DatasetFactory.getDataset("ds_usuario_cpf", null, [constraintUserCPF], null);
            let grupo = "";
            datasetGrupo.values.forEach((e) => {
                if (e.userId == user) {
                    grupo = e.grupo;
                }
            })

            c1 = DatasetFactory.createConstraint('tablename', 'tableCadastroAlcada', 'tableCadastroAlcada', ConstraintType.MUST);
            datasetAprovadores = DatasetFactory.getDataset('ds_alcada_assurant', null, [c1], ['prioridade']);

            let users_processo_obrigacao = []

            datasetAprovadores.values.forEach((e) => {
                let aprovers = e.grupo.split('\u0018').map(s => s.trim())
                if (e.hiddenProcesso.indexOf('inclusao_obrigacao') > -1 && aprovers.includes(grupo.trim())) {
                    users_processo_obrigacao.push(e);
                }
            })

            datasetAprovadores.values = users_processo_obrigacao;
            if (users_processo_obrigacao.length == 0) {
                $("#alertAlcada").show();
            } else {
                $("#alertAlcada").hide();
            }
            let prioridadeUsuario = datasetAprovadores.values.find((element) => {
                return element.idUsuario === user
            })
            prioridadeUsuario = (!prioridadeUsuario) ? {
                prioridade: 0
            } : prioridadeUsuario;
            for (let x = 0; x < datasetAprovadores.values.length; x++) {
                if (!(prioridadeUsuario.prioridade >= datasetAprovadores.values[x].prioridade) || x == datasetAprovadores.values.length - 1) {
                    let valorFinal = Utils.formatFloat(datasetAprovadores.values[x].valorFinal);
                    let idUser = Utils.usernameToId(datasetAprovadores.values[x].usuario);
                    if ((state == '4' || state == '0' || state == '100' || state == '99') && valor <= valorFinal) {
                        $('#superiorImediato').val(datasetAprovadores.values[x].usuario)
                        $('#superiorId').val(idUser)
                        $('#aprovador').val(idUser)
                        $('#proximoAprovador').val(idUser)
                        let subs = datasetAprovadores.values[x].substitutos.split('')
                        $('#subSuperiorImediato').html('');
                        $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
                        subs.forEach(element => {
                            $('#subSuperiorImediato').append(`<option value="${Utils.usernameToId(element)}">${element}</option>`)
                        })
                        $(".alertAlcada").addClass("fs-display-none");
                        break;
                    } else {
                        if (state == 4 || state == 0 || state == 100 || state == 99) {
                            $(".alertAlcada").removeClass("fs-display-none");
                            $('#superiorImediato').val('')
                            $('#superiorId').val('')
                            $('#proximoAprovador').val('')
                        }
                    }
                }
            }
        } else {
            $('#superiorImediato').val("")
            $('#superiorId').val("")
        }
        Approver.hideDuplicate()
        Approver.setSubstitute()
        $('[role="log"]').hide()
    },
    setSubstitute() {
        $('[name="subSuperiorImediato"]').val($('#idSubSuperior').val())
        $('[name="subSuperiorImediato"]').change()
    },
    events() {
        $("[name^='aprovOutroGrupo']").on('change', (e) => {
            if (e.currentTarget.value == 'nao') {
                $(".divGrupo").hide();
            } else {
                $(".divGrupo").show();
            }
        })
        if (getWKNumState() == ABERTURA || getWKNumState() == INICIO  || getWKNumState() == REVISAO_SOLICITANTE || getWKNumState() == REVISAO_ADM) {
            $('#subSuperiorImediato').on('change', (e) => {
                let valor = $('[name="subSuperiorImediato"]>option:selected')
                if (valor.val() == 'manter') {
                    $('#aprovador').val($('#superiorId').val())

                } else {
                    $('#aprovador').val(valor.val())
                }
                $('#idSubSuperior').val(e.currentTarget.selectedOptions[0].value)
                $('#nameSubSuperior').val(e.currentTarget.selectedOptions[0].text)
            })
        }
    }
}

const AccountConcept = {
    set(indexParent, codGrupoConceito = "", element) {
        var tipoAcerto = $('#tipoAcerto').val()
        if (tipoAcerto == 'presConta' && element == "grupoContaContabilPres") {
            $("#idGrupoContPres___" + indexParent).val(codGrupoConceito);
            $("#contaContabilPres___" + indexParent).removeAttr('disabled');

            if ($("#contaContabilPres___" + indexParent).val() != '' && $("#contaContabilPres___" + indexParent).val() != undefined) {
                $("#contaContabilPres___" + indexParent).select2('destroy');
            }

            if (codGrupoConceito == "") {

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_retornaGrupoConceito",
                        "constraints": []
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            codGrupoConceito = data.content.values.find(x => x.dESCGRUPOCONCEITO == $("#grupoContaContabilPres").val()[0])
                            codGrupoConceito = codGrupoConceito.cODGRUPOCONCEITO
                            $("#idGrupoContPres___" + indexParent).val(codGrupoConceito);
                        }
                    }
                });

                // Utils.consultDataset("ds_retornaGrupoConceito", null, [], false).success((data) => {
                //     codGrupoConceito = data.content.values.find(x => x.dESCGRUPOCONCEITO == $("#grupoContaContabilPres").val()[0])
                //     codGrupoConceito = codGrupoConceito.cODGRUPOCONCEITO
                //     $("#idGrupoContPres___" + indexParent).val(codGrupoConceito);
                // })
            }

            Utils.setSelects2('contaContabilPres___' + indexParent, $("#codPoliticaPres___" + indexParent).val(), false, 'ds_retornaConceitoPorGrupo', 'codConceito', 'descConceito', '', [{
                "_field": "grupo_conceito",
                "_initialValue": codGrupoConceito,
                "_type": 1
            }], false,
                (dataselected) => {
                    $('#codPoliticaPres___' + indexParent).val(dataselected.target.value.split(' - ')[0])
                }, () => {
                    $('#codPoliticaPres___' + indexParent).val('')
                }
            )
        } else {
            $("#idGrupoCont").val(codGrupoConceito);
            $(".rowConta").removeClass("col-md-5").addClass("col-md-4")
            $("#theadConta").show();
            $("#contaContabil").removeAttr('disabled');

            if ($("#contaContabil").val() != '' && $("#contaContabil").val() != undefined) {
                $("#contaContabil").select2('destroy');
            }

            if (codGrupoConceito == "") {

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_retornaGrupoConceito",
                        "constraints": []
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            codGrupoConceito = data.content.values.find(x => x.dESCGRUPOCONCEITO == $("#grupoContaContabil").val()[0])
                            codGrupoConceito = codGrupoConceito.cODGRUPOCONCEITO
                            $("#idGrupoCont").val(codGrupoConceito);
                        }
                    }
                });

                // Utils.consultDataset("ds_retornaGrupoConceito", null, [], false).success((data) => {
                //     codGrupoConceito = data.content.values.find(x => x.dESCGRUPOCONCEITO == $("#grupoContaContabil").val()[0])
                //     codGrupoConceito = codGrupoConceito.cODGRUPOCONCEITO
                //     $("#idGrupoCont").val(codGrupoConceito);
                // })
            }

            Utils.setSelects2('contaContabil', $("#codPolitica").val(), false, 'ds_retornaConceitoPorGrupo', 'codConceito', 'descConceito', '', [{
                "_field": "grupo_conceito",
                "_initialValue": codGrupoConceito,
                "_type": 1
            }], false,
                (dataselected) => {
                    $('#codPolitica').val(dataselected.target.value.split(' - ')[0])
                }, () => {
                    $('#codPolitica').val('')
                }
            )
        }
        try {

            $("#idGrupoCont").val(codGrupoConceito);
            $(".rowConta").removeClass("col-md-5").addClass("col-md-4")
            $("#theadConta").show();
            $("#contaContabil").removeAttr('disabled');

            if ($("#contaContabil").val() != '' && $("#contaContabil").val() != undefined) {
                $("#contaContabil").select2('destroy');
            }

            if (codGrupoConceito == "") {

                $.ajax({
                    url: '/api/public/ecm/dataset/datasets',
                    type: 'post',
                    async: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        "name": "ds_retornaGrupoConceito",
                        "constraints": []
                    }),
                    success: function (data) {
                        console.log(data);
                        if (data.content.values) {
                            codGrupoConceito = data.content.values.find(x => x.dESCGRUPOCONCEITO == $("#grupoContaContabil").val()[0])
                            codGrupoConceito = codGrupoConceito.cODGRUPOCONCEITO
                            $("#idGrupoCont").val(codGrupoConceito);
                        }
                    }
                });

                // Utils.consultDataset("ds_retornaGrupoConceito", null, [], false).success((data) => {
                //     codGrupoConceito = data.content.values.find(x => x.dESCGRUPOCONCEITO == $("#grupoContaContabil").val()[0])
                //     codGrupoConceito = codGrupoConceito.cODGRUPOCONCEITO
                //     $("#idGrupoCont").val(codGrupoConceito);
                // })
            }

            Utils.setSelects2('contaContabil', $("#codPolitica").val(), false, 'ds_retornaConceitoPorGrupo', 'codConceito', 'descConceito', '', [{
                "_field": "grupo_conceito",
                "_initialValue": codGrupoConceito,
                "_type": 1
            }], false,
                (dataselected) => {
                    $('#codPolitica').val(dataselected.target.value.split(' - ')[0])
                }, () => {
                    $('#codPolitica').val('')
                }
            )
        } catch (e) {
            console.log("erro ===> " + e.message);
        }
    },
    getDescGroupAccount(idGroup) {
        let description = "";

        $.ajax({
            url: '/api/public/ecm/dataset/datasets',
            type: 'post',
            async: false,
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                "name": "ds_retornaGrupoConceito",
                "constraints": []
            }),
            success: function (data) {
                console.log(data);
                if (data.content.values) {
                    data = data.content.values;
                    description = data.filter(e => e.cODGRUPOCONCEITO == idGroup)
                }
            }
        });

        // Utils.consultDataset("ds_retornaGrupoConceito", "", [], false).success(data => {
        //     data = data.content.values;
        //     description = data.filter(e => e.cODGRUPOCONCEITO == idGroup)
        // })
        return description[0]["dESCGRUPOCONCEITO"];
    },
    init() {
        if (!$("#_contaContabil").prop("disabled")) {
            Utils.setSelects2('contaContabil', $("#codPolitica").val(), false, 'ds_retornaConceitoPorGrupo', 'codConceito', 'descConceito', '', [{
                "_field": "grupo_conceito",
                "_initialValue": $("#idGrupoCont").val(),
                "_type": 1
            }], false,
                (dataselected) => {
                    $('#codPolitica').val(dataselected.target.value.split(' - ')[0])
                }, () => {
                    $('#codPolitica').val('')
                }
            )
        }
    }
}

const Payback = {
    changeAdvancedFields(divCampo) {
        $(".tipoAcerto").hide();
        if (divCampo != "")
            $("." + divCampo).show();
    },
    events() {
        $("#tipoAcerto").on('change', () => {
            Payback.changeAdvancedFields($("#tipoAcerto").val());
            var tipoAcertoFiscal = ["despesaNF", "imposto"]
            if (tipoAcertoFiscal.includes($("#tipoAcerto").val())) {
                $('#passaFiscal').val(true);
            } else {
                $("#passaFiscal").val(false);
            }

        })

        $("#temVincSim").on('change', () => {
            Field.toggle('vincAdiantamento', 'show');
        })

        $("#temVincNao").on('change', () => {
            Field.toggle('vincAdiantamento', 'hide');
        })

    },
    init() {
        Payback.events()

        let contador = 0

        Utils.setSelects2('tipoAcerto', $('#tipoAcertohidden').val(), false, '', '', '', '', [], true, (dataselected) => {
            $(".clsFields").val('');
            if (dataselected.params.data.id == 'adiantamento') {
                $("#divAdiantamento").show()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divPresConta").hide()
                $("#divDevFranquia").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoConta").show()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('adiantamento')
                $("#tipoAcertoHidden_1").val('adiantamento')
                $("#divTabelasPadroes").show()
                $('.escondeAbertura').hide()
                $('#formaPagamento_1').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_1').parent().attr('style','pointer-events: none;')
                $('#DSP').prop('disabled', false);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('.ComLim').show();
                $('.temPO').show();
            } else if (dataselected.params.data.id == 'despesaNF') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").show()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divDevFranquia").hide()
                $("#divPresConta").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoConta").show()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('despesaNF')
                $("#tipoAcertoHidden_2").val('despesaNF')
                $("#divTabelasPadroes").show()
                $('.escondeAbertura').hide()
                $('#formaPagamento_2').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_2').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', false);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('.ComLim').show();
                $('.temPO').show();
            } else if (dataselected.params.data.id == 'RH') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").show()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divPresConta").hide()
                $("#divCenCustoPres").hide()
                $("#divDevFranquia").hide()
                $("#divGrupoConta").show()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('RH')
                $("#tipoAcertoHidden_3").val('RH')
                $("#divTabelasPadroes").show()
                $('.escondeAbertura').hide()
                $('#formaPagamento_3').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_3').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', false);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('.ComLim').show();
                $('.temPO').show();
            } else if (dataselected.params.data.id == 'ovidoria') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").show()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divPresConta").hide()
                $("#divCenCustoPres").hide()
                $("#divDevFranquia").hide()
                $("#divGrupoConta").show()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('ovidoria')
                $("#tipoAcertoHidden_4").val('ovidoria')
                $("#divTabelasPadroes").show()
                $('.escondeAbertura').hide()
                $('#formaPagamento_4').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_4').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', false);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('.ComLim').show();
                $('.temPO').show();
            } else if (dataselected.params.data.id == 'comissao') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").show()
                $("#divdoImposto").hide()
                $("#divPresConta").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoConta").show()
                $("#divGrupoPres").hide()
                $("#divDevFranquia").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('comissao')
                $("#tipoAcertoHidden_5").val('comissao')
                $("#divTabelasPadroes").hide()
                $('.escondeAbertura').hide()
                $('#formaPagamento_5').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_5').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', true);
                $('#COM').prop('disabled', false);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('.ComLim').hide();
                $('.temPO').hide();
            } else if (dataselected.params.data.id == 'imposto') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").show()
                $("#divPresConta").hide()
                $("#divDevFranquia").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoConta").show()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('imposto')
                $("#tipoAcertoHidden_6").val('imposto')
                $("#divTabelasPadroes").hide()
                $('.escondeAbertura').hide()
                $('#formaPagamento_6').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_6').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', true);
                $('#COM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('#LIM').prop('disabled', false);
                $('.ComLim').hide();
                $('.temPO').hide();
            } else if (dataselected.params.data.id == 'presConta') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").show()
                $("#divDevFranquia").hide()
                $("#divCenCustoPres").show()
                $("#divGrupoPres").show()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('presConta')
                $("#tipoAcertoHidden_7").val('presConta')
                $("#divTabelasPadroes").hide()
                $('.escondeAbertura').hide()
                $('#formaPagamento_7').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_7').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', false);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('.temPO').show();
            } else if (dataselected.params.data.id == 'cosseguro') { // chamado 1854726
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").show()
                $("#divPresConta").hide()
                $("#divCosseguro").show()
                $("#rowConta").show()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('cosseguro')
                $("#tipoAcertoHidden_8").val('cosseguro')
                $("#divTabelasPadroes").hide()
                $('.escondeAbertura').hide()
                $('#formaPagamento_8').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_8').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', true);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', false);
                $('.ComLim').hide();
                $('.temPO').hide();
            } else if (dataselected.params.data.id == "devolucao_franquia") { // chamado 1854726
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").show()
                $("#divPresConta").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").show()
                $("#rowConta").show()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('devolucao_franquia')
                $("#tipoAcertoHidden_9").val('devolucao_franquia')
                $("#divTabelasPadroes").hide()
                $('.escondeAbertura').hide()
                $('#formaPagamento_9').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_9').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', true);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', false);
                $('#DSA').prop('disabled', true);
                $('#COA').prop('disabled', true);
                $('.ComLim').hide();
                $('.temPO').hide();
            } else if (dataselected.params.data.id == "despesa_apolice") { // chamado 1854726
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").show()
                $("#divPresConta").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").show()
                $("#rowConta").show()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".divContaAtiva").show()
                $("#tipoAcertohidden").val('despesa_apolice')
                $("#tipoAcertoHidden_10").val('despesa_apolice')
                $("#divTabelasPadroes").hide()
                $('.escondeAbertura').hide()
                $('#formaPagamento_10').val($('#formaPagamento').val() ? $('#formaPagamento').val() : '').change();
                $('#formaPagamento_10').parent().attr('style', 'pointer-events: none;');
                $('#DSP').prop('disabled', true);
                $('#COM').prop('disabled', true);
                $('#LIM').prop('disabled', true);
                $('#DRF').prop('disabled', true);
                $('#DSA').prop('disabled', false);
                $('#COA').prop('disabled', true);
                $('.ComLim').hide();
                $('.temPO').hide();
            }

            Utils.addMaskInputs()
            Utils.addSelect2()
            Provider.events()
            BillOfSale.events()
            Obligacion.events()
            blurValorNF();



        }, (dataUnselected) => {
            if (dataUnselected.params.data.id == 'adiantamento') {

                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoAdiantamento").val('')
                $('#formaPagamento_1').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'despesaNF') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoDespesa").val('')
                $('#formaPagamento_2').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'RH') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoRH").val('')
                $('#formaPagamento_3').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'ovidoria') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoOuvidoria").val('')
                $('#formaPagamento_4').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'comissao') {
                $("#historico, #dataVencimento_5").prop("readonly", false);
                $("#dataVencimento_5").css({"pointer-events":""});
                $("#numObligationComissao").val("");

                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoComissao").val('')
                $('#formaPagamento_5').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'imposto') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoImposto").val('')
                $('#formaPagamento_6').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'presConta') {
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $('.apagarCampoPrestacao').val('')
                $('#formaPagamento_7').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'cosseguro') { // chamado 1854726
                $("#numObligationCosseguro").val(""); // melhoria COA - DSA = adição de limpeza de campo
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoCosseguro").val('')
                $('#formaPagamento_8').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'devolucao_franquia') { // chamado 1854726
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoFranquia").val('')
                $('#formaPagamento_9').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            } else if (dataUnselected.params.data.id == 'despesa_apolice') { // chamado 1854726
                $("#numObligationDesApolice").val(""); // melhoria COA - DSA = adição de limpeza de campo
                $("#divAdiantamento").hide()
                $("#divDespesaNF").hide()
                $("#divRH").hide()
                $("#divOvidoria").hide()
                $("#divComissao").hide()
                $("#divCosseguro").hide()
                $("#divDevFranquia").hide()
                $("#divDespesaApolice").hide()
                $("#divdoImposto").hide()
                $("#divGrupoConta").hide()
                $("#divPresConta").hide()
                $("#divPresContaTable").hide()
                $("#divCenCustoPres").hide()
                $("#divGrupoPres").hide()
                $(".apagarCampoFranquia").val('')
                $('#formaPagamento_9').parent().attr('style', 'pointer-events: block;')
                $("#tipoAcertohidden").val('')
                $('#tipoObrigacao').val(null).trigger('change');
                $('#tipoObrigacaohidden').val('');
                $('#impostohidden').val('');
                $("#imposto").html('');
                $("#lblImposto").text("");
                $("#divImposto").hide();
                $("#divTabelasPadroes").hide()
                $('.temPO').show();
                unselectTypeOblig()
                calculaValorTotal()
            }
            blurValorNF();
        })
    }
}

const View = {
    setInitialUser() {
        let constraintUserCPF = DatasetFactory.createConstraint('tablename', 'tabelaUserCpf', 'tabelaUserCpf', ConstraintType.MUST);

        var datasetGrupo = DatasetFactory.getDataset("ds_usuario_cpf", null, [constraintUserCPF], null);
        let centroCusto = "";
        let idCentroCusto = "";
        let user = parent.WCMAPI.userCode
        datasetGrupo.values.forEach((e) => {
            if (e.userId == user) {
                centroCusto = e.centroCusto;
                idCentroCusto = e.centroCustoId;
            }
        })
        setTimeout(() => {
            if (centroCusto && (centroCusto != '' || centroCusto != undefined || centroCusto != null)) {
                window["centCusSolic"].setValue(centroCusto);
                window["centroCustoSolicPres"].setValue(centroCusto);
                $("#idCenCusSolic").val(idCentroCusto);
                $("#idCenCusSolicBKP").val(idCentroCusto);
                $("#centroCustoPresHidden").val(idCentroCusto);
            }
        }, 800);

    },
    setInit() {
        if (getWKNumState() != ABERTURA) {
            PO.setView()
            Provider.setView();
            Tax.setView();
            Tax.set();
            Approver.byGroup();
            let typeAct = verificaTipoAcerto();
            if ($('#ativboletovalido').val() == "true" && getFormMode() != 'VIEW') {
                console.log("Entrou no valida Boleto Ajuste");
                if ($('#contamsg').val() == 0) {
                    TOAST($('#boletovalido').val(), 'danger');
                    $('#contamsg').val(parseInt($('#contamsg').val()) + 1);
                }
                setTimeout(() => {
                    $('#contamsg').val("0");
                }, 5000);

                if (typeAct.tipoAcerto != 'presConta') {
                    $("#" + typeAct.divObrig).show();
                    $("#divCenCustoPres").hide();
                    $("#divGrupoPres").hide();
                } else {
                    $("#" + typeAct.divObrig).hide();
                    $("#divCenCustoPres").show();
                    $("#divGrupoPres").show();
                }
                $("#dataVencimento_" + typeAct.id).prop('disabled', false);
                $("#codBarras_" + typeAct.id).prop('disabled', false);
                $("#" + typeAct.valorT).prop('disabled', false);
                blurCodbarras();
                Apportionment.childEvents();
                blurValorNF();
                return;
            }
            if ($("[name=botaoAprovacao]:checked").val() == "CONTESTADO") {
                if (typeAct.tipoAcerto == "comissao" || typeAct.tipoAcerto == "imposto") {
                    $("#numeroNF" + typeAct.id).prop('disabled', false);
                    $("#dataVencimento_" + typeAct.id).prop('disabled', false);
                    $("#codBarras_" + typeAct.id).prop('disabled', false);
                }
            }
        } else {
            setTimeout(() => {
                View.setInitialUser()
            }, 1200)
            Field.toggle('creditoConta', 'show');
        }

        Approver.setView()
    }
}

const App = {
    events() {
        Archive.events();
        Approver.events();
        Apportionment.events();
        BillOfSale.events();
        Obligacion.events();
        PO.events();
        Provider.events();
        providerEvents();
    },

    init() {
        updateProgressBar($('#stateAtual').val());
        loadChat();
        definirEstadoAnexos();
        criarCheckbox();
        actionForTask();
        $("#alertAlcada").hide();
        if ($("[name=botaoAprovacao]:checked").val() == "CONTESTADO") {
            $("#divBotoesAprovacao").show();
            if ($("#taxes").val()) {
                $("#div_taxes").show();
            }

            if ($("#financeiro").val()) {
                $("#div_financeiro").show();
            }

            let typeAct = verificaTipoAcerto();
            let id = typeAct.id;

            if ($('#formaPagamentohidden_' + id).val() == "081" || $('#formaPagamentohidden_' + id).val() == "091") {
                blurCodbarras();
                blurValorNF();
                Apportionment.childEvents();
            }

        }
        if (getFormMode() != 'VIEW') {
            this.events();

            if (getWKNumState() == ABERTURA || getWKNumState() == INICIO || getWKNumState() == REVISAO_SOLICITANTE || getWKNumState() == REVISAO_ADM) {
                Provider.init();
                Obligacion.init();
                Payback.init();
                
                if(getWKNumState() == REVISAO_SOLICITANTE || getWKNumState() == REVISAO_ADM){
                    Utils.addMaskInputs();
                    blurValorNF();
                    AccountConcept.init();
                }
            } else {
                AccountConcept.init();
            }
            Utils.addSelect2();
        } else {
            $(".bpm-mobile-trash-column span i").hide();
            $(".addFilePaiFilho, .deleteFile").hide();
            $(".addRateio, .addButton").prop("disabled", true);
            $(".addGCContabil, .addButton").prop("disabled", true);
            View.setInit();
        }
        Approver.setView()
        PO.getConditionalAlert();
        View.setInit();

    }

}

$(window).on("load", () => {
    View.setInit();

})
$(document).ready(() => {
    App.init();
})

function removeElementsTableRateo() {

    $("[tablename=tabelaRateio] tr:not(:first-child").each((index, element) => {
        fnWdkRemoveChild(element);
    });

}

function verificaTipoAcerto() {
    const objAcerto = {
        tipoAcerto: '',
        id: '',
        valorT: '',
        valorL: '',
        numObrig: '',
        divObrig: ''
    }
    let tipoAcerto = $('#tipoAcerto').val();
    if (tipoAcerto == "adiantamento") {
        objAcerto.tipoAcerto = "adiantamento",
            objAcerto.id = "1",
            objAcerto.valorT = "valorAdiantamento",
            objAcerto.valorL = "valorLiqAdiantamento",
            objAcerto.numObrig = "numObligationAdiantamento",
            objAcerto.divObrig = "divAdiantamento"
    }
    if (tipoAcerto == "despesaNF") {
        objAcerto.tipoAcerto = "despesaNF",
            objAcerto.id = "2",
            objAcerto.valorT = "valorDespesa",
            objAcerto.valorL = "valorLiqDespesa",
            objAcerto.numObrig = "numObligationDespesaNF",
            objAcerto.divObrig = "divDespesaNF"
    }
    if (tipoAcerto == "RH") {
        objAcerto.tipoAcerto = "RH",
            objAcerto.id = "3",
            objAcerto.valorT = "valorRH",
            objAcerto.valorL = "valorLiqRH",
            objAcerto.numObrig = "numObligationRH",
            objAcerto.divObrig = "divRH"
    }
    if (tipoAcerto == "ovidoria") {
        objAcerto.tipoAcerto = "ovidoria",
            objAcerto.id = "4",
            objAcerto.valorT = "valorOuvidoria",
            objAcerto.valorL = "valorLiqOuvidoria",
            objAcerto.numObrig = "numObligationOuvidoria",
            objAcerto.divObrig = "divOvidoria"
    }
    if (tipoAcerto == "comissao") {
        objAcerto.tipoAcerto = "comissao",
            objAcerto.id = "5",
            objAcerto.valorT = "valorComissao",
            objAcerto.valorL = "valorLiqComissao",
            objAcerto.numObrig = "numObligationComissao",
            objAcerto.divObrig = "divComissao"
    }
    if (tipoAcerto == "imposto") {
        objAcerto.tipoAcerto = "imposto",
            objAcerto.id = "6",
            objAcerto.valorT = "valorImposto",
            objAcerto.valorL = "valorLiqImposto",
            objAcerto.numObrig = "numObligationImposto",
            objAcerto.divObrig = "divdoImposto"
    }
    if (tipoAcerto == "presConta") {
        objAcerto.tipoAcerto = "presConta",
            objAcerto.id = "7",
            objAcerto.valorT = "valorPresConta",
            objAcerto.valorL = "valorLiqPresConta",
            objAcerto.numObrig = "numObligationPresConta",
            objAcerto.divObrig = "divPresConta"
    }

    if (tipoAcerto == "cosseguro") { 
        objAcerto.tipoAcerto = "cosseguro",
            objAcerto.id = "8",
            objAcerto.valorT = "valorCosseguro",
            objAcerto.valorL = "valorLiqCosseguro",
            objAcerto.numObrig = "numObligationCosseguro",
            objAcerto.divObrig = "divCosseguro"
    }
    if (tipoAcerto == 'despesa_apolice'){ // melhoria COA - DSA
        objAcerto.tipoAcerto = "despesa_apolice",
            objAcerto.id = "10",
            objAcerto.valorT = "valorDespesaApolice",
            objAcerto.valorL = "valorLiqDespesaApolice",
            objAcerto.numObrig = "numObligationDesApolice",
            objAcerto.divObrig = "divDespesaApolice"
    }
    return objAcerto;
}

function removedZoomItem(removedItem) {
    let options = [];
    try {

        options.unshift({
            id: 'NS',
            text: 'Escolha um Substituto'
        })

        switch (removedItem.inputName) {
            case 'cenCustResp':

                $('#idCenCusResp').val('')
                $('[name=supResp]').val('')
                $('[name=idUsersupResp]').val('')
                $('[name="supSubResp"]').empty();

                $('[name="supSubResp"]').select2({
                    data: options,

                    theme: "bootstrap",
                    language: "pt-BR"
                })

                $('[name=apResp]').val('')
                $('[name=idUserapResp]').val('')
                $('[name="apSubResp"]').empty();

                break;
            case 'centCusSolic':

                $('#idCenCusSolic').val('')
                $('#idCenCusSolicBKP').val('')
                $('[name=supSoli]').val('')
                $('[name=idUsersupSoli]').val('')
                $('[name="supSubSoli"]').empty();

                $('[name="supSubSoli"]').select2({
                    data: options,

                    theme: "bootstrap",
                    language: "pt-BR"
                })

                $('[name=apSoli]').val('')
                $('[name=idUserapSoli]').val('')
                $('[name="apSubSoli"]').empty();

                $('[name="apSubSoli"]').select2({
                    data: options,

                    theme: "bootstrap",
                    language: "pt-BR"
                })

                break;
            case 'tabelasPadroes':

                $('#tabelasPadroesHidden').val('')
                $('[name=supSoli]').val('')
                $('[name=idUsersupSoli]').val('')
                $('[name="supSubSoli"]').empty();

                $('[name="supSubSoli"]').select2({
                    data: options,

                    theme: "bootstrap",
                    language: "pt-BR"
                })

                $('[name=apSoli]').val('')
                $('[name=idUserapSoli]').val('')
                $('[name="apSubSoli"]').empty();

                $('[name="apSubSoli"]').select2({
                    data: options,

                    theme: "bootstrap",
                    language: "pt-BR"
                })

                removeElementsTableRateo();
                Apportionment.sum();
                break;
        }
    } catch (e) {
        console.log("erro ===> " + e.message);
    }
}

function setSelectedZoomItem(selectedItem) {
    try {
        var inputName = '';
        if (selectedItem.inputName.indexOf("___") > -1) {
            inputName = selectedItem.inputName.split("___")[0];
            var indexParent = selectedItem.inputName.split("___")[1];
        } else {
            inputName = selectedItem.inputName;
        }

        switch (inputName) {
            case 'cenCustRespRateio':
                Apportionment.setChildCC(indexParent, selectedItem.cODCENTROCUSTO);
                break;
            case 'contaContabil':
                $("#codPolitica").val(selectedItem.codConceito);
                break;
            case 'centCusSolic':
                $('#idCenCusSolic').val(selectedItem.cODCENTROCUSTO);
                $('#idCenCusSolicBKP').val(selectedItem.cODCENTROCUSTO);
                break;
            case 'grupoContaContabil':
                AccountConcept.set("", selectedItem.cODGRUPOCONCEITO, "");
                break;
            case 'selGrupo':
                $("#selGrupoHidden").val("Pool:Group:" + selectedItem.id);
                break
            case 'contaContabilPres':
                $("#codPoliticaPres___" + indexParent).val(selectedItem.codConceito);
                break;
            case 'centroCustoSolicPres':
                $('#centroCustoPresHidden').val(selectedItem.cODCENTROCUSTO);
                break;
            case 'grupoContaContabilPres':
                AccountConcept.set(indexParent, selectedItem.cODGRUPOCONCEITO, inputName);
                break;
            case 'tabelasPadroes':
                $('#tabelasPadroesHidden').val(selectedItem.cODTABRATEO);
                Apportionment.setChildValueTableRateo(selectedItem.cODTABRATEO);
        }
    } catch (e) {
        console.log("erro ===> " + e.message);
    }
}

function calculaValorTotal() {
    var valorTotal = 0
    $('.valor').each((index, element) => {
        let provisorio = Utils.stringToFloat(element.value)
        valorTotal += parseFloat(provisorio)
        $("#valorTotal").val(valorTotal)
    })
}

function unselectTypeOblig() {
    $('#tipoObrigacao option:selected').each(function () {
        $(this).removeAttr('selected');
        $(this).prop('disabled', true);
    })
}

function displayFields() {
    let atv = getWKNumState();
    $(".escondeAbertura").hide();
    Obligacion.events()
    if (ABERTURA == atv) {
        Provider.select()
        $('#div_financeiro').hide()
        $("#div_parecerSuperior").hide();
        $('#divCenCustoPres').hide()
        $('#divGrupoConta').hide()
        $('#divGrupoPres').hide()
        $('#divPresContaTable').hide()
        $("#numObligation").parent().hide();
        $("#divBotoesAprovacao").hide();
        let imposto = 0;
        imposto = imposto.toFixed(2);
        imposto = imposto.toLocaleString("pt-BR", {
            useGrouping: true
        })
        $("#imposto_valor").val(imposto);

        $.ajax({
            url: '/api/public/ecm/dataset/datasets',
            type: 'post',
            async: false,
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                "name": "dsConsultaComLim",
                "constraints": []
            }),
            success: function (data) {

                if (data.content.values) {
                    data = data.content.values;
                    data = data.map((e, i) => {
                        if (e.TIPOOBLIG == "COM") {
                            Tax.allCOM.push({
                                option: e.NUM_OBLIG + " - " + Number(e.VALOR).toLocaleString("pt-br"),
                                cnpj: e.CNPJ,
                                contaAtiva: e.AGENCIA + " " + e.CONTA + "-" + e.DIGITO,
                                dataCriacao: "",
                                dataVencimento: "",
                                historico: ""
                            })
                        }

                        if (e.TIPOOBLIG == "LIM") {
                            Tax.allLIM.push({
                                option: e.NUM_OBLIG + " - " + Number(e.VALOR).toLocaleString("pt-br"),
                                cnpj: e.CNPJ,
                                contaAtiva: e.AGENCIA + " " + e.CONTA + "-" + e.DIGITO,

                            })
                        }
                    })
                }
            }
        })


        // Utils.consultDataset('dsConsultaComLim', null, [], false).then((data) => {
        //     data = data.content.values;
        //     data = data.map((e, i) => {
        //         if (e.TIPOOBLIG == "COM") {
        //             Tax.allCOM.push({
        //                 option: e.NUM_OBLIG + " - " + Number(e.VALOR).toLocaleString("pt-br"),
        //                 cnpj: e.CNPJ,
        //                 contaAtiva: e.AGENCIA + " " + e.CONTA + "-" + e.DIGITO,
        //                 dataCriacao: "",
        //                 dataVencimento: "",
        //                 historico: ""
        //             })
        //         }

        //         if (e.TIPOOBLIG == "LIM") {
        //             Tax.allLIM.push({
        //                 option: e.NUM_OBLIG + " - " + Number(e.VALOR).toLocaleString("pt-br"),
        //                 cnpj: e.CNPJ,
        //                 contaAtiva: e.AGENCIA + " " + e.CONTA + "-" + e.DIGITO,

        //             })
        //         }
        //     })

        // })
        $("#botaoAdicionarAnexo").fileupload({
            dataType: 'json',
            start: () => FLUIGC.loading(window).show,
            done: (e, data) => {
                var file = data.result.files[0];

                Archive.save(file);
            },
            fail: (e, data) => {
                console.log("Falha no fileupload", data);
                TOAST('Não foi possivel publicar o arquivo.', 'danger');
            },
            stop: () => FLUIGC.loading(window).hide()
        });
        $('#dataAbertura').val(new Date().toLocaleDateString('pt-BR'));
    }
    if (APROVACAO == atv) {
        Provider.select()
        $('#div_financeiro').hide()
        let typeAct = verificaTipoAcerto();
        let id = typeAct.id;
        if ($('#formaPagamentohidden_' + id).val() == "071" || $('#formaPagamentohidden_' + id).val() == "073") {
            Tax.get();
            Tax.set();
        }
        $(".rowConta").removeClass("col-md-6").addClass("col-md-4");

    }
    else {
        Provider.select();
        // Tax.get();
        // Tax.set();
        $(".rowConta").removeClass("col-md-6").addClass("col-md-4");
    }
    if (atv != INICIO && atv != ABERTURA) {
        Provider.reload();
        Payback.changeAdvancedFields();
        $(".bpm-mobile-trash-column span i").hide();
        $(".addFilePaiFilho, .deleteFile").hide();
        $(".addRateio, .addButton").prop("disabled", true);
        $(".addGCContabil").prop("disabled", true);
        $("#fornecedor").select2({
            disabled: 'readonly'
        });



        let textImposto = $("#impostohidden").val();

        $("#imposto option:selected").text(textImposto);
        $("#_imposto option:selected").text(textImposto);

        var tipoAcerto = $('#tipoAcerto').val()
        if (tipoAcerto != 'presConta') {
            $('#divPresConta').hide();
            $('#divCenCustoPres').hide();
            $('#divGrupoPres').hide();
        } else {
            $('.filhoDivCampos').hide();
            $('#divPresConta').show();
            $('#divCenCustoPres').show();
            $('#divGrupoPres').show();
        }
    } else {
    }
    if (atv != INICIO && atv != ABERTURA && atv != GRAVA_OBRIGACAO_NO_ACSEL && atv != VERIFICA_PAGAMENTO_NO_ACSEL) {
        $("#divBotoesAprovacao").show();
    }
    if (AVALIACAO_DO_FINANCEIRO != atv) {
        //$(".aprovGrupo").hide();
    } else {
        $(".parecerGrupo").hide();
        if ($("#selGrupoHidden").val()) {
            //$("#divBotoesAprovacao, .aprovGrupo").css("pointer-events", "none");
            $(".parecerGrupo").show();
        }
    }
    if (AVALIACAO_DO_FINANCEIRO == atv) {
        let obrigImposto = $("#listarobrigacoes").val();
        if (obrigImposto == 'false') {
            $("#botaoReprocessar").removeClass("fs-display-none");
        }
    }
    if (atv != AVALIACAO_DO_FINANCEIRO && atv != AVALIACAO_GRUPO_RESPONSAVEL) {
        $("#div_taxes").hide();
    }
    if (atv == INICIO || atv == REVISAO_SOLICITANTE || atv == REVISAO_ADM) {
        Provider.select()
        $("#divBotoesAprovacao").css("pointer-events", 'none');
        let tipoAcerto = $('#tipoAcerto').val()
        if (tipoAcerto == "presConta") {
            $("#divPresConta").show()
            $("#divGrupoConta").hide();
            $("#divPresConta").show();
        } else {
            if (tipoAcerto == "adiantamento") {
                $("#divAdiantamento").show();
            }
            if (tipoAcerto == "despesaNF") {
                $("#divDespesaNF").show();
            }
            if (tipoAcerto == "RH") {
                $("#divRH").show();
            }
            if (tipoAcerto == "ovidoria") {
                $("#divOvidoria").show();
            }
            if (tipoAcerto == "comissao") {
                $("#divComissao").show();
            }
            if (tipoAcerto == "imposto") {
                $("#divdoImposto").show();
            }
            if (tipoAcerto == "cosseguro") {
                $("#divCosseguro").show();
            }
            if (tipoAcerto == "despesa_apolice") {
                $("#divDespesaApolice").show();
            }
            $("#divCenCustoPres").hide();
            $("#divGrupoPres").hide();
        }
    }

    if (atv == AVALIACAO_GRUPO_RESPONSAVEL) {
        $(".aprovGrupo").show()
        $(".aprovGrupo ").css("pointer-events", "none");
        $("#div_financeiro").show();
        //$("#aprovacaoContestado").parent().hide();
    }
    let aprovadores = $("#textAprovadores").val() ? JSON.parse($("#textAprovadores").val()) : [];

}



var beforeSendValidate = function (numState, nextState) {
    let msg = "";

    $('#divBotoesAprovacao:visible:not([readonly])').each((index, element) => {
        if ($('[name="aprovacao"]').val() == '') {
            msg += 'Aprovação não definida, por favor, selecionar uma opção. </br>'
        }
    })

    $(".obrigatorio:visible:not([readonly])").each((index, element) => {
        if (element.tagName != 'SPAN') {
            msg += validateEmptyFields(element);
        }
    })

    if (numState == INICIO || numState == ABERTURA || numState == REVISAO_SOLICITANTE || numState == REVISAO_ADM) {

        const valuesObr = {
            totalRateio: $("#totalRateio").val(),
            totalNF: $("#valorDespesa").val()
        }

        const floatObr = {
            valorNF: parseFloat(valuesObr.totalNF.replace('.', '').replace(',', '.')),
            valorRateio: parseFloat(valuesObr.totalRateio.replace('.', '').replace(',', '.'))
        }

        const validaValores = floatObr.valorNF - floatObr.valorRateio

        if (validaValores > 0 || validaValores < 0) {
            throw "O valor do rateio está abaixo do valor total da NF. Por favor, ajuste para prosseguir com o fluxo"
        }

        if ($("#tabelaUploadFiles tr:not(:first-child)").length == 0 || $("#upId___1").val() == "") {
            msg += "É necessário anexar ao menos um Documento <br>";
        }
        if ($("#tipoAcerto").val() == "presConta") {
            if ($("#tabelaGrupoContaContabil tr:not(:first-child)").length == 0 || $("[name^=centroCustoSolicPres___]").val() == "") {

                msg += "É necessário inserir um Centro de Custo Solicitante <br>";
            }

            $("#tabelaGrupoContaContabil tr:not(:first-child)").find("input[name^=valorGCContabil___]").each((index, valor) => {

                let negative = valor.value;
                if (negative < "0") {
                    if ($("#valorTotal").val() != "0,01") {
                        if ($("#totalRateio").val() != $("#valorTotal").val()) {
                            msg += "Se houver desconto, o Valor Total deve ser R$ 0,01. Reveja o valor do desconto. <br>";
                        }
                    }
                }
            })
        }
        if ($('#listarobrigacoes').val() != 'true') {
            if ($("#tabelaRateio tr:not(:first-child)").length == 0 || $("[name^=cenCustRespRateio___]").val() == "") {
                msg += "É necessário inserir ao menos um Centro de Custo Responsável <br>";
            }
        }

        if ($("#tipoAcerto").val() == "presConta") {
            if ($("#totalRateio").val() != $("#valorTotal").val() && $("#valorTotal").val() != "0,01") {
                msg += "Valor Total Do Rateio não corresponde ao Valor Total da Obrigação, insira um desconto no Grupo Contabil. <br>";
            }
        }

        if ($("#tipoAcerto").val() != "presConta" && $('#listarobrigacoes').val() != 'true') {
            if (!$("#idGrupoCont").val() || !$("#codPolitica").val()) {
                msg += "Preenchimento dos conceitos contábeis é obrigatório <br>";
            }
            if ($("#totalRateio").val().replaceAll('.', '') != $("#valorTotal").val().replaceAll('.', '')) {
                msg += "Valor Total Do Rateio não corresponde ao Valor Total da Obrigação <br>";
            }
        }


        let tipoAcerto = verificaTipoAcerto();
        console.log(tipoAcerto);
        let id = tipoAcerto.id;

        console.log("if do pagamento 71");
        if ($("#formaPagamento_" + id).val() == "071" && $("#contAtivForn" + id).val() == '') {
            console.log("if dentro do pagamento 71");
            msg += "Campo Conta Ativa vazio, escolha uma forma de pagamento. <br>";
        }
        console.log("if do pagamento 81");

        if ($("#formaPagamento_" + id).val() == "081" && $("#codBarras_" + id).val().length < "54") {
            console.log("if dentro do pagamento 81");
            msg += "Código de barras é invalido, insira um código válido para continuar. <br>";
        }
        if ($("#historico").val().length > 60) {
            msg += "Campo hitórico é muito grande, ajustar até 60 caracteres . <br>";
        }

        /*if($("#hd_cod_grupoAdm").val() == ""){
            msg += "Nenhum fornecedor com grupo de ADM parametrizado foi selecionado <br>";
        }*/
    }

    if (AVALIACAO_GRUPO_RESPONSAVEL == numState) {
        if ($("[name^='botaoAprovacao']:checked").val() == "APROVADO") {
            $("#selGrupoHidden").val("aprovado");
        } else {
            $("#selGrupoHidden").val("reprovado");
        }
    }
    if (msg != "") {
        console.log("throw msg: " + msg)
        throw msg;
    }
    if (numState == AVALIACAO_DO_FINANCEIRO || numState == APROVACAO || numState == VALIDACAO_ADM) {
        if ($("[name=botaoAprovacao]:checked").val() == "CONTESTADO" && ($("#tipoObrigacaohidden").val() != 'COM' && $("#tipoObrigacaohidden").val() != 'DSA' && $("#tipoObrigacaohidden").val() != 'COA') ||
            $("[name=botaoAprovacao]:checked").val() == "REPROVAR" && $("#tipoObrigacaohidden").val() != 'COM') {

            console.log('if $("[name=botaoAprovacao]:checked").val() == "CONTESTADO" && $("#tipoObrigacaohidden").val() != "COM" || $("[name=botaoAprovacao]:checked").val() == "REPROVAR" && $("#tipoObrigacaohidden").val() != "COM"')
            Obligacion.cancel();
            PO.sum();
        }
    }
    if ((numState == INICIO || numState == ABERTURA || numState == REVISAO_SOLICITANTE || numState == REVISAO_ADM) && !msg) {
        PO.discount();
    }
}

function validateEmptyFields(campo) {
    var msg = "";
    if (campo.name.split('___')[1]) {
        if ($(campo).val() == "" || $(campo).val() == undefined || $(campo).val() == null || $(campo).val() == "R$ 0,00" || $(campo).val() == "0,00" || $(campo).val() == "R$ NaN") {
            fnWdkRemoveChild(campo.parentElement)
        }

        $('#validacao').val('true')
        return msg;
    } else {

        var lineBreaker = "<br>";

        if ($(campo).val() == "" || $(campo).val() == undefined || $(campo).val() == null || $(campo).val() == "R$ 0,00" || $(campo).val() == "0,00" || $(campo).val() == "R$ NaN") {

            msg += "Campo '" + $(campo).siblings("label").text() + "' é obrigatório!" + lineBreaker;

        } else if ($(campo).siblings("label").text() == 'Telefone') {

            if ($(campo).val().length < 14) {
                msg += "Numero de telefone não esta completo !" + lineBreaker;
            }

        } else if ($(campo).siblings("label").text() == 'CEP') {

            let validacep = /^[0-9]{8}$/

            if (validacep.test($(campo).val())) {
                msg += "CEP invalido na linha " + campo.split('___')[1] + " !" + lineBreaker;
            }
        }
        return msg;
    }
}

function returnData(data) {
    let newData;
    let newString;
    if (data.indexOf('/') > -1) {
        newData = data.split('/');
        newString = "" + newData[2] + newData[1] + newData[0] + "";
    } else {
        newData = data.split('-');
        newString = "" + newData[0] + newData[1] + newData[2] + "";
    }
    return newString;
}

function deletaValor(element) {
    if ($("[tablename=tabelaRateio] tr:not(:first-child").length == 1) {
        $(".addRateio").prop("disabled", false);
    }
    fnWdkRemoveChild(element)
    Apportionment.sum()
}

function deletaValorContabil(element) {
    fnWdkRemoveChild(element);
    Apportionment.sumContabil();
}

function clearformImposto() {
    let tipoAcerto = $('#tipoAcerto').val();
    let tipoAcertoId;
    let numobligField;
    let valorboletoField;
    let divnumoblig;
    let dataVenc;

    if (tipoAcerto == "comissao") {
        tipoAcertoId = "5";
        numobligField = "numObligationComissao";
        valorboletoField = "valorComissao";
        divnumoblig = "divNumObligComissao";
        dataVenc = "dataVencimento_5";
    }
    if (tipoAcerto == "imposto") {
        tipoAcertoId = "6";
        numobligField = "numObligationImposto";
        valorboletoField = "valorImposto";
        divnumoblig = "divNumObligImposto";
        dataVenc = "dataVencimento_6";
    }

    if (tipoAcerto == "cosseguro") { // melhoria COA - DSA
        tipoAcertoId = "8";
        numobligField = "numObligationCosseguro";
        valorboletoField = "valorCosseguro";
        divnumoblig = "divNumObligCosseguro";
        dataVenc = "dataVencimento_8";
    }

    let csCentCus = [{
        _field: "nNumOblig",
        _initialValue: $("#idCenCusSolicBKP").val(),
        _finalValue: $("#idCenCusSolicBKP").val(),
        _type: 1
    }]

    let centCusDesc = '';
    let centCusCod = '';

    $.ajax({
        url: '/api/public/ecm/dataset/datasets',
        type: 'post',
        async: false,
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({
            "name": "ds_retornaCentroCusto",
            "constraints": csCentCus
        }),
        success: function (res) {
            console.log(res);
            if (res) {
                res = res.content.values[0];
                centCusDesc = res.dESCCENTROCUSTO;
                centCusCod = res.cODCENTROCUSTO;
            }
        }
    });

    // Utils.consultDataset("ds_retornaCentroCusto", null, csCentCus, false).success((res) => {
    //     res = res.content.values[0];
    //     centCusDesc = res.dESCCENTROCUSTO;
    //     centCusCod = res.cODCENTROCUSTO;
    // });

    if (centCusDesc) {
        Utils.setZoomData("centCusSolic", centCusDesc);
    }

    $('#idCenCusSolic').val(centCusCod);
    $('#' + dataVenc).val('');
    $('#' + valorboletoField).prop('disabled', false);
    $('#' + valorboletoField).attr('readonly', false);
    $('#' + valorboletoField).val("0,00");

    if (valorboletoField == "valorComissao") {
        $("#valorLiqComissao").val("0,00");
    } else if (valorboletoField == "valorImposto") {
        $("#valorLiqImposto").val("0,00");
    }

    $('#historico').val('');
    $('#' + divnumoblig).hide();
    $('#' + numobligField).val('');
    $('#num_obrigacao').val('');

    Approver.byGroup();
}

function nameValorBoleto(codTipoPago, id) {
    let idValorBoleto;
    if (codTipoPago == "081" || codTipoPago == "091") {

        let valorBoleto;
        if (id == "1") {
            idValorBoleto = "valorLiqAdiantamento";
        }
        if (id == "2") {
            idValorBoleto = "valorLiqDespesa";
        }
        if (id == "3") {
            idValorBoleto = "valorLiqRH";
        }
        if (id == "4") {
            idValorBoleto = "valorLiqOuvidoria";
        }
        if (id == "5") {
            idValorBoleto = "valorLiqComissao";
        }
        if (id == "6") {
            idValorBoleto = "valorLiqImposto";
        }
        if (id == "7") {
            idValorBoleto = "valorLiqPresConta";
        }
        return valorBoleto = $('#' + idValorBoleto).val();
    }
}

function returnData(data) {
    if (data.indexOf('/') > -1) {
        var newData = data.split('/')
        var newString = "" + newData[2] + newData[1] + newData[0] + ""
    } else {
        var newData = data.split('-')
        var newString = "" + newData[0] + newData[1] + newData[2] + ""
    }
    return newString
}

function loadChat() {
    let campos = '';
    let atividadeArea = ''
    if($.inArray(getWKNumState(), [APROVACAO, AVALIACAO_DO_FINANCEIRO, VALIDACAO_ADM, REVISAO_SOLICITANTE, REVISAO_ADM]) > -1){
        if(getWKNumState() == REVISAO_SOLICITANTE) {
            campos = '#parecerSuperior';
            atividadeArea = '99';
        }
        if(getWKNumState() == VALIDACAO_ADM || getWKNumState() == REVISAO_ADM) {
            campos = '#parecerSuperior';
            atividadeArea = '92';
        }
        if(getWKNumState() == APROVACAO){
            campos = '#parecerSuperior';
            atividadeArea = '21';
        }
        if(getWKNumState() == AVALIACAO_DO_FINANCEIRO){
            campos = '#parecerFinanceiro';
            atividadeArea = '49';
        }

        $(campos).on("change",function () {
            let ultimoItemResp = '';
            $("#tblChat input[id^=hd_chat_tarefa___]").each(function () {
                if($(this).val() == atividadeArea){
                    ultimoItemResp = $(this).parents("tr").find('textarea').val();
                }
            });

            if ($(this).val().trim() == "" || $(this).val().trim() == ultimoItemResp) {
                if ($("#tblChat input[id^=hd_chat_status___]:last").val() == "EDIT") {
                    $("#tblChat tbody tr:last").remove();
                }
            }
            else {
                if ($("#tblChat input[id^=hd_chat_status___]:last").val() != "EDIT") {
                    wdkAddChild("tblChat");
                    $("#tblChat tbody tr:last").hide();
                }
    
                let data = new Date();
                let dia = data.getDate().toString().padStart(2, '0');
                let mes = (data.getMonth() + 1).toString().padStart(2, '0');
                let ano = data.getFullYear();
                let horas = data.getHours().toString().padStart(2, '0');
                let minutos = data.getMinutes().toString().padStart(2, '0');
    
                let c1 = DatasetFactory.createConstraint("colleaguePK.colleagueId", getWKUser(), getWKUser(), ConstraintType.MUST);
                let ds_usuario = DatasetFactory.getDataset("colleague", null, [c1], null).values;
    
                $("#tblChat input[id^=hd_chat_usuario___]:last").val(ds_usuario[0]["colleagueName"]);
                $("#tblChat input[id^=hd_chat_idUsuario___]:last").val(getWKUser())
                $("#tblChat input[id^=hd_chat_horario___]:last").val(`${dia}/${mes}/${ano} - ${horas}:${minutos} `);
                $("#tblChat input[id^=hd_chat_imagem___]:last").val("/social/api/rest/social/image/profile/" + ds_usuario[0]["login"] + "/SMALL_PICTURE");
                $("#tblChat input[id^=hd_chat_tarefa___]:last").val(getWKNumState());
                $("#tblChat input[id^=hd_chat_status___]:last").val("EDIT");
    
                $("#tblChat tbody textarea:last").val($(this).val().trim());
            }
        });
    }

    $("#tblChat tbody tr").not(':first').each(function () {

        let tarefaMsg = $(this).find("input[id^=hd_chat_tarefa]").val();
        tarefasSolicitantes = ["0", "4", "18", "69", '99'];
        tarefasAprovSup = ['21'];
        tarefasAprovFinan = ['49'];
        tarefasAprovOutroGrp = ['46'];
        tarefasAdmArea = ['92', '100']
        if ($.inArray(tarefaMsg, tarefasSolicitantes) > -1) {
            $(this).find(".dados-chat-esq .lbl_nomeMensagem").text($(this).find("input[id^=hd_chat_usuario]").val());
            $(this).find(".dados-chat-esq .img_mensagem img").prop("src", $(this).find("input[id^=hd_chat_imagem]").val());
            $(this).find(".dados-chat-esq .lbl_papel").text("Solicitante");
            $(this).find(".dados-chat-dir .img_mensagem").addClass("hide");
        }
        else {
            if ($.inArray(tarefaMsg, tarefasAprovSup) > -1) {
                $(this).find(".dados-chat-dir .lbl_papel").text("Superior imediato");
            }
            if ($.inArray(tarefaMsg, tarefasAprovFinan) > -1) {
                $(this).find(".dados-chat-dir .lbl_papel").text("Financeiro");
            }
            if ($.inArray(tarefaMsg, tarefasAprovOutroGrp) > -1) {
                $(this).find(".dados-chat-dir .lbl_papel").text("Aprovador outro grupo");
            }
            if ($.inArray(tarefaMsg, tarefasAdmArea) > -1) {
                $(this).find(".dados-chat-dir .lbl_papel").text("ADM da área");
            }
            $(this).find(".dados-chat-dir .lbl_nomeMensagem").text($(this).find("input[id^=hd_chat_usuario]").val());
            $(this).find(".dados-chat-dir .img_mensagem img").prop("src", $(this).find("input[id^=hd_chat_imagem]").val());
            $(this).find(".dados-chat-esq .img_mensagem").addClass("hide");
        }

        $(this).find(".lbl-horario").text($(this).find("input[id^=hd_chat_horario]").val());
    });

    if ($("#tblChat input[id^=hd_chat_status___]:last").val() == "EDIT") {
        $("#tblChat tbody tr:last").hide();
        //$("#").val($("#tblChat tbody textarea:last").val());
    }
    else {
        $("#parecerSuperior, #parecerFinanceiro").val("");
    }
}

function criarPainelObrigacoes() {
    $("#div-dados-obrigacoes").html(""); let total = 0;
    $("#tblDadosObrigacoes tbody tr").not(":first").each(function () {
        let item = `
    < div class="item-obrigacao" >
                <div>
                    <p>Número de Obriação</p>
                    <h4>${$(this).find("input[id*=txt_obrigacao_numero___]").val()}</h4>
                </div>
                <div>
                    <p>Valor</p>
                    <h4>R$${$(this).find("input[id*=txt_obrigacao_valor___]").val()}</h4>
                </div>
            </ >
    `;
        $("#div-dados-obrigacoes").append(item);

        let valorItem = parseFloat($(this).find("input[id*=txt_obrigacao_valor___]").val().split(".").join("").replace(",", "."));
        total += valorItem;
    });
    //let totalFormatado = total.toFixed(2).replace(".",",");

    $(".obrigacao-total h4").text(`R$${total.toLocaleString('pt-br', { minimumFractionDigits: 2 })} `);

    $("#painelObrigacoes").removeClass("hide");
}

function criarCheckbox() {
    FLUIGC.switcher.init("#chk_solicitacao_substituicao");
    FLUIGC.switcher.onChange("#chk_solicitacao_substituicao", function (event, state) {
        if (state) {
            $(".menuSubstituto").show();
            // $("#subSuperiorImediato").removeAttr("disabled");
        }
        else {
            $(".menuSubstituto").hide();
            //$("#subSuperiorImediato").attr("disabled" ,true);
        }
    });

    FLUIGC.switcher.setFalse("#chk_solicitacao_substituicao");

    FLUIGC.switcher.init("#chk_solicitacao_padroes");
    FLUIGC.switcher.onChange("#chk_solicitacao_padroes", function (event, state) {
        if (state) {
            tabelasPadroes.disable(true);
            $("#tabelaRateio tbody tr:visible .fluigicon-trash").click();
            addItemRateio();
            $("#tabelaRateio tbody tr:visible .fluigicon-trash").hide();
        }
        else {
            tabelasPadroes.disable(false);
            $("#tabelaRateio tbody tr:visible .fluigicon-trash").show();
            $("#tabelaRateio tbody tr:visible .fluigicon-trash").click();
        }

        tabelasPadroes.clear();
    });

    if ($.inArray(getWKNumState(), [ABERTURA, INICIO]) == -1) {
        //FLUIGC.switcher.disable("#chk_solicitacao_substituicao");
    }
    else {
        if ($("#subSuperiorImediato").val() != 'manter') {
            FLUIGC.switcher.setTrue("#chk_solicitacao_substituicao");
        }
    }

    if ($.inArray(getWKNumState(), [ABERTURA, INICIO, AVALIACAO_DO_FINANCEIRO, VALIDACAO_ADM, REVISAO_ADM]) == -1) {
        FLUIGC.switcher.disable("#chk_solicitacao_padroes");
    }
    else if ($("#tabelasPadroes").val() == '' && $.inArray(getWKNumState(), [INICIO, AVALIACAO_DO_FINANCEIRO, VALIDACAO_ADM, REVISAO_ADM]) > -1) {
        //FLUIGC.switcher.setTrue("#chk_solicitacao_padroes");
    }
}

function actionForTask() {
    /*if ($.inArray(getWKNumState(), [VALIDACAO_ADM, APROVACAO]) > -1) {
        $("#aprovacaoContestado").parent().hide();
    }*/
    if(getWKNumState() == ABERTURA){
        if($("#tipo_abertura").val() == ""){
            $("#tipo_abertura").val("M");

            $(".valor").on("blur", e => {
                FLUIGC.switcher.setTrue("#chk_solicitacao_padroes");
            });
        }
    }
    if ($.inArray(getWKNumState(), [APROVACAO, AVALIACAO_GRUPO_RESPONSAVEL]) > -1) {
        //$("#contaContabil").attr("disabled", true);
        $("#contaContabil").parents("#divConta").css({ "pointer-events": "none" });
    }
    if ($.inArray(getWKNumState(), [ABERTURA, INICIO, REVISAO_SOLICITANTE, AVALIACAO_DO_FINANCEIRO]) == -1) {
        $("#tabelaRateio i.fluigicon-trash").hide();
    }
    if ($.inArray(getWKNumState(), [AVALIACAO_DO_FINANCEIRO]) > -1) {
        $("#tabelaRateio .addRateio").removeAttr("disabled");
        $("#outro-aprovador .col-md-4:first").append(`<input id="chk_outro_aprovador" type="checkbox" data-on-color="success" data-on-text="Sim" data-off-text="Não"> `);
        $("#outro-aprovador").show();
        $(".aprovGrupoButtons").hide();

        FLUIGC.switcher.init("#chk_outro_aprovador");
        FLUIGC.switcher.onChange("#chk_outro_aprovador", function (event, state) {
            if (state) {
                $("#outroGrupoSim").click();
            }
            else {
                $("#outroGrupoNao").click();
            }
        });

        if ($("input[name='aprovOutroGrupo']:checked").val() == "sim") { // || $("input[name='aprovOutroGrupo']").val() == 'sim'
            FLUIGC.switcher.setTrue("#chk_outro_aprovador");
        }
        else{
            FLUIGC.switcher.setFalse("#chk_outro_aprovador");
        }
    }

    if ($.inArray(getWKNumState(), [VALIDACAO_ADM, APROVACAO, AVALIACAO_DO_FINANCEIRO]) > -1) {
        $("input[name='botaoAprovacao'], input[name='aprovOutroGrupo']").on("click", function () {
            if ($("input[name='botaoAprovacao']:checked").val() == 'CONTESTADO' && ((getWKNumState() == AVALIACAO_DO_FINANCEIRO && $("input[name='aprovOutroGrupo']:checked").val() == 'nao') || getWKNumState() != AVALIACAO_DO_FINANCEIRO)) {
                $("#divOpcoesRevisao").show();
                $("#divBotoesAprovacao").removeClass("col-md-offset-2").removeClass("col-md-8").addClass("col-md-6");
            }
            else {
                $("#divOpcoesRevisao").hide();
                $("#divBotoesAprovacao").addClass("col-md-offset-2").addClass("col-md-8").removeClass("col-md-6");
            }

            $("#parecerFinanceiro, #parecerSuperior").removeClass("obrigatorio");
            if($("input[name='botaoAprovacao']:checked").val() == 'CONTESTADO'){
                if (getWKNumState() == AVALIACAO_DO_FINANCEIRO) {
                    $("#parecerFinanceiro").addClass("obrigatorio");
                }
            
                if(getWKNumState() == APROVACAO){
                    $("#parecerSuperior").addClass("obrigatorio");
                }
            }
        });

        if(getWKNumState() == VALIDACAO_ADM){
            $("#slc_revisao_opcao").html(`
                <option value="solicitante">Solicitante</option>
            `);
            // <option value="adm_area">Administração da área</option>
            //<option value="fornecedor">Fornecedor</option>
        }

        if(getWKNumState() == APROVACAO){
            $("#slc_revisao_opcao").html(`
                <option value="solicitante">Solicitante</option>
            `);

            if($("#hd_cod_grupoAdm").val() != ''){
                $("#slc_revisao_opcao").append(`
                    <option value="adm_area">Administração da área</option>
                `);
            }
            // <option value="adm_area">Administração da área</option>
            //<option value="fornecedor">Fornecedor</option>
        }

        if(getWKNumState() == AVALIACAO_DO_FINANCEIRO){
            $("#slc_revisao_opcao").html(`
                <option value="solicitante">Solicitante</option>
            `);

            if($("#hd_cod_grupoAdm").val() != ''){
                $("#slc_revisao_opcao").append(`
                    <option value="fornecedor">Fornecedor</option>
                    <option value="adm_area">Administração da área</option>
                `);
            }
            // <option value="adm_area">Administração da área</option>
            //<option value="fornecedor">Fornecedor</option>
        }
    }

    if ($.inArray(getWKNumState(), [REVISAO_SOLICITANTE, REVISAO_ADM, AVALIACAO_GRUPO_RESPONSAVEL]) > -1) {

        let aprovacaoTimer = setInterval(function () {
            $("#divBotoesAprovacao").hide();
            clearInterval(aprovacaoTimer);
        }, 2000);
    }

    if ($.inArray(getWKNumState(), [REVISAO_SOLICITANTE, REVISAO_ADM]) > -1) {

        if($('#tipoObrigacaohidden').val() == "COM" && $("#impostohidden").val() != ""){
            $("#historico, #dataVencimento_5").prop("readonly", true);
            $("#dataVencimento_5").css({"pointer-events":"none"}); 

            if($("#imposto_net").val() != "SIM"){
                $("#dataVencimento_5").prop("readonly", false);
            }
        }
        else if(($('#tipoObrigacaohidden').val() == "COA" || $('#tipoObrigacaohidden').val() == "DSA") && $("#impostohidden").val() != ""){
            $("#historico").prop("readonly", true);
        }
    }

    if($.inArray(getWKNumState(), [ABERTURA, INICIO, VERIF_ERRO_GRAVA_OBRIGACAO, REVISAO_SOLICITANTE, REVISAO_ADM]) <= -1){
        $("#historico").removeClass("obrigatorio");
        $("#historico").prop("readonly", true);
    }
    
    /*if($.inArray(getWKNumState(), [INICIO, REVISAO_SOLICITANTE, REVISAO_ADM]) > -1){
        $("#historico").val($("#tblChat tbody tr:nth-child(2) textarea").val());
    }*/

    $('#divBotoesAprovacao label').on('click', function () {
        //let typeAlert = ($(this).hasClass('aprovar')? 'success' : ($(this).hasClass('reprovar')? 'danger' : 'warning'));
        FLUIGC.toast({
            title: 'Validação ',
            message: 'Solicitação marcada para ' + $(this).text().toLowerCase(),
            type: 'info'
        });
    });
}

function addItemRateio(){
    wdkAddChild('tabelaRateio');
    Apportionment.childEvents();
}