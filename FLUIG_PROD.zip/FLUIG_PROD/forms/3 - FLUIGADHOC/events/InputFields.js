function inputFields(form) {
	var indexes = form.getChildrenIndexes("tbatividades");
	form.setValue('qtativ', indexes.length);
}