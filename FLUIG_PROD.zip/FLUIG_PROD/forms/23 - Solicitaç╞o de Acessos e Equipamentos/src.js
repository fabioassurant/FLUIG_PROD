var arrayCheck = new Array();

$(document).ready(() => {
    initFields();
    events();
    initAprovacao();
    verificarcampos();
})

function verificarcampos(){
    console.log("Passando no verifica campos");

    if (mode() != "VIEW"){
        var valorInputs = $("#para_nome").val();
        var valorZoom = $("#para_nome_zoom").val();

        var valorInputsGeren = $("#para_gerente").val();
        var valorZoomGere = $("#para_gerente_zoom").val();
   
    }else{
        var valorInputs = $("#para_nome")[0].innerText.trim();
        var valorZoom = $("#para_nome_zoom")[0].innerText.trim();

        var valorInputsGeren = $("#para_nome")[0].innerText.trim();
        var valorZoomGere = $("#para_nome_zoom")[0].innerText.trim();
        var valorEspelho = $("#para_usuario_espelho")[0].innerText.trim();
        if(valorEspelho != ""){
            $('.para_usuario_espelho').show();
        }

        var valorInputsGeren = $("#para_gerente")[0].innerText.trim();
        var valorZoomGere = $("#para_gerente_zoom")[0].innerText.trim();
    }
    

    if( valorInputs == "" &&  valorZoom == ""){
        return;
    }else if(valorInputs == "" && valorZoom != ""){
        $(".para_nome").removeClass("obrigatorio");
        $(".para_nome").addClass("fs-display-none");
        
        $(".para_nome_zoom").removeClass("fs-display-none");
        $("#para_nome_zoom").addClass("obrigatorio");
        $("#para_nome_zoom").prop('readonly', true);
    }else if(valorInputs != "" && valorZoom == ""){
        $(".para_nome_zoom").removeClass("obrigatorio");
        $(".para_nome_zoom").addClass("fs-display-none");
        
        $(".para_nome").removeClass("fs-display-none");
        $("#para_nome").addClass("obrigatorio");
        $("#para_nome").prop('readonly', true);
    }

    if(valorInputsGeren == "" && valorZoomGere == ""){
        return;
    }
    else if(valorInputsGeren == "" && valorZoomGere != ""){
        $(".para_gerente").removeClass("obrigatorio");
        $(".para_gerente").addClass("fs-display-none");
        
        $(".para_gerente_zoom").removeClass("fs-display-none");
        $("#para_gerente_zoom").addClass("obrigatorio");
        $("#para_gerente_zoom").prop('readonly', true);
    }
    else if(valorInputsGeren != "" && valorZoomGere == ""){
        $(".para_gerente_zoom").removeClass("obrigatorio");
        $(".para_gerente_zoom").addClass("fs-display-none");
        
        $(".para_gerente").removeClass("fs-display-none");
        $("#para_gerente").addClass("obrigatorio");
        $("#para_gerente").prop('readonly', true);
    }
}


function initAprovacao() {
    $('[name=botaoAprovacaoTi], [name=botaoAprovacao], [name=botaoAprovacaoSol]').change(event => {
        if (event.target.name === "botaoAprovacaoTi") {
            $('[name=aprovacaoTI]').val(event.target.value)
            if (event.target.value === "REPROVADO") {
                $('.motivoRecusaTI').show();
                $("#motivoRecusaTI").addClass("obrigatorio");
            } else {
                $('.motivoRecusaTI').hide();
                $("#motivoRecusaTI").removeClass("obrigatorio");
            }
        } else if (event.target.name === "botaoAprovacao") {
            $('[name=aprovacaoGestor]').val(event.target.value)
            if (event.target.value === "REPROVADO") {
                $('.motivoRecusaGestor').show();
                $("#motivoRecusaTI").addClass("obrigatorio");
            } else {
                $('.motivoRecusaGestor').hide();
                $("#motivoRecusaTI").removeClass("obrigatorio");
            }
        } else {
            $('[name=aprovacaoSol]').val(event.target.value)
            if (event.target.value === "REPROVADO") {
                $('.motivoRecusaSol').show();
                $("#motivoRecusaSol").addClass("obrigatorio");
            } else {
                $('.motivoRecusaSol').hide();
                $("#motivoRecusaSol").removeClass("obrigatorio");
            }
        }
    });


    if ($('#tipo_funcionario').val() === "assurant") {
        $('.matricula').show();
    }

    if ($('[name=aprovacaoTI]').val() === "REPROVADO") {
        $('[name=botaoAprovacaoTi]')[1].checked = true
        $('.motivoRecusaTI').show();
    } else {
        $('[name=botaoAprovacaoTi]')[0].checked = true
    }
    if ($('[name=aprovacaoGestor]').val() === "REPROVADO") {
        $('[name=botaoAprovacao]')[1].checked = true
        $('.motivoRecusaGestor').show();
    } else {
        $('[name=botaoAprovacao]')[0].checked = true
    }
    if ($('[name=aprovacaoSol]').val() === "REPROVADO") {
        $('[name=botaoAprovacaoSol]')[1].checked = true
        $('.motivoRecusaSol').show();
    } else {
        $('[name=botaoAprovacaoSol]')[0].checked = true
    }

}
//controla campo matricula
function changeColleagueType() {
    if (event.target.value === 'assurant') {
        $('.matricula').show();
        $('.matricula').addClass("obrigatorio");
    } else {
        $('.matricula').hide();
    }
}

//controla campos após finalizacao do processo
function setFinalActivity() {
    $("#liberacaoAnalista").show();
    $("#acessos_soft").prop("disabled", "disabled")
}

//consulta genérica de dataset
function consultDataset(dataset, tabela, constraints, async) {
    var cst = constraints != null ? constraints : []
    if (tabela != null) cst.push({
        "_field": "tablename",
        "_initialValue": tabela,
        "_finalValue": tabela,
        "_type": 1
    })
    return $.ajax({
        url: '/api/public/ecm/dataset/datasets',
        type: 'post',
        async: async,
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({
            "name": dataset,
            "constraints": cst
        }),
        success: function(data) {}
    });
}

//controla visualização das divs dos campos
function controlVisibilityField(campo, type) {
    if (campo) {
        if (type == 'show') {
            $("." + campo).removeClass("fs-display-none");
            $("#" + campo).addClass("obrigatorio");
        } else {
            $("." + campo).addClass("fs-display-none");
            $("#" + campo).removeClass("obrigatorio");
        }
    }
}

//eventos dos elementos
function events() {
    $("#tipo_funcionario").on('change', (e) => {
        changeColleagueType();
        if (e.target.value == "assurant" && $("#tipo_requisicao").val() != 'novo_usuario') {
            controlVisibilityField('para_nome_zoom', 'show');
            controlVisibilityField('para_nome', 'hide');
        } else {
            controlVisibilityField('para_nome_zoom', 'hide');
            controlVisibilityField('para_nome', 'show');
        }

        // if (e.target.value == "terceiro") {
        //     $(".div_para_lan").show();
        // } else {
        //     $(".div_para_lan").hide();
        // }
        if (e.target.value == "externo") {
            $(".div_para_lan").hide();
        }
    })

    $("#tipo_requisicao").on("change", e => {
        if (e.target.value != 'novo_usuario' && $("#tipo_funcionario").val() == 'assurant') {
            controlVisibilityField('para_nome_zoom', 'show');
            controlVisibilityField('para_nome', 'hide');
        } else {
            controlVisibilityField('para_nome_zoom', 'hide');
            controlVisibilityField('para_nome', 'show');
        }

        let option = e.target.value;
        controlNameField(option);
    })



    $("[name=funcionario_interno]").on("change", e => {
        if (e.target.checked) {
            $("[name=funcionario_externo]").prop("checked", false);
        }
    })

    $("[name=funcionario_externo]").on("change", e => {
        if (e.target.checked) {
            $("[name=funcionario_interno]").prop("checked", false);
        }
    })
}

function controlNameField(option) {
    // if (option == 'alteracao' || option == 'exclusao') {
    //     controlVisibilityField('para_nome_zoom', 'show');
    //     controlVisibilityField('para_nome', 'hide');
    //     controlVisibilityField('para_gerente', 'show');
    //     controlVisibilityField('para_gerente_zoom', 'hide');
    // } else {
    //     controlVisibilityField('para_nome_zoom', 'hide');
    //     controlVisibilityField('para_nome', 'show');
    //     controlVisibilityField('para_gerente', 'hide');
    //     controlVisibilityField('para_gerente_zoom', 'show');
    // }

    if (option == 'alteracao' || option == 'recontratacao' || (option == 'novo_usuario' && $("#tipo_funcionario").val() == "assurant")) {
        $(".div_para_lan").show();
        $(".para_usuario_espelho").show();
    } else if (option == 'novo_usuario' && $("#tipo_funcionario").val() == "terceiro") {
        $(".div_para_lan").hide();
        $(".para_usuario_espelho").show();
    } else {
        $(".div_para_lan").show();
        $(".para_usuario_espelho").hide();
    }

    if(option == 'alteracao' || option == 'recontratacao'){
        $('#span_nome').show();
        $('#span_nome_zoom').show();
        $('#span_lan').show();
        $('#span_email').show();
        $('#span_departamento').hide();
        $('#span_usuario_espelho').show();
        $('#span_cargo').hide();
    }

    if(option == 'novo_usuario'){
        $('#span_nome').show();
        // $('#span_nome_zoom').show();
        $('#span_lan').hide();
        $('#span_email').show();
        $('#span_departamento').show();
        $('#span_usuario_espelho').show();
        $('#span_cargo').show();
    }

    if(option == 'exclusao'){
        $('#span_nome').show();
        $('#span_nome_zoom').show();
        $('#span_lan').show();
        $('#span_email').show();
        $('#span_departamento').show();
        $('#span_usuario_espelho').hide();
        $('#span_cargo').hide();
    }
}

function initFields() {
    let atv = getAtv();
    // $("#tel_solicitante").mask("(99) 99999-9999");
    $(".div_para_lan").show();
    $("#acessos_soft option").removeAttr("selected")
    $("#acessos_soft").html("")
    $('#acessos_soft').multiSelect({
        selectableHeader: "<div class='custom-header'>Itens Disponíveis</div>",
        selectionHeader: "<div class='custom-header'>Itens Selecionados</div>",
        keepOrder: true,
        afterSelect: function(values) {
            let ind = arrayCheck.findIndex(e => e == values[0]);
            if (ind < 0) {
                arrayCheck.push(values[0]);
            }
        },
        afterDeselect: function(values) {
            arrayCheck.forEach((e, i) => {
                if (e == values[0]) {
                    arrayCheck.splice(i, 1);
                }
            })
        }
    })

    consultDataset("ds_itens_acesso_equip", "itens_acesso_equip", [], false).success((data) => {
        data = data.content.values;
        let index = 0;
        data.sort((a, b) => {
            return (a.item > b.item) ? 1 : ((b.item > a.item) ? -1 : 0);
        })
        data.forEach((e, i) => {
            $('#acessos_soft').multiSelect('addOption', {
                value: e.item,
                text: e.item,
                index: i
            });
        })
    })

    if (atv == FINAL) {
        setFinalActivity();
    }

    if (atv == ABERTURA) {

        $("#data_solicitacao").val(new Date().toLocaleString('pt-BR').split(' ')[0]);

    } else {
        if ($("#tipo_requisicao").val() == 'exclusao') {
            $(".para_usuario_espelho").hide();
        }
        arrayCheck = JSON.parse($("#checkbox_check").val());
        $("#acessos_soft").multiSelect("select", arrayCheck);
        
        $(".div_sel_2 .ms-elem-selectable,.div_sel_2 .ms-elem-selection").css("pointer-events", "none");
        
        if ($("#tipo_funcionario").val() == "assurant") {
            controlVisibilityField('para_nome_zoom', 'show');
            controlVisibilityField('para_nome', 'hide');
        } else {
            controlVisibilityField('para_nome_zoom', 'hide');
            controlVisibilityField('para_nome', 'show');
        }
        controlNameField($("#tipo_requisicao").val());
    }

    if (atv == INICIO) {
        if (mode() != "VIEW")
            $(".div_sel_2").css("pointer-events", "auto");
    }

    if (atv == SUPORTE_TI) {
        let user = parent.WCMAPI.user;
        $("#analista_resp, #_analista_resp").val(user);
        $("#_data_final, #data_final").val(returnDate());
    }

}

function returnDate() {
    let data = new Date().toLocaleDateString('pt-BR');
    return data;
}



var beforeSendValidate = function(numState, nextState) {
    let msg = "";
    if (getAtv() == ABERTURA || getAtv() == INICIO) {
        $("#checkbox_check").val(JSON.stringify(arrayCheck));
        $(".obrigatorio").each((index, element) => {
            if ($(element).val() == undefined || $(element).val() == null) {
                msg += "\nCampo '" + element.labels[0].textContent + "' é obrigatório!";
            }
        })

        if (!$("[name=funcionario_interno]").prop("checked") && !$("[name=funcionario_externo]").prop("checked")) {
            msg += "\nTipo de Funcionário (Interno ou Externo) é Obrigatório";
        }
        if ($("#checkbox_check").val() == "[]") {
            msg += "\nSelecione uma opção da Lista de Acessos";
        }
    } else if (getAtv() == TI_APROVA) {

        msg = verifyApprove("TI", msg);

    } else if (getAtv() == GESTOR) {

        msg = verifyApprove('Gestor', msg);

    } else if (getAtv() == VALIDACAO_ACESSOS) {

        msg = verifyApprove('Sol', msg);

    }

    if (msg != "") {
        throw msg;
    }
}

function verifyApprove(area, msg) {

    if (!$(`[name=aprovacao${area}]`).val()) {
        msg += "\nAprovação é Obrigatória";
    } else if ($(`[name=aprovacao${area}]`).val() == "REPROVADO" && !$(`#motivoRecusa${area}`).val()) {
        msg += "\Motivo da Recusa é Obrigatório";
    }

    return msg;
}

function setSelectedZoomItem(selectedItem) {

    if (selectedItem.inputId == "para_nome_zoom") {
        var para_solicitante = selectedItem["colleagueId"];

        var csUsuarioCPF = []
        csUsuarioCPF.push(DatasetFactory.createConstraint("tablename", "tabelaUserCpf", "tabelaUserCpf", ConstraintType.MUST));
        var ds_usuario_cpf = DatasetFactory.getDataset("ds_usuario_cpf", null, csUsuarioCPF, null)


        var csAlcadaAssurant = []
        csAlcadaAssurant.push(DatasetFactory.createConstraint("tablename", "tableCadastroAlcada", "tableCadastroAlcada", ConstraintType.MUST));
        var ds_alcada_assurant = DatasetFactory.getDataset("ds_alcada_assurant", null, csAlcadaAssurant, null)

        for (let i = 0; i < ds_usuario_cpf.values.length; i++) {
            if (ds_usuario_cpf.values[i].userId == para_solicitante) {
                var grupoUsuario = ds_usuario_cpf.values[i].grupo
            }
        }

        for (let i = 0; i < ds_alcada_assurant.values.length; i++) {
            var grupoUsuarioAl = ds_alcada_assurant.values[i].grupo
            if (grupoUsuarioAl.includes(grupoUsuario) && ds_alcada_assurant.values[i].prioridade == "1" && ds_alcada_assurant.values[i].hiddenProcesso.indexOf('acesso_equipamento') > -1) {
                $("#para_gerente").val(ds_alcada_assurant.values[i].usuario)
                $("#gestores").val(ds_alcada_assurant.values[i].idUsuario);
            }
        }
    } else if (selectedItem.inputId == "para_gerente_zoom") {
        $('#gestores').val(selectedItem["colleagueId"]);
    }

}