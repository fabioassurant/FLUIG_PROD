const activities = {
    ABERTURA: 0,
    INICIO: 4,
    TI_APROVA: 29,
    SOLICITANTE: 5,
    GESTOR: 7,
    CANCELAR: 11,
    SUPORTE_TI: 15,
    ENVIA_EMAIL: 19,
    VALIDACAO_ACESSOS: 38,
    FINAL: 23, 
}