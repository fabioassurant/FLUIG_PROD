function displayFields(form, customHTML) {
    var atv = getValue("WKNumState");
    1
    var mode = form.getFormMode();

    form.setEnabled("acessos_soft", true);
    customHTML.append("<script>function getAtv(){ return " + atv + "};</script>");
    customHTML.append("<script>function mode(){ return '" + mode + "'};</script>");
    // INICIO
    if (atv == 0 || atv == 4) {
        form.setVisibleById("liberacaoAnalista", false);
        form.setVisibleById("aprovacaoGestor", false);
        form.setVisibleById("aprovacaoTI", false);
        form.setVisibleById("aprovacaoSolicitante", false);
    }

    // INICIO
    if (atv == 4) {
        var requester = getValue("WKUser");
        form.setValue("requester", requester);

        if (form.getValue('botaoAprovacaoTi') == 'REPROVADO') {
            form.setVisibleById("aprovacaoTI", true);
            form.setVisibleById('motivoTI', true);
            form.setEnabled('motivoRecusaTI', false);
            form.setEnabled("botaAprovacaoTi", true);
            customHTML.append("<script>$('[name=botaoAprovacaoTi]').parent().parent().css('pointer-events', 'none')</script>")
        }

        if (form.getValue('botaoAprovacao') == 'REPROVADO') {
            form.setVisibleById("aprovacaoGestor", true);
            form.setVisibleById('motivoGestor', true);
            form.setEnabled('motivoRecusaGestor', false);
            form.setEnabled("botaoAprovacao", true);
            customHTML.append("<script>$('[name=botaoAprovacao]').parent().parent().css('pointer-events', 'none')</script>")
        }
    }

    // TI APROVA
    if (atv == 29) {
        habilitaCampos(form);

        var requester = getValue("WKUser");
        form.setValue("requester", requester);

        form.setVisibleById("liberacaoAnalista", false);

        form.setVisibleById("aprovacaoGestor", false);
        form.setEnabled('motivoRecusaGestor', false);

        form.setEnabled("aprovacaoTI", true);
        form.setEnabled("botaoAprovacaoTi", true);
        form.setEnabled("motivoRecusaTI", true);
        form.setVisibleById("aprovacaoSolicitante", false);
        form.setEnabled('motivoRecusaSol', false);

        if (form.getValue('botaoAprovacao') == 'REPROVADO') {
            form.setVisibleById("aprovacaoGestor", true);
            form.setVisibleById('motivoGestor', true);
            form.setEnabled('motivoRecusaGestor', false);
            form.setEnabled("botaoAprovacao", true);
            customHTML.append("<script>$('[name=botaoAprovacao]').parent().parent().css('pointer-events', 'none')</script>")
        }
    }

    // GESTOR APROVA
    if (atv == 7) {
        habilitaCampos(form);

        var requester = getValue("WKUser");
        form.setValue("requester", requester);

        form.setVisibleById("liberacaoAnalista", false);

        form.setEnabled("botaoAprovacao", true);

        form.setVisibleById("aprovacaoTI", false);
        form.setEnabled('motivoRecusaTI', false);
        form.setEnabled("motivoRecusaGestor", true);
        form.setVisibleById("aprovacaoSolicitante", false);
        form.setEnabled('motivoRecusaSol', false);
    }

    // LIBERAÇÃO REALIZADA PELO SUPORTE TI
    if (atv == 15) {
        habilitaCampos(form);

        var requester = getValue("WKUser");
        form.setValue("requester", requester);
        customHTML.append("<script>$('#liberacaoAnalista').css('pointer-events', 'auto');</script>")
        form.setVisibleById("aprovacaoGestor", false);
        form.setEnabled('motivoRecusaGestor', false);

        form.setVisibleById("aprovacaoTI", false);
        form.setEnabled('motivoRecusaTI', false);

        form.setVisibleById("aprovacaoSolicitante", false);
        form.setEnabled('motivoRecusaSol', false);
        form.setEnabled("para_lan", true);
        if (form.getValue('botaoAprovacaoSol') == 'REPROVADO') {
            form.setVisibleById("aprovacaoSolicitante", true);
            form.setVisibleById('motivoSol', true);
            form.setEnabled('motivoRecusaSol', false);
            form.setEnabled("botaoAprovacaoSol", true);
            form.setEnabled("comentarios_outros", true);
            customHTML.append("<script>$('#aprovacaoAprovadoSol').parent().parent().css('pointer-events', 'none');</script>")
            customHTML.append("<script>$('#comentarios_outros').parent().removeClass('fs-display-none');</script>")
        }
    }

    // VALIDAÇÃO DE ACESSOS
    if (atv == 38) {
        habilitaCampos(form);

        var requester = getValue("WKUser");
        form.setValue("requester", requester);

        form.setVisibleById("liberacaoAnalista", true);
        customHTML.append("<script>$('#liberacaoAnalista').css('pointer-events', 'none');</script>")
        form.setVisibleById("aprovacaoGestor", false);
        form.setEnabled('motivoRecusaGestor', false);

        form.setVisibleById("aprovacaoTI", false);
        form.setEnabled('motivoRecusaTI', false);
        form.setEnabled("aprovacaoSolicitante", true);
        form.setEnabled("botaoAprovacaoSol", true);
        form.setEnabled("motivoRecusaSol", true);
        form.setEnabled("comentarios_outros", false);
        if (form.getValue('botaoAprovacaoSol') == 'REPROVADO') {
            customHTML.append("<script>$('#_comentarios_outros').parent().removeClass('fs-display-none');</script>")

        }
    }
}

function habilitaCampos(form) {
    var habilitar = false; // Informe True para Habilitar ou False para Desabilitar os campos
    var mapaForm = new java.util.HashMap();
    mapaForm = form.getCardData();
    var it = mapaForm.keySet().iterator();

    while (it.hasNext()) { // Laço de repetição para habilitar/desabilitar os campos
        var key = it.next();
        if (key.indexOf("botaoAprovacao") < 0 && key.indexOf("ticket") < 0 && key.indexOf("descricao") < 0 && key.indexOf("motivoRecusa") < 0 && key.indexOf("data_final") < 0) {
            form.setEnabled(key, habilitar);
        }
    }
    form.setEnabled("acessos_soft", true);
}