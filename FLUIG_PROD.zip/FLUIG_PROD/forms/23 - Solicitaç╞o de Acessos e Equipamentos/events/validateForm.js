function validateForm(form) {

	var atv = getValue('WKNumState');
	var enviar = getValue('WKCompletTask')
	var msg = '';

	if (enviar == true || enviar == 'true') {
		if (atv == 0 || atv == 4) {

			/* 
			Alteração
			*/
			if (form.getValue('tipo_funcionario') == '' || form.getValue('tipo_funcionario') == null) {
				msg += '</br> Selecione o campo <b>"Tipo de Funcionário"</b>';
			}

			if (form.getValue('tipo_requisicao') == '' || form.getValue('tipo_requisicao') == null) {
				msg += '</br> Selecione o campo <b>"Tipo de Requisição"</b>';
			}

			/* 
				Alteração
		   */
			if (form.getValue('tipo_requisicao') == 'alteracao') {

				if (form.getValue('nome_solicitante') == '' || form.getValue('nome_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Nome"</b>';
				}
				if (form.getValue('dep_solicitante') == '' || form.getValue('dep_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Departamento"</b>';
				}

				if(form.getValue('tipo_funcionario') == 'assurant'){
					if (form.getValue('para_nome_zoom') == '' || form.getValue('para_nome_zoom') == null) {
						msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
					}
				}else{
					if (form.getValue('para_nome') == '' || form.getValue('para_nome') == null) {
						msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
					}
				}
				if (form.getValue('para_lan') == '' || form.getValue('para_lan') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Lan ID"</b>';
				}
				if (form.getValue('para_email') == '' || form.getValue('para_email') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Email"</b>';
				}
				if (form.getValue('para_usuario_espelho') == '' || form.getValue('para_usuario_espelho') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Usuário Espelho"</b>';
				}
				/* 
				 Recontratação
				*/
			} else if (form.getValue('tipo_requisicao') == 'recontratacao') {

				if (form.getValue('nome_solicitante') == '' || form.getValue('nome_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Nome"</b>';
				}
				if (form.getValue('dep_solicitante') == '' || form.getValue('dep_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Departamento"</b>';
				}

				if(form.getValue('tipo_funcionario') == 'assurant'){
					if (form.getValue('para_nome_zoom') == '' || form.getValue('para_nome_zoom') == null) {
						msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
					}
				}else{
					if (form.getValue('para_nome') == '' || form.getValue('para_nome') == null) {
						msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
					}
				}
				if (form.getValue('para_lan') == '' || form.getValue('para_lan') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Lan ID"</b>';
				}
				if (form.getValue('para_email') == '' || form.getValue('para_email') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Email"</b>';
				}
				if (form.getValue('para_usuario_espelho') == '' || form.getValue('para_usuario_espelho') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Usuário Espelho"</b>';
				}
				/* 
			 		Novo Usuario
				*/
			} else if (form.getValue('tipo_requisicao') == 'novo_usuario') {

				if (form.getValue('nome_solicitante') == '' || form.getValue('nome_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Nome"</b>';
				}
				if (form.getValue('dep_solicitante') == '' || form.getValue('dep_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Departamento"</b>';
				}

				// if(form.getValue('tipo_funcionario') == 'assurant'){
				// 	if (form.getValue('para_nome_zoom') == '' || form.getValue('para_nome_zoom') == null) {
				// 		msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
				// 	}
				// }else{
					if (form.getValue('para_nome') == '' || form.getValue('para_nome') == null) {
						msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
					}
				// }
				if (form.getValue('para_email') == '' || form.getValue('para_email') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Email"</b>';
				}
				if (form.getValue('para_cargo') == '' || form.getValue('para_cargo') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Cargo"</b>';
				}
				if (form.getValue('para_departamento') == '' || form.getValue('para_departamento') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Departamento"</b>';
				}
				if (form.getValue('para_usuario_espelho') == '' || form.getValue('para_usuario_espelho') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Usuário Espelho"</b>';
				}
				/* 
			 		Exclusão
				*/
			}else if (form.getValue('tipo_requisicao') == 'exclusao') {

				if (form.getValue('nome_solicitante') == '' || form.getValue('nome_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Nome"</b>';
				}
				if (form.getValue('dep_solicitante') == '' || form.getValue('dep_solicitante') == null) {
					msg += '</br> <b>Painel Dados Solicitante - </b> Preencha o campo <b>"Departamento"</b>';
				}

				if(form.getValue('tipo_funcionario') == 'assurant'){
					if (form.getValue('para_nome_zoom') == '' || form.getValue('para_nome_zoom') == null) {
						msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
					}
				}else{
					if (form.getValue('para_nome') == '' || form.getValue('para_nome') == null) {
						msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Nome"</b>';
					}
				}
				if (form.getValue('para_lan') == '' || form.getValue('para_lan') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Lan ID"</b>';
				}
				if (form.getValue('para_departamento') == '' || form.getValue('para_departamento') == null) {
					msg += '</br> <b>Painel A Quem se des... - </b> Preencha o campo <b>"Departamento"</b>';
				}
			}
		}

	}

	if (msg != '') {
		throw msg;
	}

}