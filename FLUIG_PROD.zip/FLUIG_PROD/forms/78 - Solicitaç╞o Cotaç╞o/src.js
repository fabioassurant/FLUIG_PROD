const USER = parent.WCMAPI.userCode;
var arrColleague = [];
const PARENTID = 77; //Alterar o "0" para código da pasta "Raiz/Formulários Fluig/Solicitação de Cotação/Documentos" 
var objPercent = {};
const TOAST = (message, type) => {
    FLUIGC.toast({
        title: "",
        message: message,
        type: type,
    });
};

$(document).ready(() => {
    initFields();
    events();
    handleFilesOtherActivities();
    handleObservacaoRate();
    setTheftTabText();
    if (formMode() == "VIEW") {
        $("#pricing").hide();
        $("#tabCertificados .addDocumento").parent().css("pointer-events", "none");
        let product = $("#tipo_produto").text();
        $(`ul li a:contains(${product})`).parents("li").first().show()
        $("#tbl_certificados").show();
        disableFields("rate-request");
        disableFields("certificados");
        $("#btnCertificados").prop("disabled", true);
        disableFields(product);
        if (product == "ad") {
            disableFields("theft");
        }
        if (product == "theftad") {
            disableFields("ad");
            disableFields("theft");
        }

        if (product == "ad" || product == "theftad" || product == "theft") {
            setTheftTabText()
        }

    }
});

function handleFilesOtherActivities() {
    $(".addDocumento").each((index, element) => {
        const fileName = $(element).parents(".input-group").find("input[type='text']");
        const removeButton = $(element).parents(".input-group").find(".remover");
        //logo que inicia a atividade verifica se tem valor
        //se ja tiver significa que o arquivo foi adicionado em outra atividade
        if (fileName.val() != "") {
            removeButton.hide();
        }
    });
}

function handleObservacaoRate() {
    if (ativAtual == ATUARIAL) {
        $("#text_observacao_pricing").keyup((event) => {
            const obsPricing = event.currentTarget.value;
            $("#obs_dev_rate_req").val(obsPricing);
        });
    }
}

function limit120(element) {
    if (element.value > 120) {
        element.value = 120;
    }
    if (element.value < 0) {
        element.value = 0;
    }
}

function setTheftTabText() {
    if (ativAtual != 0) {
        const tipoProduto = $("#tipo_produto").val() != "" ? $("#tipo_produto").val() : $("#tipo_produto").text().toLowerCase();
        if (tipoProduto == "theft" || tipoProduto == "theftad" || tipoProduto == "ad") {
            $("#theft_ad a").text(tipoProduto == "theft" ? "Theft" : tipoProduto == "ad" ? "AD" : "TheftAD");
        }
    }
}

function initFields() {
    $(".escondeAbertura").hide();
    addMaskFields();
    let arrayStatus = returnOptionsStatus();
    upload();


    if (ativAtual != ATUARIAL) {
        $("#tabAprovacaoAtuarial").css("pointer-events", "none");
        $("#analista_pricing_1").attr("readonly", true);
    }
    if (ativAtual == ATUARIAL) {
        $("#aprovacaoAtuarial").show();
        $("#select_status_review_pricing").parent().css("pointer-events", "none");
        //$("#select_status_pricing").parent().css("pointer-events", "none");
        $("#status").val(arrayStatus.atuarial);
        setButtonsFile("up_arquivo_pm_email_01");
        setButtonsFile("up_arquivo_pm_outro_01");
    }
    if (ativAtual == ABERTURA) {
        // $("#widget_solicitante").val(parent.WCMAPI.user);
        fillObjPercent();
        returnColleague();
        consultDataset("DSformCotacaoassurant", null, []).success((data) => {
            let rate = data.content.values.length + 1;
            $("#numRate").val(rate);
        });
        consultPreviousRate();

        $("#tipo_produto").select2({
            allowClear: true,
            placeholder: "Selecione...",
            theme: "bootstrap",
            language: "pt-BR",
            width: "100%",
        });

        $("#uf").select2({
            data: returnUF(),
            allowClear: true,
            placeholder: "",
            theme: "bootstrap",
            language: "pt-BR",
            width: "100%",
        });

        var currentDate = new Date();
        var data = currentDate.toLocaleDateString("pt-br");
        $("#status").val(arrayStatus.inicio);
        $("#data_rate").val(data);
        return;
    } else {
        setVisibleFiles();
        if ($("[name=aprovacaoSolicitacao]:checked").val() == "REPROVAR") {
            $("#aprovacao").show();
        }
        if (formMode() != "VIEW") {
            $("." + $("#tipo_produto").val()).show();
        } else {
            $("#pricing").hide()
            $("." + $("#tipo_produto").text()).show();
            if ($("#tipo_produto").text() == "Credit") {
                $(".creditLife").show()
            }
            $(".addDocumento").each((i, e) => {
                let idBtn = e.id;
                if ($(`#${idBtn}`).parents("div").first().find("span").first().text()) {
                    setButtonsFile(idBtn);
                }
            });

        }
        $("#aprovacaoAtuarial").show();
    }

    if (ativAtual != ABERTURA && ativAtual != INICIO) {
        $("#tabCertificados .addDocumento").parent().css("pointer-events", "none");

        let product = "";
        if (formMode() == "VIEW") {
            product = $("#tipo_produto").text();
        } else {
            product = $("#tipo_produto").val();
        }
        $("#tbl_certificados").show();
        disableFields("rate-request");
        disableFields("certificados");
        $("#btnCertificados").prop("disabled", true);
        disableFields(product);
        if (product == "ad") {
            disableFields("theft");
        }
        if (product == "theftad") {
            disableFields("ad");
            disableFields("theft");
        }
    } else {
        $("#tabCertificados .addDocumento").parent().css("pointer-events", "auto");
    }

    if (ativAtual == PEER_REVIEW) {
        $("#select_status_review_pricing").parent().css("pointer-events", "auto");
        $("#select_status_pricing").parent().css("pointer-events", "none");
        $("#radios").show();
        return;
    } else {
        $("#radios").css("pointer-events", "none");
    }
    if (ativAtual == COTACAO) {
        $("#select_status_pricing").parent().css("pointer-events", "auto");
        $("#select_status_review_pricing").parent().css("pointer-events", "none");
        if ($("input:radio[name=aprovacaoPricing]:checked").val() == "NAO") {
            $("#radios").show();
            $("#status").val(arrayStatus.analistas);
        } else {
            $("#radios").hide();
        }
        return;
    }

    if (ativAtual == INICIO) {
        $("[tablename=tbl_certificados]").show();
        $("#btnCertificados").prop("disabled", true);
        $("#btnRemoverProjecao").removeAttr("disabled");
        const linesTotal = rowIndex.tbl_certificados;
        for (let i = -3; i < linesTotal; i++) {
            let line = i + 3;
            if (i < 2) {
                $(`#cert_elegiveis___${line}, #cert_premio_medio___${line}`).removeAttr("readonly");
            }
        }
        addEventsTable();
        addMaskTable();

        if ($("[name=aprovacaoSolicitacao]:checked").val() == "REPROVAR") {
            $("#obs_dev_rate_req").val($("#aprovacaoRateRequest").val());
            $("#text_observacao_pricing, #_text_observacao_pricing").val($("#aprovacaoRateRequest").val())
        }
    }
}

function setVisibleFiles() {
    $(".addDocumento").each((i, e) => {
        let idBtn = e.id;
        if ($(`#${idBtn}`).parents("div").first().find("input").first().val()) {
            setButtonsFile(idBtn);
        }
    });
}

function setButtonsFile(button) {
    $(`#${button}`).parent().siblings().removeClass("fs-display-none");
    $(`#${button}`).parent().addClass("fs-display-none");
}

function returnColleague() {
    consultDataset("colleague", null, []).success((data) => {
        data = data.content.values;

        data = data.map((e) => {
            arrColleague.push({ id: e["colleaguePK.colleagueId"], text: e["colleagueName"] });
        });
        arrColleague.unshift({ id: "", text: "Selecione..." });

        $("#zoomCRM")
            .select2({
                data: arrColleague,
                allowClear: true,
                placeholder: "Selecione...",
                theme: "bootstrap",
                language: "pt-BR",
                width: "100%",
            })
            .on("select2:select", (dataselected) => {
                $("#zoomCRMHidden").val(dataselected);
            });

        $("#zoomCRM").val(USER).trigger("change");
    });
}

function returnPricingAnalist() {
    let cs = [{
        _field: "colleagueGroupPK.groupId",
        _initialValue: "PRICING",
        _type: 1,
    }, ];

    consultDataset("colleagueGroup", null, cs).success((data) => {
        data = data.content.values;
        let options = [];

        data = data.map((e) => {
            let name = arrColleague.find((el) => el.id == e["colleaguePK.colleagueId"]);
            options.push({ id: name.id, text: name.text });
        });

        console.log(options);
    });
}

function setSelectedZoomItem(selectedItem) {
    if (selectedItem) {
        switch (selectedItem.inputId) {
            case "analista_pricing_1":
                let inputSelected = selectedItem["userId"];
                $("#widget_analista_pricing1").val(inputSelected);
                const analista2Value = $("#analista_peer_review").val();
                if (inputSelected == analista2Value) {
                    FLUIGC.toast({
                        title: "Usuário já selecionado",
                        message: " no campo Analista Peer View",
                        type: "warning",
                    });
                    window[selectedItem.inputId].clear();
                }
                break;

            case "analista_pricing_2":
                let campoSelected = selectedItem["userId"];
                $("#analista_peer_review").val(campoSelected);
                const analista1Value = $("#widget_analista_pricing1").val();
                if (campoSelected == analista1Value) {
                    FLUIGC.toast({
                        title: "Usuário já selecionado",
                        message: " no campo Analista Pricing",
                        type: "warning",
                    });
                    window[selectedItem.inputId].clear();
                }
                break;
            default:
                console.log("default");
        }
    }
}

//eventos da tabela de projeção estao na função addEventsTable();
function events() {
    //events onclick
    $("#btnCertificados").on("click", (e) => {
        addCertificatesLines();
    });

    $("#btnRemoverProjecao").on("click", (e) => {
        removeCertificatesLines();
        $("#btnCertificados").removeAttr("disabled");
        $("#" + e.target.id).prop("disabled", true);
    });

    $(".visualizar").on("click", (e) => {
        let docId = $(e.currentTarget).parents("div").first().find("input").length != 0 ? $(e.currentTarget).parents("div").first().find("input").first().val().split(" - ")[0] : $(e.currentTarget).parents("div").first().find("span").first().text().split(" - ")[0];
        openDocument(docId, 1000);
        //let linkDoc = returnLinkDocument(docId);
        window.location.href = linkDoc;
    });
    //fim eventos onclick

    $(".remover").on("click", (e) => {
        removeDocument(e.currentTarget);
    });
    //eventos on change
    $("#select_status_pricing").change((event) => {
        const value = event.currentTarget.value;
        if (value == "1" || value == "2" || value == "3" || value == "4" || value == "5") {
            $("#data_entrega_pricing").val(new Date().toLocaleDateString("pt-BR"));
            $("#data_npb_pricing").val("");
        } else if (value == "6" || value == "7" || value == "8") {
            $("#data_entrega_pricing").val(new Date().toLocaleDateString("pt-BR"));
            $("#data_npb_pricing").val(new Date().toLocaleDateString("pt-BR"));
        } else {
            $("#data_entrega_pricing").val("");
            $("#data_npb_pricing").val("");
        }
    });

    $("#upgrade_subsidio").on("change", (e) => {
        if (e.target.value == "sim") {
            $("#valor_subsidio").show();
        } else {
            $("#valor_subsidio").hide();
        }
    });

    $("#upgrade_reposicao").on("change", (e) => {
        if (e.target.value == "sim") {
            $("#valor_desconto").show();
        } else {
            $("#valor_desconto").hide();
        }
    });

    $("#analista_pricing_1").on("change", (e) => {
        $("#analista_pricing_pm").val(e.target.text);
    });

    $("#analista_pricing_2").on("change", (e) => {
        $("#analista__peer_pm_pricing").val(e.target.text);
    });

    $("#tipo_produto").on("change", (e) => {
        if (e.target.value == "theft") {
            $("#theft_fields").show();
            $("#ad_fields").hide();
        }
        if (e.target.value == "theftad") {
            $("#theft_fields").show();
            $("#ad_fields").show();
        }
        if (e.target.value == "ad") {
            $("#theft_fields").hide();
            $("#ad_fields").show();
        }
        $(".escondeAbertura").hide();
        if (rowIndex.tbl_certificados > 0) $("#tbl_certificados").show();
        $("." + e.target.value).show();
        let thefts = ["theft", "ad", "theftad"];
        $("#produto").val($("#tipo_produto option:selected").text());
        if (thefts.indexOf(e.target.value) > -1) {
            $("#theft_ad a").text($("#" + e.target.id + " option:selected").text());
            $("#theft_ad a").click();
            return;
        }
        if (e.target.value == "esc") {
            $("#certificados a").click();
            return;
        }
        $("#" + e.target.value + " a").click();
    });

    $("#select_pm_pricing").on("change", (e) => {
        if (e.target.value == 2) {
            $(".executar_pm").attr("readonly", true);
            $(".executar_select").attr("readonly", true);
            $(".executar_file").attr("readonly", true);
            $(".executar_check").attr("readonly", true);
            // $(".executar_zoom").attr("readonly", true);
        } else {
            $(".executar_pm").attr("readonly", false);
            $(".executar_select").attr("readonly", false);
            $(".executar_file").attr("readonly", false);
            $(".executar_check").attr("readonly", false);
            // $(".executar_zoom").attr("readonly", false);
        }
    });
    // analista 1
    $("#select_status_pricing").on("change", (e) => {
        $("#status, #pm_status, #widget_status").val($("#" + e.currentTarget.id + " option:selected").text());
        if (e.currentTarget.value == "7") {
            let currentDate = new Date();
            $("#data_npb_pricing").val(currentDate.toLocaleDateString("pt-BR"));
        } else if (e.currentTarget.value == "3") {
            let currentDate = new Date();
            $("#data_entrega_pricing").val(currentDate.toLocaleDateString("pt-BR"));
        }
    });

    // analista 2 - peer review
    $("#select_status_review_pricing").on("change", (e) => {
        $("#widget_status").val($("#" + e.currentTarget.id + " option:selected").text());
    });

    $("input:radio[name=aprovacaoSolicitacao]").on("change", () => {
        // retorna o value do radio selecionado
        var value = $("input:radio[name=aprovacaoSolicitacao]:checked").val();
        console.log(value);

        if (value == "REPROVAR") {
            $("#aprovacao").show();
        } else {
            $("#aprovacao").hide();
        }
    });

    $(".distribuicao input").on("blur", (e) => {
        if (e.target.value && e.target.id.indexOf("total") < 0) {
            objPercent[e.target.id].automatic = false;
            divisionPercent(e.target.id);
        } else {
            objPercent[e.target.id].automatic = true;
        }
    });

    $(".calc-total").keyup((event) => {
        divisionPercent(event.currentTarget.id);
        const row = $(event.currentTarget).parents(".distribuicao");
        let total = 0;
        row.find(".calc-total").each((index, element) => {
            let value = element.value || "0";
            value = value.replaceAll(".", "").replaceAll(",", ".");
            value = parseFloat(value);
            total += value;
        });
        row.find(".total").val(total.toFixed(2)).trigger("input");
    });
    //fim eventos on change
}

function fillObjPercent() {
    $(".distribuicao input").each((i, e) => {
        objPercent[e.id] = {};
        objPercent[e.id].automatic = true;
    });
}

function addCertificatesLines() {
    $("#tbl_certificados").show();
    $("#btnRemoverProjecao").removeAttr("disabled");
    $("#btnCertificados").prop("disabled", true);

    let index = 12;
    for (let i = -3; i < index; i++) {
        if (i == 0) {
            continue;
        }
        let line = wdkAddChild("tbl_certificados");
        if (i < 2) {
            $(`#cert_elegiveis___${line}, #cert_premio_medio___${line}`).removeAttr("readonly");
        }
        if (i < 0) {
            $(`#cert_ano___${line}`).val(`${i} (passado)`);
        } else {
            $(`#cert_ano___${line}`).val(i);
        }
    }
    addEventsTable();
    addMaskTable();
}

function removeCertificatesLines() {
    $('[tablename="tbl_certificados"] tr:not(:first-child)').each(function(i, e) {
        fnWdkRemoveChild(e);
    });
    $("#tbl_certificados").hide();
}

//apenas eventos da tabela de projeção
function addEventsTable() {
    $("[name^=cert_cres_anual___]").on("blur", (e) => {
        let valueAnualGrowth = formatPercentage(e.target.value);
        let index = parseInt(e.target.id.split("___")[1]);
        let eligibleValue = $(`#cert_elegiveis___${index}`).val().replace(/\./g, "");
        if (eligibleValue != "") {
            let result = eligibleFormula(valueAnualGrowth, eligibleValue);
            result = Number(result.toFixed(0));
            result = result.toLocaleString("pt-BR", { useGrouping: true });
            if (index >= 4) {
                let nextIndex = index + 1;
                $(`#cert_elegiveis___${nextIndex}`).val(result).trigger("blur");
            } else {
                $(`#cert_elegiveis___${index}`).val(result);
            }
            let previousIndex = index - 1;
            let previousPrize = $(`#cert_premio_medio___${previousIndex}`).val();
            $(`#cert_premio_medio___${index}`).val(previousPrize);
        }
    });

    $("[name^=cert_elegiveis___]").on("blur", (e) => {
        let eligibleValue = e.target.value.replace(/\./g, "");
        let index = parseInt(e.target.id.split("___")[1]);
        if (index == 4) {
            let valueAnualGrowth = formatPercentage($(`#cert_cres_anual___${index}`).val());
            let penetrationValue = formatPercentage($(`#cert_penetracao___${index}`).val());
            if (valueAnualGrowth != "") {
                let result = eligibleFormula(valueAnualGrowth, eligibleValue);
                if (result) {
                    result = Number(result.toFixed(0));
                    result = result.toLocaleString("pt-BR", { useGrouping: true });
                    let nextIndex = index + 1;
                    $(`#cert_elegiveis___${nextIndex}`).val(result);
                }
            }
            if (penetrationValue != "") {
                let result = certificatesFormula(eligibleValue, penetrationValue);
                result = result.toLocaleString("pt-BR", { useGrouping: true, minimumFractionDigits: 2 });
                $(`#cert_certificados___${index}`).val(result);
            }
        }
        let previousIndex = index - 1;
        let previousPrize = $(`#cert_premio_medio___${previousIndex}`).val();
        $(`#cert_premio_medio___${index}`).val(previousPrize);
    });

    $("[name^=cert_penetracao___]").on("blur", (e) => {
        let penetrationValue = formatPercentage(e.target.value);
        let index = parseInt(e.target.id.split("___")[1]);
        let eligibleValue = $(`#cert_elegiveis___${index}`).val().replace(/\./g, "");
        if (eligibleValue != "") {
            let result = certificatesFormula(eligibleValue, penetrationValue);
            result = result.toLocaleString("pt-BR", { useGrouping: true, minimumFractionDigits: 2 });
            $(`#cert_certificados___${index}`).val(result);
        }
    });

    $("[name^=cert_premio_medio___]").on("change", (e) => {
        const value = e.currentTarget.value;
        const row = parseInt(e.currentTarget.id.split("___")[1]);
        const nextPremio = $(`#cert_premio_medio___${row + 1}`);
        if (nextPremio.is("[readonly]") && !e.currentTarget.readOnly) {
            const tableLength = $("[tablename='tbl_certificados'] tbody tr:not(:first)").length;
            for (let i = row + 1; i <= tableLength; i++) {
                if ($(`#cert_elegiveis___${i}`).val()) {
                    $(`#cert_premio_medio___${i}`).val(value);
                }
            }
        }
    });
}

function formatPercentage(percent) {
    return parseFloat(percent.replace("%", "")) / 100;
}

function certificatesFormula(eligible, penetration) {
    if (!eligible || !penetration) {
        return "";
    }
    return eligible * penetration;
}

function AveragePrizeFormula(previousAnualGrowth, previousValue) {
    if (previousAnualGrowth > 0) {
        return previousValue;
    }
    return "";
}

function eligibleFormula(previousAnualGrowth, previousValue) {
    if (!previousAnualGrowth || !previousValue) {
        return "";
    }
    return (previousValue *= 1 + previousAnualGrowth);
}

var beforeSendValidate = (atual, next) => {
    $("#widget_DataSolicitacao").val($("#data_rate").val());

};

function consultPreviousRate() {
    let dataset = "DSformCotacaoassurant";
    let tableName = "tbl_certificados";
    consultDataset(dataset, null, []).success((data) => {
        data = data.content.values;
        let dataSelect = [];
        data.forEach((e) => dataSelect.push({ id: e.documentid, text: e.widget_numSolicitacao + " - " + e.numRate }));
        dataSelect.unshift({ id: "", text: "" });
        $("#rate_anterior")
            .select2({
                data: dataSelect,
                allowClear: true,
                placeholder: "Selecione...",
                theme: "bootstrap",
                language: "pt-BR",
                width: "100%",
            })
            .on("select2:select", (dataselected) => {
                docId = dataselected.currentTarget.value;
                let dados = data.filter((e) => {
                    return e.documentid === parseInt(docId);
                });
                console.log(dados);
                fillRateAnterior(dados[0]);
                let cst = [{
                    _field: "documentid",
                    _initialValue: docId,
                    _finalValue: docId,
                    _type: 1,
                }, ];
                consultDataset(dataset, tableName, cst).success((data) => {
                    data = data.content.values;
                    console.log("dataaa ---->  ");
                    console.log(data);
                    if (rowIndex.tbl_certificados == 0) {
                        addCertificatesLines();
                    }
                    if (data.length > 0) {
                        fillTableRateAnterior(data);
                    }
                    setVisibleFiles();
                });
            });
    });
}

function consultDataset(dataset, tableName, constraints) {
    var cst = constraints != null ? constraints : [];
    if (tableName != null)
        cst.push({
            _field: "tablename",
            _initialValue: tableName,
            _finalValue: tableName,
            _type: 1,
        });

    return $.ajax({
        url: "/api/public/ecm/dataset/datasets",
        type: "post",
        async: false,
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({
            name: dataset,
            constraints: cst,
        }),
        success: function(data) {},
    });
}

function fillRateAnterior(arrayData) {
    let arrFields = ["tipo_produto", "status", "produto", "widget_solicitante", "zoomCRM", "data_rate"]
    for (el in arrayData) {
        if (arrayData[el] && el.indexOf("#") < 0 && el.indexOf("numRate") < 0) {

            if (arrFields.indexOf(el) < 0) {
                $(`[name=${el}]`).val(arrayData[el]);
            }

            if (el === "status") {
                $(`[name=${el}]`).val("Rate em Preenchimento");
            }
        }
    }
}

function fillTableRateAnterior(arrayData) {
    let arrayFields = Object.keys(arrayData[0]);
    arrayData.forEach((e, i) => {
        let lineNumber = returnLineNumber(e["cert_ano"]);
        for (el in e) {
            if (e[el] && el.indexOf("#") < 0) {
                $(`[name=${el}___${lineNumber}]`).val(e[el]);
            }
        }
    });
}

function returnLineNumber(year) {
    let line = 0;

    $("[tablename=tbl_certificados] tr:not(:first-child)").each((i, e) => {
        if ($(e).find("[name^=cert_ano___]").val() == year) {
            line = i + 1;
        }
    })

    return line;
}

function addMaskTable() {
    $("[name^=cert_elegiveis___]").maskMoney({
        prefix: "",
        thousands: ".",
        precision: 0,
    });

    $("[name ^=cert_premio_medio___]").maskMoney({
        prefix: "",
        decimal: ",",
        thousands: ".",
    });
}

function addMaskFields() {
    $(".dinheiro").maskMoney({
        prefix: "R$",
        decimal: ",",
        thousands: ".",
    });

    $(".porcent").mask("##0,00%", { reverse: true });
    $("#cnpj").mask("99.999.999/9999-99");
    $("#upgrade_prazo_financ").mask("##0 Meses", { reverse: true });
}

function returnOptionsStatus() {
    return {
        inicio: "Rate em Preenchimento",
        atuarial: "Rate Enviado",
        analistas: "Rate em andamento",
        envioCotacao: "Rate encaminhado",
    };
}

function disableFields(className) {
    $(`.${className}`).attr("readonly", true);
    $(`select.${className}`).css("pointer-events", 'none');
}

function enableFields(className) {
    $(`.${className}`).removeAttr("readonly");
    $(`select.${className}`).css("pointer-events", 'auto');
}

function upload() {
    $(".addDocumento").fileupload({
        dataType: "json",
        start: () => FLUIGC.loading(window).show,
        done: (e, data) => {
            var file = data.result.files[0];
            var idBtn = e.target.id;
            saveDocuments(file, idBtn);
        },
        fail: (e, data) => {
            console.log("Falha no fileupload", data);
            TOAST("Não foi possivel publicar o arquivo.", "danger");
        },
        stop: () => FLUIGC.loading(window).hide(),
    });
}

function removeDocument(idBtn) {
    var document = $(idBtn).parents("div").first().find("input").first().val().split(" - ")[0];
    if (document != "" && document != undefined) {
        var myLoading1 = FLUIGC.loading(window);
        myLoading1.show();

        $.ajax({
            async: true,
            type: "POST",
            contentType: "application/json",
            url: "/api/public/2.0/documents/deleteDocument/" + document,
            error: function() {
                TOAST("Falha ao enviar excluir documento, contate o administrador", "danger");
                myLoading1.hide();
            },
            success: function(data) {
                $(idBtn).parents("div").first().find("input").first().val("");
                $(idBtn).siblings().addClass("fs-display-none");
                $(idBtn).prev().prev().removeClass("fs-display-none");
                $(idBtn).addClass("fs-display-none");
                TOAST("Documento Removido com Sucesso.", "success");
                myLoading1.hide();
            },
        });
    }
}

function saveDocuments(file, idBtn) {
    $.ajax({
            url: "/api/public/ecm/document/createDocument",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify({
                description: file.name,
                parentId: PARENTID,
                attachments: [{
                    fileName: file.name,
                }, ],
            }),
        })
        .done((result) => {
            let documentId = result.content.id;
            $(`#${idBtn}`)
                .parents("div")
                .first()
                .find("input")
                .first()
                .val(documentId + " - " + file.name);
            $(`#${idBtn}`).parent().siblings().removeClass("fs-display-none");
            $(`#${idBtn}`).parent().addClass("fs-display-none");
            TOAST('Arquivo "' + file.name + '" publicado com sucesso.', "success");
        })
        .fail((result) => {
            TOAST("Não foi possivel publicar o arquivo.", "danger");
            console.log("Falha", result);
        });
}

function returnLinkDocument(docId) {
    consultDataset("dsDownloadURLDocument", null, [{
        _field: "documentId",
        _initialValue: docId,
        _finalValue: docId,
        _type: 1
    }]).success(data => {
        return data.content.values[0]["URL_DOWNLOAD"]
    })
}

function openDocument(docId, docVersion) {
    var parentOBJ;

    if (window.opener) {
        parentOBJ = window.opener.parent;
    } else {
        parentOBJ = parent;
    }

    var cfg = {
        url: "/ecm_documentview/documentView.ftl",
        maximized: true,
        title: "Visualizador de Documentos",
        callBack: function() {
            parentOBJ.ECM.documentView.getDocument(docId, docVersion);
        },
        customButtons: [],
    };
    parentOBJ.ECM.documentView.panel = parentOBJ.WCMC.panel(cfg);
}

function divisionPercent(idCampo) {
    let value = formatPercentage($(`#${idCampo}`).val());
    let inputs = $(`#${idCampo}`).parent().siblings().find("input");
    let qtd = 0;
    let automatics = [];
    inputs.each((i, e) => {
        if (e.id.indexOf("total") < 0) {
            if (objPercent[e.id]["automatic"] || $(e).val() == "") {
                qtd++;
                objPercent[e.id]["automatic"] = true;
                automatics.push(e.id);
            }

            if (!objPercent[e.id]["automatic"]) {
                value += formatPercentage($(e).val());
            }
        }
    });

    let division = String((((1 - value) / qtd) * 100).toFixed(2)).replace(".", ",") + "%";

    automatics.forEach((e) => {
        $(`#${e}`).val(division);
    });
}