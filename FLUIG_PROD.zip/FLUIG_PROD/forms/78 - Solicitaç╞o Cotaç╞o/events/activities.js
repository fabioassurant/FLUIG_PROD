const ABERTURA = 0;
const INICIO = 4;
const FINAL = 23;
const ATUARIAL = 5;
const COTACAO = 10;
const PEER_REVIEW = 12;