function displayFields(form, customHTML) {
    var currentActivity = getValue("WKNumState");
    var mode = form.getFormMode();
    var numProces = getValue("WKNumProces");

    var user = getValue("WKUser");

    customHTML.append("<script>var ativAtual =" + currentActivity + ", numProces = " + numProces + "</script>");
    customHTML.append("<script>   disableFields('pm-pricing');   </script>");
    customHTML.append("<script> function formMode(){return '" + mode + "'}</script>")
    customHTML.append("<script>console.log('" + currentActivity + "')</script>");
    //Abertura
    if (currentActivity != 0) {
        form.setValue("widget_ativAtual", currentActivity);
        form.setValue("widget_numSolicitacao", numProces);
    } else {
        form.setValue("widget_solicitante", user);
        form.setVisibleById("pricing", false);
    }

    //Início
    if (currentActivity == 4 || currentActivity == 2) {
        setFieldsPMPricing(form);
        form.setVisibleById("pricing", false);
        form.setVisibleById("pm_pricing", true);
    }

    //Atuarial
    if (currentActivity == 5) {
        setFieldsPMPricing(form);
        form.setVisibleById("pm_pricing", false);
    } else {}

    //analista pricing
    if (currentActivity == 10 || currentActivity == 12 || currentActivity == 17) {
        form.setVisibleById("pm_pricing", false);
        setFieldsPMPricing(form);
    }

    if (currentActivity == 23) {
        setFieldsPMPricing(form);
    }
    //

    if (form.getValue("tipo_produto") == "theft") {
        form.setVisibleById("theft_fields", true);
        form.setVisibleById("ad_fields", false);
    }
    if (form.getValue("tipo_produto") == "theftad") {
        form.setVisibleById("theft_fields", true);
        form.setVisibleById("ad_fields", true);
    }

    if (form.getValue("tipo_produto") == "ad") {
        form.setVisibleById("theft_fields", false);
        form.setVisibleById("ad_fields", true);
    }
}

function setFieldsPMPricing(form) {
    form.setValue("analista_pricing_pm", form.getValue("analista_pricing_1"));
    form.setValue("resumo_lucro_pm_pricing", form.getValue("resumo_lucro_pricing"));
    form.setValue("resumo_da_pm_pricing", form.getValue("resumo_da_pricing"));
    form.setValue("data_pm_pricing", form.getValue("data_entrega_pricing"));
    form.setValue("analista__peer_pm_pricing", form.getValue("analista_pricing_2"));
    form.setValue("resumo_uff_pm_pricing", form.getValue("resumo_uff_pricing"));
    form.setValue("resumo_comissao_pm_pricing", form.getValue("resumo_comissao_pricing"));
    form.setValue("data_nbp_pm_pricing", form.getValue("data_npb_pricing"));
    form.setValue("roi_pm_pricing", form.getValue("resumo_roi_pricing"));
    form.setValue("up_arquivo_pm_pricing_01", form.getValue("up_incluir_pm_pricing_01"));
    form.setValue("up_arquivo_aux_pricing_02", form.getValue("up_pricing_01"));
    form.setValue("up_arquivo_pm_nbp_01", form.getValue("up_incluir_pricing_01"));
    form.setValue("up_arquivo_aux_nbp_02", form.getValue("up_pricing_02"));
    //form.setValue("pm_status", form.getValue("status"));
    form.setValue("up_arquivo_pm_email_01", form.getValue("up_arquivo_nbp_01"));
    form.setValue("up_arquivo_pm_outro_01", form.getValue("up_arquivo_outro_01"));
    //form.setValue("up_arquivo_pm_outro", form.getValue("analista_pricing_2"));
}