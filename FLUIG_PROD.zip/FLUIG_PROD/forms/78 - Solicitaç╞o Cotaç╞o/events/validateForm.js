function validateForm(form) {

    var msg = "";
    var state = getValue("WKNumState");
    //abertura ==== 0 inicio ===== 2
    if (state == 0 || state == 2) {
        if (!form.getValue("tipo_produto")) {
            msg += "\nÉ necessário informar o tipo de produto\n";
        }
    }

    //atuarial ====== 5
    if (state == 5) {
        if (form.getValue("aprovacaoSolicitacao") == "REPROVAR" && !form.getValue("aprovacaoRateRequest")) {
            msg += "\nÉ necessário informar o motivo da reprovação\n";
        } else if (form.getValue("aprovacaoSolicitacao") == "") {
            msg += "\nÉ necessário preencher a aprovação\n";
        } else if (!form.getValue("analista_pricing_1")) {
            msg += "\n É necessário informar o Analista Pricing\n";
        }
    }
    // analista pricing
    if (state == 10) {
        if (!form.getValue("analista_pricing_2")) {
            msg += "\n É necessário informar o Analista Peer Review\n";
        }
    }
    if (msg) {
        throw msg;
    }
}