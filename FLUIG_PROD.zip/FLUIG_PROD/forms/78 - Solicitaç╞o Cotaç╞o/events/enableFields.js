function enableFields(form) {
    // habilitaCampos(form);

    var currentActivity = getValue("WKNumState");

    //analista pricing - cotação 1
    //nova regra deve manter habilitado
    // if (currentActivity != 10) {
    //     form.setEnabled("select_status_pricing", false);
    // }

    if (currentActivity != 5) {
        form.setEnabled("analista_pricing_1", false);
    }

    if (currentActivity != 10 && currentActivity != 12) {
        form.setEnabled("text_observacao_pricing", false);
    }

    if (currentActivity != 0 && currentActivity != 4) {
        form.setEnabled("tipo_produto", false);
    }
    //nova regra deve manter habilitado
    if (currentActivity != 12) {
        //form.setEnabled("select_status_review_pricing", false);
    } else {
        form.setEnabled("analista_pricing_2", false);
    }
}