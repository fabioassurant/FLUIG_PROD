function displayFields(form,customHTML){
	var userId = getValue("WKUser");
	var atividade = getValue("WKNumState");
	var formMode = form.getFormMode();
	
	if(atividade == INICIO || atividade == INICIO_SOL){
		var user = getUser(userId);
		
		form.setValue("nmSolicitante", user);
		form.setValue("dataAbertura", dataHora("data"));
		form.setValue("horaAbertura", dataHora("hora"));
		
		form.setVisibleById('painelApvCompliance', false);
		form.setVisibleById('painelApvGestorAdm', false);
	}	
	
	if(atividade == AJUSTAR_SOLIC){
		if(form.getValue("apvComplianceHidden") == "reprovar"){
			form.setVisibleById('painelApvCompliance', true);
			form.setVisibleById('painelApvGestorAdm', false);
		}
		if(form.getValue("apvGestorAdmHidden") == "reprovar"){
			form.setVisibleById('painelApvCompliance', false);
			form.setVisibleById('painelApvGestorAdm', true);
		}
	}
	
	if(atividade == APV_DOCUMENTACAO){
		form.setVisibleById('painelApvGestorAdm', false);
	}
	
	customHTML.append("<script>");
    customHTML.append("		function getFormMode(){ return '" + formMode + "'};");
    customHTML.append("		function getWKNumState(){ return " + getValue("WKNumState") + "};");
    customHTML.append("		function getWKUser(){ return '" + userId + "'};");
    customHTML.append("</script>");
}

function dataHora(infoData){
	var dataAtual = new Date();
	var dia = dataAtual.getDate();
	var mes = dataAtual.getMonth() + 1;
	var ano = dataAtual.getFullYear();
	var hora = dataAtual.getHours();
	var minuto = dataAtual.getMinutes();
	
	if(dia < 10){
		dia = "0" + dia;
	}
	if(mes < 10){
		mes = "0" + mes;
	}
	if(hora < 10){
		hora = "0" + hora;
	}
	if(minuto < 10){
		minuto = "0" + minuto;
	}
	
	if(infoData == "data"){
		return dia + "/" + mes + "/" + ano;
	}else{
		return hora + ":" + minuto;
	}
}

function getUser(colleagueId){
	var user = "";
	var c1 = (DatasetFactory.createConstraint("colleaguePK.colleagueId", colleagueId, colleagueId, ConstraintType.MUST));
	var constraints = new Array(c1);
	var dataset = DatasetFactory.getDataset("colleague", null, constraints, null);

	if(dataset.rowsCount > 0) {
	user = dataset.getValue(0,"colleagueName");
	}else{
	log.error("Usuário " + colleagueId + " não encontrado!");
	throw("Usuário " + colleagueId + " não encontrado!");
	};

	return user;
}