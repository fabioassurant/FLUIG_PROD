function enableFields(form) {
    var atividade = getValue("WKNumState");
    
    if (atividade != INICIO && atividade != INICIO_SOL && atividade != AJUSTAR_SOLIC) {
    	bloqueiaCamposFornecedor(form);
    }
    if (atividade == AJUSTAR_SOLIC) {
    	bloqueiaCamposCompliance(form);
    	bloqueiaCamposAdm(form);
    }
    if (atividade == APV_CADASTRO) {
    	bloqueiaCamposCompliance(form);
    }
    if (atividade == APV_DOCUMENTACAO) {
    	bloqueiaCamposAdm(form);
    }
    
    if(atividade == TRATAR_ERRO){
    	bloqueiaCamposFornecedor(form);
    	bloqueiaCamposCompliance(form);
    	bloqueiaCamposAdm(form);
    }
}

function bloqueiaCamposFornecedor(form){
	form.setEnabled("tipoCadastro", false);
    if(form.getValue("tipoCadastroHidden") == "novo"){
		form.setEnabled("cnpjCpf", false);
	}else{			
		form.setEnabled("cnpjCpfAcsel", false);
	}
    form.setEnabled("razaoSocial", false);
    form.setEnabled("nmFantasia", false);
    form.setEnabled("email", false);
    form.setEnabled("telefone", false);
    form.setEnabled("cep", false);
    form.setEnabled("endereco", false);
    form.setEnabled("numero", false);
    form.setEnabled("bairro", false);
    /*if(form.getValue("tipoCadastroHidden") == "novo"){
		form.setEnabled("cidadeAcsel", false);
	}else{			
		form.setEnabled("cidade", false);
	}
    if(form.getValue("tipoCadastroHidden") == "novo"){
		form.setEnabled("ufAcsel", false);
	}else{			
		form.setEnabled("uf", false);
	}
   form.setEnabled("novoBanco", false);
    if(form.getValue("novoBancoHidden") == "sim"){
		form.setEnabled("banco", false);
	}else{			
		form.setEnabled("bancoAcsel", false);
	}*/
    form.setEnabled("cidadeAcsel", false);
    form.setEnabled("ufAcsel", false);
    form.setEnabled("bancoAcsel", false);
    form.setEnabled("agencia", false);
    form.setEnabled("conta", false);
    form.setEnabled("tipoAcsel", false);
    form.setEnabled("dataContrato", false);
    form.setEnabled("emiteNF", false);
}

function bloqueiaCamposCompliance(form){
	form.setEnabled("apvCompliance", false);
    form.setEnabled("obsCompliance", false);
}

function bloqueiaCamposAdm(form){
	form.setEnabled("apvGestorAdm", false);
    form.setEnabled("obsGestorAdm", false);
}