	function validateForm(form){
	var atividade = getValue("WKNumState");
	var proxAtividade = getValue("WKNextState");
	var campos = [];
	
	if(atividade == INICIO || atividade == INICIO_SOL || atividade == AJUSTAR_SOLIC){
		if(form.getValue("cnpjCpf") == "" || form.getValue("cnpjCpf") == null){
			campos.push("Campo CNPJ/CPF é obrigatório!\n")
		}
		if(form.getValue("razaoSocial") == "" || form.getValue("razaoSocial") == null){
			campos.push("Campo Razão Social/Nome é obrigatório!\n")
		}
		if(form.getValue("nmFantasia") == "" || form.getValue("nmFantasia") == null){
			campos.push("Campo Nome Fantasia é obrigatório!\n")
		}
		if(form.getValue("email") == "" || form.getValue("email") == null){
			campos.push("Campo E-mail é obrigatório!\n")
		}
		if(form.getValue("telefone") == "" || form.getValue("telefone") == null){
			campos.push("Campo Telefone é obrigatório!\n")
		}
		if(form.getValue("cep") == "" || form.getValue("cep") == null){
			campos.push("Campo CEP é obrigatório!\n")
		}
		if(form.getValue("endereco") == "" || form.getValue("endereco") == null){
			campos.push("Campo Endereço é obrigatório!\n")
		}
		if(form.getValue("numero") == "" || form.getValue("numero") == null){
			campos.push("Campo Número é obrigatório!\n")
		}
		if(form.getValue("bairro") == "" || form.getValue("bairro") == null){
			campos.push("Campo Bairro é obrigatório!\n")
		}
		if(form.getValue("cidadeAcsel") == "" || form.getValue("cidadeAcsel") == null){
			campos.push("Campo Cidade é obrigatório!\n")
		}
		if(form.getValue("ufAcsel") == "" || form.getValue("ufAcsel") == null){
			campos.push("Campo UF é obrigatório!\n")
		}	
		/*if(form.getValue("novoBancoHidden") == "" || form.getValue("novoBancoHidden") == null){
			campos.push("Campo Novo Banco é obrigatório!\n")
		}
		if(form.getValue("novoBancoHidden") == "sim"){
			if(form.getValue("banco") == "" || form.getValue("banco") == null){
				campos.push("Campo Banco é obrigatório!\n")
			}
		}else{
			if(form.getValue("bancoAcsel") == "" || form.getValue("bancoAcsel") == null){
				campos.push("Campo Banco é obrigatório!\n")
			}
		}		
		if(form.getValue("bancoAcsel") == "" || form.getValue("bancoAcsel") == null){
			campos.push("Campo Banco é obrigatório!\n")
		}
		if(form.getValue("agencia") == "" || form.getValue("agencia") == null){
			campos.push("Campo Agência é obrigatório!\n")
		}
		if(form.getValue("conta") == "" || form.getValue("conta") == null){
			campos.push("Campo Conta é obrigatório!\n")
		}
		if(form.getValue("tipoAcsel") == "" || form.getValue("tipoAcsel") == null){
			campos.push("Campo Tipo é obrigatório!\n")
		}*/
		if(form.getValue("dataContrato") == "" || form.getValue("dataContrato") == null){
			campos.push("Campo Data é obrigatório!\n")
		}
		if(form.getValue("emiteNFHidden") == "" || form.getValue("emiteNFHidden") == null){
			campos.push("Campo Emite NF é obrigatório!\n")
		}
		
		if(campos != ""){
			throw "\n" + campos;
		}
	}
	
	if(atividade == APV_DOCUMENTACAO){	
		if(form.getValue("apvCompliance") == "" || form.getValue("apvCompliance") == null){
			campos.push("É obrigatório informar a aprovação!\n");
		}
		if((form.getValue("obsCompliance") == "" || form.getValue("obsCompliance") == null) &&
		   (form.getValue("apvComplianceHidden") == "reprovar" || form.getValue("apvComplianceHidden") == "cancelar")){
			campos.push("Campo Observação/Justificativa é obrigatório!\n");
		}
		
		if(campos != ""){
			throw "\n" + campos;
		}
	}
	
	if(atividade == APV_CADASTRO){	
		if(form.getValue("apvGestorAdm") == "" || form.getValue("apvGestorAdm") == null){
			campos.push("É obrigatório informar a aprovação!\n");
		}
		if((form.getValue("obsGestorAdm") == "" || form.getValue("obsGestorAdm") == null) &&
		   (form.getValue("apvGestorAdmHidden") == "reprovar" || form.getValue("apvGestorAdmHidden") == "cancelar")){
			throw "\nCampo Observação/Justificativa é obrigatório!";
		}
		
		if(campos != ""){
			throw "\n" + campos;
		}
	}
}