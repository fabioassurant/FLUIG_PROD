$(document).ready(function(){
	var atividade = getWKNumState();
	
	if(atividade == INICIO || atividade == INICIO_SOL){
		$("#tipoCadastroHidden").val("novo");
		//$("#novoBancoHidden").val("sim");
		$("#emiteNFHidden").val("S");
		$("#divCidadeAcsel").hide();		
		//reloadZoomFilterValues("cidadeAcsel", "estado," + codEstado);
		//window["cidadeAcsel"].disable(true);
		//setZoomData("", "");
	}
	if(atividade == AJUSTAR_SOLIC){
		var apvCompl = $("#apvComplianceHidden").val();
		var apvAdm = $("#apvGestorAdmHidden").val();
		
		/*if(apvCompl == "reprovar"){
			$("#painelApvCompliance").show();
		}else if(apvAdm == "reprovar"){
			$("#painelApvGestoAdm").show();
		}	*/
	}
	if(atividade == INICIO || atividade == INICIO_SOL || atividade == AJUSTAR_SOLIC){
		var calendarioData = FLUIGC.calendar("#dataContrato");
		calendarioData.setMinDate(new Date());
		
		$(".caixaAlta").on("input", function(){
			$(this).val($(this).val().toUpperCase());
		});
		
		/*
		 * Função para controlar a máscara de CNPJ ou CPF
		 * Wesley Falcon - Moove - 13/03/2023
		 */
		var options = {
		    onKeyPress: function (cpf, ev, el, op){
		        var masks = ['000.000.000-000', '00.000.000/0000-00'];
		        $('.cpfOuCnpj').mask((cpf.length > 14) ? masks[1] : masks[0], op);
		    }
		}
		$('.cpfOuCnpj').length > 11 ? $('.cpfOuCnpj').mask('00.000.000/0000-00', options) : $('.cpfOuCnpj').mask('000.000.000-00#', options);
		
		/*
		 * Função para controlar a máscara de Conta Corrente
		 * Wesley Falcon - Moove - 19/04/2023
		 */
		$("#conta").on('blur', function(){
			var conta = $("#conta").val();
			var nova = conta.slice(0, -1) + '-' + conta.slice(-1);
			$("#conta").val(nova);
		});
		
		$('input[name^="tipoCadastro"]').on('change', function(){
			var tipo = $('input[name=tipoCadastro]:checked').val();
			if(tipo == "novo"){
				$("#divCidadeAcsel").hide();
				$("#tipoCadastroHidden").val("novo");
			}else{
				$("#divCidadeAcsel").show();
				$("#tipoCadastroHidden").val("alteracao");
				reloadZoomFilterValues("cidadeAcsel", "");
			}
		});
		
		$("#cnpjCpf").on('blur', function(){
			var cnpjCpf = $("#cnpjCpf").val();
			var tipo = $('input[name=tipoCadastro]:checked').val();	
			//var banco = $('input[name=novoBanco]:checked').val();
			       
			if (cnpjCpf.length > 14){
				$("#tipoFornecedorHidden").val("CNPJ");
				$("#documentoHidden").val(cnpjCpf.substr(0, 15).replace(".", "").replace(".", "").replace("/", ""));
				$("#fimDocumentoHidden").val(cnpjCpf.substr(16));
		 	} else {
		 		$("#tipoFornecedorHidden").val("CPF");
		 		$("#documentoHidden").val(cnpjCpf.substr(0, 11).replace(".", "").replace(".", ""));
				$("#fimDocumentoHidden").val(cnpjCpf.substr(12));
		 	}
			
			if(tipo == "alteracao"){	
				var constraint1 = DatasetFactory.createConstraint('cNumId', $("#documentoHidden").val(), $("#documentoHidden").val(), ConstraintType.MUST);
	            var constraint2 = DatasetFactory.createConstraint('cDvId', $("#fimDocumentoHidden").val(), $("#fimDocumentoHidden").val(), ConstraintType.MUST);
	            var constraint3 = DatasetFactory.createConstraint('cTipoId', $("#tipoFornecedorHidden").val(), $("#tipoFornecedorHidden").val(), ConstraintType.MUST);  
	            var dsFornecedor = DatasetFactory.getDataset('ds_consulta_fornecedor', null, new Array(constraint1, constraint2, constraint3), null).values;
	            
	            if(dsFornecedor[0].RETORNO == "OK"){
		            for (var i = 0; i < dsFornecedor.length; i++) {
		            	$("#razaoSocial").val(dsFornecedor[0].NOME);
		            	$("#nmFantasia").val(dsFornecedor[0].NOME_FANTASIA);
		            	$("#email").val(dsFornecedor[0].EMAIL);
		            	var fim = "";
		            	var telefone = dsFornecedor[0].TELEFONE;
		            	var ddd = "(" + telefone.split(" ")[0] + ")";
		            	telefone = telefone.split(" ")[1];
		            	if(telefone.length > 8){
		            		fim = telefone.slice(-4);
		            		telefone = telefone.substr(0, 5) + "-" + fim;
		            	}else{
		            		fim = telefone.slice(-4);
		            		telefone = telefone.substr(0, 4) + "-" + fim;
		            	}		            	
		            	$("#telefone").val(ddd + " " + telefone);
		            	var cep = dsFornecedor[0].CEP;
	            		var fim = cep.slice(-3);
	            		cep = cep.substr(0, 5) + "-" + fim;
		            	$("#cep").val(cep);
		            	$("#endereco").val(dsFornecedor[0].ENDERECO);
		            	$("#numero").val(dsFornecedor[0].NUMERO);
		            	$("#bairro").val(dsFornecedor[0].BAIRRO);
		            	if(dsFornecedor[0].CIDADE != ""){
			            	setZoomData("cidadeAcsel", dsFornecedor[0].CIDADE);
			            	$("#cidadeHidden").val(dsFornecedor[0].CIDADE_COD);
		            	}
		            	if(dsFornecedor[0].ESTADO_COD != ""){
			            	setZoomData("ufAcsel", dsFornecedor[0].ESTADO_COD);
			            	$("#ufHidden").val(dsFornecedor[0].ESTADO_COD);
		            	}
		            	if(dsFornecedor[0].BANCO != ""){
			            	setZoomData("bancoAcsel", dsFornecedor[0].BANCO);
			            	$("#bancoHidden").val(dsFornecedor[0].BANCO);
		            	}
		            	$("#agencia").val(dsFornecedor[0].AGENCIA);
		            	var conta = dsFornecedor[0].CONTA;
		            	conta = conta.slice(0, -1) + '-' + conta.slice(-1);
		            	$("#conta").val(conta);
		            	if(dsFornecedor[0].TIPO_PAGT != ""){
		            		setZoomData("tipoAcsel", dsFornecedor[0].TIPO_CONTA_DESC);
		            		$("#bancoHidden").val(dsFornecedor[0].TIPO_CONTA);
		            	}
		            	if(dsFornecedor[0].EMITE_NOTA == "S"){
		            		$("#emiteNFSim").prop("checked", true);
		            		$("#emiteNFHidden").val(dsFornecedor[0].EMITE_NOTA);
		            	}else{
		            		$("#emiteNFNao").prop("checked", true);
		            		$("#emiteNFHidden").val(dsFornecedor[0].EMITE_NOTA);
		            	}		
		            	if(dsFornecedor[0].DATA_NF != ""){
			            	var data = dsFornecedor[0].DATA_NF;
			            	data = data.substr(6) + "/" + data.substr(4, 2) + "/" + data.substr(0, 4);
			            	$("#dataContrato").val(data);
		            	}
		            	$("#retornoIntegracao").val(dsFornecedor[0].RETORNO);
					}
	            }else{
	            	FLUIGC.toast({
			 			message: "Fornecedor não encontrado.",
						type: "danger"
			 		});
	            	$("#retornoIntegracao").val(dsFornecedor[0].RETORNO);
	            }
			} else{
				var constraint1 = DatasetFactory.createConstraint('cNumId', $("#documentoHidden").val(), $("#documentoHidden").val(), ConstraintType.MUST);
	            var constraint2 = DatasetFactory.createConstraint('cDvId', $("#fimDocumentoHidden").val(), $("#fimDocumentoHidden").val(), ConstraintType.MUST);
	            var constraint3 = DatasetFactory.createConstraint('cTipoId', $("#tipoFornecedorHidden").val(), $("#tipoFornecedorHidden").val(), ConstraintType.MUST);  
	            var dsFornecedor = DatasetFactory.getDataset('ds_consulta_fornecedor', null, new Array(constraint1, constraint2, constraint3), null).values;
	            
	            if(dsFornecedor[0].RETORNO == "OK"){
	            	FLUIGC.toast({
			 			message: "Fornecedor já cadastrado.",
						type: "danger"
			 		});
	            }
			}		
		});
		
		/*
		 * Função para validar o e-mail
		 * Wesley Falcon - Moove - 13/03/2023
		 */
		$("#email").on('blur', function(){
			var email = $("#email").val();
			if (/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(email)){
			   console.log("E-mail ok")
		 	} else {
		 		FLUIGC.toast({
		 			message: "O e-mail " + email + ", está incorreto",
					type: "danger"
		 		});
		 		$("#email").val("");
		 	}
		});
		
		/*$('input[name^="novoBanco"]').on('change', function(){
			var novo = $('input[name=novoBanco]:checked').val();
			
			if(novo == "sim"){
				$("#divBancoAcsel").hide();
				$("#divInputBanco").show();
				$("#novoBancoHidden").val("sim");
				window["bancoAcsel"].clear();
			}else{
				$("#divBancoAcsel").show();
				$("#divInputBanco").hide();
				$("#novoBancoHidden").val("nao");
			}
		});*/
		
		$('input[name^="emiteNF"]').on('change', function(){
			var emite = $('input[name=emiteNF]:checked').val();
			
			if(emite == "sim"){
				$("#emiteNFHidden").val("S");
			}else{
				$("#emiteNFHidden").val("N");
			}
		});
		
		$('#cidadeAcsel').on('click', function(){
			console.log("TESTE")
		});		
	}
	if(atividade == APV_DOCUMENTACAO){
		//$("#painelApvCompliance").show();
		
		$('input[name^="apvCompliance"]').on('change', function(){
			var apv = $('input[name=apvCompliance]:checked').val();
			$("#apvComplianceHidden").val(apv);
		});
	}
	if(atividade == APV_CADASTRO){
		//$("#painelApvGestorAdm").show();
		
		$('input[name^="apvGestorAdm"]').on('change', function(){
			var apv = $('input[name=apvGestorAdm]:checked').val();
			$("#apvGestorAdmHidden").val(apv);
		});
	}
});


/*
 * Funções para controlar a máscara de telefone
 * Wesley Falcon - Moove - 13/03/2023
 */
function mask(o, f) {
	setTimeout(function() {
		var v = mphone(o.value);
		
	    if (v != o.value) {
	      o.value = v;
	    }
	}, 1);
}
function mphone(v) {
	var r = v.replace(/\D/g, "");
	r = r.replace(/^0/, "");
	
	if (r.length > 10) {
		r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
	} else if (r.length > 5) {
		r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
	} else if (r.length > 2) {
		r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
	} else {
		r = r.replace(/^(\d*)/, "($1");
	}
	return r;
}

function setSelectedZoomItem(selectedItem){
	if(selectedItem.hasOwnProperty("inputId")){
		if(selectedItem.inputId.indexOf("ufAcsel") != -1){
			var codEstado = selectedItem.CODIGO;
			$("#divCidadeAcsel").show();
			reloadZoomFilterValues("cidadeAcsel", "estado," + codEstado);
			$("#ufHidden").val(codEstado);
			setZoomData("ufAcsel", codEstado);
		}
		if(selectedItem.inputId.indexOf("cidadeAcsel") != -1){
			var codEstado = $("#cidadeHidden").val(selectedItem.CODIGO);
		}
		if(selectedItem.inputId.indexOf("bancoAcsel") != -1){
			$("#bancoHidden").val(selectedItem.CODIGO);
		}
		if(selectedItem.inputId.indexOf("tipoAcsel") != -1){
			$("#tipoHidden").val(selectedItem.CODIGO);
		}
	}
}

function removedZoomItem(removedItem){
	if(removedItem.inputId == "ufAcsel"){
		window["ufAcsel"].clear();
		window["cidadeAcsel"].clear();
		reloadZoomFilterValues("cidadeAcsel", "");
		$("#divCidadeAcsel").hide();
		$("#ufHidden").val("");
	}
	if(removedItem.inputId == "cidadeAcsel"){
		window["cidadeAcsel"].clear();
		reloadZoomFilterValues("cidadeAcsel", "estado," + $("#ufHidden").val());
		$("#cidadeHidden").val("");
	}
	if(removedItem.inputId == "bancoAcsel"){
		window["bancoAcsel"].clear();
		$("#bancoHidden").val("");
	}
	if(removedItem.inputId == "tipoAcsel"){
		window["tipoAcsel"].clear();
		$("#tipoHidden").val("");
	}
}

function setZoomData(instance, value) {
    try {
        window[instance].setValue(value);
    } catch (e) {
        console.log("erro ===> " + e.message);
    }
}