function displayFields(form, customHTML) {
    var user = getValue("WKUser");
    var state = getValue("WKNumState");
    var numProcess = getValue("WKNumProces")
    var mode = form.getFormMode();


    form.setValue("WKNumState", state);
    form.setValue("WKNumProces", numProcess);
    customHTML.append('<script> function getCurrentUser(){return "' + user + '"}; function getCurrentState(){return Number("' + state + '")}; function getCurrentMode(){return "' + mode + '"}; </script>');

    if (mode != "VIEW") {
        if (state == ABRIRPROCESSO || state == INICIO) {
            form.setEnabled("respAssinatura", false);
            hideAll(form);
            if (form.getValue('flagAprovador') == "avaliacaoER" || form.getValue('flagAprovador') == "compliance" || form.getValue('flagAprovador') == "avaliacao") {
                form.setVisibleById('div_pai_Aprovacao', true);
                customHTML.append("<script>  $('#div_pai_Aprovacao').css('pointer-events','none')</script>")
                aprov = form.getValue("aprovacao1") == "" ? form.setVisibleById('div_aprovacao1', false) : form.setVisibleById('div_aprovacao1', true);
                aprov = form.getValue("aprovacao2") == "" ? form.setVisibleById('div_aprovacao2', false) : form.setVisibleById('div_aprovacao2', true);
                aprov = form.getValue("aprovacao3") == "" ? form.setVisibleById('div_aprovacao3', false) : form.setVisibleById('div_aprovacao3', true);
                aprov = form.getValue("aprovacao4") == "" ? form.setVisibleById('div_aprovacao4', false) : form.setVisibleById('div_aprovacao4', true);
                aprov = form.getValue("aprovacao5") == "" ? form.setVisibleById('div_aprovacao5', false) : form.setVisibleById('div_aprovacao5', true);
            } else {
                form.setVisibleById('div_pai_Aprovacao', false);
            }
            customHTML.append('<script> changeView();jumpProcess() </script>');

        } else if (state == AVALIACAO || state == COMPLIANCE) {
            var value = form.getValue("NFPSRadioPrazo")
            //blockAllFields(form, customHTML);
            blockCabecalho(form);
            blockNovoContratoFornPrest(form, customHTML, AVALIACAO);
            blockNovoTipoNegocio(form, customHTML, AVALIACAO);
            blockAditivoFornPrest(form, customHTML, AVALIACAO);
            blockAditivoNegocio(form, customHTML, AVALIACAO)
            blockDistrato(form, customHTML, AVALIACAO);
            blockPropostaComercial(form, customHTML, AVALIACAO);
            blockNotificacao(form, customHTML, AVALIACAO);
            blockCessao(form, customHTML, AVALIACAO);
            setFiledAprovacao(form, state, customHTML);

            hideButtonAssign(customHTML);
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView(); </script>');

            form.setVisibleById('div_pai_Aprovacao', true);
            if (state == COMPLIANCE) {
                blockNovoContratoFornPrest(form, customHTML, COMPLIANCE);
                blockAditivoFornPrest(form, customHTML, COMPLIANCE);
                blockAditivoNegocio(form, customHTML, COMPLIANCE)
                blockPropostaComercial(form, customHTML, COMPLIANCE);
                blockNovoTipoNegocio(form, customHTML, COMPLIANCE);
                blockNotificacao(form, customHTML, COMPLIANCE);
                blockCessao(form, customHTML, COMPLIANCE);
                blockDistrato(form, customHTML, COMPLIANCE);

                // customHTML.append('<script> $(".addFileNoFatherAndSon").removeAttr("disabled"); $(".addFileNoFatherAndSon").children("input").removeAttr("disabled"); </script>')
            } else {
                // form.setEnabled("NFPSvalorTotal", true);
                // form.setEnabled("NFPSvalorTotalAnual", true);
                // form.setEnabled("NFPSvalorTotalMensal", true);
            }
        } else if (state == AVALICAOELABREV) {
            var value = form.getValue("NFPSRadioPrazo")
            var assinatura = form.getValue("escolhaAssinatura")
            // blockAllFields(form);
            blockCabecalho(form);
            // blockNovoContratoFornPrest(form, customHTML, AVALICAOELABREV);
            // blockNovoTipoNegocio(form, customHTML,AVALICAOELABREV);
            // blockAditivoFornPrest(form, customHTML, AVALICAOELABREV);
            // blockAditivoNegocio(form, customHTML, AVALICAOELABREV)
            // blockDistrato(form, customHTML, AVALICAOELABREV);
            // blockPropostaComercial(form, customHTML, AVALICAOELABREV);
            // blockNotificacao(form, customHTML, AVALICAOELABREV);
            // blockCessao(form, customHTML, AVALICAOELABREV);
            setFiledAprovacao(form, state, customHTML);
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView();</script>');
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>');
            form.setVisibleById('div_pai_Aprovacao', true);
            form.setEnabled("respAssinatura", true);

            if (assinatura == "EXTERNO") {
                customHTML.append('<script> $("[name=escolhaAssinatura]:checked").parent().css("pointer-events","none") </script>')
            } else if (assinatura == "INTERNO") {
                customHTML.append('<script> $("[name=escolhaAssinatura]:checked").parent().css("pointer-events","none") </script>')
            }

        } else if (state == TROCADEMINUTA) {
            var value = form.getValue("NFPSRadioPrazo")
            // blockAllFields(form);
            blockCabecalho(form);
            blockNovoContratoFornPrest(form, customHTML, TROCADEMINUTA);
            // blockNovoTipoNegocio(form, customHTML);
            // blockAditivoFornPrest(form, customHTML);
            blockDistrato(form, customHTML, TROCADEMINUTA);
            blockPropostaComercial(form, customHTML, TROCADEMINUTA);
            blockNotificacao(form, customHTML, TROCADEMINUTA);
            blockCessao(form, customHTML, TROCADEMINUTA);
            setFiledAprovacao(form, state, customHTML);
            hideButtonAssign(customHTML)
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView();  </script>')
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>')
            form.setVisibleById('div_pai_Aprovacao', false);
        } else if (state == PROVASSINATURAPARCEIRO) {

            var value = form.getValue("NFPSRadioPrazo")
            // blockAllFields(form);
            blockCabecalho(form);
            blockNovoContratoFornPrest(form, customHTML, PROVASSINATURAPARCEIRO);
            blockNovoTipoNegocio(form, customHTML, PROVASSINATURAPARCEIRO);
            blockAditivoFornPrest(form, customHTML, PROVASSINATURAPARCEIRO);
            blockAditivoNegocio(form, customHTML, PROVASSINATURAPARCEIRO)
            blockDistrato(form, customHTML, PROVASSINATURAPARCEIRO);
            blockPropostaComercial(form, customHTML, PROVASSINATURAPARCEIRO);
            blockNotificacao(form, customHTML, PROVASSINATURAPARCEIRO);
            blockCessao(form, customHTML, PROVASSINATURAPARCEIRO);
            setFiledAprovacao(form, state, customHTML);
            hideButtonAssign(customHTML)
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView(); </script>');
            form.setValue('assinaturaExterna', '1');
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>');
        } else if (state == ANALISE) {
            var value = form.getValue("NFPSRadioPrazo")
            // blockAllFields(form);
            blockCabecalho(form);
            // blockNovoContratoFornPrest(form, customHTML, ANALISE);
            // blockNovoTipoNegocio(form, customHTML, ANALISE);
            // blockAditivoFornPrest(form, customHTML, ANALISE);
            // blockAditivoNegocio(form, customHTML, ANALISE)
            // blockDistrato(form, customHTML, ANALISE);
            // blockPropostaComercial(form, customHTML, ANALISE);
            // blockNotificacao(form, customHTML, ANALISE);
            // blockCessao(form, customHTML, ANALISE);
            setFiledAprovacao(form, state, customHTML);
            hideButtonAssign(customHTML)
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView();  </script>')
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>')
            form.setVisibleById('div_pai_Aprovacao', true);
        } else if (state == PROVASSINATURAINTER) {
            var value = form.getValue("NFPSRadioPrazo")
            // blockAllFields(form);
            blockCabecalho(form);
            blockNovoContratoFornPrest(form, customHTML, PROVASSINATURAINTER);
            blockNovoTipoNegocio(form, customHTML, PROVASSINATURAINTER);
            blockAditivoFornPrest(form, customHTML, PROVASSINATURAINTER);
            blockAditivoNegocio(form, customHTML, PROVASSINATURAINTER)
            blockDistrato(form, customHTML, PROVASSINATURAINTER);
            blockPropostaComercial(form, customHTML);
            blockNotificacao(form, customHTML, PROVASSINATURAINTER);
            blockCessao(form, customHTML, PROVASSINATURAINTER);
            setFiledAprovacao(form, state, customHTML);
            hideButtonAssign(customHTML)
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView();  </script>')
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>')
            form.setVisibleById('div_pai_Aprovacao', false);
            form.setValue('assinaturaInterna', '1');

        } else if (state == GRAVACONTRATO) {
            // var value = form.getValue("NFPSRadioPrazo")
            // blockAllFields(form);
            // blockCabecalho(form);
            // blockNovoContratoFornPrest(form, customHTML);
            // blockNovoTipoNegocio(form, customHTML, GRAVACONTRATO);
            // blockAditivoFornPrest(form, customHTML);
            // blockDistrato(form, customHTML);
            // blockPropostaComercial(form, customHTML);
            // blockNotificacao(form, customHTML);
            // blockCessao(form, customHTML);
            // setFiledAprovacao(form, state, customHTML);
            // hideButtonAssign(customHTML)
            // blockOutrasSolic(form, customHTML);
            // customHTML.append('<script> changeView();  </script>')
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>')
            // form.setVisibleById('div_pai_Aprovacao', false);

        } else if (state == FALHACRIACAO) {
            var value = form.getValue("NFPSRadioPrazo")
            // blockAllFields(form);
            blockCabecalho(form);
            blockNovoContratoFornPrest(form, customHTML, FALHACRIACAO);
            blockNovoTipoNegocio(form, customHTML, FALHACRIACAO);
            blockAditivoFornPrest(form, customHTML, FALHACRIACAO);
            blockDistrato(form, customHTML, FALHACRIACAO);
            blockPropostaComercial(form, customHTML, FALHACRIACAO);
            blockNotificacao(form, customHTML);
            blockCessao(form, customHTML);
            setFiledAprovacao(form, state, customHTML);
            hideButtonAssign(customHTML)
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView(); </script>');
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>');
            form.setVisibleById('div_pai_Aprovacao', false);

        } else if (state == REALIZACADASTROFORN || state == CADASTRO_ACSEL) {
            var value = form.getValue("NFPSRadioPrazo")
            // blockAllFields(form);
            blockCabecalho(form);
            blockNovoContratoFornPrest(form, customHTML);
            blockNovoTipoNegocio(form, customHTML, REALIZACADASTROFORN);
            blockAditivoFornPrest(form, customHTML);
            blockDistrato(form, customHTML);
            blockPropostaComercial(form, customHTML);
            blockNotificacao(form, customHTML);
            blockCessao(form, customHTML);
            setFiledAprovacao(form, state, customHTML);
            hideButtonAssign(customHTML)
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView();</script>');
            // customHTML.append('<script> changeView(); $(".contestar").hide(); </script>');
            form.setVisibleById('div_pai_Aprovacao', false);

        } else {
            blockCabecalho(form);
            blockNovoContratoFornPrest(form, customHTML);
            blockNovoTipoNegocio(form, customHTML);
            blockAditivoFornPrest(form, customHTML);
            blockDistrato(form, customHTML);
            blockPropostaComercial(form, customHTML);
            blockNotificacao(form, customHTML);
            blockCessao(form, customHTML);
            blockAprovacao(form, customHTML);
            hideButtonAssign(customHTML)
            blockOutrasSolic(form, customHTML);
            customHTML.append('<script> changeView(); </script>');
            form.setVisibleById('div_pai_Aprovacao', false);

        }

        if (state != ABRIRPROCESSO && state != INICIO) {
            var NFPSvaluePrazo = form.getValue("NFPSRadioPrazo")
            var NTNvaluePrazo = form.getValue("NTNRadioPrazo")


            // if(NFPSvaluePrazo != "") {
            // customHTML.append('<script> controlPrazos("' + NFPSvaluePrazo + '", "disabled"); </script>');
            // }

            // if(NTNvaluePrazo != "") {
            //     customHTML.append('<script> controlPrazos("' + NTNvaluePrazo + '", "disabled"); </script>');
            // }

            // customHTML.append('<script> controlPrazos("' + value + '", "disabled"); </script>');
        }
    } else {

        customHTML.append('<script> changeView(); </script>');

        blockButtons(customHTML);

        blockAprovacao(form, customHTML);

    }

    var index = form.getChildrenIndexes("historico");
    if (index > 0) {
        form.setVisibleById('div_historico', true);
    } else {
        form.setVisibleById('div_historico', false);
    }

    // if (state != COMPLIANCE) {
    //     form.setEnabled('riscoContrato', false)
    // } else {
    //     form.setEnabled('riscoContrato', true)
    // }

    customHTML.append("	<script>function getWKNumState(){ return " + state + "};</script>");


}

function hideButtonAssign(customHTML) {
    customHTML.append('<script> $("#escolhaAssinaturaExterno").parent().hide(); $("#escolhaAssinaturaInterno").parent().hide() </script>')
}

function blockButtonsView(customHTML) {
    customHTML.append('<script> $(".addFileNoFatherAndSon").attr("disabled",true); $(".addFileNoFatherAndSon").children("input").attr("disabled",true); $(".deleteFile").attr("disabled",true); $(".delLine").hide(); $(".addButton").attr("disabled",true); </script>')
}

function blockButtons(customHTML) {
     customHTML.append('<script> $(".delLine").hide();</script>')
    // customHTML.append('<script> $(".addFileNoFatherAndSon").attr("disabled",true); $(".addFileNoFatherAndSon").children("input").attr("disabled",true); $(".deleteFile").attr("disabled",true); $(".delLine").hide();</script>')
}

function hideAll(form) {
    form.setVisibleById('div_pai_Novo_Contrato_Fornecedor_Prestador_Servico', false);
    form.setVisibleById('div_pai_Novo_Contrato_Tipo_Negocio', false);
    form.setVisibleById('div_pai_Aditivo_Fornecedor_Prestador_Servico', false);
    form.setVisibleById('div_pai_Aditivo_Distrato', false);
    form.setVisibleById('div_pai_Proposta_Comercial', false);
    form.setVisibleById('div_pai_Notificacao', false);
    form.setVisibleById('div_pai_Cessao', false);
    form.setVisibleById('div_pai_outrasSolic', false);
    form.setVisibleById('divAssinaturaExterno', false);
    form.setVisibleById('divAssinaturaInterno', false);
}

function blockCabecalho(form) {
    form.setEnabled('tipoContrato', false);
    form.setEnabled('servicoJuridico', false);
    form.setEnabled('respAssinatura', false);
}

function blockNovoContratoFornPrest(form, customHTML, state) {
    form.setEnabled('NFPStituloContrato', false);
    form.setEnabled('NFPScontratante', false);
    form.setEnabled('NFPSobjetoContrato', false);
    form.setEnabled('NFPScontratoIndeterminado', false);
    form.setEnabled('NFPSflagContratoVigencia', false);
    form.setEnabled('NFPSvigenciaFalta', false);
    form.setEnabled('NFPSdataAviso', false);
    form.setEnabled('NFPSinicioVigencia', false);
    form.setEnabled('NFPSfimVigencia', false);
    form.setEnabled('NFPSAvisoPrevio', false);
    form.setEnabled('NFPSRenovacaoAutomatica', false);
    form.setEnabled('NFPSobservacoes', false);
    form.setEnabled('NFPSoutrosDetalhes', false);
    form.setEnabled('NFPSvalorTotal1', false);
    form.setEnabled('NFPSvalorTotalMensal1', false);
    form.setEnabled('NFPSvalorTotalAnual1', false);
    form.setEnabled('NFPSValorContratoObs', false);




    customHTML.append("<script> $('[name=NFPSRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")

    blockButtons(customHTML)

    var tabelaContratado = form.getChildrenIndexes("NFPStabelaContratado");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaContratado) {
            form.setEnabled('NFPSrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPScpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPStelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPScep' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPScidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSpais' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSbanco' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSagencia' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSconta' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSnacionalEstrangeira' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPStipo' + '___' + tabelaContratado[position], false);

        }
    } else {
        for (position in tabelaContratado) {
            form.setEnabled('NFPSrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPScpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPStelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPScep' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPScidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('NFPSpais' + '___' + tabelaContratado[position], false);
        }
    }

    var tabelaUploadFiles = form.getChildrenIndexes("NFPStabelaUploadFiles");
    for (position in tabelaUploadFiles) {
        form.setEnabled('NFPSbtnAdicionar___' + tabelaUploadFiles[position], false);
        form.setEnabled('NFPSdeletar___' + tabelaUploadFiles[position], false);
        if (form.getValue('NFPSidFile___' + tabelaUploadFiles[position])) {
            form.setVisibleById('NFPSbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        }
    }

}

function blockNovoTipoNegocio(form, customHTML, state) {
    form.setEnabled('NTNtituloContrato', false);
    form.setEnabled('NTNempPartNeg', false);
    form.setEnabled('NTNnomeFantGrup', false);
    form.setEnabled('NTNobjetoContrato', false);
    form.setEnabled('NTNprodComeInter', false);
    form.setEnabled('NTNcontratoIndeterm', false);
    form.setEnabled('NTNcontVigenDetRenovAuto', false);
    form.setEnabled('NTNvigenciaFalta', false);
    form.setEnabled('NTNobservacoes', false);
    form.setEnabled('NTNcontNegAdit', false);
    form.setEnabled('NTNquaisUpfrontBonus', false);
    form.setEnabled('NTNquaisBonusPerformance', false);
    form.setEnabled('NTNquaisProfitSharing', false);
    form.setEnabled('NTNquaisReembCartaCredito', false);
    form.setEnabled('NTNquaisInvestMarketMinGarant', false);
    form.setEnabled('NTNquaisFindesFee', false);
    form.setEnabled('NTNquaisIncluAltDespAgeCamp', false);
    form.setEnabled('NTNquaisIncluAltDespPrestServ', false);
    form.setEnabled('NTNquaisIncluAltDespVar', false);
    form.setEnabled('NTNgarantiaContrato', false);
    form.setEnabled('NTNtipoGarantia', false);
    form.setEnabled('NTNinicioVidenciaGarantia', false);
    form.setEnabled('NTNfimVigenciaGarantia', false);
    form.setEnabled('NTNdataAvisoVenc', false);
    form.setEnabled('NTNoutrosDetalhes', false);
    form.setEnabled("NTNvalorMulta", false);
    form.setEnabled("NTNDescGarantia", false);
    form.setEnabled("NTNBonusDetalhamento", false);
    form.setEnabled("NTNBonusPerformDet", false);
    form.setEnabled("NTNProfitSharingDetalhamento", false);
    form.setEnabled("NTNReembCartaCreditoDet", false);
    form.setEnabled("NTNIncluAltDespPrestServDet", false);
    form.setEnabled("NTNIncluAltDespVarDet", false);
    form.setEnabled("NTNinicioVigencia", false);
    form.setEnabled("NTNfimVigencia", false);
    form.setEnabled("NTNdataAviso", false);
    form.setEnabled("NTNAvisoPrevio", false);
    form.setEnabled("NTNRenovacaoAutomatica", false);






    customHTML.append("<script> $('#NTNflagMulta').parent().css('pointer-events', 'none') </script>")
    customHTML.append("<script> $('[name=NTNRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")
    blockButtons(customHTML)

    var tabelaClienteRep = form.getChildrenIndexes("NTNtabelaClienteRep");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('NTNrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNtelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNpaisA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNbancoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNagenciaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcontaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNnacionalEstrangeiraA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNtipoA' + '___' + tabelaClienteRep[position], false);

        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('NTNrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNtelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNpaisA' + '___' + tabelaClienteRep[position], false);
        }
    }


    var tabelaClienteRep = form.getChildrenIndexes("NTNtabelaCorretIntermed");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('NTNrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNtelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNpaisB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNbancoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNagenciaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcontaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNnacionalEstrangeiraB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNtipoB' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('NTNrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNtelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNpaisB' + '___' + tabelaClienteRep[position], false);
        }
    }

    var tabelaParSegu = form.getChildrenIndexes("NTNtabelaParSegu");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaParSegu) {
            form.setEnabled('NTNrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNcpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNtelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNcepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNcidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNpaisC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNbancoC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNagenciaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNcontaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNnacionalEstrangeiraC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NTNtipoC' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaParSegu) {
            form.setEnabled('NTNrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNcpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNtelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNcepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNcidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NTNpaisC' + '___' + tabelaParSegu[position], false);
        }
    }
}

function blockAditivoNegocio(form, customHTML, state) {

    // form.setEnabled('AFPSvaloresContratoAlt', false);
    form.setEnabled('AFPSNomeFantasiaGrupo', false);
    form.setEnabled('AFPSobjetoContrato', false);
    form.setEnabled('AFPSprodComeInte', false);
    form.setEnabled('AFPSobservacoes', false);
    form.setEnabled('AFPScontNegAdit', false);
    form.setEnabled('AFPSquaisUpfrontBonus', false);
    form.setEnabled('AFPSquaisBonusPerformance', false);
    form.setEnabled('AFPSquaisProfitSharing', false);
    form.setEnabled('AFPSquaisReembCartaCredito', false);
    form.setEnabled('AFPSquaisInvestMarketMinGarant', false);
    form.setEnabled('AFPSquaisFindesFee', false);
    form.setEnabled('AFPSquaisIncluAltDespAgeCamp', false);
    form.setEnabled('AFPSquaisIncluAltDespPrestServ', false);
    form.setEnabled('AFPSquaisIncluAltDespVar', false);
    form.setEnabled("AFPSBonusDetalhamento", false);
    form.setEnabled("AFPSBonusPerformDet", false);
    form.setEnabled("AFPSProfitSharingDetalhamento", false);
    form.setEnabled("AFPSReembCartaCreditoDet", false);
    form.setEnabled("AFPSIncluAltDespPrestServDet", false);
    form.setEnabled("AFPSIncluAltDespVarDet", false);
    form.setEnabled("AFPSinicioVigencia", false);
    form.setEnabled("AFPSfimVigencia", false);
    form.setEnabled("AFPSdataAviso", false);
    form.setEnabled("AFPSPeriodoRenovacao", false);
    form.setEnabled("AFPSRenovacaoAutomatica", false);
    form.setEnabled('AFPSempPartNeg', false);
    form.setEnabled('AFPSgarantiaContrato', false);
    form.setEnabled('AFPStipoGarantia', false);
    form.setEnabled('AFPSinicioVidenciaGarantia', false);
    form.setEnabled('AFPSfimVigenciaGarantia', false);
    form.setEnabled('AFPSdataAvisoVenc', false);
    form.setEnabled('AFPSoutrosDetalhes', false);
    form.setEnabled("AFPSvalorMulta", false);
    form.setEnabled("AFPSDescGarantia", false);
    
    customHTML.append("<script> $('#AFPSflagMulta').parent().css('pointer-events', 'none') </script>")
    customHTML.append("<script> $('[name=AFPSRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")
    blockButtons(customHTML)

    var tabelaContratado = form.getChildrenIndexes("AFPStabelaContratado");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaContratado) {
            form.setEnabled('AFPSrazaoSocialC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSnomeFantasiaC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScpfCnpjC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSemailC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPStelefoneC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSenderecoC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScepC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSbairroC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScidadeC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSufC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSpaisC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSbanco' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSagencia' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSconta' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSnacionalEstrangeira' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPStipo' + '___' + tabelaContratado[position], false);

        }
    } else {
        for (position in tabelaContratado) {
            form.setEnabled('AFPSrazaoSocialC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSnomeFantasiaC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScpfCnpjC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSemailC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPStelefoneC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSenderecoC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScepC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSbairroC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScidadeC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSufC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSpaisC' + '___' + tabelaContratado[position], false);
        }
    }


    var tabelaClienteRep = form.getChildrenIndexes("ATNtabelaCorretIntermed");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('ATNrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNtelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNpaisB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNbancoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNagenciaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcontaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNnacionalEstrangeiraB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNtipoB' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('ATNrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNtelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNpaisB' + '___' + tabelaClienteRep[position], false);
        }
    }

    var tabelaParSegu = form.getChildrenIndexes("ATNtabelaParSegu");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaParSegu) {
            form.setEnabled('ATNrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNcpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNtelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNcepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNcidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNpaisC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNbancoC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNagenciaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNcontaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNnacionalEstrangeiraC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('ATNtipoC' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaParSegu) {
            form.setEnabled('ATNrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNcpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNtelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNcepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNcidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('ATNpaisC' + '___' + tabelaParSegu[position], false);
        }
    }
}

function blockAditivoFornPrest(form, customHTML, state) {
    form.setEnabled('AFPSidentifAditivo', false);
    form.setEnabled('AFPScontratante', false);
    form.setEnabled('AFPStituloContrato', false);
    form.setEnabled('AFPSobjetoAditivo', false);
    form.setEnabled('AFPSvalorTotal', false);
    form.setEnabled('AFPSvalorTotalMensal', false);
    form.setEnabled('AFPSvalorTotalAnual', false);
    form.setEnabled('AFPSobs', false);

    customHTML.append("<script> $('[name=NFPSRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")

    blockButtons(customHTML)

    var tabelaContratado = form.getChildrenIndexes("AFPStabelaContratado");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaContratado) {
            form.setEnabled('AFPSrazaoSocialC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSnomeFantasiaC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScpfCnpjC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSemailC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPStelefoneC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSenderecoC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScepC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSbairroC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScidadeC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSufC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSpaisC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSbanco' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSagencia' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSconta' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSnacionalEstrangeira' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPStipo' + '___' + tabelaContratado[position], false);

        }
    } else {
        for (position in tabelaContratado) {
            form.setEnabled('AFPSrazaoSocialC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSnomeFantasiaC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScpfCnpjC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSemailC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPStelefoneC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSenderecoC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScepC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSbairroC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPScidadeC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSufC' + '___' + tabelaContratado[position], false);
            form.setEnabled('AFPSpaisC' + '___' + tabelaContratado[position], false);
        }
    }

}

function blockDistrato(form, customHTML, state) {
    form.setEnabled('DIStituloContrato', false);
    form.setEnabled('DISdataTerminoCont', false);
    form.setEnabled('DISvalorPendenteQuitacao', false);
    form.setEnabled('DISvalorPendente', false);
    form.setEnabled('DISdescricaoPendencia', false);
    form.setEnabled('DISobrigPendenteCumpri', false);
    form.setEnabled('DISobrigPendente', false);
    form.setEnabled("DIScontratante", false);
    form.setEnabled("DISempPartNeg", false);
    form.setEnabled("DISobrigPendenteText", false);
    form.setEnabled("DISnomeFantGrup", false);
    form.setEnabled("DISobjetoContrato", false);
    form.setEnabled("DISprodComeInte", false);
    form.setEnabled("DISobservacoes", false);
    form.setEnabled('DIScontNegAdit', false);
    form.setEnabled('DISquaisUpfrontBonus', false);
    form.setEnabled('DISquaisBonusPerformance', false);
    form.setEnabled('DISquaisProfitSharing', false);
    form.setEnabled('DISquaisReembCartaCredito', false);
    form.setEnabled('DISquaisInvestMarketMinGarant', false);
    form.setEnabled('DISquaisFindesFee', false);
    form.setEnabled('DISquaisIncluAltDespAgeCamp', false);
    form.setEnabled('DISquaisIncluAltDespPrestServ', false);
    form.setEnabled('DISquaisIncluAltDespVar', false);
    form.setEnabled("DISBonusDetalhamento", false);
    form.setEnabled("DISBonusPerformDet", false);
    form.setEnabled("DISProfitSharingDetalhamento", false);
    form.setEnabled("DISReembCartaCreditoDet", false);
    form.setEnabled("DISIncluAltDespPrestServDet", false);
    form.setEnabled("DISIncluAltDespVarDet", false);
    form.setEnabled('DISgarantiaContrato', false);
    form.setEnabled('DIStipoGarantia', false);
    form.setEnabled('DISinicioVidenciaGarantia', false);
    form.setEnabled('DISfimVigenciaGarantia', false);
    form.setEnabled('DISdataAvisoVenc', false);
    form.setEnabled("DISDescGarantia", false);
    form.setEnabled("DISinicioVigencia", false);
    form.setEnabled("DISfimVigencia", false);
    form.setEnabled("DISdataAviso", false);
    form.setEnabled("DISPeriodoRenovacao", false);
    form.setEnabled("DISRenovacaoAut", false);
    form.setEnabled("DISvalorTotal", false);
    form.setEnabled("DISvalorTotalMensal", false);
    form.setEnabled("DISvalorTotalAnual", false);






    customHTML.append("<script> $('[name=DISRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")


    // blockButtons(customHTML)

    var tabelaUploadFiles = form.getChildrenIndexes("DIStabelaUploadFiles");
    for (position in tabelaUploadFiles) {
        form.setEnabled('DISbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        form.setEnabled('DISdeletar' + '___' + tabelaUploadFiles[position], false);
        if (form.getValue('DISidFile___' + tabelaUploadFiles[position])) {
            form.setVisibleById('DISbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        }
    }

    var tabelaContratado = form.getChildrenIndexes("DIStabelaContratado");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {

        for (position in tabelaContratado) {
            form.setEnabled('DISrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIScpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIStelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIScep' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIScidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISpais' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISbanco' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISagencia' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISconta' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISnacionalEstrangeira' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIStipo' + '___' + tabelaContratado[position], false);

        }
    } else {
        for (position in tabelaContratado) {
            form.setEnabled('DISrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIScpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIStelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIScep' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('DIScidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('DISpais' + '___' + tabelaContratado[position], false);
        }
    }

    var tabelaClienteRep = form.getChildrenIndexes("DIStabelaClienteRep");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('DISrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIStelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISpaisA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISbancoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISagenciaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScontaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISnacionalEstrangeiraA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIStipoA' + '___' + tabelaClienteRep[position], false);

        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('DISrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIStelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISpaisA' + '___' + tabelaClienteRep[position], false);
        }
    }

    var tabelaClienteRep = form.getChildrenIndexes("DIStabelaCorretIntermed");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('DISrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIStelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISpaisB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISbancoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISagenciaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScontaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISnacionalEstrangeiraB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIStipoB' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('DISrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIStelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISpaisB' + '___' + tabelaClienteRep[position], false);
        }
    }

    var tabelaParSegu = form.getChildrenIndexes("DIStabelaParSegu");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaParSegu) {
            form.setEnabled('DISrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIScpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIStelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIScepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIScidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISpaisC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISbancoC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISagenciaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIScontaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DISnacionalEstrangeiraC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('DIStipoC' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaParSegu) {
            form.setEnabled('DISrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIScpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIStelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIScepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DIScidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('DISpaisC' + '___' + tabelaParSegu[position], false);
        }
    }

}

function blockPropostaComercial(form, customHTML, state) {
    // form.setEnabled('PROCcontrato', false);
    form.setEnabled('PROCindeticacaoProposta', false);
    form.setEnabled('PROCobjetoProp', false);
    form.setEnabled('PROCflagPropostaInd', false);
    form.setEnabled('PROCflagPropostaVigenDetRen', false);
    form.setEnabled('PROCvigenciaFalta', false);
    form.setEnabled('PROCinicioVigencia', false);
    form.setEnabled('PROCfimVigencia', false);
    form.setEnabled('PROCdataAviso', false);
    form.setEnabled('PROCAvisoPrevio', false);
    form.setEnabled('PROCRenovacaoAutomatica', false);
    form.setEnabled('PROCvigenciaProp', false);
    form.setEnabled('PROCfimVigenciaProp', false);
    form.setEnabled('PROCvalorServContProp', false);
    form.setEnabled('PROCvalorTotal', false);
    form.setEnabled("PROCvalorTotalMensal", false);
    form.setEnabled("PROCvalorTotalAnual", false);

    customHTML.append("<script> $('[name=PROCRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")

    blockButtons(customHTML)

    var tabelaUploadFiles = form.getChildrenIndexes("PROCtabelaUploadFiles");
    for (position in tabelaUploadFiles) {
        form.setEnabled('PROCbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        form.setEnabled('PROCdeletar' + '___' + tabelaUploadFiles[position], false);
        if (form.getValue('PROCidFile___' + tabelaUploadFiles[position])) {
            form.setVisibleById('PROCbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        }
    }

    var tabelaContratado = form.getChildrenIndexes("PROCtabelaContratado");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {

        for (position in tabelaContratado) {
            form.setEnabled('PROCrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCcpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCtelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCcep' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCcidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCpais' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCbanco' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCagencia' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCconta' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCnacionalEstrangeira' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCtipo' + '___' + tabelaContratado[position], false);

        }
    } else {
        for (position in tabelaContratado) {
            form.setEnabled('PROCrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCcpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCtelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCcep' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCcidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('PROCpais' + '___' + tabelaContratado[position], false);
        }
    }

}

function blockNotificacao(form, customHTML, state) {
    form.setEnabled('NOTtipoNotificacao', false);
    form.setEnabled('NOTdataTerminoContratoEsp', false);
    form.setEnabled('NOTflagpendenteQuitacao', false);
    form.setEnabled('NOTvalorPendente', false);
    form.setEnabled('NOTdescricaoPendencia', false);
    form.setEnabled('NOTobrigacaoPendenteCump', false);
    form.setEnabled('NOTobrigPendenteQual', false);
    form.setEnabled('NOTobrigDescumprida', false);
    form.setEnabled('NOTclausulaViolada', false);
    form.setEnabled('NOTflagMulta', false);
    form.setEnabled('NOTvalorMulta', false);
    form.setEnabled('NOTflagEncerraContrato', false);
    form.setEnabled('NOTterminoContratoEsperada', false);
    form.setEnabled('NOTdescPendFinanc', false);
    form.setEnabled('NOTclausulaContrato', false);
    form.setEnabled('NOTvalPendFinanc', false);
    form.setEnabled('NOTdataInicioVigenNovaTabela', false);
    form.setEnabled('NOTdescNotificacaoDiversa', false);
    form.setEnabled('NOToutrosDetalhes', false);
    form.setEnabled("NOTcontratante", false);
    form.setEnabled("NOTDescricao", false);
    form.setEnabled("NOTempPartNeg", false);
    form.setEnabled("NOTnomeFantGrup", false);
    form.setEnabled("NOTtituloContrato", false);
    form.setEnabled("NOTobjetoContrato", false);
    form.setEnabled("NOTprodComeInte", false);
    form.setEnabled("NOTobservacoes", false);
    form.setEnabled('NOTcontNegAdit', false);
    form.setEnabled('NOTquaisUpfrontBonus', false);
    form.setEnabled('NOTquaisBonusPerformance', false);
    form.setEnabled('NOTquaisProfitSharing', false);
    form.setEnabled('NOTquaisReembCartaCredito', false);
    form.setEnabled('NOTquaisInvestMarketMinGarant', false);
    form.setEnabled('NOTquaisFindesFee', false);
    form.setEnabled('NOTquaisIncluAltDespAgeCamp', false);
    form.setEnabled('NOTquaisIncluAltDespPrestServ', false);
    form.setEnabled('NOTquaisIncluAltDespVar', false);
    form.setEnabled("NOTBonusDetalhamento", false);
    form.setEnabled("NOTBonusPerformDet", false);
    form.setEnabled("NOTProfitSharingDetalhamento", false);
    form.setEnabled("NOTReembCartaCreditoDet", false);
    form.setEnabled("NOTIncluAltDespPrestServDet", false);
    form.setEnabled("NOTIncluAltDespVarDet", false);
    form.setEnabled('NOTgarantiaContrato', false);
    form.setEnabled('NOTtipoGarantia', false);
    form.setEnabled('NOTinicioVidenciaGarantia', false);
    form.setEnabled('NOTfimVigenciaGarantia', false);
    form.setEnabled('NOTdataAvisoVenc', false);
    form.setEnabled("NOTDescGarantia", false);
    form.setEnabled("NOTinicioVigencia", false);
    form.setEnabled("NOTfimVigencia", false);
    form.setEnabled("NOTdataAviso", false);
    form.setEnabled("NOTPeriodoRenovacao", false);
    form.setEnabled("NOTRenovacaoAut", false);
    form.setEnabled('NOTvalorTotal', false);
    form.setEnabled("NOTvalorTotalMensal", false);
    form.setEnabled("NOTvalorTotalAnual", false);


    customHTML.append("<script> $('[name=NOTRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")


    blockButtons(customHTML)
    var tabelaUploadFiles = form.getChildrenIndexes("NOTtabelaUploadFiles");
    for (position in tabelaUploadFiles) {
        form.setEnabled('NOTbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        form.setEnabled('NOTdeletar' + '___' + tabelaUploadFiles[position], false);
        if (form.getValue('NOTidFile___' + tabelaUploadFiles[position])) {
            form.setVisibleById('NOTbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        }
    }

    var tabelaContratado = form.getChildrenIndexes("NOTtabelaContratado");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {

        for (position in tabelaContratado) {
            form.setEnabled('NOTrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTcpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTtelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTcep' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTcidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTpais' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTbanco' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTagencia' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTconta' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTnacionalEstrangeira' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTtipo' + '___' + tabelaContratado[position], false);

        }
    } else {
        for (position in tabelaContratado) {
            form.setEnabled('NOTrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTcpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTtelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTcep' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTcidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('NOTpais' + '___' + tabelaContratado[position], false);
        }
    }


    var tabelaClienteRep = form.getChildrenIndexes("NOTtabelaClienteRep");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('NOTrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTtelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTpaisA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTbancoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTagenciaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcontaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTnacionalEstrangeiraA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTtipoA' + '___' + tabelaClienteRep[position], false);

        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('NOTrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTtelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTpaisA' + '___' + tabelaClienteRep[position], false);
        }
    }

    var tabelaClienteRep = form.getChildrenIndexes("NOTtabelaCorretIntermed");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('NOTrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTtelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTpaisB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTbancoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTagenciaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcontaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTnacionalEstrangeiraB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTtipoB' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('NOTrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTtelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTpaisB' + '___' + tabelaClienteRep[position], false);
        }
    }

    var tabelaParSegu = form.getChildrenIndexes("NOTtabelaParSegu");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaParSegu) {
            form.setEnabled('NOTrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTcpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTtelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTcepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTcidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTpaisC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTbancoC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTagenciaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTcontaC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTnacionalEstrangeiraC' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('NOTtipoC' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaParSegu) {
            form.setEnabled('NOTrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTcpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTtelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTcepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTcidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('NOTpaisC' + '___' + tabelaParSegu[position], false);
        }
    }
}

function blockCessao(form, customHTML, state) {
    form.setEnabled("CESObs", false);
    form.setEnabled("CESdataCessao", false);
    form.setEnabled("CESobjetoContrato", false);
    form.setEnabled("CESprodComeInte", false);
    form.setEnabled("CESobservacoes", false);
    form.setEnabled('CEScontNegAdit', false);
    form.setEnabled('CESquaisUpfrontBonus', false);
    form.setEnabled('CESquaisBonusPerformance', false);
    form.setEnabled('CESquaisProfitSharing', false);
    form.setEnabled('CESquaisReembCartaCredito', false);
    form.setEnabled('CESquaisInvestMarketMinGarant', false);
    form.setEnabled('CESquaisFindesFee', false);
    form.setEnabled('CESquaisIncluAltDespAgeCamp', false);
    form.setEnabled('CESquaisIncluAltDespPrestServ', false);
    form.setEnabled('CESquaisIncluAltDespVar', false);
    form.setEnabled("CESBonusDetalhamento", false);
    form.setEnabled("CESBonusPerformDet", false);
    form.setEnabled("CESProfitSharingDetalhamento", false);
    form.setEnabled("CESReembCartaCreditoDet", false);
    form.setEnabled("CESIncluAltDespPrestServDet", false);
    form.setEnabled("CESIncluAltDespVarDet", false);
    form.setEnabled('CESgarantiaContrato', false);
    form.setEnabled('CEStipoGarantia', false);
    form.setEnabled('CESinicioVidenciaGarantia', false);
    form.setEnabled('CESfimVigenciaGarantia', false);
    form.setEnabled('CESdataAvisoVenc', false);
    form.setEnabled("CESDescGarantia", false);
    form.setEnabled("CESinicioVigencia", false);
    form.setEnabled("CESfimVigencia", false);
    form.setEnabled("CESdataAviso", false);
    form.setEnabled("CESPeriodoRenovacao", false);
    form.setEnabled("CESRenovacaoAut", false);
    form.setEnabled('CESvalorTotal', false);
    form.setEnabled("CESvalorTotalMensal", false);
    form.setEnabled("CESvalorTotalAnual", false);
    blockButtons(customHTML)

    customHTML.append("<script> $('[name=CESRadioPrazo]').parent().parent().css('pointer-events', 'none') </script>")

    //Tabela Cessionario Fornecedor/Prestador de Serviço -----------------------------------------------------------------
    var tabelaContratado = form.getChildrenIndexes("CEStabelaCessionario");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {

        for (position in tabelaContratado) {
            form.setEnabled('CESrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEScpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEStelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEScep' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEScidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESpais' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESbanco' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESagencia' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESconta' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESnacionalEstrangeira' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEStipo' + '___' + tabelaContratado[position], false);

        }
    } else {
        for (position in tabelaContratado) {
            form.setEnabled('CESrazaoSocial' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESnomeFantasia' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEScpfCnpj' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESemail' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEStelefone' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESendereco' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEScep' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESbairro' + '___' + tabelaContratado[position], false);
            form.setEnabled('CEScidade' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESuf' + '___' + tabelaContratado[position], false);
            form.setEnabled('CESpais' + '___' + tabelaContratado[position], false);
        }
    }

    //Tabela Cessionario Fornecedor/Prestador de Serviço novo--------------------------------------------------------------

    var tabelaNovoContratado = form.getChildrenIndexes("CEStabelaNovoCessionario");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {

        for (position in tabelaNovoContratado) {
            form.setEnabled('CESrazaoSocialNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESnomeFantasiaNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEScpfCnpjNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESemailNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEStelefoneNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESenderecoNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEScepNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESbairroNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEScidadeNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESufNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESpaisNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESbancoNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESagenciaNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEScontaNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESnacionalEstrangeiraNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEStipoNova' + '___' + tabelaNovoContratado[position], false);

        }
    } else {
        for (position in tabelaNovoContratado) {
            form.setEnabled('CESrazaoSocialNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESnomeFantasiaNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEScpfCnpjNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESemailNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEStelefoneNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESenderecoNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEScepNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESbairroNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CEScidadeNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESufNova' + '___' + tabelaNovoContratado[position], false);
            form.setEnabled('CESpaisNova' + '___' + tabelaNovoContratado[position], false);
        }
    }
    //Tabela Cessionario Negocio Cliente Representante-----------------------------------------------------------------

    var tabelaClienteRep = form.getChildrenIndexes("CEStabelaClienteRep");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('CESrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEStelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESpaisA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESbancoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESagenciaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScontaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESnacionalEstrangeiraA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEStipoA' + '___' + tabelaClienteRep[position], false);

        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('CESrazaoSocialA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESnomeFantasiaA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScpfCnpjA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESemailA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEStelefoneA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESenderecoA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScepA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESbairroA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScidadeA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESufA' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESpaisA' + '___' + tabelaClienteRep[position], false);
        }
    }

    //Tabela Cessionario Negocio Cliente Representante Novo-----------------------------------------------------------------
    var tabelaClienteRepNovo = form.getChildrenIndexes("CEStabelaClienteRepNovo");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRepNovo) {
            form.setEnabled('CESrazaoSocialNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESnomeFantasiaNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEScpfCnpjNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESemailNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEStelefoneNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESenderecoNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEScepNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESbairroNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEScidadeNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESufNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESpaisNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESbancoNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESagenciaNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEScontaNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESnacionalEstrangeiraNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEStipoNovaA' + '___' + tabelaClienteRepNovo[position], false);

        }
    } else {
        for (position in tabelaClienteRepNovo) {
            form.setEnabled('CESrazaoSocialNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESnomeFantasiaNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEScpfCnpjNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESemailNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEStelefoneNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESenderecoNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEScepNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESbairroNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CEScidadeNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESufNovaA' + '___' + tabelaClienteRepNovo[position], false);
            form.setEnabled('CESpaisNovaA' + '___' + tabelaClienteRepNovo[position], false);
        }
    }



    //Tabela Cessionario Negocio Corretora Intermediario-----------------------------------------------------------------

    var tabelaClienteRep = form.getChildrenIndexes("CEStabelaCorretIntermed");
    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaClienteRep) {
            form.setEnabled('CESrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEStelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESpaisB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESbancoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESagenciaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScontaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESnacionalEstrangeiraB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEStipoB' + '___' + tabelaClienteRep[position], false);
        }
    } else {
        for (position in tabelaClienteRep) {
            form.setEnabled('CESrazaoSocialB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESnomeFantasiaB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScpfCnpjB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESemailB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEStelefoneB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESenderecoB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScepB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESbairroB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CEScidadeB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESufB' + '___' + tabelaClienteRep[position], false);
            form.setEnabled('CESpaisB' + '___' + tabelaClienteRep[position], false);
        }
    }
    //Tabela Cessionario Negocio Corretora Intermediario Novo-------------------------------------------------------
    var tabelaCorretIntermedNovo = form.getChildrenIndexes("CEStabelaCorretIntermedNovo");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaCorretIntermedNovo) {
            form.setEnabled('CESrazaoSocialNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESnomeFantasiaNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEScpfCnpjNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESemailNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEStelefoneNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESenderecoNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEScepNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESbairroNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEScidadeNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESufNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESpaisNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESbancoNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESagenciaNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEScontaNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESnacionalEstrangeiraNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEStipoNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
        }
    } else {
        for (position in tabelaCorretIntermedNovo) {
            form.setEnabled('CESrazaoSocialNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESnomeFantasiaNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEScpfCnpjNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESemailNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEStelefoneNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESenderecoNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEScepNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESbairroNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CEScidadeNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESufNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
            form.setEnabled('CESpaisNovaB' + '___' + tabelaCorretIntermedNovo[position], false);
        }
    }

    //Tabela Cessionario Negocio Parceiro Seguro-----------------------------------------------------------------
    var tabelaParSegu = form.getChildrenIndexes("CEStabelaParSegu");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaParSegu) {
            form.setEnabled('CESrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEScpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEStelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEScepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEScidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESpaisC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESbancoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESagenciaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEScontaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESnacionalEstrangeiraC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEStipoC' + '___' + tabelaParSegu[position], false);
        }
    } else {
        for (position in tabelaParSegu) {
            form.setEnabled('CESrazaoSocialC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESnomeFantasiaC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEScpfCnpjC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESemailC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEStelefoneC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESenderecoC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEScepC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESbairroC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CEScidadeC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESufC' + '___' + tabelaParSegu[position], false);
            form.setEnabled('CESpaisC' + '___' + tabelaParSegu[position], false);
        }
    }

    //Tabela Cessionario Negocio Parceiro Seguro Novo-----------------------------------------------------------------
    var tabelaParSeguNova = form.getChildrenIndexes("CEStabelaDadosParceirosNovo");

    if (state == PROVASSINATURAPARCEIRO || state == PROVASSINATURAINTER || state == COMPLIANCE) {
        for (position in tabelaParSeguNova) {
            form.setEnabled('CESrazaoSocialNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESnomeFantasiaNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEScpfCnpjNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESemailNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEStelefoneNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESenderecoNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEScepNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESbairroNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEScidadeNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESufNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESpaisNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESbancoNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESagenciaNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEScontaNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESnacionalEstrangeiraNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEStipoNovaC' + '___' + tabelaParSeguNova[position], false);
        }
    } else {
        for (position in tabelaParSeguNova) {
            form.setEnabled('CESrazaoSocialNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESnomeFantasiaNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEScpfCnpjNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESemailNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEStelefoneNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESenderecoNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEScepNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESbairroNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CEScidadeNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESufNovaC' + '___' + tabelaParSeguNova[position], false);
            form.setEnabled('CESpaisNovaC' + '___' + tabelaParSeguNova[position], false);
        }
    }

}

function blockOutrasSolic(form, customHTML) {
    form.setEnabled("OSdescricao", false);
    blockButtons(customHTML);

    var tabelaUploadFiles = form.getChildrenIndexes("OStabelaUploadFiles");
    for (position in tabelaUploadFiles) {
        form.setEnabled('OSbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        form.setEnabled('OSdeletar' + '___' + tabelaUploadFiles[position], false);
        if (form.getValue('OSidFile___' + tabelaUploadFiles[position])) {
            form.setVisibleById('OSbtnAdicionar' + '___' + tabelaUploadFiles[position], false);
        }
    }
}

function blockAprovacao(form, customHTML) {
    customHTML.append('<script> $(".aprovar").attr("disabled",true); $(".reprovar").attr("disabled",true); $(".contestar").attr("disabled",true);</script>')
    form.setEnabled('aprovacaoSolicitacao', false);
    form.setEnabled('div_aprovacao1', false);
    form.setEnabled('div_aprovacao2', false);
    form.setEnabled('div_aprovacao3', false);
    form.setEnabled('div_aprovacao4', false);
    form.setEnabled('div_aprovacao5', false);
}

function setFiledAprovacao(form, state, customHTML) {
    if (state == PROVASSINATURAPARCEIRO) {

        customHTML.append("<script>  $('#div_pai_Aprovacao').css('pointer-events','none')</script>")

        var valueAprov = form.getValue("aprovacaoSolicitacao");
        if (valueAprov == "REPROVAR" || valueAprov == "CONTESTADO") {
            form.setVisibleById("div_pai_Aprovacao", true);
            var aprov = "";
            form.setEnabled('aprovacao1', false);
            form.setEnabled('aprovacao2', false);
            form.setEnabled('aprovacao3', false);
            form.setEnabled('aprovacao4', false);
            form.setEnabled('aprovacao5', false);
            customHTML.append("<script> $('[name=aprovacaoSolicitacao]').parent().css('pointer-events', 'none'); </script>")
            aprov = form.getValue("aprovacao1") == "" ? form.setVisibleById('div_aprovacao1', false) : form.setVisibleById('div_aprovacao1', true);
            aprov = form.getValue("aprovacao2") == "" ? form.setVisibleById('div_aprovacao2', false) : form.setVisibleById('div_aprovacao2', true);
            aprov = form.getValue("aprovacao3") == "" ? form.setVisibleById('div_aprovacao3', false) : form.setVisibleById('div_aprovacao3', true);
            aprov = form.getValue("aprovacao4") == "" ? form.setVisibleById('div_aprovacao4', false) : form.setVisibleById('div_aprovacao4', true);
            aprov = form.getValue("aprovacao5") == "" ? form.setVisibleById('div_aprovacao5', false) : form.setVisibleById('div_aprovacao5', true);
        } else {
            // form.setValue("aprovacaoSolicitacao", "");
            form.setVisibleById("div_pai_Aprovacao", false);
        }
    } else {
        customHTML.append("<script> $('[name=aprovacaoSolicitacao]').parent().css('pointer-events', 'auto'); </script>")
        form.setValue("aprovacaoSolicitacao", "");
        form.setVisibleById('div_aprovacao1', false);
        form.setVisibleById('div_aprovacao2', false);
        form.setVisibleById('div_aprovacao3', false);
        form.setVisibleById('div_aprovacao4', false);
        form.setVisibleById('div_aprovacao5', false);

        if (form.getValue('aprovacao4') != "") {
            form.setVisibleById('div_aprovacao1', true);
            form.setVisibleById('div_aprovacao2', true);
            form.setVisibleById('div_aprovacao3', true);
            form.setVisibleById('div_aprovacao4', true);
            form.setVisibleById('div_aprovacao5', true);
            form.setEnabled('aprovacao1', false);
            form.setEnabled('aprovacao2', false);
            form.setEnabled('aprovacao3', false);
            form.setEnabled('aprovacao4', false);
        } else if (form.getValue('aprovacao3') != "") {
            form.setVisibleById('div_aprovacao1', true);
            form.setVisibleById('div_aprovacao2', true);
            form.setVisibleById('div_aprovacao3', true);
            form.setVisibleById('div_aprovacao4', true);
            form.setEnabled('aprovacao1', false);
            form.setEnabled('aprovacao2', false);
            form.setEnabled('aprovacao3', false);
        } else if (form.getValue('aprovacao2') != "") {
            form.setVisibleById('div_aprovacao1', true);
            form.setVisibleById('div_aprovacao2', true);
            form.setVisibleById('div_aprovacao3', true);
            form.setEnabled('aprovacao1', false);
            form.setEnabled('aprovacao2', false);
        } else if (form.getValue('aprovacao1') != "") {
            form.setVisibleById('div_aprovacao1', true);
            form.setVisibleById('div_aprovacao2', true);
            form.setEnabled('aprovacao1', false);
        } else {
            form.setVisibleById('div_aprovacao1', true);
            form.setEnabled('aprovacao1', true);
        }
    }


}