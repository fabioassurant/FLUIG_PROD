function validateForm(form){
    /*if(form.getValue('validacao') != 'true'){
        throw 'Erro na validação do formulário'
    }*/
}