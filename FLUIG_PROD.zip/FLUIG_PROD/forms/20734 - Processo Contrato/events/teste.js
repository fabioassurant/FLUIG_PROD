var constraintColleagueGroup1 = DatasetFactory.createConstraint('colleagueGroupPK.groupId', 'IMPLANTA��O', 'IMPLANTA��O', ConstraintType.MUST);
var datasetColleagueGroup = DatasetFactory.getDataset('colleagueGroup', null, new Array(constraintColleagueGroup1), null);

var constraintColleagueGroup1 = DatasetFactory.createConstraint('colleagueGroupPK.groupId', 'ADMINISTRATIVO', 'ADMINISTRATIVO', ConstraintType.MUST);
var datasetColleagueGroup = DatasetFactory.getDataset('colleagueGroup', null, new Array(constraintColleagueGroup1), null);
