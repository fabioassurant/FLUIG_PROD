const PARENTID = {
    'OUTR': '20730',
    'DIS': '20728',
    'PROC': '20731',
    'NOT': '20727',
    'CES': '20729',
}


const global = {
    'contadorRazao': 0,
    'historicoCessaoSelect': []
}

const TOAST = (message, type) => {
    FLUIGC.toast({
        title: '',
        message: message,
        type: type
    });
}

$(document).ready(() => {
    initFields();
    viewingEvents();
    addTableButtonsEvents();
    addFilesEventsNonFatherAndSon();
    hideAllTypesNotification();
    addMaskInputs();
    habilitarRisco('', getCurrentState());

    $('#tipoContrato').on('change', (element) => {
        changeView();
        if (element.currentTarget.value == 'forncedorPrestadorServico') {
            $("#NFPStituloContrato").val("Contrato de Prestação de Serviços/ Contrato de Fornecimento")
            $("#tituloContrato").val("Contrato de Prestação de Serviços/ Contrato de Fornecimento")
            $('#PROCobjetoProp').parent().show()
            $('#PROCflagPropostaInd').parent().show()
            $('#PROCflagPropostaVigenDetRen').parent().hide()
            $('#PROCvigenciaFalta').parent().hide()
        } else {
            $('#PROCobjetoProp').parent().hide()
            $('#PROCflagPropostaInd').parent().hide()
            $('#PROCflagPropostaVigenDetRen').parent().show()
            $('#PROCvigenciaFalta').parent().show()

        }
    });
    $('#servicoJuridico').on('change', (e) => {
        var tipoService = $("#servicoJuridico").val()
        if (tipoService == "outrasSolicitacoes") {
            $("#div_riscoContrato").hide()
        }
        changeView();

    });
    if (getCurrentState() == INICIO || getCurrentState() == ABRIRPROCESSO) {
        FLUIGC.calendar('.dataFluig')

        var user = getCurrentUser()
        $("#solicitante").val(user)

        var tipoContrato = $("#TipoContrato").val()
        $('#TipoContratoHidden').val(tipoContrato)

        $("#NTNPeriodoRenovacao").attr('disabled', false)

    }
    if (getCurrentState() == PROVASSINATURAPARCEIRO) {
        // $('[name=aprovacaoSolicitacao]').parent().hide()
        // $("#div_pai_Aprovacao").show()

    }

})

function initFields() {
    if (getCurrentState() != ABRIRPROCESSO) {
        blockButtonNovoContrato()
        BlockButtonAditivo()
        blockButtonDistrato()
        blockButtonNotificacao()
        blockButtonProposta()
        blockButtonCessao()
        var dataCedente = []
        dataCedente.push({
            id: "",
            text: ""
        }, {
            id: "Contratante",
            text: "Contratante"
        }, {
            id: "Contratado",
            text: "Contratado"
        })

        $("#CEScedente").select2({
            data: dataCedente,
            allowClear: true,
            theme: "bootstrap",
            language: "pt-BR",
            tags: true,
            tokenSeparators: [',', '']
        })

        let CEScedenteHidden = $("#CEScedenteHidden").val()
        let CEScedenteSplit = CEScedenteHidden.split(',')
        $("#CEScedente").val(CEScedenteSplit).trigger('change')
        $("#CEScedente").parent().css('pointer-events', 'none')


        var dataCedenteNeg = []
        dataCedenteNeg.push({
            id: "",
            text: ""
        }, {
            id: "empresaParticipante",
            text: "Empresa Participante"
        }, {
            id: "clienteRep",
            text: "Cliente Representante"
        }, {
            id: "corretora",
            text: "Corretora"
        }, {
            id: "parceiro",
            text: "Parceiro"
        })

        $("#CEScedenteNeg").select2({
            data: dataCedenteNeg,
            allowClear: true,
            theme: "bootstrap",
            language: "pt-BR",
            tags: true,
            tokenSeparators: [',', '']
        }).on("select2:unselect", (selected) => {
            console.log('entrou no unselect Empresa Cedente')
            if (selected.params.data.id == 'empresaParticipante') {
                $('#divCESlistaCedenteEmpPart').addClass('fs-display-none')
            } else if (selected.params.data.id == 'clienteRep') {
                $('#divCESlistaCedenteclienteRep').addClass('fs-display-none')
            } else if (selected.params.data.id == 'corretora') {
                $('#divCESlistaCedentecorretora').addClass('fs-display-none')
            } else if (selected.params.data.id == 'parceiro') {
                $('#divCESlistaCedenteparceiro').addClass('fs-display-none')
            }
        });


        let CEScedenteNegHidden = $("#CEScedenteNegHidden").val()
        let CEScedenteNegSplit = CEScedenteNegHidden.split(',')
        $("#CEScedenteNeg").val(CEScedenteNegSplit).trigger('change')
        $("#CEScedenteNeg").parent().css('pointer-events', 'none')

        if ($("#DISvalorPendenteQuitacao").val() == 'sim') {
            $('#DISvalorPendente, #_DISvalorPendente').parent().show();
            // $('[name="_DISvalorPendente"]').parent().show();
            // $('[name="_DISobrigPendenteText"]').parent().show();
        } else {
            $('[name="_DISvalorPendente"]').parent().hide();
            $('[name="_DISobrigPendenteText"]').parent().hide();
            $('[name="_DISvalorPendente"]').val('');
        }


        if ($("#CESlistaCedenteContratante").val() != '') {
            $("#CESdivListaCedenteContratante").removeClass("fs-display-none");
            $("#CESlistaCedenteContratante").css('pointer-events', 'none')
        }
        if ($("#CESlistaCedenteContratado").val() != '') {
            $("#CESdivListaCedenteContratado").removeClass("fs-display-none");
            $("#CESlistaCedenteContratado").css('pointer-events', 'none')
        }

        if ($("#CESlistaCedenteEmpPart").val() != null) {
            $("#divCESlistaCedenteEmpPart").removeClass("fs-display-none");
            $("#CESlistaCedenteEmpPart").css('pointer-events', 'none')

        }

        if ($("#CESlistaCedentecliRepHidden").val() != '') {
            $("#divCESlistaCedenteclienteRep").removeClass("fs-display-none");
            var optionClienteRep = []
            var documentIdH = $("#documentIdHidden").val()

            consultDataset('ds_processo_contrato', 'NTNtabelaClienteRep', [{
                "_field": "documentid",
                "_initialValue": documentIdH,
                "_finalValue": documentIdH,
                "_type": 1
            }]).success(newData => {
                for (let i = 0; i < newData.content.values.length; i++) {
                    optionClienteRep.push({
                        id: newData.content.values[i]['NTNrazaoSocialA'],
                        text: newData.content.values[i]['NTNrazaoSocialA']
                    })
                }

                $("#CESlistaCedenteclienteRep").select2({
                    data: optionClienteRep,
                    allowClear: true,
                    theme: "bootstrap",
                    language: "pt-BR",
                    tags: true,
                    tokenSeparators: [',', '']
                })

                let hiddenValue = $("#CESlistaCedentecliRepHidden").val()
                let hiddenSplit = hiddenValue.split(',')
                $("#CESlistaCedenteclienteRep").val(hiddenSplit).trigger('change')
            });
            $("#CESlistaCedenteclienteRep").parent().css('pointer-events', 'none')
        }

        if ($("#CESlistaCedentecorHidden").val() != '') {
            $("#divCESlistaCedentecorretora").removeClass("fs-display-none");
            var optionCorretora = []
            var documentIdH = $("#documentIdHidden").val()

            consultDataset('ds_processo_contrato', 'NTNtabelaCorretIntermed', [{
                "_field": "documentid",
                "_initialValue": documentIdH,
                "_finalValue": documentIdH,
                "_type": 1
            }]).success(newData => {
                for (let i = 0; i < newData.content.values.length; i++) {
                    optionCorretora.push({
                        id: newData.content.values[i]['NTNrazaoSocialB'],
                        text: newData.content.values[i]['NTNrazaoSocialB']
                    })
                }

                $("#CESlistaCedentecorretora").select2({
                    data: optionCorretora,
                    allowClear: true,
                    theme: "bootstrap",
                    language: "pt-BR",
                    tags: true,
                    tokenSeparators: [',', '']
                })
                let hiddenValue = $("#CESlistaCedentecorHidden").val()
                let hiddenSplit = hiddenValue.split(',')
                $("#CESlistaCedentecorretora").val(hiddenSplit).trigger('change')
            });
            $("#CESlistaCedentecorretora").parent().css('pointer-events', 'none')

        }

        if ($("#CESlistaCedenteparcHidden").val() != '') {
            $("#divCESlistaCedenteparceiro").removeClass("fs-display-none");
            // $("#CESlistaCedenteparceiro").css('pointer-events', 'none')
            var optionParceiro = []
            var documentIdH = $("#documentIdHidden").val()

            consultDataset('ds_processo_contrato', 'NTNtabelaParSegu', [{
                "_field": "documentid",
                "_initialValue": documentIdH,
                "_finalValue": documentIdH,
                "_type": 1
            }]).success(newData => {
                for (let i = 0; i < newData.content.values.length; i++) {
                    optionParceiro.push({
                        id: newData.content.values[i]['NTNrazaoSocialC'],
                        text: newData.content.values[i]['NTNrazaoSocialC']
                    })
                }
                $("#CESlistaCedenteparceiro").select2({
                    data: optionParceiro,
                    allowClear: true,
                    theme: "bootstrap",
                    language: "pt-BR",
                    tags: true,
                    tokenSeparators: [',', '']
                })
                let hiddenValue = $("#CESlistaCedenteparcHidden").val()
                let hiddenSplit = hiddenValue.split(',')
                $("#CESlistaCedenteparceiro").val(hiddenSplit).trigger('change')
            });

            $("#CESlistaCedenteparceiro").parent().css('pointer-events', 'none')
        }


        if ($("#DISobrigPendenteCumpri").val() == "sim") {
            $("#_DISobrigPendente, #DISobrigPendente").parent().show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#DISobrigPendente").removeAttr("style").show();
            }
        }

        if ($("#_NOTflagMulta").prop("checked") || $("#NOTflagMulta").prop("checked")) {
            $(".NOTdivValorMulta").removeAttr("style").show();
            $("#_NOTvalorMulta").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NOTvalorMulta").removeAttr("style").show();
            }
        }

        if ($("#_NOTflagpendenteQuitacao").prop("checked") || $("#NOTflagpendenteQuitacao").prop("checked")) {
            $(".NOTdivValorPendente").removeAttr("style").show();
            $("#NOTflagpendenteQuitacao").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NOTflagpendenteQuitacao").removeAttr("style").show();
            }
        }

        if ($("#_NOTobrigacaoPendenteCump").prop("checked") || $("#NOTobrigacaoPendenteCump").prop("checked")) {
            $(".NOTdivObrigPendenteQual").removeAttr("style").show();
            $("#NOTobrigacaoPendenteCump").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NOTobrigacaoPendenteCump").removeAttr("style").show();
            }
        }

        if ($("#_NOTflagMultaDC").prop("checked") || $("#NOTflagMultaDC").prop("checked")) {
            $(".NOTdivValorMultaDC").removeAttr("style").show();
            $("#_NOTvalorMultaDC").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NOTvalorMultaDC").removeAttr("style").show();
            }
        }

        if ($("#_NOTflagMultaPF").prop("checked") || $("#NOTflagMultaPF").prop("checked")) {
            $(".NOTdivValorMultaPF").removeAttr("style").show();
            $("#_NOTflagMultaPF").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NOTflagMultaPF").removeAttr("style").show();
            }
        }

        if ($("#_NOTflagEncerraContrato").prop("checked") || $("#NOTflagEncerraContrato").prop("checked")) {
            $(".NOTdivDataTerminoEsperado").removeAttr("style").show();
            $("#_NOTflagEncerraContrato").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NOTflagEncerraContrato").removeAttr("style").show();
            }
        }

        if ($("#_NTNquaisUpfrontBonus").prop("checked") || $("#NTNquaisUpfrontBonus").prop("checked")) {
            $(".NTNdivBonusDetalhamento").removeAttr("style").show();
            $("#_NTNBonusDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NTNquaisUpfrontBonus").removeAttr("style").show();
            }
        }

        if ($("#_NTNquaisProfitSharing").prop("checked") || $("#NTNquaisProfitSharing").prop("checked")) {
            $(".NTNdivProfitSharingDetalhamento").removeAttr("style").show();
            $("#_NTNProfitSharingDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NTNquaisProfitSharing").removeAttr("style").show();
            }
        }

        if ($("#_NTNquaisIncluAltDespVar").prop("checked") || $("#NTNquaisIncluAltDespVar").prop("checked")) {
            $(".NTNdivIncluAltDespVarDet").removeAttr("style").show();
            $("#_NTNIncluAltDespVarDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NTNIncluAltDespVarDet").removeAttr("style").show();
            }
        }

        if ($("#_NTNquaisBonusPerformance").prop("checked") || $("#NTNquaisBonusPerformance").prop("checked")) {
            $(".NTNdivBonusPerformDet").removeAttr("style").show();
            $("#_NTNBonusPerformDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NNTNBonusPerformDet").removeAttr("style").show();
            }
        }

        if ($("#_NTNquaisReembCartaCredito").prop("checked") || $("#NTNquaisReembCartaCredito").prop("checked")) {
            $(".NTNdivReembCartaCreditoDet").removeAttr("style").show();
            $("#_NTNReembCartaCreditoDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NTNReembCartaCreditoDet").removeAttr("style").show();
            }
        }

        if ($("#_NTNquaisIncluAltDespPrestServ").prop("checked") || $("#NTNquaisIncluAltDespPrestServ").prop("checked")) {
            $(".NTNdivIncluAltDespPrestServDet").removeAttr("style").show();
            $("#_NTNIncluAltDespPrestServDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#NTNIncluAltDespPrestServDet").removeAttr("style").show();
            }
        }

        if ($("#_AFPSquaisUpfrontBonus").prop("checked") || $("#AFPSquaisUpfrontBonus").prop("checked")) {
            $("#divAFPSBonusDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divAFPSBonusDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_AFPSquaisBonusPerformance").prop("checked") || $("#AFPSquaisBonusPerformance").prop("checked")) {
            $("#divAFPSBonusPerformDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divAFPSBonusPerformDet").removeAttr("style").show();
            }
        }

        if ($("#_AFPSquaisProfitSharing").prop("checked") || $("#AFPSquaisProfitSharing").prop("checked")) {
            $("#divAFPSProfitSharingDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divAFPSProfitSharingDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_AFPSquaisReembCartaCredito").prop("checked") || $("#AFPSquaisReembCartaCredito").prop("checked")) {
            $("#divAFPSReembCartaCreditoDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divAFPSReembCartaCreditoDet").removeAttr("style").show();
            }
        }

        if ($("#_AFPSquaisIncluAltDespPrestServ").prop("checked") || $("#AFPSquaisIncluAltDespPrestServ").prop("checked")) {
            $("#divAFPSIncluAltDespPrestServDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divAFPSIncluAltDespPrestServDet").removeAttr("style").show();
            }
        }

        if ($("#_AFPSquaisIncluAltDespVar").prop("checked") || $("#AFPSquaisIncluAltDespVar").prop("checked")) {
            $("#divAFPSIncluAltDespVarDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divAFPSIncluAltDespVarDet").removeAttr("style").show();
            }
        }


        if ($("#_DISquaisUpfrontBonus").prop("checked") || $("#DISquaisUpfrontBonus").prop("checked")) {
            $("#divDISBonusDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divDISBonusDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_DISquaisBonusPerformance").prop("checked") || $("#DISquaisBonusPerformance").prop("checked")) {
            $("#divDISBonusPerformDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divDISBonusPerformDet").removeAttr("style").show();
            }
        }

        if ($("#_DISquaisProfitSharing").prop("checked") || $("#DISquaisProfitSharing").prop("checked")) {
            $("#divDISProfitSharingDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divDISProfitSharingDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_DISquaisReembCartaCredito").prop("checked") || $("#DISquaisReembCartaCredito").prop("checked")) {
            $("#divDISReembCartaCreditoDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divDISReembCartaCreditoDet").removeAttr("style").show();
            }
        }

        if ($("#_DISquaisIncluAltDespPrestServ").prop("checked") || $("#DISquaisIncluAltDespPrestServ").prop("checked")) {
            $("#divDISIncluAltDespPrestServDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divDISIncluAltDespPrestServDet").removeAttr("style").show();
            }
        }

        if ($("#_DISquaisIncluAltDespVar").prop("checked") || $("#DISquaisIncluAltDespVar").prop("checked")) {
            $("#divDISIncluAltDespVarDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divDISIncluAltDespVarDet").removeAttr("style").show();
            }
        }

        if ($("#_NOTquaisUpfrontBonus").prop("checked") || $("#NOTquaisUpfrontBonus").prop("checked")) {
            $("#divNOTBonusDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divNOTBonusDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_NOTquaisBonusPerformance").prop("checked") || $("#NOTquaisBonusPerformance").prop("checked")) {
            $("#divNOTBonusPerformDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divNOTBonusPerformDet").removeAttr("style").show();
            }
        }

        if ($("#_NOTquaisProfitSharing").prop("checked") || $("#NOTquaisProfitSharing").prop("checked")) {
            $("#divNOTProfitSharingDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divNOTProfitSharingDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_NOTquaisReembCartaCredito").prop("checked") || $("#NOTquaisReembCartaCredito").prop("checked")) {
            $("#divNOTReembCartaCreditoDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divNOTReembCartaCreditoDet").removeAttr("style").show();
            }
        }

        if ($("#_NOTquaisIncluAltDespPrestServ").prop("checked") || $("#NOTquaisIncluAltDespPrestServ").prop("checked")) {
            $("#divNOTIncluAltDespPrestServDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divNOTIncluAltDespPrestServDet").removeAttr("style").show();
            }
        }

        if ($("#_NOTquaisIncluAltDespVar").prop("checked") || $("#NOTquaisIncluAltDespVar").prop("checked")) {
            $("#divNOTIncluAltDespVarDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divNOTIncluAltDespVarDet").removeAttr("style").show();
            }
        }

        if ($("#_CESquaisUpfrontBonus").prop("checked") || $("#CESquaisUpfrontBonus").prop("checked")) {
            $("#divCESBonusDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divCESBonusDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_CESquaisBonusPerformance").prop("checked") || $("#CESquaisBonusPerformance").prop("checked")) {
            $("#divCESBonusPerformDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divCESBonusPerformDet").removeAttr("style").show();
            }
        }

        if ($("#_CESquaisProfitSharing").prop("checked") || $("#CESquaisProfitSharing").prop("checked")) {
            $("#divCESProfitSharingDetalhamento").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divCESProfitSharingDetalhamento").removeAttr("style").show();
            }
        }

        if ($("#_CESquaisReembCartaCredito").prop("checked") || $("#CESquaisReembCartaCredito").prop("checked")) {
            $("#divCESReembCartaCreditoDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divCESReembCartaCreditoDet").removeAttr("style").show();
            }
        }

        if ($("#_CESquaisIncluAltDespPrestServ").prop("checked") || $("#CESquaisIncluAltDespPrestServ").prop("checked")) {
            $("#divCESIncluAltDespPrestServDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divCESIncluAltDespPrestServDet").removeAttr("style").show();
            }
        }

        if ($("#_CESquaisIncluAltDespVar").prop("checked") || $("#CESquaisIncluAltDespVar").prop("checked")) {
            $("#divCESIncluAltDespVarDet").removeAttr("style").show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $("#divCESIncluAltDespVarDet").removeAttr("style").show();
            }
        }

        if ($("#AFPSvaloresContratoAlt").val() == "sim") {
            $('[name="_AFPSnovoServReneg"]').parent().show();
            $('[name="_AFPSTabela"]').parent().show();
            $('[name="AFPSnovoServReneg"]').parent().show();
            $('[name="AFPSTabela"]').parent().show();
            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                $('[name="AFPSnovoServReneg"]').parent().show();
            }
        }

        if ($('[name="NFPSRadioPrazo"]:checked').val() == 'determinado') {
            $("#divNFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSPeriodoRenovacao").show()
            $("#divNFPSRenovacaoAut").hide()
        }
        if ($('[name="NFPSRadioPrazo"]:checked').val() == 'indeterminado') {
            $("#divNFPSinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#NFPSDivFimVigencia").hide()
            $("#divNFPSdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNFPSPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNFPSRenovacaoAut").hide()
        }
        if ($('[name="NFPSRadioPrazo"]:checked').val() == 'renovacao') {
            $("#divNFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSPeriodoRenovacao").hide()
            $("#divNFPSRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }

        if ($('[name="PROCRadioPrazo"]:checked').val() == 'determinado') {
            $("#divPROCinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#PROCDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCRenovacaoAut").hide()
        }
        if ($('[name="PROCRadioPrazo"]:checked').val() == 'indeterminado') {
            $("#divPROCinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#PROCDivFimVigencia").hide()
            $("#divPROCdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divPROCPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divPROCRenovacaoAut").hide()
        }
        if ($('[name="PROCRadioPrazo"]:checked').val() == 'renovacao') {
            $("#divPROCinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#PROCDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCPeriodoRenovacao").hide()
            $("#divPROCRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }

        if ($('[name="NTNRadioPrazo"]:checked').val() == 'determinado') {
            $("#divNTNinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NTNDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNPeriodoRenovacao").show()
            $("#divNTNRenovacaoAut").hide()
        }
        if ($('[name="NTNRadioPrazo"]:checked').val() == 'indeterminado') {
            $("#divNTNinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#NTNDivFimVigencia").hide()
            $("#divNTNdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNTNPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNTNRenovacaoAut").hide()
        }
        if ($('[name="NTNRadioPrazo"]:checked').val() == 'renovacao') {
            $("#divNTNinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NTNDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNPeriodoRenovacao").hide()
            $("#divNTNRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }

        if ($('[name="AFPSRadioPrazo"]:checked').val() == 'determinado') {
            $("#divAFPSdatasPrazo").show()
            $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
        if ($('[name="AFPSRadioPrazo"]:checked').val() == 'indeterminado') {
            $("#divAFPSdatasPrazo").show()
            $("#AFPSDivFimVigencia").hide()
            $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
        }
        if ($('[name="AFPSRadioPrazo"]:checked').val() == 'renovacao') {
            $("#AFPSPrazoRenov").prop('checked', true)
            $("#divAFPSdatasPrazo").show()
            $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }

        if ($('[name="DISRadioPrazo"]:checked').val() == 'determinado') {
            $("#divDISdatasPrazo").show()
            $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
        if ($('[name="DISRadioPrazo"]:checked').val() == 'indeterminado') {
            $("#divDISdatasPrazo").show()
            $("#DISDivFimVigencia").hide()
            $("#divDISPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
        }
        if ($('[name="DISRadioPrazo"]:checked').val() == 'renovacao') {
            $("#DISPrazoRenov").prop('checked', true)
            $("#divDISdatasPrazo").show()
            $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }

        if ($('[name="NOTRadioPrazo"]:checked').val() == 'determinado') {
            $("#divNOTdatasPrazo").show()
            $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
        if ($('[name="NOTRadioPrazo"]:checked').val() == 'indeterminado') {
            $("#divNOTdatasPrazo").show()
            $("#NOTDivFimVigencia").hide()
            $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
        }
        if ($('[name="NOTRadioPrazo"]:checked').val() == 'renovacao') {
            $("#NOTPrazoRenov").prop('checked', true)
            $("#divNOTdatasPrazo").show()
            $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }

        if ($('[name="CESRadioPrazo"]:checked').val() == 'determinado') {
            $("#divCESdatasPrazo").show()
            $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
        if ($('[name="CESRadioPrazo"]:checked').val() == 'indeterminado') {
            $("#divCESdatasPrazo").show()
            $("#CESDivFimVigencia").hide()
            $("#divCESPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
        }
        if ($('[name="CESRadioPrazo"]:checked').val() == 'renovacao') {
            $("#CESPrazoRenov").prop('checked', true)
            $("#divCESdatasPrazo").show()
            $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }

        if ($("#AFPSnovoServReneg").val() || $("#_AFPSnovoServReneg").val()) {
            let object = {}
            object = {
                novo: () => {
                    $("#AFPSdivDetalhamento").show()
                },
                renegociacao: () => {
                    $("#AFPSdivDetalhamento").hide()
                }
            }

            if (getCurrentState() == TROCADEMINUTA || getCurrentState() == INICIO) {
                object = {
                    novo: () => {
                        $('[name="AFPSdetalhamentoProdNovo"]').parent().show();
                        // $('[name="AFPSdetalhamentoProdNovo"]').parent().show();
                        // $('[name="AFPSnovoValorContrato"]').parent().hide();
                        // $('[name="AFPSvalorServContrtAdt"]').parent().show();
                        // $('[name="AFPSvalorMensal"]').parent().show();
                        // $('[name="AFPSnovoValorContrato"]').parent().hide();
                        // $('[name="AFPSnovoValorMensal"]').parent().hide();
                    },
                    renegociacao: () => {
                        $('[name="AFPSdetalhamentoProdNovo"]').parent().hide();

                        // $('[name="AFPSdetalhamentoProdNovo"]').parent().hide();
                        // $('[name="AFPSnovoValorContrato"]').parent().show();
                        // $('[name="AFPSnovoValorMensal"]').parent().show();
                        // $('[name="AFPSvalorServContrtAdt"]').parent().hide();
                        // $('[name="AFPSvalorMensal"]').parent().hide();
                    }
                }
            }
            object[$("#AFPSnovoServReneg").val()]();
        }

        if ($("[name=NFPSRadioPrazo]:checked").val()) {

        }

        if (getCurrentState() == AVALICAOELABREV && !$("[name=aprovacaoSolicitacao]:checked").val()) {
            $("[name=escolhaAssinatura]").parent().hide();
        } else if (getCurrentState() == AVALICAOELABREV && $("#servicoJuridico").val() == 'notificacao') {
            $("[name=escolhaAssinatura]").parent().hide();
        }

        $('#divContratoPoint').css('pointer-events', 'none')

        if ($("#AFPSvaloresContratoAlt").val() == 'sim') {
            $('#ATNdivTabela').show()
        }
    }
}

function blockButtonNovoContrato() {
    var tipoContrato = $("#tipoContrato").val()

    if (tipoContrato == 'forncedorPrestadorServico') {
        if ($('#NFPSminutaContratoId').val() != '') {
            blockUploadsButtons('NFPSminutaContratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('NFPSminutaContratoFile', false);
        }

        if ($('#NFPSpropostaComercialId').val() != '') {
            blockUploadsButtons('NFPSpropostaComercialFile', true, false, false, true)
        } else {
            blockUploadsButtons('NFPSpropostaComercialFile', false);
        }

        if ($('#NFPSuploadEmailId').val() != '') {
            blockUploadsButtons('NFPSuploadEmailName', true, false, false, true)
        } else {
            blockUploadsButtons('NFPSuploadEmailName', false);
        }

        if ($('#NFPSdocumentosSocietariosId').val() != '') {
            blockUploadsButtons('NFPSdocumentosSocietariosFile', true, false, false, true)
        } else {
            blockUploadsButtons('NFPSdocumentosSocietariosFile', false);
        }

        if ($('#NFPSuploadLGPDDocId').val() != '') {
            blockUploadsButtons('NFPSuploadLGPDDocFile', true, false, false, true)
        } else {
            blockUploadsButtons('NFPSuploadLGPDDocFile', false);
        }

    } else if (tipoContrato == 'negocios') {
        if ($('#NTNminutaContratoId').val() != '') {
            blockUploadsButtons('NTNminutaContratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('NTNminutaContratoFile', false);
        }

        if ($('#NTNnbpId').val() != '') {
            blockUploadsButtons('NTNnbpFile', true, false, false, true)
        } else {
            blockUploadsButtons('NTNnbpFile', false);
        }

        if ($('#NTNpmId').val() != '') {
            blockUploadsButtons('NTNpmFile', true, false, false, true)
        } else {
            blockUploadsButtons('NTNpmFile', false);
        }

        if ($('#NTNuploadEmailId').val() != '') {
            blockUploadsButtons('NTNuploadEmailFile', true, false, false, true)
        } else {
            blockUploadsButtons('NTNuploadEmailFile', false);
        }

        if ($('#NTNdocumentosSocietariosId').val() != '') {
            blockUploadsButtons('NTNdocumentosSocietariosFile', true, false, false, true)
        } else {
            blockUploadsButtons('NTNdocumentosSocietariosFile', false);
        }

        if ($('#NTNuploadLGPDDocId').val() != '') {
            blockUploadsButtons('NTNuploadLGPDDocFile', true, false, false, true)
        } else {
            blockUploadsButtons('NTNuploadLGPDDocFile', false);
        }
    }

}

function BlockButtonAditivo() {
    var tipoContrato = $("#tipoContrato").val()
    if (tipoContrato == 'forncedorPrestadorServico') {


        if ($('#AFPSuploadEmailId').val() != '') {
            blockUploadsButtons('AFPSuploadEmailFile', true, false, false, true)
        } else {
            blockUploadsButtons('AFPSuploadEmailFile', false);
        }

        if ($('#AFPSpropostaComercialId').val() != '') {
            blockUploadsButtons('AFPSpropostaComercialFile', true, false, false, true)
        } else {
            blockUploadsButtons('AFPSpropostaComercialFile', false);
        }

        if ($('#AFPSdocumentosSocietariosId').val() != '') {
            blockUploadsButtons('AFPSdocumentosSocietariosFile', true, false, false, true)
        } else {
            blockUploadsButtons('AFPSdocumentosSocietariosFile', false);
        }

        if ($('#AFPSminutaContratoId').val() != '') {
            blockUploadsButtons('AFPSminutaContratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('AFPSminutaContratoFile', false);
        }

        if ($('#AFPSuploadLGPDDocId').val() != '') {
            blockUploadsButtons('AFPSuploadLGPDDocFile', true, false, false, true)
        } else {
            blockUploadsButtons('AFPSuploadLGPDDocFile', false);
        }

    } else if (tipoContrato == 'negocios') {

        if ($('#ATNminutaContratoId').val() != '') {
            blockUploadsButtons('ATNminutaContratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('ATNminutaContratoFile', false);
        }

        if ($('#ATNnbpId').val() != '') {
            blockUploadsButtons('ATNnbpFile', true, false, false, true)
        } else {
            blockUploadsButtons('ATNnbpFile', false);
        }

        if ($('#ATNpmId').val() != '') {
            blockUploadsButtons('ATNpmFile', true, false, false, true)
        } else {
            blockUploadsButtons('ATNpmFile', false);
        }

        if ($('#ATNuploadEmailId').val() != '') {
            blockUploadsButtons('ATNuploadEmailFile', true, false, false, true)
        } else {
            blockUploadsButtons('ATNuploadEmailFile', false);
        }

        if ($('#ATNdocumentosSocietariosId').val() != '') {
            blockUploadsButtons('ATNdocumentosSocietariosFile', true, false, false, true)
        } else {
            blockUploadsButtons('ATNdocumentosSocietariosFile', false);
        }

        if ($('#ATNuploadLGPDDocId').val() != '') {
            blockUploadsButtons('ATNuploadLGPDDocFile', true, false, false, true)
        } else {
            blockUploadsButtons('ATNuploadLGPDDocFile', false);
        }

        if ($('#ATNanexoTabelaId').val() != '') {
            blockUploadsButtons('ATNanexoTabelaFile', true, false, false, true)
        } else {
            blockUploadsButtons('ATNanexoTabelaFile', false);
        }

    }


}

function blockButtonDistrato() {
    var tipoContrato = $("#tipoContrato").val()
    if (tipoContrato == 'forncedorPrestadorServico') {

        if ($('#DISuploadEmailId').val() != '') {
            blockUploadsButtons('DISuploadEmailFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISuploadEmailFile', false);
        }

        if ($('#DISpropostaComercialId').val() != '') {
            blockUploadsButtons('DISpropostaComercialFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISpropostaComercialFile', false);
        }

        if ($('#DISdocumentosSocietariosId').val() != '') {
            blockUploadsButtons('DISdocumentosSocietariosFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISdocumentosSocietariosFile', false);
        }

        if ($('#DISminutaDistratoId').val() != '') {
            blockUploadsButtons('DISminutaDistratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISminutaDistratoFile', false);
        }

        if ($('#DISuploadLGPDDocId').val() != '') {
            blockUploadsButtons('DISuploadLGPDDocFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISuploadLGPDDocFile', false);
        }

    } else if (tipoContrato == 'negocios') {
        if ($('#DISminutaContratoId').val() != '') {
            blockUploadsButtons('DISminutaContratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISminutaContratoFile', false);
        }

        if ($('#DISnbpId').val() != '') {
            blockUploadsButtons('DISnbpFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISnbpFile', false);
        }

        if ($('#DISpmId').val() != '') {
            blockUploadsButtons('DISpmFile', true, false, false, true)
        } else {
            blockUploadsButtons('DISpmFile', false);
        }

        if ($('#DISuploadEmailIdA').val() != '') {
            blockUploadsButtons('DISuploadEmailFileA', true, false, false, true)
        } else {
            blockUploadsButtons('DISuploadEmailFileA', false);
        }

        if ($('#DISdocumentosSocietariosIdA').val() != '') {
            blockUploadsButtons('DISdocumentosSocietariosFileA', true, false, false, true)
        } else {
            blockUploadsButtons('DISdocumentosSocietariosFileA', false);
        }

        if ($('#DISuploadLGPDDocIdA').val() != '') {
            blockUploadsButtons('DISuploadLGPDDocFileA', true, false, false, true)
        } else {
            blockUploadsButtons('DISuploadLGPDDocFileA', false);
        }

    }
}

function blockButtonNotificacao() {
    var tipoContrato = $("#tipoContrato").val()

    if (tipoContrato == 'forncedorPrestadorServico') {
        if ($('#NOTuploadEmailId').val() != '') {
            blockUploadsButtons('NOTuploadEmailFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTuploadEmailFile', false);
        }

        if ($('#NOTpropostaComercialId').val() != '') {
            blockUploadsButtons('NOTpropostaComercialFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTpropostaComercialFile', false);
        }

        if ($('#NOTdocumentosSocietariosId').val() != '') {
            blockUploadsButtons('NOTdocumentosSocietariosFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTdocumentosSocietariosFile', false);
        }

        if ($('#NOTminutaContratoId').val() != '') {
            blockUploadsButtons('NOTminutaNotificaFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTminutaNotificaFile', false);
        }

        if ($('#NOTuploadLGPDDocId').val() != '') {
            blockUploadsButtons('NOTuploadLGPDDocFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTuploadLGPDDocFile', false);
        }
    } else {
        if ($('#NOTminutaContratoId').val() != '') {
            blockUploadsButtons('NOTminutaContratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTminutaContratoFile', false)
        }

        if ($('#NOTnbpId').val() != '') {
            blockUploadsButtons('NOTnbpFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTnbpFile', false);
        }

        if ($('#NOTpmId').val() != '') {
            blockUploadsButtons('NOTpmFile', true, false, false, true)
        } else {
            blockUploadsButtons('NOTpmFile', false);
        }

        if ($('#NOTuploadEmailIdA').val() != '') {
            blockUploadsButtons('NOTuploadEmailFileA', true, false, false, true)
        } else {
            blockUploadsButtons('NOTuploadEmailFileA', false);
        }

        if ($('#NOTdocumentosSocietariosIdA').val() != '') {
            blockUploadsButtons('NOTdocumentosSocietariosFileA', true, false, false, true)
        } else {
            blockUploadsButtons('NOTdocumentosSocietariosFileA', false);
        }

        if ($('#NOTuploadLGPDDocIdA').val() != '') {
            blockUploadsButtons('NOTuploadLGPDDocFileA', true, false, false, true)
        } else {
            blockUploadsButtons('NOTuploadLGPDDocFileA', false);
        }
    }
}

function blockButtonProposta() {
    if ($('#PROCuploadEmailId').val() != '') {
        blockUploadsButtons('PROCuploadEmailFile', true, false, false, true)
    } else {
        blockUploadsButtons('PROCuploadEmailFile', false);
    }

    if ($('#PROCpropostaComercialId').val() != '') {
        blockUploadsButtons('PROCpropostaComercialFile', true, false, false, true)
    } else {
        blockUploadsButtons('PROCpropostaComercialFile', false);
    }

    if ($('#PROCdocumentosSocietariosId').val() != '') {
        blockUploadsButtons('PROCdocumentosSocietariosFile', true, false, false, true)
    } else {
        blockUploadsButtons('PROCdocumentosSocietariosFile', false);
    }

    if ($('#PROCminutaPropostaId').val() != '') {
        blockUploadsButtons('PROCminutaPropostaFile', true, false, false, true)
    } else {
        blockUploadsButtons('PROCminutaPropostaFile', false);
    }

    if ($('#PROCuploadLGPDDocId').val() != '') {
        blockUploadsButtons('PROCuploadLGPDDocFile', true, false, false, true)
    } else {
        blockUploadsButtons('PROCuploadLGPDDocFile', false);
    }
}

function blockButtonCessao() {
    var tipoContrato = $("#tipoContrato").val()

    if (tipoContrato == 'forncedorPrestadorServico') {

        if ($('#CESuploadEmailId').val() != '') {
            blockUploadsButtons('CESuploadEmailFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESuploadEmailFile', false);
        }

        if ($('#CESpropostaComercialId').val() != '') {
            blockUploadsButtons('CESpropostaComercialFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESpropostaComercialFile', false);
        }

        if ($('#CESdocumentosSocietariosId').val() != '') {
            blockUploadsButtons('CESdocumentosSocietariosFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESdocumentosSocietariosFile', false);
        }

        if ($('#CESminutaCessaoId').val() != '') {
            blockUploadsButtons('CESminutaCessaoFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESminutaCessaoFile', false);
        }

        if ($('#CESuploadLGPDDocId').val() != '') {
            blockUploadsButtons('CESuploadLGPDDocFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESuploadLGPDDocFile', false);
        }

    } else {

        if ($('#CESminutaContratoId').val() != '') {
            blockUploadsButtons('CESminutaContratoFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESminutaContratoFile', false);
        }

        if ($('#CESnbpId').val() != '') {
            blockUploadsButtons('CESnbpFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESnbpFile', false);
        }

        if ($('#CESpmId').val() != '') {
            blockUploadsButtons('CESpmFile', true, false, false, true)
        } else {
            blockUploadsButtons('CESpmFile', false);
        }

        if ($('#CESuploadEmailIdA').val() != '') {
            blockUploadsButtons('CESuploadEmailFileA', true, false, false, true)
        } else {
            blockUploadsButtons('CESuploadEmailFileA', false);
        }

        if ($('#CESdocumentosSocietariosIdA').val() != '') {
            blockUploadsButtons('CESdocumentosSocietariosFileA', true, false, false, true)
        } else {
            blockUploadsButtons('CESdocumentosSocietariosFileA', false);
        }

        if ($('#CESuploadLGPDDocIdA').val() != '') {
            blockUploadsButtons('CESuploadLGPDDocFileA', true, false, false, true)
        } else {
            blockUploadsButtons('CESuploadLGPDDocFileA', false);
        }
    }
}

function jumpProcess() {
    consultDataset('workflowColleagueRole').success(data => {
        values = data.content.values.find(e => getCurrentUser() == e['workflowColleagueRolePK.colleagueId']);

        if (values['workflowColleagueRolePK.roleId'] == 'admin') {
            $('#div_pai_pular_fluxo').show();

        }
    })
}

function vaiPular() {
    if ($("#pularFluxoSim").is(':checked')) {
        $("#vaiPular").val("Sim")
    } else {
        $("#vaiPular").val("Nao")
    }
}

// $("#NFPSdataAviso").on('blur', () => {
//     var dataDeAviso = $("#NFPSdataAviso").val()
//     var dia2 = dataDeAviso.substr(0, 2)
//     var mes2 = dataDeAviso.substring(3, 5)
//     var ano2 = dataDeAviso.substring(6, 10)

//     var dataCont = ano2 + "/" + mes2 + "/" + dia2
//     $("#dataCont").val(dataCont)
// })

function setSelectedZoomItem(selectedItem) {
    switch (selectedItem.inputName) {
        case 'respAssinatura':
            $('#idRespAssinatura').val(selectedItem.UsuarioId)
            break;

        case 'NTNempPartNeg':
            $('#NTNempPartNegHidden').val(selectedItem.empresaGrupo)
    }
}

function removedZoomItem(removedItem) {
    switch (removedItem.inputName) {
        case 'respAssinatura':
            $('#idRespAssinatura').val('')
            break;
    }
}

const addFilesEventsNonFatherAndSon = () => {
    $(".deleteFile").on('click', (element) => {
        if (element.currentTarget.parentElement.childNodes[5].value) {
            let [type, adic] = element.currentTarget.parentElement.childNodes[5].name.split("Id")
            deleteDocument(element.currentTarget.parentElement.childNodes[5].value, type, adic)
            blockUploadsButtons(element.currentTarget.parentElement.childNodes[1].childNodes[1].name, false)
            // $(element.currentTarget.parentElement.childNodes[1]).attr('disabled', false);
            // $(element.currentTarget.parentElement.childNodes[1].childNodes[1]).attr('disabled', false);
        } else {
            TOAST('Nenhum arquivo adicionado!', 'warning');
        }
    });

    $(".visualizeFile").on('click', (element) => {

        if (element.currentTarget.parentElement.childNodes[5].value) {
            
            openDocument(element.currentTarget.parentElement.childNodes[5].value, 1000)
        } else {
            TOAST('Nenhum arquivo adicionado!', 'warning');
        }
    });

    $(document).on('click', '.downloadFile', (element) => {
        if (element.currentTarget.parentElement.childNodes[5].value) {
            let url = gerarLinkArquivo(element.currentTarget.parentElement.childNodes[5].value);
            element.currentTarget.children[0].href = url;
        } else {
            TOAST('Nenhum arquivo adicionado!', 'warning');
        }
    });

    $(".addFileNoFatherAndSon").each((index, element) => {
        let parentid = returnBelongingContainer(element.childNodes[1].id)
        console.log(parentid)
        let [type, adic] = element.childNodes[1].id.split("File")

        $(element.childNodes[1]).fileupload({
            dataType: 'json',
            start: () => FLUIGC.loading(window).show,
            done: (e, data) => {

                let file = data.result.files[0];
                let name = saveDocuments(file, null, PARENTID[parentid], type, adic);

                blockUploadsButtons(element.childNodes[1].name, true)
                // $(element).attr('disabled', true);
                // $(element.childNodes[1]).attr('disabled', true);
            },
            fail: (e, data) => {
                console.log("Falha no fileupload", data);
                TOAST('Não foi possivel publicar o arquivo.', 'danger');
            },
            stop: () => FLUIGC.loading(window).hide()
        });
    });
}

const addChildTables = (tableName) => {
    let type = tableName.split('tabelaUploadFiles')[0]
    let linha = wdkAddChild(tableName);

    if (tableName.includes('UploadFiles')) {
        $(".addFilePaiFilho").each((index, element) => {
            $(element.childNodes[1]).fileupload({
                dataType: 'json',
                start: () => FLUIGC.loading(window).show,
                done: (e, data) => {

                    let file = data.result.files[0];
                    console.log(file)
                    console.log(linha)
                    console.log(PARENTID[((PARENTID[type]) ? type : 'OUTR')])

                    saveDocuments(file, linha, PARENTID[((PARENTID[type]) ? type : 'OUTR')], type);

                    blockUploadsButtons('' + type + 'File___' + linha, true)
                    // $('#' + type + 'File___' + linha).attr('disabled', true);
                    // $('#' + type + 'File___' + linha).parent().attr('disabled', true);
                },
                fail: (e, data) => {
                    console.log("Falha no fileupload", data);
                    TOAST('Não foi possivel publicar o arquivo.', 'danger');
                },
                stop: () => FLUIGC.loading(window).hide()
            });
        });

        $('#' + type + 'btnVisualizar___' + linha).on('click', (element) => {
            if (element.currentTarget.parentElement.childNodes[5].value) {
                openDocument(element.currentTarget.parentElement.childNodes[5].value, 1000)
            } else {
                TOAST('Nenhum arquivo adicionado!', 'warning');
            }
        });

        
    }

    if ($('#prefixo').val() == 'AFPS' || $('#prefixo').val() == 'CES' || $('#prefixo').val() == 'NFPS' || $('#prefixo').val() == 'NTN' || $('#prefixo').val() == 'NOT' || $('#prefixo').val() == 'DIS') {
        $(`#${$('#prefixo').val()}banco___${linha}`).select2();
        $(`#${$('#prefixo').val()}bancoA___${linha}`).select2();
        $(`#${$('#prefixo').val()}bancoB___${linha}`).select2();
        $(`#${$('#prefixo').val()}bancoC___${linha}`).select2();



    }

    addDeleteLineEvent(tableName);
}

const addTableButtonsEvents = () => {
    $('#btnAddtabelaContratado').on('click', (element) => {
        addChildTables('NFPStabelaContratado');
    })

    $('#btnAddtabelaClienteRep').on('click', (element) => {
        addChildTables('NTNtabelaClienteRep');
    })

    $('#btnAddtabelaCorretIntermed').on('click', (element) => {
        addChildTables('NTNtabelaCorretIntermed');
    })

    $('#ATNbtnAddtabelaCorretIntermed').on('click', (element) => {
        addChildTables('ATNtabelaCorretIntermed');
    })

    $('#btnAddtabelaParSegu').on('click', (element) => {
        addChildTables('NTNtabelaParSegu');
    })

    $('#ATNbtnAddtabelaParSegu').on('click', (element) => {
        addChildTables('ATNtabelaParSegu');
    })

    $('#btnAddPROCtabelaContratado').on('click', (element) => {
        addChildTables('PROCtabelaContratado');
    })


    $('#btnAddtabelaUploadFile').on('click', (element) => {
        addChildTables('AFPStabelaUploadFiles');
    })

    $('#btnAddOStabelaUploadFile').on('click', (element) => {
        addChildTables('OStabelaUploadFiles');
    })

    $('#btnAddDIStabelaClienteRep').on('click', (element) => {
        addChildTables('DIStabelaClienteRep');
    })

    $('#DISbtnAddtabelaCorretIntermed').on('click', (element) => {
        addChildTables('DIStabelaCorretIntermed');
    })

    $('#DISbtnAddtabelaParSegu').on('click', (element) => {
        addChildTables('DIStabelaParSegu');
    })

    $('#btnAddNOTtabelaContratado').on('click', (element) => {
        addChildTables('NOTtabelaContratado');
    })

    $('#btnAddNOTtabelaClienteRep').on('click', (element) => {
        addChildTables('NOTtabelaClienteRep');
    })

    $('#NOTbtnAddtabelaCorretIntermed').on('click', (element) => {
        addChildTables('NOTtabelaCorretIntermed');
    })

    $('#NOTbtnAddtabelaParSegu').on('click', (element) => {
        addChildTables('NOTtabelaParSegu');
    })

    $('#btnAddAFPStabelaUploadFile').on('click', (element) => {
        addChildTables('AFPStabelaUploadFiles');
    })

    $('#btnAddAFPStabelaContratado').on('click', (element) => {
        addChildTables('AFPStabelaContratado');
    })

    $("#btnAddDIStabelaContratado").on("click", (element) => {
        addChildTables("DIStabelaContratado");
    })
    $('#btnAddDIStabelaUploadFile').on('click', (element) => {
        addChildTables('DIStabelaUploadFiles');
    })
    $('#btnAddCEStabelaUploadFile').on('click', (element) => {
        addChildTables('CEStabelaUploadFiles');
    })
    $('#btnAddPROCtabelaUploadFile').on('click', (element) => {
        addChildTables('PROCtabelaUploadFiles');
    })

    $('#btnAddNFPStabelaUploadFile').on('click', (element) => {
        addChildTables('NFPStabelaUploadFiles');
    })

    $('#btnAddNOTCtabelaUploadFile').on('click', (element) => {
        addChildTables('NOTtabelaUploadFiles');
    })

    $('#btnAddNTNtabelaUploadFile').on('click', (element) => {
        addChildTables('NTNtabelaUploadFiles');
    })

    $('#btnAddCEStabelaNovoCessionario').on('click', (element) => {
        addChildTables('CEStabelaNovoCessionario');
    })

    $('#btnAddCEStabelaCessionario').on('click', (element) => {
        addChildTables('CEStabelaCessionario');
    })

    $('#btnAddCEStabelaClienteRep').on('click', (element) => {
        addChildTables('CEStabelaClienteRep');
    })

    $('#btnAddCEStabelaClienteRepNovo').on('click', (element) => {
        addChildTables('CEStabelaClienteRepNovo');
    })

    $('#btnAddCEStabelaCorretIntermedNovo').on('click', (element) => {
        addChildTables('CEStabelaCorretIntermedNovo');
    })

    $('#CESbtnAddtabelaCorretIntermed').on('click', (element) => {
        addChildTables('CEStabelaCorretIntermed');
    })

    $('#btnAddCEStabelaDadosParceirosNovo').on('click', (element) => {
        addChildTables('CEStabelaDadosParceirosNovo');
    })

    $('#CESbtnAddtabelaParSegu').on('click', (element) => {
        addChildTables('CEStabelaParSegu');
    })

    $('#btnAddOTHERtabelaUploadFile').on('click', (element) => {
        addChildTables('OTHERStabelaUploadFiles');
    })

}

const addDeleteLineEvent = (tableName) => {
    $('.delLine').on('click', (element) => {
        if (tableName.includes('UploadFiles')) {
            if (element.currentTarget.parentElement.childNodes[5].value) deleteDocument(element.currentTarget.parentElement.childNodes[5].value);
            fnWdkRemoveChild(element.currentTarget.parentElement.childNodes[3])
        } else {
            fnWdkRemoveChild(element.currentTarget.parentElement.parentElement.childNodes[5].childNodes[3])
        }
    })
}

const deleteDocument = (documentId, type = '', clearAll = false, adic = "") => {
    top.WCMAPI.Create({
        url: "/api/public/2.0/documents/deleteDocument/" + documentId,
        method: "POST",
        success: e => {
            if (!clearAll) {
                $('[name="' + type + 'Name' + adic + '"]').val('')
                $('[name="' + type + 'Id' + adic + '"]').val('')
                TOAST("Arquivo deletado com sucesso.", "success")
            } else {
                console.log('Arquivo apagado :' + documentId)
            }
        },
        error: e => {
            console.log("Falha ao deletar o arquivo", e);
            TOAST("Falha ao deletar o arquivo.", "danger");
        }
    });
}

function gerarLinkArquivo(idDoc) {
    var link;
    var url = "/api/public/2.0/documents/getDownloadURL/" + idDoc;
    //var obj = {};
    //var params = JSON.stringify(obj);

    $.ajax(url, {
        async: false,
        method: "GET",
        dataType: "json",
        contentType: "application/json",
        //data: params,

        success: function (data) {
            link = data.content;
        },
        error: function (e) {
            console.log(e);
        }
    });

    return link;
}

const saveDocuments = (file, index, parentId, type, adic = "") => {
    $.ajax({
        url: '/api/public/ecm/document/createDocument',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            "description": file.name,
            "parentId": parentId,
            "attachments": [{
                "fileName": file.name
            }]
        })
    }).done((result) => {
        let documentId = result.content.id;
        console.log(documentId)
        console.log(file.name)
        if (index) {
            console.log("entrou no if do index")
            console.log(index)
            $('[name="' + type + 'Id___' + index + '"]').val(documentId);
            $('[name="' + type + 'Name___' + index + '"]').val(file.name);
        } else {
            $('[name="' + type + 'Name' + adic + '"]').val(file.name)
            $('[name="' + type + 'Id' + adic + '"]').val(documentId)
        }

        TOAST('Arquivo ' + file.name + ' publicado com sucesso.', 'success');
    }).fail((result) => {
        TOAST('Não foi possivel publicar o arquivo.', 'danger');
        console.log("Falha", result);
    });
}

const openDocument = (docId, docVersion) => {
    var parentOBJ = (window.opener) ? window.opener.parent : parent;
    var cfg = {
        url: "/ecm_documentview/documentView.ftl",
        maximized: true,
        title: "Visualizador de Documentos",
        callBack: function () {
            parentOBJ.ECM.documentView.getDocument(docId, docVersion);
        },
        customButtons: []
    };
    parentOBJ.ECM.documentView.panel = parentOBJ.WCMC.panel(cfg);
}

const changeView = () => {
    try {
        const options = JSON.parse(`{
        "Fornecedor/Prestador de serviço": "forncedorPrestadorServico",
        "Negócios": "negocios",
        "Novo contrato": "novoContrato",
        "Aditivo": "aditivo",
        "Distrato": "distrato",
        "Proposta comercial": "propostaComercial",
        "Notificação": "notificacao",
        "Cessão de contrato": "cessaoContrato",
        "Outras Solicitações": "outrasSolicitacoes"
        }`)

        let tipoContrato = (getCurrentMode() != "VIEW") ? $('[name="tipoContrato"]').val() : options[$('[name="tipoContrato"]').text()];
        let servicoJuridico = (getCurrentMode() != "VIEW") ? $('[name="servicoJuridico"]').val() : options[$('[name="servicoJuridico"]').text()];

        const options2 = JSON.parse(`{
        "novoContrato": "${(tipoContrato == "negocios") ? "div_pai_Novo_Contrato_Tipo_Negocio" : "div_pai_Novo_Contrato_Fornecedor_Prestador_Servico"}",
        "aditivo": "div_pai_Aditivo_Fornecedor_Prestador_Servico",
        "distrato": "div_pai_Aditivo_Distrato",
        "propostaComercial": "div_pai_Proposta_Comercial",
        "notificacao": "div_pai_Notificacao",
        "cessaoContrato": "div_pai_Cessao",
        "outrasSolicitacoes": "div_pai_outrasSolic"
        }`)

        if (servicoJuridico == "aditivo") {
            getPreviousContracts('AFPScontrato')
            if (tipoContrato == "negocios") {
                $("#AFPSvaloresContratoAlt").parent().show();
                $("#divAFPSNomeFantasiaGrupo").show();
                $("#AFPSNegocioCorretoraTable").show();
                $("#AFPSNegocioDadosParceirosTable").show();
                $("#AFPSdivDescricaoServ").show();
                $("#AFPSLabelContratante").text('Empresa Participante do Negócio')
                $("#AFPSDocumentos").hide();
                $("#ATNdocumentos").show();
                // $("#divAFPSPrazos").show()
                $("#divAFPSGarantia").show()
                $("#ATNdivQuadroComlFin").show();
                $("#AFPSValores").hide()
                $('#AFPSlabelPrimeiraTable').text('Dados do Cliente/Representante/ Estipulante')
            } else {
                $("#AFPSvaloresContratoAlt").parent().hide();
                $("#divAFPSNomeFantasiaGrupo").hide();
                $("#AFPSLabelContratante").text('Contratante')
                $("#AFPSNegocioCorretoraTable").hide();
                $("#AFPSNegocioDadosParceirosTable").hide();
                $("#AFPSdivDescricaoServ").hide();
                $("#AFPSDocumentos").show();
                $("#ATNdocumentos").hide();
                $("#ATNdivQuadroComlFin").hide();
                // $("#divAFPSPrazos").hide()
                $("#divAFPSGarantia").hide()
                $("#AFPSValores").show()
                $('#AFPSlabelPrimeiraTable').text('Dados da Contratada')
            }
        }
        if (servicoJuridico == "distrato") {
            getPreviousContracts('DIScontrato')
            if (tipoContrato == "negocios") {
                $(".distratoNegocios").show();
                $(".distratoFornecedor").hide();
            } else {
                $(".distratoNegocios").hide();
                $(".distratoFornecedor").show();
            }
        }
        if (servicoJuridico == "propostaComercial") {
            $(".prazo-determinado").parent().hide();
            $("#PROCPeriodoRenovacao").parent().hide();
            $("#PROCRenovacaoAut").parent().hide();
            getPreviousContracts('PROCcontrato');
            if (tipoContrato == "negocios") {
                $(".PROCfornecedor").hide();
            } else {
                $(".PROCfornecedor").show();
            }
        }
        if (servicoJuridico == "notificacao") {
            getPreviousContracts('NOTcontrato')
            if (tipoContrato == "negocios") {
                $(".notificacaoFornecedor").hide();
                $(".notificacaoNegocios").show();
            } else {
                $(".notificacaoFornecedor").show();
                $(".notificacaoNegocios").hide();
            }
        }
        if (servicoJuridico == "cessaoContrato") {
            getPreviousContracts('CEScontrato')
            if (tipoContrato == "negocios") {
                $(".cessaoFornecedor").hide();
                $(".cessaoNegocios").show();
            } else {
                $(".cessaoFornecedor").show();
                $(".cessaoNegocios").hide();
            }
        }

        if (servicoJuridico == "novoContrato") {
            $(".prazo-determinado").parent().hide();
            $("#NFPSPeriodoRenovacao").parent().hide();
            $("#NFPSRenovacaoAut").parent().hide();
            $("#NTNPeriodoRenovacao").parent().hide();
            $("#NTNRenovacaoAut").parent().hide();

        }


        if (tipoContrato && servicoJuridico) {
            hideAll(options2[servicoJuridico]);
            //clearFieldsAditivo();
            if (getCurrentState() == ABRIRPROCESSO) {
                clearDocuments();
            }
        }

        if (tipoContrato == "negocios") {
            $("#servicoJuridico option:contains(Proposta)").hide()
        } else {
            $("#servicoJuridico option:contains(Proposta)").show()
        }

        const prefixo = JSON.parse(`{
        "div_pai_Novo_Contrato_Tipo_Negocio":"NTN",
        "div_pai_Novo_Contrato_Fornecedor_Prestador_Servico":"NFPS",
        "div_pai_Aditivo_Fornecedor_Prestador_Servico":"AFPS",
        "div_pai_Aditivo_Distrato":"DIS",
        "div_pai_Proposta_Comercial":"PROC",
        "div_pai_Notificacao":"NOT",
        "div_pai_Cessao":"CES",
        "div_pai_outrasSolic":"OS"
        }`)

        $("#prefixo").val(prefixo[options2[servicoJuridico]])

    } catch (e) {
        throw e.message;
    }

}

const hideAll = (campo = "") => {
    $('#div_pai_Novo_Contrato_Fornecedor_Prestador_Servico').hide();
    $('#div_pai_Novo_Contrato_Tipo_Negocio').hide();
    $('#div_pai_Aditivo_Fornecedor_Prestador_Servico').hide();
    $('#div_pai_Aditivo_Distrato').hide();
    $('#div_pai_Proposta_Comercial').hide();
    $('#div_pai_Notificacao').hide();
    $('#div_pai_Cessao').hide();
    $('#div_pai_outrasSolic').hide();

    if (campo) {
        $('#' + campo).show();
    }
}

const consultDataset = (dataset, tabela, constraints) => {
    var cst = constraints != null ? constraints : []
    if (tabela != null) cst.push({
        "_field": "tablename",
        "_initialValue": tabela,
        "_finalValue": tabela,
        "_type": 1
    })
    return $.ajax({
        url: '/api/public/ecm/dataset/datasets',
        type: 'post',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({
            "name": dataset,
            "constraints": cst
        }),
        success: function (data) {}
    });
}

const returnBelongingContainer = (name) => {
    let resultString = "";
    for (i in name) {
        if (name.charAt(i) == (name.charAt(i)).toUpperCase()) {
            resultString += name.charAt(i)
        } else {
            break;
        }
    }
    return ((PARENTID[resultString]) ? resultString : 'OUTR');
}

const clearDocuments = () => {
    $(".anexoArea").each((index, element) => {
        if (element.childNodes[5].value) {
            deleteDocument(element.childNodes[5].value, '', true);
            element.childNodes[5].value = '';
            element.childNodes[3].value = '';
            blockUploadsButtons(element.childNodes[1].childNodes[1].name, false)
            // $(element.childNodes[1]).attr('disabled', false)
            // $(element.childNodes[1].childNodes[1]).attr('disabled', false)
        }
    })
}

const viewingEvents = () => {
    $('[name="NFPStituloContrato"]').on('change', (element) => {
        if (element.currentTarget.value) {
          $("#tituloContrato").val(element.currentTarget.value) 
        } 
    });

    $('[name="NFPSflagContratoVigencia"]').on('change', (element) => {
        if (element.currentTarget.checked) {
            $('[name="NFPSvigenciaFalta"').parent().show();
        } else {
            $('[name="NFPSvigenciaFalta"').parent().hide();
        }
    });

    $('[name="NTNcontVigenDetRenovAuto"]').on('change', (element) => {
        if (element.currentTarget.value) {
            $('[name="NTNvigenciaFalta"').parent().show();
        } else {
            $('[name="NTNvigenciaFalta"').parent().hide();
        }
    });
    $('[name="tipoContrato"]').on('change', (element) => {

        if ($("#servicoJuridico").val() == "aditivo" && $("#tipoContrato").val() == "negocios") {
            $('#divNBP').show()
        } else {
            $('#divNBP').hide()
        }


        // if ($("#tipoContrato").val() == "negocios") {
        if ($("#servicoJuridico").val() == "aditivo" || $("#servicoJuridico").val() == "novoContrato") {

            $('#divLGPD').show()
        }
        // } else {
        //     $('#divLGPD').hide()
        // }

    });
    $('[name="servicoJuridico"]').on('change', (element) => {

        if ($("#servicoJuridico").val() == "aditivo" && $("#tipoContrato").val() == "negocios") {
            $('#divNBP').show()
        } else {
            $('#divNBP').hide()
        }

    });
    
    $("[name=NFPSRadioPrazo]").on("change", (element) => {
        let id = element.currentTarget.id;
        let value = element.currentTarget.value;
        controlPrazos(id, value);
    })

    $("[name=NTNRadioPrazo]").on("change", (element) => {
        let id = element.currentTarget.id;
        let value = element.currentTarget.value;
        controlPrazos(id, value);
    })

    $("[name=PROCRadioPrazo]").on("change", (element) => {
        let id = element.currentTarget.id;
        let value = element.currentTarget.value;
        controlPrazos(id, value);
    })

    $("[name=AFPSRadioPrazo]").on("change", (element) => {
        let id = element.currentTarget.id;
        let value = element.currentTarget.value;
        controlPrazos(id, value);
    })

    $("[name=DISRadioPrazo]").on("change", (element) => {
        let id = element.currentTarget.id;
        let value = element.currentTarget.value;
        controlPrazos(id, value);
    })

    $("[name=NOTRadioPrazo]").on("change", (element) => {
        let id = element.currentTarget.id;
        let value = element.currentTarget.value;
        controlPrazos(id, value);
    })

    $("[name=CESRadioPrazo]").on("change", (element) => {
        let id = element.currentTarget.id;
        let value = element.currentTarget.value;
        controlPrazos(id, value);
    })

    $('[name="NFPSdataAviso"]').on('change', (element) => {
        if (element.currentTarget.value) {
            var dataDeAviso = element.currentTarget.value
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)

            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $('[name="dataNotificacaoSolicitante"]').val(dataCont);
        }
    });
    
    $('[name="NTNdataAviso"]').on('change', (element) => {
        if (element.currentTarget.value) {
            var dataDeAviso = element.currentTarget.value
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)

            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $('[name="dataNotificacaoSolicitante"]').val(dataCont);
            // $('[name="dataNotificacaoSolicitante"').val(element.currentTarget.value);
        }
    });

    $('[name="AFPSdataAviso"]').on('change', (element) => {
        if (element.currentTarget.value) {
            var dataDeAviso = element.currentTarget.value
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)

            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $('[name="dataNotificacaoSolicitante"]').val(dataCont);
            // $('[name="dataNotificacaoSolicitante"').val(element.currentTarget.value);
        }
    });

    $('[name="PROCdataAviso"]').on('change', (element) => {
        if (element.currentTarget.value) {
            var dataDeAviso = element.currentTarget.value
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)

            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $('[name="dataNotificacaoSolicitante"]').val(dataCont);
        }
    });

    $('[name="NOTdataAviso"]').on('change', (element) => {
        if (element.currentTarget.value) {
            var dataDeAviso = element.currentTarget.value
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)

            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $('[name="dataNotificacaoSolicitante"]').val(dataCont);
        }
    });

    $('[name="CESdataAviso"]').on('change', (element) => {
        if (element.currentTarget.value) {
            var dataDeAviso = element.currentTarget.value
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)

            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $('[name="dataNotificacaoSolicitante"]').val(dataCont);
        }
    });

    $('#AFPSvaloresContratoAlt').on('change', (element) => {
        if (element.currentTarget.value == 'sim') {
            $('[name="AFPSnovoServReneg"]').parent().show();
            $("#ATNdivTabela").show()
        } else {
            $('[name="AFPSnovoServReneg"]').parent().hide();
            $('[name="AFPSnovoServReneg"]').val('');

            $('[name="AFPSTabela"]').parent().hide();
            $("#ATNdivTabela").hide()

            $('[name="AFPSdetalhamentoProdNovo"]').parent().hide();
            $('[name="AFPSdetalhamentoProdNovo"]').val('');
        }
    });

    $('#AFPSnovoServReneg').on('change', (element) => {
        let object = {
            novo: () => {
                $('[name="AFPSdetalhamentoProdNovo"]').parent().show();

                // $('[name="AFPSvalorServContrtAdt"]').parent().show();
                // $('[name="AFPSvalorMensal"]').parent().show();
                // $('[name="AFPSnovoValorContrato"]').parent().hide();
                // $('[name="AFPSnovoValorMensal"]').parent().hide();
            },
            renegociacao: () => {
                $('[name="AFPSdetalhamentoProdNovo"]').parent().hide();

                // $('[name="AFPSnovoValorContrato"]').parent().show();
                // $('[name="AFPSnovoValorMensal"]').parent().show();
                // $('[name="AFPSvalorServContrtAdt"]').parent().hide();
                // $('[name="AFPSvalorMensal"]').parent().hide();
            }
        }
        if (object[element.currentTarget.value]) {
            object[element.currentTarget.value]();
        } else {
            $('[name="AFPSdetalhamentoProdNovo"]').parent().hide();

            // $('[name="AFPSnovoValorContrato"]').parent().hide();
            // $('[name="AFPSnovoValorMensal"]').parent().hide();
            // $('[name="AFPSvalorServContrtAdt"]').parent().hide();
            // $('[name="AFPSvalorMensal"]').parent().hide();
            // $('[name="AFPSnovoValorContrato"]').val('');
            // $('[name="AFPSnovoValorMensal"]').val('');
            // $('[name="AFPSvalorServContrtAdt"]').val('');
            // $('[name="AFPSvalorMensal"]').val('');
        }
    })

    $('#DISvalorPendenteQuitacao').on('change', (element) => {
        if (element.currentTarget.value == 'sim') {
            $('[name="DISvalorPendente"]').parent().show();
            $('[name="DISobrigPendenteText"]').parent().show();
        } else {
            $('[name="DISvalorPendente"]').parent().hide();
            $('[name="DISobrigPendenteText"]').parent().hide();
            $('[name="DISvalorPendente"]').val('');
        }
    });

    $('#DISobrigPendenteCumpri').on('change', (element) => {
        if (element.currentTarget.value == 'sim') {
            $('[name="DISobrigPendente"]').parent().show();
        } else {
            $('[name="DISobrigPendente"]').parent().hide();
            $('[name="DISobrigPendente"]').val('');
        }
    });

    $('#DISdescricaoPendencia').on('change', (element) => {
        if (element.currentTarget.value == 'sim') {
            $('[name="DISobrigPendenteText"]').parent().show();
        } else {
            $('[name="DISobrigPendenteText"]').parent().hide();
            $('[name="DISobrigPendenteText"]').val('');
        }
    });

    $('#NOTtipoNotificacao').on('change', (element) => {
        let object = {
            encerrarContrato: () => {
                hideAllTypesNotification();
                $('.encerrarContrato').show();
            },
            notificaDescumprimento: () => {
                hideAllTypesNotification();
                $('.notificaDescumprimento').show();
            },
            cobrarPendenciasFinanceiras: () => {
                hideAllTypesNotification();
                $('.cobrarPendenciasFinanceiras').show();
                $("#NOTdivValorMulta").addClass("fs-display-none");
            },
            alteracaoTabelaPrecos: () => {
                hideAllTypesNotification();
                $('.alteracaoTabelaPrecos').show();
            },
            outros: () => {
                hideAllTypesNotification();
                $('.outros').show();
                $("#NOTdivValorMulta").addClass("fs-display-none");
            }
        }

        object[element.currentTarget.value]();
    });

    $('.flag').on('change', (element) => {
        let obj = {
            "NTNflagMulta": (checked) => {
                if (checked) {
                    $(".NTNdivValorMulta").removeAttr("style").show();
                    $("#NTnvalorMulta").removeAttr("style").show();
                } else {
                    $(".NTNdivValorMulta").css("display", 'none');
                }
            },
            "NOTflagMultaDC": (checked) => {
                if (checked) {
                    $(".NOTdivValorMultaDC").removeAttr("style").show();
                    $("#NOTvalorMulta").removeAttr("style").show();
                } else {
                    $(".NOTdivValorMultaDC").css("display", 'none');
                }
            },
            "NOTflagMultaPF": (checked) => {
                if (checked) {
                    $(".NOTdivValorMultaPF").removeAttr("style").show();
                    $("#NOTvalorMultaPF").removeAttr("style").show();
                } else {
                    $(".NOTdivValorMultaPF").css("display", 'none');
                }
            },
            "NOTflagMulta": (checked) => {
                if (checked) {
                    $(".NOTdivValorMulta").removeAttr("style").show();
                    $("#NOTvalorMulta").removeAttr("style").show();
                } else {
                    $(".NOTdivValorMulta").css("display", 'none');
                }
            },
            "NOTflagEncerraContrato": (checked) => {
                if (checked) {
                    $('#NOTterminoContratoEsperada').parent().show()
                } else {
                    $('#NOTterminoContratoEsperada').parent().hide()
                }
            },
            "NOTflagpendenteQuitacao": (checked) => {
                if (checked) {
                    $(".NOTdivValorPendente").removeAttr("style").show();
                    $("#NOTvalorPendente").removeAttr("style").show();
                } else {
                    $(".NOTdivValorPendente").css("display", 'none');
                }
            },
            "NOTobrigacaoPendenteCump": (checked) => {
                if (checked) {
                    $('.NOTdivObrigPendenteQual').removeAttr("style").show();
                    $('#NOTobrigPendenteQual').removeAttr("style").show();
                } else {
                    $('.NOTdivObrigPendenteQual').css("display", 'none');
                }
            },
            "AFPSflagContratoVigencia": (checked) => {
                if (checked) {
                    $('.AFPSdivVigenciaFalta').removeAttr("style").show();
                    $('#AFPSvigenciaFalta').removeAttr("style").show();
                } else {
                    $('.AFPSdivVigenciaFalta').css("display", 'none');
                }
            },
            "NTNcontVigenDetRenovAuto": (checked) => {
                if (checked) {
                    $('.NTNdivVigenciaFalta').removeAttr("style").show();
                    $('#NTNvigenciaFalta').removeAttr("style").show();
                } else {
                    $('.NTNdivVigenciaFalta').css("display", 'none');
                }
            },
            "NTNquaisUpfrontBonus": (checked) => {
                if (checked) {
                    $(".NTNdivBonusDetalhamento").removeAttr("style").show();
                    $("#NTNBonusDetalhamento").removeAttr("style").show();
                } else {
                    $(".NTNdivBonusDetalhamento").css("display", 'none');
                }
            },
            "NTNquaisProfitSharing": (checked) => {
                if (checked) {
                    $(".NTNdivProfitSharingDetalhamento").removeAttr("style").show();
                    $("#NTNProfitSharingDetalhamento").removeAttr("style").show();
                } else {
                    $(".NTNdivProfitSharingDetalhamento").css("display", 'none');
                }
            },
            "NTNquaisIncluAltDespVar": (checked) => {
                if (checked) {
                    $(".NTNdivIncluAltDespVarDet").removeAttr("style").show();
                    $("#NTNIncluAltDespVarDet").removeAttr("style").show();
                } else {
                    $(".NTNdivIncluAltDespVarDet").css("display", 'none');
                }
            },
            "NTNquaisBonusPerformance": (checked) => {
                if (checked) {
                    $(".NTNdivBonusPerformDet").removeAttr("style").show();
                    $("#NTNBonusPerformDet").removeAttr("style").show();
                } else {
                    $(".NTNdivBonusPerformDet").css("display", 'none');
                }
            },
            "NTNquaisReembCartaCredito": (checked) => {
                if (checked) {
                    $(".NTNdivReembCartaCreditoDet").removeAttr("style").show();
                    $("#NTNReembCartaCreditoDet").removeAttr("style").show();
                } else {
                    $(".NTNdivReembCartaCreditoDet").css("display", 'none');
                }
            },
            "NTNquaisIncluAltDespPrestServ": (checked) => {
                if (checked) {
                    $(".NTNdivIncluAltDespPrestServDet").removeAttr("style").show();
                    $("#NTNIncluAltDespPrestServDet").removeAttr("style").show();
                } else {
                    $(".NTNdivIncluAltDespPrestServDet").css("display", 'none');
                }
            },
            "AFPSquaisUpfrontBonus": (checked) => {
                if (checked) {
                    $("#divAFPSBonusDetalhamento").removeAttr("style").show();
                    $("#AFPSBonusDetalhamento").removeAttr("style").show();
                } else {
                    $("#divAFPSBonusDetalhamento").css("display", 'none');
                }
            },
            "AFPSquaisProfitSharing": (checked) => {
                if (checked) {
                    $("#divAFPSProfitSharingDetalhamento").removeAttr("style").show();
                    $("#AFPSProfitSharingDetalhamento").removeAttr("style").show();
                } else {
                    $("#divAFPSProfitSharingDetalhamento").css("display", 'none');
                }
            },
            "AFPSquaisIncluAltDespVar": (checked) => {
                if (checked) {
                    $("#divAFPSIncluAltDespVarDet").removeAttr("style").show();
                    $("#AFPSIncluAltDespVarDet").removeAttr("style").show();
                } else {
                    $("#divAFPSIncluAltDespVarDet").css("display", 'none');
                }
            },
            "AFPSquaisBonusPerformance": (checked) => {
                if (checked) {
                    $("#divAFPSBonusPerformDet").removeAttr("style").show();
                    $("#AFPSBonusPerformDet").removeAttr("style").show();
                } else {
                    $("#divAFPSBonusPerformDet").css("display", 'none');
                }
            },
            "AFPSquaisReembCartaCredito": (checked) => {
                if (checked) {
                    $("#divAFPSReembCartaCreditoDet").removeAttr("style").show();
                    $("#AFPSReembCartaCreditoDet").removeAttr("style").show();
                } else {
                    $("#divAFPSReembCartaCreditoDet").css("display", 'none');
                }
            },
            "AFPSquaisIncluAltDespPrestServ": (checked) => {
                if (checked) {
                    $("#divAFPSIncluAltDespPrestServDet").removeAttr("style").show();
                    $("#AFPSIncluAltDespPrestServDet").removeAttr("style").show();
                } else {
                    $("#divAFPSIncluAltDespPrestServDet").css("display", 'none');
                }
            },
            "DISquaisUpfrontBonus": (checked) => {
                if (checked) {
                    $("#divDISBonusDetalhamento").removeAttr("style").show();
                    $("#DISBonusDetalhamento").removeAttr("style").show();
                } else {
                    $("#divDISBonusDetalhamento").css("display", 'none');
                }
            },
            "DISquaisProfitSharing": (checked) => {
                if (checked) {
                    $("#divDISProfitSharingDetalhamento").removeAttr("style").show();
                    $("#DISProfitSharingDetalhamento").removeAttr("style").show();
                } else {
                    $("#divDISProfitSharingDetalhamento").css("display", 'none');
                }
            },
            "DISquaisIncluAltDespVar": (checked) => {
                if (checked) {
                    $("#divDISIncluAltDespVarDet").removeAttr("style").show();
                    $("#DISIncluAltDespVarDet").removeAttr("style").show();
                } else {
                    $("#divDISIncluAltDespVarDet").css("display", 'none');
                }
            },
            "DISquaisBonusPerformance": (checked) => {
                if (checked) {
                    $("#divDISBonusPerformDet").removeAttr("style").show();
                    $("#DISBonusPerformDet").removeAttr("style").show();
                } else {
                    $("#divDISBonusPerformDet").css("display", 'none');
                }
            },
            "DISquaisReembCartaCredito": (checked) => {
                if (checked) {
                    $("#divDISReembCartaCreditoDet").removeAttr("style").show();
                    $("#DISReembCartaCreditoDet").removeAttr("style").show();
                } else {
                    $("#divDISReembCartaCreditoDet").css("display", 'none');
                }
            },
            "DISquaisIncluAltDespPrestServ": (checked) => {
                if (checked) {
                    $("#divDISIncluAltDespPrestServDet").removeAttr("style").show();
                    $("#DISIncluAltDespPrestServDet").removeAttr("style").show();
                } else {
                    $("#divDISIncluAltDespPrestServDet").css("display", 'none');
                }
            },
            "NOTquaisUpfrontBonus": (checked) => {
                if (checked) {
                    $("#divNOTBonusDetalhamento").removeAttr("style").show();
                    $("#NOTBonusDetalhamento").removeAttr("style").show();
                } else {
                    $("#divNOTBonusDetalhamento").css("display", 'none');
                }
            },
            "NOTquaisProfitSharing": (checked) => {
                if (checked) {
                    $("#divNOTProfitSharingDetalhamento").removeAttr("style").show();
                    $("#NOTProfitSharingDetalhamento").removeAttr("style").show();
                } else {
                    $("#divNOTProfitSharingDetalhamento").css("display", 'none');
                }
            },
            "NOTquaisIncluAltDespVar": (checked) => {
                if (checked) {
                    $("#divNOTIncluAltDespVarDet").removeAttr("style").show();
                    $("#NOTIncluAltDespVarDet").removeAttr("style").show();
                } else {
                    $("#divNOTIncluAltDespVarDet").css("display", 'none');
                }
            },
            "NOTquaisBonusPerformance": (checked) => {
                if (checked) {
                    $("#divNOTBonusPerformDet").removeAttr("style").show();
                    $("#NOTBonusPerformDet").removeAttr("style").show();
                } else {
                    $("#divNOTBonusPerformDet").css("display", 'none');
                }
            },
            "NOTquaisReembCartaCredito": (checked) => {
                if (checked) {
                    $("#divNOTReembCartaCreditoDet").removeAttr("style").show();
                    $("#NOTReembCartaCreditoDet").removeAttr("style").show();
                } else {
                    $("#divNOTReembCartaCreditoDet").css("display", 'none');
                }
            },
            "NOTquaisIncluAltDespPrestServ": (checked) => {
                if (checked) {
                    $("#divNOTIncluAltDespPrestServDet").removeAttr("style").show();
                    $("#NOTIncluAltDespPrestServDet").removeAttr("style").show();
                } else {
                    $("#divNOTIncluAltDespPrestServDet").css("display", 'none');
                }
            },


            "CESquaisUpfrontBonus": (checked) => {
                if (checked) {
                    $("#divCESBonusDetalhamento").removeAttr("style").show();
                    $("#CESBonusDetalhamento").removeAttr("style").show();
                } else {
                    $("#divCESBonusDetalhamento").css("display", 'none');
                }
            },
            "CESquaisProfitSharing": (checked) => {
                if (checked) {
                    $("#divCESProfitSharingDetalhamento").removeAttr("style").show();
                    $("#CESProfitSharingDetalhamento").removeAttr("style").show();
                } else {
                    $("#divCESProfitSharingDetalhamento").css("display", 'none');
                }
            },
            "CESquaisIncluAltDespVar": (checked) => {
                if (checked) {
                    $("#divCESIncluAltDespVarDet").removeAttr("style").show();
                    $("#CESIncluAltDespVarDet").removeAttr("style").show();
                } else {
                    $("#divCESIncluAltDespVarDet").css("display", 'none');
                }
            },
            "CESquaisBonusPerformance": (checked) => {
                if (checked) {
                    $("#divCESBonusPerformDet").removeAttr("style").show();
                    $("#CESBonusPerformDet").removeAttr("style").show();
                } else {
                    $("#divCESBonusPerformDet").css("display", 'none');
                }
            },
            "CESquaisReembCartaCredito": (checked) => {
                if (checked) {
                    $("#divCESReembCartaCreditoDet").removeAttr("style").show();
                    $("#CESReembCartaCreditoDet").removeAttr("style").show();
                } else {
                    $("#divCESReembCartaCreditoDet").css("display", 'none');
                }
            },
            "CESquaisIncluAltDespPrestServ": (checked) => {
                if (checked) {
                    $("#divCESIncluAltDespPrestServDet").removeAttr("style").show();
                    $("#CESIncluAltDespPrestServDet").removeAttr("style").show();
                } else {
                    $("#divCESIncluAltDespPrestServDet").css("display", 'none');
                }
            },
        }
        obj[element.currentTarget.name](element.currentTarget.checked);
    });

    $("[name=aprovacaoSolicitacao]").on("change", e => {
        value = e.target.value;
        if (value == "APROVADO" && getCurrentState() == AVALICAOELABREV && $("#servicoJuridico").val() != 'notificacao') {
            $("[name=escolhaAssinatura]").parent().show();
        } else if (value == "APROVADO" && $("#servicoJuridico").val() == 'notificacao') {
            $("#divAssinaturaExterno").hide();
            $("#divAssinaturaInterno").hide();

        } else {
            $("[name=escolhaAssinatura]").parent().hide();
        }

    })
}

function controlPrazos(id, value) {
    if (id.includes('NFPS')) {
        if (value == 'determinado') {
            $("#divNFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSRenovacaoAut").hide()
        } else if (value == 'indeterminado') {
            $("#divNFPSinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#NFPSDivFimVigencia").hide()
            $("#divNFPSdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNFPSPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNFPSRenovacaoAut").hide()
        } else if (value == 'renovacao') {
            $("#divNFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNFPSPeriodoRenovacao").hide()
            $("#divNFPSRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
    } else if (id.includes('PROC')) {
        if (value == 'determinado') {
            $("#divPROCinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#PROCDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCRenovacaoAut").hide()
        } else if (value == 'indeterminado') {
            $("#divPROCinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#PROCDivFimVigencia").hide()
            $("#divPROCdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divPROCPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divPROCRenovacaoAut").hide()
        } else if (value == 'renovacao') {
            $("#divPROCinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#PROCDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divPROCPeriodoRenovacao").hide()
            $("#divPROCRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
    } else if (id.includes('NTN')) {
        if (value == 'determinado') {
            $("#divNTNinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NTNDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNRenovacaoAut").hide()
        } else if (value == 'indeterminado') {
            $("#divNTNinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#NTNDivFimVigencia").hide()
            $("#divNTNdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNTNPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNTNRenovacaoAut").hide()
        } else if (value == 'renovacao') {
            $("#divNTNinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NTNDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNTNPeriodoRenovacao").hide()
            $("#divNTNRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
    } else if (id.includes('AFPS')) {
        $("#divAFPSdatasPrazo").show()
        if (value == 'determinado') {
            $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSRenovacaoAut").hide()
        } else if (value == 'indeterminado') {
            $("#divAFPSinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#AFPSDivFimVigencia").hide()
            $("#divAFPSdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divAFPSRenovacaoAut").hide()
        } else if (value == 'renovacao') {
            $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divAFPSPeriodoRenovacao").hide()
            $("#divAFPSRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
    } else if (id.includes('DIS')) {
        $("#divDISdatasPrazo").show()
        if (value == 'determinado') {
            $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISRenovacaoAut").hide()
        } else if (value == 'indeterminado') {
            $("#divDISinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#DISDivFimVigencia").hide()
            $("#divDISdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divDISPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divDISRenovacaoAut").hide()
        } else if (value == 'renovacao') {
            $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divDISPeriodoRenovacao").hide()
            $("#divDISRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
    } else if (id.includes('NOT')) {
        $("#divNOTdatasPrazo").show()
        if (value == 'determinado') {
            $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTRenovacaoAut").hide()
        } else if (value == 'indeterminado') {
            $("#divNOTinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#NOTDivFimVigencia").hide()
            $("#divNOTdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divNOTRenovacaoAut").hide()
        } else if (value == 'renovacao') {
            $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divNOTPeriodoRenovacao").hide()
            $("#divNOTRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
    } else if (id.includes('CES')) {
        $("#divCESdatasPrazo").show()
        if (value == 'determinado') {
            $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESRenovacaoAut").hide()
        } else if (value == 'indeterminado') {
            $("#divCESinicioVigencia").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#CESDivFimVigencia").hide()
            $("#divCESdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divCESPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
            $("#divCESRenovacaoAut").hide()
        } else if (value == 'renovacao') {
            $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
            $("#divCESPeriodoRenovacao").hide()
            $("#divCESRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
        }
    }

}

const hideAllTypesNotification = () => {

    $('.encerrarContrato').hide()
    $('.notificaDescumprimento').hide()
    $('.cobrarPendenciasFinanceiras').hide()
    $('.alteracaoTabelaPrecos').hide()
    $('.outros').hide()

    if (getCurrentState() != ABRIRPROCESSO) {
        if ($('#NOTtipoNotificacao').val() == "encerrarContrato") {
            $('.encerrarContrato').show()
        } else if ($('#NOTtipoNotificacao').val() == "notificaDescumprimento") {
            $('.notificaDescumprimento').show()
        } else if ($('#NOTtipoNotificacao').val() == "cobrarPendenciasFinanceiras") {
            $('.cobrarPendenciasFinanceiras').show()
        } else if ($('#NOTtipoNotificacao').val() == "alteracaoTabelaPrecos") {
            $('.alteracaoTabelaPrecos').show()
        } else if ($('#NOTtipoNotificacao').val() == "outros") {
            $('.outros').show()
        }
    }

}

const addMaskInputs = () => {
    $('.dinheiro').mask("#.##0,00", {
        reverse: true
    });

    $(document).on('keydown', '.cpfCnpj', function (e) {

        var digit = e.key.replace(/\D/g, '');

        var value = $(this).val().replace(/\D/g, '');

        var size = value.concat(digit).length;

        $(this).mask((size <= 11) ? '000.000.000-00' : '00.000.000/0000-00');
    });

    $('.phone').mask('(00) 0000-00009');

    $(document).on("keydown blur", '.email', (element) => {
        if ((element.key == ';' || element.type == "focusout") && element.currentTarget.value != "") {
            let email = element.currentTarget.value.split(';').filter((e, index) => {
                e = e.trim();
                if (!(e.includes('@') && e.includes('.'))) {
                    TOAST('Email invalido retirado do campo!', 'danger');
                } else {
                    return e
                }
            });
            element.currentTarget.value = email.join('; ')
        }
    });

    $(".cep").mask("99.999-999");

    $(".agencia").mask("9999", {
        reverse: true
    });

    $(".contacorrente").mask("9999999999-9", {
        reverse: true
    })

    $(".uf").mask("AA");

    $(".dataFluig").mask("99/99/9999");
    $(document).on("blur", '.uf', e => {
        e.currentTarget.value = e.currentTarget.value.toUpperCase()
    })
}

const getPreviousContracts = (nameCampo) => {
    consultDataset('ds_processo_contrato', null, [{
        "_field": "servicoJuridico",
        "_initialValue": 'novoContrato',
        "_type": 1
    }]).success((data) => {
        let type = ''
        let dataSelect = [];
        let results = data.content.values;
        if ($('#tipoContrato').val() == 'forncedorPrestadorServico') {
            type = 'forncedorPrestadorServico';
            results = results.map(function (el) {
                if (el.tipoContrato == 'forncedorPrestadorServico') {
                    dataSelect.push({
                        id: el["documentid"],
                        text: el["NFPScontratante"] + " - " + el["NFPStituloContrato"]
                    });
                }
            });
        } else if ($('#tipoContrato').val() == 'negocios') {
            type = 'negocios';
            results = results.map(function (el) {
                if (el.tipoContrato == 'negocios') {
                    dataSelect.push({
                        id: el["documentid"],
                        text: el["NTNtituloContrato"] + " - " + el["NTNempPartNeg"]
                    });
                }
            });
        }

        dataSelect.unshift({
            id: '',
            text: ''
        })

        let valueContrato = $(`#${nameCampo}`).val();
        $(`#${nameCampo}`).empty();
        if (getCurrentState() == ABRIRPROCESSO || getCurrentState() == INICIO || getCurrentState() == TROCADEMINUTA) {

            $(`#${nameCampo}`).select2({
                data: dataSelect,
                allowClear: true,
                placeholder: "Selecione o Contrato",
                theme: "bootstrap",
                language: "pt-BR"
            }).on('select2:select', (dataChange) => {
                $("#CEScedente").html('');
                if (nameCampo == "AFPScontrato") {
                    addFieldsAditivo(dataChange, type);
                } else if (nameCampo == "DIScontrato") {
                    addFieldsDistrato(dataChange, type);
                } else if (nameCampo == "PROCcontrato") {
                    addFieldsProposta(dataChange, type)
                } else if (nameCampo == "NOTcontrato") {
                    addFieldsNotificacao(dataChange, type)
                } else if (nameCampo == "CEScontrato") {
                    addFieldsCessao(dataChange, type)
                }
            });

            $(`#${nameCampo}`).on("select2:unselect", () => {
                if (nameCampo == "AFPScontrato") {
                    clearFieldsAditivo();
                } else if (nameCampo == "DIScontrato") {
                    clearFieldsDistrato()
                } else if (nameCampo == "NOTcontrato") {
                    clearFieldsNotificacao()
                } else if (nameCampo == "CEScontrato") {
                    clearFieldsCessao()
                }
            })

            $(`#${nameCampo}`).val(valueContrato).change()

        } else if (getCurrentState() == AVALICAOELABREV || getCurrentState() == PROVASSINATURAPARCEIRO || getCurrentState() == ANALISE || getCurrentState() == PROVASSINATURAINTER || getCurrentState() == GRAVACONTRATO || getCurrentState() == FALHACRIACAO || getCurrentState() == REALIZACADASTROFORN || getCurrentState() == CADASTRO_ACSEL || getCurrentState() == AVALIACAO || getCurrentState() == COMPLIANCE) {
            $(`#${nameCampo}`).select2({
                data: dataSelect,
                allowClear: true,
                placeholder: "Selecione o Contrato",
                theme: "bootstrap",
                language: "pt-BR"
            }).on('select2:select', (dataChange) => {
                $("#CEScedente").html('');
                if (nameCampo == "AFPScontrato") {
                    addFieldsAditivo(dataChange, type);
                }
            });

            $(`#${nameCampo}`).on("select2:unselect", () => {
                if (nameCampo == "AFPScontrato") {
                    clearFieldsAditivo();
                }
            })

            $(`#${nameCampo}`).val(valueContrato).change()
            $(`#${nameCampo}`).parent().css('pointer-events', 'none')

        }
    })
}

const addFieldsAditivo = (dataChange, type) => {
    consultDataset('ds_processo_contrato', null, [{
        "_field": "documentid",
        "_initialValue": dataChange.target.value,
        "_finalValue": dataChange.target.value,
        "_type": 1
    }]).success(newData => {

        let valores = {
            tituloContrato: '',
            contratante: '',
            empPartNeg: '',
            objetoContrato: '',
            contratoIndeterminado: '',
            flagContratoVigencia: 'checked',
            dataAviso: '',
            inicioVigencia: '',
            fimVigencia: '',
            valorTotal1: '',
            valorTotalMensal1: '',
            valorTotalAnual1: '',
            observacoes: '',
            minutaContratoName: '',
            nbpName: '',
            pmName: '',
            uploadEmailName: '',
            uploadOutrosDocName: '',
            uploadLGPDDocName: '',
            propostaComercialName: '',
            documentosSocietariosName: '',
            minutaContratoId: '',
            nbpId: '',
            pmId: '',
            uploadEmailId: '',
            uploadOutrosDocId: '',
            propostaComercialId: '',
            documentosSocietariosId: '',
            uploadLGPDDocId: '',
            outrosDetalhes: '',
            nomeFantGrup: '',
            objetoContrato: '',
            prodComeInter: '',
            contNegAdit: '',
            quaisUpfrontBonus: '',
            BonusDetalhamento: '',
            quaisBonusPerformance: '',
            BonusPerformDet: '',
            quaisProfitSharing: '',
            ProfitSharingDetalhamento: '',
            quaisReembCartaCredito: '',
            ReembCartaCreditoDet: '',
            quaisInvestMarketMinGarant: '',
            quaisFindesFee: '',
            quaisIncluAltDespAgeCamp: '',
            quaisIncluAltDespPrestServ: '',
            IncluAltDespPrestServDet: '',
            quaisIncluAltDespVar: '',
            IncluAltDespVarDet: '',
            garantiaContrato: '',
            tipoGarantia: '',
            DescGarantia: '',
            inicioVidenciaGarantia: '',
            fimVigenciaGarantia: '',
            dataAvisoVenc: '',
            RadioPrazo: '',
            inicioVigencia: '',
            fimVigencia: '',
            dataAviso: '',
            AvisoPrevio: '',
            avisoPrevio: '',
            RenovacaoAutomatica: ''
        }
        if (type == 'forncedorPrestadorServico') {
            console.log(valores)
            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)
            $(`#riscoContrato`).parent().css('pointer-events', 'none')

            for (let property in newData.content.values[0]) {
                if (property.includes('NFPS')) {
                    if (valores.hasOwnProperty(property.split('NFPS')[1])) {
                        valores[property.split('NFPS')[1]] = newData.content.values[0][property]
                    }
                }
            }

            consultDataset('ds_processo_contrato', 'NFPStabelaContratado', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {

                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('AFPStabelaContratado');
                    $('#AFPSrazaoSocialC___' + linha).val(element.NFPSrazaoSocial)
                    $('#AFPSnomeFantasiaC___' + linha).val(element.NFPSnomeFantasia)
                    $('#AFPScpfCnpjC___' + linha).val(element.NFPScpfCnpj)
                    $('#AFPSemailC___' + linha).val(element.NFPSemail)
                    $('#AFPStelefoneC___' + linha).val(element.NFPStelefone)
                    $('#AFPSenderecoC___' + linha).val(element.NFPSendereco)
                    $('#AFPScepC___' + linha).val(element.NFPScep)
                    $('#AFPSbairroC___' + linha).val(element.NFPSbairro)
                    $('#AFPScidadeC___' + linha).val(element.NFPScidade)
                    $('#AFPSufC___' + linha).val(element.NFPSuf)
                    $('#AFPSpaisC___' + linha).val(element.NFPSpais)
                    $('#AFPSbanco___' + linha).val(element.NFPSbanco)
                    $('#AFPSagencia___' + linha).val(element.NFPSagencia)
                    $('#AFPSconta___' + linha).val(element.NFPSconta)
                    $('#AFPSnacionalEstrangeira___' + linha).val(element.NFPSnacionalEstrangeira)
                    $('#AFPStipo___' + linha).val(element.NFPStipo)
                });
            });

            consultDataset('ds_processo_contrato', 'NFPStabelaUploadFiles', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('AFPStabelaContratado');

                    valores.NFPSId ? blockUploadsButtons('AFPSbFile___' + linha, true, false, false, true) : blockUploadsButtons('AFPSbFile___' + linha, true, false, false, true);

                    $('#AFPSbName___' + linha).val(element.NFPSName)
                    $('AFPSbId___' + linha).val(element.NFPSId)
                });
            });
            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);

            window["AFPScontratante"].setValue(valores.contratante);
            $('#AFPStituloContrato').val(valores.tituloContrato)
            $('#tituloContrato').val(valores.tituloContrato)
            $('#AFPSvalorTotal').val(valores.valorTotal1);
            $('#AFPSvalorTotalMensal').val(valores.valorTotalMensal1);
            $('#AFPSvalorTotalAnual').val(valores.valorTotalAnual1);
            $('#AFPSminutaContratoName').val(valores.minutaContratoName);
            $('#AFPSuploadEmailName').val(valores.uploadEmailName);
            $('#AFPSuploadLGPDDocName').val(valores.uploadLGPDDocName);
            $('#AFPSpropostaComercialName').val(valores.propostaComercialName);
            $('#AFPSdocumentosSocietariosName').val(valores.documentosSocietariosName);
            $('#AFPSminutaContratoId').val(valores.minutaContratoId);
            $('#AFPSuploadEmailId').val(valores.uploadEmailId);
            $('#AFPSpropostaComercialId').val(valores.propostaComercialId);
            $('#AFPSdocumentosSocietariosId').val(valores.documentosSocietariosId);
            $('#AFPSuploadLGPDDocId').val(valores.uploadLGPDDocId);

            valores.uploadEmailId ? blockUploadsButtons('AFPSuploadEmailFile', true, false, false, true) : blockUploadsButtons('AFPSuploadEmailFile', false);
            valores.propostaComercialId ? blockUploadsButtons('AFPSpropostaComercialFile', true, false, false, true) : blockUploadsButtons('AFPSpropostaComercialFile', false);
            valores.documentosSocietariosId ? blockUploadsButtons('AFPSdocumentosSocietariosFile', true, false, false, true) : blockUploadsButtons('AFPSdocumentosSocietariosFile', false);
            valores.minutaContratoId ? blockUploadsButtons('AFPSminutaContratoFile', true, false, false, true) : blockUploadsButtons('AFPSminutaContratoFile', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('AFPSuploadLGPDDocFile', true, false, false, true) : blockUploadsButtons('AFPSuploadLGPDDocFile', false);

            if (valores.RadioPrazo == 'determinado') {
                $("#AFPSPrazoDet").prop('checked', true)
                $("#divAFPSdatasPrazo").show()
                $("#AFPSinicioVigencia").val(valores.inicioVigencia)
                $("#AFPSfimVigencia").val(valores.fimVigencia)
                $("#AFPSdataAviso").val(valores.dataAviso)
                $("#AFPSPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#AFPSPrazoIndet").prop('checked', true)
                $("#divAFPSdatasPrazo").show()
                $("#AFPSDivFimVigencia").hide()
                $("#AFPSinicioVigencia").val(valores.inicioVigencia)
                $("#AFPSdataAviso").val(valores.dataAviso)
                $("#AFPSPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#AFPSPrazoRenov").prop('checked', true)
                $("#divAFPSdatasPrazo").show()
                $("#AFPSinicioVigencia").val(valores.inicioVigencia)
                $("#AFPSfimVigencia").val(valores.fimVigencia)
                $("#AFPSdataAviso").val(valores.dataAviso)
                $("#AFPSRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }

        } else if (type == 'negocios') {
            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)
            $(`#riscoContrato`).parent().css('pointer-events', 'none')

            for (let property in newData.content.values[0]) {
                if (property.includes('NTN')) {
                    console.log(newData)
                    if (valores.hasOwnProperty(property.split('NTN')[1])) {
                        valores[property.split('NTN')[1]] = newData.content.values[0][property]
                    }
                }
            }

            consultDataset('ds_processo_contrato', 'NTNtabelaClienteRep', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('AFPStabelaContratado');
                    $('#AFPSrazaoSocialC___' + linha).val(element.NTNrazaoSocialA)
                    $('#AFPSnomeFantasiaC___' + linha).val(element.NTNnomeFantasiaA)
                    $('#AFPScpfCnpjC___' + linha).val(element.NTNcpfCnpjA)
                    $('#AFPSemailC___' + linha).val(element.NTNemailA)
                    $('#AFPStelefoneC___' + linha).val(element.NTNtelefoneA)
                    $('#AFPSenderecoC___' + linha).val(element.NTNenderecoA)
                    $('#AFPScepC___' + linha).val(element.NTNcepA)
                    $('#AFPSbairroC___' + linha).val(element.NTNbairroA)
                    $('#AFPScidadeC___' + linha).val(element.NTNcidadeA)
                    $('#AFPSufC___' + linha).val(element.NTNufA)
                    $('#AFPSpaisC___' + linha).val(element.NTNpaisA)
                    $('#AFPSbanco___' + linha).val(element.NTNbancoA)
                    $('#AFPSagencia___' + linha).val(element.NTNagenciaA)
                    $('#AFPSconta___' + linha).val(element.NTNcontaA)
                    $('#AFPSnacionalEstrangeira___' + linha).val(element.NTNnacionalEstrangeiraA)
                    $('#AFPStipo___' + linha).val(element.NTNtipoA)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaCorretIntermed', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('ATNtabelaCorretIntermed');
                    $('#ATNrazaoSocialB___' + linha).val(element.NTNrazaoSocialB)
                    $('#ATNnomeFantasiaB___' + linha).val(element.NTNnomeFantasiaB)
                    $('#ATNcpfCnpjB___' + linha).val(element.NTNcpfCnpjB)
                    $('#ATNemailB___' + linha).val(element.NTNemailB)
                    $('#ATNtelefoneB___' + linha).val(element.NTNtelefoneB)
                    $('#ATNenderecoB___' + linha).val(element.NTNenderecoB)
                    $('#ATNcepB___' + linha).val(element.NTNcepB)
                    $('#ATNbairroB___' + linha).val(element.NTNbairroB)
                    $('#ATNcidadeB___' + linha).val(element.NTNcidadeB)
                    $('#ATNufB___' + linha).val(element.NTNufB)
                    $('#ATNpaisB___' + linha).val(element.NTNpaisB)
                    $('#ATNbancoB___' + linha).val(element.NTNbancoB)
                    $('#ATNagenciaB___' + linha).val(element.NTNagenciaB)
                    $('#ATNcontaB___' + linha).val(element.NTNcontaB)
                    $('#ATNnacionalEstrangeiraB___' + linha).val(element.NTNnacionalEstrangeiraB)
                    $('#ATNtipoB___' + linha).val(element.NTNtipoB)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaParSegu', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('ATNtabelaParSegu');
                    $('#ATNrazaoSocialC___' + linha).val(element.NTNrazaoSocialC)
                    $('#ATNnomeFantasiaC___' + linha).val(element.NTNnomeFantasiaC)
                    $('#ATNcpfCnpjC___' + linha).val(element.NTNcpfCnpjC)
                    $('#ATNemailC___' + linha).val(element.NTNemailC)
                    $('#ATNtelefoneC___' + linha).val(element.NTNtelefoneC)
                    $('#ATNenderecoC___' + linha).val(element.NTNenderecoC)
                    $('#ATNcepC___' + linha).val(element.NTNcepC)
                    $('#ATNbairroC___' + linha).val(element.NTNbairroC)
                    $('#ATNcidadeC___' + linha).val(element.NTNcidadeC)
                    $('#ATNufC___' + linha).val(element.NTNufC)
                    $('#ATNpaisC___' + linha).val(element.NTNpaisC)
                    $('#ATNbancoC___' + linha).val(element.NTNbancoC)
                    $('#ATNagenciaC___' + linha).val(element.NTNagenciaC)
                    $('#ATNcontaC___' + linha).val(element.NTNcontaC)
                    $('#ATNnacionalEstrangeiraC___' + linha).val(element.NTNnacionalEstrangeiraC)
                    $('#ATNtipoC___' + linha).val(element.NTNtipoC)
                });
            });
            console.log(valores)
            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);

            $('#AFPStituloContrato').val(valores.tituloContrato);
            $('#tituloContrato').val(valores.tituloContrato);
            window["AFPScontratante"].setValue(valores.empPartNeg);
            $('#AFPSobjetoContrato').val(valores.objetoContrato);
            $('#AFPSNomeFantasiaGrupo').val(valores.nomeFantGrup);
            $('#AFPSobjetoContrato').val(valores.objetoContrato);
            $('#AFPSprodComeInte').val(valores.prodComeInter);
            $('#AFPSobservacoes').val(valores.observacoes);
            $('#AFPSgarantiaContrato').val(valores.garantiaContrato);
            $('#AFPStipoGarantia').val(valores.tipoGarantia);
            $('#AFPSDescGarantia').val(valores.DescGarantia);
            $('#AFPSinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
            $('#AFPSfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
            $('#AFPSdataAvisoVenc').val(valores.dataAvisoVenc);


            $('#ATNminutaContratoName').val(valores.minutaContratoName);
            $('#ATNnbpName').val(valores.nbpName);
            $('#ATNpmName').val(valores.pmName);
            $('#ATNuploadEmailName').val(valores.uploadEmailName);
            $('#ATNdocumentosSocietariosName').val(valores.documentosSocietariosName);
            $('#ATNuploadLGPDDocName').val(valores.uploadLGPDDocName);
            $('#ATNminutaContratoId').val(valores.minutaContratoId);
            $('#ATNnbpId').val(valores.nbpId);
            $('#ATNpmId').val(valores.pmId);
            $('#ATNuploadEmailId').val(valores.uploadEmailId);
            $('#ATNdocumentosSocietariosId').val(valores.documentosSocietariosId);
            $('#ATNuploadLGPDDocId').val(valores.uploadLGPDDocId);

            valores.minutaContratoId ? blockUploadsButtons('ATNminutaContratoFile', true, false, false, true) : blockUploadsButtons('ATNminutaContratoFile', false);
            valores.nbpId ? blockUploadsButtons('ATNnbpFile', true, false, false, true) : blockUploadsButtons('ATNnbpFile', false);
            valores.pmId ? blockUploadsButtons('ATNpmFile', true, false, false, true) : blockUploadsButtons('ATNpmFile', false);
            valores.uploadEmailId ? blockUploadsButtons('ATNuploadEmailFile', true, false, false, true) : blockUploadsButtons('ATNuploadEmailFile', false);
            valores.documentosSocietariosId ? blockUploadsButtons('ATNdocumentosSocietariosFile', true, false, false, true) : blockUploadsButtons('ATNdocumentosSocietariosFile', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('ATNuploadLGPDDocFile', true, false, false, true) : blockUploadsButtons('ATNuploadLGPDDocFile', false);
            (valores.contNegAdit == 'sim') ? $('#AFPScontNegAditSim').prop('checked', true): $('#AFPScontNegAditNao').prop('checked', true);
            (valores.quaisInvestMarketMinGarant != null) ? $('#AFPSquaisInvestMarketMinGarant').prop('checked', true): $('#AFPSquaisInvestMarketMinGarant').prop('checked', false);
            (valores.quaisFindesFee != null) ? $('#AFPSquaisFindesFee').prop('checked', true): $('#AFPSquaisFindesFee').prop('checked', false);
            (valores.quaisIncluAltDespAgeCamp != null) ? $('#AFPSquaisIncluAltDespAgeCamp').prop('checked', true): $('#AFPSquaisIncluAltDespAgeCamp').prop('checked', false);
            if (valores.quaisUpfrontBonus != null) {
                $("#AFPSquaisUpfrontBonus").prop('checked', true)
                $("#divAFPSBonusDetalhamento").show()
                $("#AFPSBonusDetalhamento").val(valores.BonusDetalhamento)
            }
            if (valores.quaisBonusPerformance != null) {
                $("#AFPSquaisBonusPerformance").prop('checked', true)
                $("#divAFPSBonusPerformDet").show()
                $("#AFPSBonusPerformDet").val(valores.BonusPerformDet)
            }
            if (valores.quaisProfitSharing != null) {
                $("#AFPSquaisProfitSharing").prop('checked', true)
                $("#divAFPSquaisProfitSharing").show()
                $("#AFPSProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
            }
            if (valores.quaisReembCartaCredito != null) {
                $("#AFPSquaisReembCartaCredito").prop('checked', true)
                $("#divAFPSReembCartaCreditoDet").show()
                $("#AFPSReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
            }
            if (valores.quaisIncluAltDespPrestServ != null) {
                $("#AFPSquaisIncluAltDespPrestServ").prop('checked', true)
                $("#divAFPSIncluAltDespPrestServDet").show()
                $("#AFPSIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
            }
            if (valores.quaisIncluAltDespVar != null) {
                $("#AFPSquaisIncluAltDespVar").prop('checked', true)
                $("#divAFPSIncluAltDespVarDet").show()
                $("#AFPSIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
            }

            if (valores.RadioPrazo == 'determinado') {
                $("#AFPSPrazoDet").prop('checked', true)
                $("#divAFPSdatasPrazo").show()
                $("#AFPSinicioVigencia").val(valores.inicioVigencia)
                $("#AFPSfimVigencia").val(valores.fimVigencia)
                $("#AFPSdataAviso").val(valores.dataAviso)
                $("#AFPSPeriodoRenovacao").val(valores.avisoPrevio)
                $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#AFPSPrazoIndet").prop('checked', true)
                $("#divAFPSdatasPrazo").show()
                $("#divAFPSinicioVigencia").show()
                $("#divAFPSPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')
                $("#divAFPSdataAviso").show().removeClass('col-sm-3').addClass('col-sm-4')
                $("#AFPSDivFimVigencia").hide()
                $("#AFPSinicioVigencia").val(valores.inicioVigencia)
                $("#AFPSdataAviso").val(valores.dataAviso)
                $("#AFPSPeriodoRenovacao").val(valores.avisoPrevio)

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#AFPSPrazoRenov").prop('checked', true)
                $("#divAFPSdatasPrazo").show()
                $("#AFPSinicioVigencia").val(valores.inicioVigencia)
                $("#AFPSfimVigencia").val(valores.fimVigencia)
                $("#AFPSdataAviso").val(valores.dataAviso)
                $("#AFPSRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divAFPSinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#AFPSDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divAFPSRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }

        }
    });
}

const addFieldsDistrato = (dataChange, type) => {
    consultDataset('ds_processo_contrato', null, [{
        "_field": "documentid",
        "_initialValue": dataChange.target.value,
        "_finalValue": dataChange.target.value,
        "_type": 1
    }]).success(newData => {
        let valores = {
            tituloContrato: '',
            contratante: '',
            empPartNeg: '',
            objetoContrato: '',
            contratoIndeterminado: '',
            flagContratoVigencia: 'checked',
            dataAviso: '',
            inicioVigencia: '',
            fimVigencia: '',
            AFPSidentifAditivo: '',
            valorTotal1: '',
            valorTotalMensal1: '',
            valorTotalAnual1: '',
            observacoes: '',
            minutaContratoName: '',
            nbpName: '',
            pmName: '',
            uploadEmailName: '',
            uploadOutrosDocName: '',
            uploadLGPDDocName: '',
            propostaComercialName: '',
            documentosSocietariosName: '',
            minutaContratoId: '',
            nbpId: '',
            pmId: '',
            uploadEmailId: '',
            uploadOutrosDocId: '',
            propostaComercialId: '',
            documentosSocietariosId: '',
            uploadLGPDDocId: '',
            outrosDetalhes: '',
            nomeFantGrup: '',
            objetoContrato: '',
            prodComeInter: '',
            contNegAdit: '',
            quaisUpfrontBonus: '',
            BonusDetalhamento: '',
            quaisBonusPerformance: '',
            BonusPerformDet: '',
            quaisProfitSharing: '',
            ProfitSharingDetalhamento: '',
            quaisReembCartaCredito: '',
            ReembCartaCreditoDet: '',
            quaisInvestMarketMinGarant: '',
            quaisFindesFee: '',
            quaisIncluAltDespAgeCamp: '',
            quaisIncluAltDespPrestServ: '',
            IncluAltDespPrestServDet: '',
            quaisIncluAltDespVar: '',
            IncluAltDespVarDet: '',
            garantiaContrato: '',
            tipoGarantia: '',
            DescGarantia: '',
            inicioVidenciaGarantia: '',
            fimVigenciaGarantia: '',
            dataAvisoVenc: '',
            RadioPrazo: '',
            inicioVigencia: '',
            fimVigencia: '',
            dataAviso: '',
            AvisoPrevio: '',
            avisoPrevio: '',
            RenovacaoAutomatica: ''
        }

        if (type == 'forncedorPrestadorServico') {
            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)
            $(`#riscoContrato`).parent().css('pointer-events', 'none')

            for (let property in newData.content.values[0]) {
                if (property.includes('NFPS')) {
                    if (valores.hasOwnProperty(property.split('NFPS')[1])) {
                        valores[property.split('NFPS')[1]] = newData.content.values[0][property]
                    }
                }
            }

            consultDataset('ds_processo_contrato', 'NFPStabelaContratado', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('DIStabelaContratado');

                    $('#DISrazaoSocial___' + linha).val(element.NFPSrazaoSocial)
                    $('#DISnomeFantasia___' + linha).val(element.NFPSnomeFantasia)
                    $('#DIScpfCnpj___' + linha).val(element.NFPScpfCnpj)
                    $('#DISemail___' + linha).val(element.NFPSemail)
                    $('#DIStelefone___' + linha).val(element.NFPStelefone)
                    $('#DISendereco___' + linha).val(element.NFPSendereco)
                    $('#DIScep___' + linha).val(element.NFPScep)
                    $('#DISbairro___' + linha).val(element.NFPSbairro)
                    $('#DIScidade___' + linha).val(element.NFPScidade)
                    $('#DISuf___' + linha).val(element.NFPSuf)
                    $('#DISpais___' + linha).val(element.NFPSpais)
                    $('#DISbanco___' + linha).val(element.NFPSbanco)
                    $('#DISagencia___' + linha).val(element.NFPSagencia)
                    $('#DISconta___' + linha).val(element.NFPSconta)
                    $('#DISnacionalEstrangeira___' + linha).val(element.NFPSnacionalEstrangeira)
                    $('#DIStipo___' + linha).val(element.NFPStipo)
                });
            });

            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);

            window["DIScontratante"].setValue(valores.contratante);
            $('#tituloContrato').val(valores.tituloContrato);
            $('#DISvalorTotal').val(valores.valorTotal1);
            $('#DISvalorTotalMensal').val(valores.valorTotalMensal1);
            $('#DISvalorTotalAnual').val(valores.valorTotalAnual1);
            $('#DISminutaDistratoName').val(valores.minutaContratoName);
            $('#DISuploadEmailName').val(valores.uploadEmailName);
            $('#DISuploadLGPDDocName').val(valores.uploadLGPDDocName);
            $('#DISpropostaComercialName').val(valores.propostaComercialName);
            $('#DISdocumentosSocietariosName').val(valores.documentosSocietariosName);
            $('#DISminutaDistratoId').val(valores.minutaContratoId);
            $('#DISuploadEmailId').val(valores.uploadEmailId);
            $('#DISpropostaComercialId').val(valores.propostaComercialId);
            $('#DISdocumentosSocietariosId').val(valores.documentosSocietariosId);
            $('#DISuploadLGPDDocId').val(valores.uploadLGPDDocId);

            valores.uploadEmailId ? blockUploadsButtons('DISuploadEmailFile', true, false, false, true) : blockUploadsButtons('DISuploadEmailFile', false);
            valores.propostaComercialId ? blockUploadsButtons('DISpropostaComercialFile', true, false, false, true) : blockUploadsButtons('DISpropostaComercialFile', false);
            valores.documentosSocietariosId ? blockUploadsButtons('DISdocumentosSocietariosFile', true, false, false, true) : blockUploadsButtons('DISdocumentosSocietariosFile', false);
            valores.minutaContratoId ? blockUploadsButtons('DISminutaDistratoFile', true, false, false, true) : blockUploadsButtons('DISminutaDistratoFile', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('DISuploadLGPDDocFile', true, false, false, true) : blockUploadsButtons('DISuploadLGPDDocFile', false);

            if (valores.RadioPrazo == 'determinado') {
                $("#DISPrazoDet").prop('checked', true)
                $("#divDISdatasPrazo").show()
                $("#DISinicioVigencia").val(valores.inicioVigencia)
                $("#DISfimVigencia").val(valores.fimVigencia)
                $("#DISdataAviso").val(valores.dataAviso)
                $("#DISPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#DISPrazoIndet").prop('checked', true)
                $("#divDISdatasPrazo").show()
                $("#DISDivFimVigencia").hide()
                $("#DISinicioVigencia").val(valores.inicioVigencia)
                $("#DISdataAviso").val(valores.dataAviso)
                $("#DISPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divDISPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#DISPrazoRenov").prop('checked', true)
                $("#divDISdatasPrazo").show()
                $("#DISinicioVigencia").val(valores.inicioVigencia)
                $("#DISfimVigencia").val(valores.fimVigencia)
                $("#DISdataAviso").val(valores.dataAviso)
                $("#DISRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }

        } else if (type == 'negocios') {
            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)
            $(`#riscoContrato`).parent().css('pointer-events', 'none')

            for (let property in newData.content.values[0]) {
                if (property.includes('NTN')) {
                    if (valores.hasOwnProperty(property.split('NTN')[1])) {
                        valores[property.split('NTN')[1]] = newData.content.values[0][property]
                    }
                }
            }

            consultDataset('ds_processo_contrato', 'NTNtabelaClienteRep', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('DIStabelaClienteRep');
                    $('#DISrazaoSocialA___' + linha).val(element.NTNrazaoSocialA)
                    $('#DISnomeFantasiaA___' + linha).val(element.NTNnomeFantasiaA)
                    $('#DIScpfCnpjA___' + linha).val(element.NTNcpfCnpjA)
                    $('#DISemailA___' + linha).val(element.NTNemailA)
                    $('#DIStelefoneA___' + linha).val(element.NTNtelefoneA)
                    $('#DISenderecoA___' + linha).val(element.NTNenderecoA)
                    $('#DIScepA___' + linha).val(element.NTNcepA)
                    $('#DISbairroA___' + linha).val(element.NTNbairroA)
                    $('#DIScidadeA___' + linha).val(element.NTNcidadeA)
                    $('#DISufA___' + linha).val(element.NTNufA)
                    $('#DISpaisA___' + linha).val(element.NTNpaisA)
                    $('#DISbancoA___' + linha).val(element.NTNbancoA)
                    $('#DISagenciaA___' + linha).val(element.NTNagenciaA)
                    $('#DIScontaA___' + linha).val(element.NTNcontaA)
                    $('#DISnacionalEstrangeiraA___' + linha).val(element.NTNnacionalEstrangeiraA)
                    $('#DIStipoA___' + linha).val(element.NTNtipoA)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaCorretIntermed', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('DIStabelaCorretIntermed');
                    $('#DISrazaoSocialB___' + linha).val(element.NTNrazaoSocialB)
                    $('#DISnomeFantasiaB___' + linha).val(element.NTNnomeFantasiaB)
                    $('#DIScpfCnpjB___' + linha).val(element.NTNcpfCnpjB)
                    $('#DISemailB___' + linha).val(element.NTNemailB)
                    $('#DIStelefoneB___' + linha).val(element.NTNtelefoneB)
                    $('#DISenderecoB___' + linha).val(element.NTNenderecoB)
                    $('#DIScepB___' + linha).val(element.NTNcepB)
                    $('#DISbairroB___' + linha).val(element.NTNbairroB)
                    $('#DIScidadeB___' + linha).val(element.NTNcidadeB)
                    $('#DISufB___' + linha).val(element.NTNufB)
                    $('#DISpaisB___' + linha).val(element.NTNpaisB)
                    $('#DISbancoB___' + linha).val(element.NTNbancoB)
                    $('#DISagenciaB___' + linha).val(element.NTNagenciaB)
                    $('#DIScontaB___' + linha).val(element.NTNcontaB)
                    $('#DISnacionalEstrangeiraB___' + linha).val(element.NTNnacionalEstrangeiraB)
                    $('#DIStipoB___' + linha).val(element.NTNtipoB)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaParSegu', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('DIStabelaParSegu');
                    $('#DISrazaoSocialC___' + linha).val(element.NTNrazaoSocialC)
                    $('#DISnomeFantasiaC___' + linha).val(element.NTNnomeFantasiaC)
                    $('#DIScpfCnpjC___' + linha).val(element.NTNcpfCnpjC)
                    $('#DISemailC___' + linha).val(element.NTNemailC)
                    $('#DIStelefoneC___' + linha).val(element.NTNtelefoneC)
                    $('#DISenderecoC___' + linha).val(element.NTNenderecoC)
                    $('#DIScepC___' + linha).val(element.NTNcepC)
                    $('#DISbairroC___' + linha).val(element.NTNbairroC)
                    $('#DIScidadeC___' + linha).val(element.NTNcidadeC)
                    $('#DISufC___' + linha).val(element.NTNufC)
                    $('#DISpaisC___' + linha).val(element.NTNpaisC)
                    $('#DISbancoC___' + linha).val(element.NTNbancoC)
                    $('#DISagenciaC___' + linha).val(element.NTNagenciaC)
                    $('#DIScontaC___' + linha).val(element.NTNcontaC)
                    $('#DISnacionalEstrangeiraC___' + linha).val(element.NTNnacionalEstrangeiraC)
                    $('#DIStipoC___' + linha).val(element.NTNtipoC)
                });
            });
            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);

            window["DISempPartNeg"].setValue(valores.empPartNeg);
            $("#DIStituloContrato").val(valores.tituloContrato);
            $('#tituloContrato').val(valores.tituloContrato);
            $('#DISnomeFantGrup').val(valores.nomeFantGrup);
            $('#DISobjetoContrato').val(valores.objetoContrato);
            $('#DISprodComeInte').val(valores.prodComeInter);
            $('#DISobservacoes').val(valores.observacoes);
            $('#DISgarantiaContrato').val(valores.garantiaContrato);
            $('#DIStipoGarantia').val(valores.tipoGarantia);
            $('#DISDescGarantia').val(valores.DescGarantia);
            $('#DISinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
            $('#DISfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
            $('#DISdataAvisoVenc').val(valores.dataAvisoVenc);

            $('#DISminutaContratoName').val(valores.minutaContratoName);
            $('#DISnbpName').val(valores.nbpName);
            $('#DISpmName').val(valores.pmName);
            $('#DISuploadEmailNameA').val(valores.uploadEmailName);
            $('#DISdocumentosSocietariosNameA').val(valores.documentosSocietariosName);
            $('#DISuploadLGPDDocNameA').val(valores.uploadLGPDDocName);
            $('#DISminutaContratoId').val(valores.minutaContratoId);
            $('#DISnbpId').val(valores.nbpId);
            $('#DISpmId').val(valores.pmId);
            $('#DISuploadEmailIdA').val(valores.uploadEmailId);
            $('#DISdocumentosSocietariosIdA').val(valores.documentosSocietariosId);
            $('#DISuploadLGPDDocIdA').val(valores.uploadLGPDDocId);

            valores.minutaContratoId ? blockUploadsButtons('DISminutaContratoFile', true, false, false, true) : blockUploadsButtons('DISminutaContratoFile', false);
            valores.nbpId ? blockUploadsButtons('DISnbpFile', true, false, false, true) : blockUploadsButtons('DISnbpFile', false);
            valores.pmId ? blockUploadsButtons('DISpmFile', true, false, false, true) : blockUploadsButtons('DISpmFile', false);
            valores.uploadEmailId ? blockUploadsButtons('DISuploadEmailFileA', true, false, false, true) : blockUploadsButtons('DISuploadEmailFileA', false);
            valores.documentosSocietariosId ? blockUploadsButtons('DISdocumentosSocietariosFileA', true, false, false, true) : blockUploadsButtons('DISdocumentosSocietariosFileA', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('DISuploadLGPDDocFileA', true, false, false, true) : blockUploadsButtons('DISuploadLGPDDocFileA', false);

            (valores.contNegAdit == 'sim') ? $('#DIScontNegAditSim').prop('checked', true): $('#DIScontNegAditNao').prop('checked', true);
            (valores.quaisInvestMarketMinGarant != null) ? $('#DISquaisInvestMarketMinGarant').prop('checked', true): $('#DISquaisInvestMarketMinGarant').prop('checked', false);
            (valores.quaisFindesFee != null) ? $('#DISquaisFindesFee').prop('checked', true): $('#DISquaisFindesFee').prop('checked', false);
            (valores.quaisIncluAltDespAgeCamp != null) ? $('#DISquaisIncluAltDespAgeCamp').prop('checked', true): $('#DISquaisIncluAltDespAgeCamp').prop('checked', false);
            if (valores.quaisUpfrontBonus != null) {
                $("#DISquaisUpfrontBonus").prop('checked', true)
                $("#divDISBonusDetalhamento").show()
                $("#DISBonusDetalhamento").val(valores.BonusDetalhamento)
            }
            if (valores.quaisBonusPerformance != null) {
                $("#DISquaisBonusPerformance").prop('checked', true)
                $("#divDISBonusPerformDet").show()
                $("#DISBonusPerformDet").val(valores.BonusPerformDet)
            }
            if (valores.quaisProfitSharing != null) {
                $("#DISquaisProfitSharing").prop('checked', true)
                $("#divDISquaisProfitSharing").show()
                $("#DISProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
            }
            if (valores.quaisReembCartaCredito != null) {
                $("#DISquaisReembCartaCredito").prop('checked', true)
                $("#divDISReembCartaCreditoDet").show()
                $("#DISReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
            }
            if (valores.quaisIncluAltDespPrestServ != null) {
                $("#DISquaisIncluAltDespPrestServ").prop('checked', true)
                $("#divDISIncluAltDespPrestServDet").show()
                $("#DISIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
            }
            if (valores.quaisIncluAltDespVar != null) {
                $("#DISquaisIncluAltDespVar").prop('checked', true)
                $("#divDISIncluAltDespVarDet").show()
                $("#DISIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
            }

            if (valores.RadioPrazo == 'determinado') {
                $("#DISPrazoDet").prop('checked', true)
                $("#divDISdatasPrazo").show()
                $("#DISinicioVigencia").val(valores.inicioVigencia)
                $("#DISfimVigencia").val(valores.fimVigencia)
                $("#DISdataAviso").val(valores.dataAviso)
                $("#DISPeriodoRenovacao").val(valores.avisoPrevio)
                $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#DISPrazoIndet").prop('checked', true)
                $("#divDISdatasPrazo").show()
                $("#DISDivFimVigencia").hide()
                $("#DISinicioVigencia").val(valores.inicioVigencia)
                $("#DISdataAviso").val(valores.dataAviso)
                $("#DISPeriodoRenovacao").val(valores.avisoPrevio)
                $("#divDISPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#DISPrazoRenov").prop('checked', true)
                $("#divDISdatasPrazo").show()
                $("#DISinicioVigencia").val(valores.inicioVigencia)
                $("#DISfimVigencia").val(valores.fimVigencia)
                $("#DISdataAviso").val(valores.dataAviso)
                $("#DISRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divDISinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#DISDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divDISRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }


        }
    });
}


const addFieldsProposta = (dataChange, type) => {

    consultDataset('ds_processo_contrato', null, [{
        "_field": "documentid",
        "_initialValue": dataChange.target.value,
        "_finalValue": dataChange.target.value,
        "_type": 1
    }]).success(newData => {
        let valores = {
            tituloContrato: '',
            contratante: '',
            objetoContrato: '',
            contratoIndeterminado: '',
            flagContratoVigencia: 'checked',
            dataAviso: '',
            inicioVigencia: '',
            AFPSidentifAditivo: '',
            fimVigencia: '',
            valorTotal1: '',
            valorTotalMensal1: '',
            valorTotalAnual1: '',
            observacoes: '',
            minutaContratoName: '',
            uploadEmailName: '',
            propostaComercialName: '',
            documentosSocietariosName: '',
            uploadLGPDDocName: '',
            minutaContratoId: '',
            uploadEmailId: '',
            propostaComercialId: '',
            documentosSocietariosId: '',
            uploadLGPDDocId: '',
            outrosDetalhes: '',
            riscoContrato: ''
        }
        if (type == 'forncedorPrestadorServico') {
            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)
            $(`#riscoContrato`).parent().css('pointer-events', 'none')


            for (let property in newData.content.values[0]) {
                if (property.includes('NFPS')) {
                    if (valores.hasOwnProperty(property.split('NFPS')[1])) {
                        valores[property.split('NFPS')[1]] = newData.content.values[0][property]
                    }
                }
            }

            consultDataset('ds_processo_contrato', 'NFPStabelaContratado', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                console.log(dataTable)

                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('PROCtabelaContratado');

                    $('#PROCrazaoSocial___' + linha).val(element.NFPSrazaoSocial)
                    $('#PROCnomeFantasia___' + linha).val(element.NFPSnomeFantasia)
                    $('#PROCcpfCnpj___' + linha).val(element.NFPScpfCnpj)
                    $('#PROCemail___' + linha).val(element.NFPSemail)
                    $('#PROCtelefone___' + linha).val(element.NFPStelefone)
                    $('#PROCendereco___' + linha).val(element.NFPSendereco)
                    $('#PROCcep___' + linha).val(element.NFPScep)
                    $('#PROCbairro___' + linha).val(element.NFPSbairro)
                    $('#PROCcidade___' + linha).val(element.NFPScidade)
                    $('#PROCuf___' + linha).val(element.NFPSuf)
                    $('#PROCpais___' + linha).val(element.NFPSpais)
                    $('#PROCbanco___' + linha).val(element.NFPSbanco)
                    $('#PROCagencia___' + linha).val(element.NFPSagencia)
                    $('#PROCconta___' + linha).val(element.NFPSconta)
                    $('#PROCnacionalEstrangeira___' + linha).val(element.NFPSnacionalEstrangeira)
                    $('#PROCtipo___' + linha).val(element.NFPStipo)
                });
            });

        }
        var dataDeAviso = valores.dataAviso
        var dia2 = dataDeAviso.substring(0, 2)
        var mes2 = dataDeAviso.substring(3, 5)
        var ano2 = dataDeAviso.substring(6, 10)
        var dataCont = ano2 + "/" + mes2 + "/" + dia2
        $("#dataNotificacaoSolicitante").val(dataCont);
        $('#tituloContrato').val(valores.tituloContrato);
        window["PROCcontratante"].setValue(valores.contratante);
        $('#PROCvalorTotal').val(valores.valorTotal1);
        $('#PROCvalorTotalMensal').val(valores.valorTotalMensal1);
        $('#PROCvalorTotalAnual').val(valores.valorTotalAnual1);
        $('#PROCminutaPropostaName').val(valores.minutaContratoName);
        $('#PROCuploadEmailName').val(valores.uploadEmailName);
        $('#PROCuploadLGPDDocName').val(valores.uploadLGPDDocName);
        $('#PROCpropostaComercialName').val(valores.propostaComercialName);
        $('#PROCdocumentosSocietariosName').val(valores.documentosSocietariosName);
        $('#PROCminutaPropostaId').val(valores.minutaContratoId);
        $('#PROCuploadEmailId').val(valores.uploadEmailId);
        $('#PROCpropostaComercialId').val(valores.propostaComercialId);
        $('#PROCdocumentosSocietariosId').val(valores.documentosSocietariosId);
        $('#PROCuploadLGPDDocId').val(valores.uploadLGPDDocId);

        valores.uploadEmailId ? blockUploadsButtons('PROCuploadEmailFile', true, false, false, true) : blockUploadsButtons('PROCuploadEmailFile', false);
        valores.propostaComercialId ? blockUploadsButtons('PROCpropostaComercialFile', true, false, false, true) : blockUploadsButtons('PROCpropostaComercialFile', false);
        valores.documentosSocietariosId ? blockUploadsButtons('PROCdocumentosSocietariosFile', true, false, false, true) : blockUploadsButtons('PROCdocumentosSocietariosFile', false);
        valores.minutaContratoId ? blockUploadsButtons('PROCminutaPropostaFile', true, false, false, true) : blockUploadsButtons('PROCminutaPropostaFile', false);
        valores.uploadLGPDDocId ? blockUploadsButtons('PROCuploadLGPDDocFile', true, false, false, true) : blockUploadsButtons('PROCuploadLGPDDocFile', false);
    });
}

const addFieldsNotificacao = (dataChange, type) => {
    consultDataset('ds_processo_contrato', null, [{
        "_field": "documentid",
        "_initialValue": dataChange.target.value,
        "_finalValue": dataChange.target.value,
        "_type": 1
    }]).success(newData => {
        let valores = {
            tituloContrato: '',
            contratante: '',
            empPartNeg: '',
            objetoContrato: '',
            contratoIndeterminado: '',
            flagContratoVigencia: 'checked',
            dataAviso: '',
            inicioVigencia: '',
            fimVigencia: '',
            AFPSidentifAditivo: '',
            valorTotal1: '',
            valorTotalMensal1: '',
            valorTotalAnual1: '',
            observacoes: '',
            minutaContratoName: '',
            nbpName: '',
            pmName: '',
            uploadEmailName: '',
            uploadOutrosDocName: '',
            uploadLGPDDocName: '',
            propostaComercialName: '',
            documentosSocietariosName: '',
            minutaContratoId: '',
            nbpId: '',
            pmId: '',
            uploadEmailId: '',
            uploadOutrosDocId: '',
            propostaComercialId: '',
            documentosSocietariosId: '',
            uploadLGPDDocId: '',
            outrosDetalhes: '',
            nomeFantGrup: '',
            objetoContrato: '',
            prodComeInter: '',
            contNegAdit: '',
            quaisUpfrontBonus: '',
            BonusDetalhamento: '',
            quaisBonusPerformance: '',
            BonusPerformDet: '',
            quaisProfitSharing: '',
            ProfitSharingDetalhamento: '',
            quaisReembCartaCredito: '',
            ReembCartaCreditoDet: '',
            quaisInvestMarketMinGarant: '',
            quaisFindesFee: '',
            quaisIncluAltDespAgeCamp: '',
            quaisIncluAltDespPrestServ: '',
            IncluAltDespPrestServDet: '',
            quaisIncluAltDespVar: '',
            IncluAltDespVarDet: '',
            garantiaContrato: '',
            tipoGarantia: '',
            DescGarantia: '',
            inicioVidenciaGarantia: '',
            fimVigenciaGarantia: '',
            dataAvisoVenc: '',
            RadioPrazo: '',
            inicioVigencia: '',
            fimVigencia: '',
            dataAviso: '',
            AvisoPrevio: '',
            RenovacaoAutomatica: ''
        }

        if (type == 'forncedorPrestadorServico') {
            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)
            $(`#riscoContrato`).parent().css('pointer-events', 'none')

            for (let property in newData.content.values[0]) {
                if (property.includes('NFPS')) {
                    if (valores.hasOwnProperty(property.split('NFPS')[1])) {
                        valores[property.split('NFPS')[1]] = newData.content.values[0][property]
                    }
                }
            }

            consultDataset('ds_processo_contrato', 'NFPStabelaContratado', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('NOTtabelaContratado');

                    $('#NOTrazaoSocial___' + linha).val(element.NFPSrazaoSocial)
                    $('#NOTnomeFantasia___' + linha).val(element.NFPSnomeFantasia)
                    $('#NOTcpfCnpj___' + linha).val(element.NFPScpfCnpj)
                    $('#NOTemail___' + linha).val(element.NFPSemail)
                    $('#NOTtelefone___' + linha).val(element.NFPStelefone)
                    $('#NOTendereco___' + linha).val(element.NFPSendereco)
                    $('#NOTcep___' + linha).val(element.NFPScep)
                    $('#NOTbairro___' + linha).val(element.NFPSbairro)
                    $('#NOTcidade___' + linha).val(element.NFPScidade)
                    $('#NOTuf___' + linha).val(element.NFPSuf)
                    $('#NOTpais___' + linha).val(element.NFPSpais)
                    $('#NOTbanco___' + linha).val(element.NFPSbanco)
                    $('#NOTagencia___' + linha).val(element.NFPSagencia)
                    $('#NOTconta___' + linha).val(element.NFPSconta)
                    $('#NOTnacionalEstrangeira___' + linha).val(element.NFPSnacionalEstrangeira)
                    $('#NOTtipo___' + linha).val(element.NFPStipo)
                });
            });

            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);

            window["NOTcontratante"].setValue(valores.contratante);
            $('#tituloContrato').val(valores.tituloContrato);
            $('#NOTvalorTotal').val(valores.valorTotal1);
            $('#NOTvalorTotalMensal').val(valores.valorTotalMensal1);
            $('#NOTvalorTotalAnual').val(valores.valorTotalAnual1);
            $('#NOTminutaNotificaName').val(valores.minutaContratoName);
            $('#NOTuploadEmailName').val(valores.uploadEmailName);
            $('#NOTuploadLGPDDocName').val(valores.uploadLGPDDocName);
            $('#NOTpropostaComercialName').val(valores.propostaComercialName);
            $('#NOTdocumentosSocietariosName').val(valores.documentosSocietariosName);
            $('#NOTminutaNotificaId').val(valores.minutaContratoId);
            $('#NOTuploadEmailId').val(valores.uploadEmailId);
            $('#NOTpropostaComercialId').val(valores.propostaComercialId);
            $('#NOTdocumentosSocietariosId').val(valores.documentosSocietariosId);
            $('#NOTuploadLGPDDocId').val(valores.uploadLGPDDocId);

            valores.uploadEmailId ? blockUploadsButtons('NOTuploadEmailFile', true, false, false, true) : blockUploadsButtons('NOTuploadEmailFile', false);
            valores.propostaComercialId ? blockUploadsButtons('NOTpropostaComercialFile', true, false, false, true) : blockUploadsButtons('NOTpropostaComercialFile', false);
            valores.documentosSocietariosId ? blockUploadsButtons('NOTdocumentosSocietariosFile', true, false, false, true) : blockUploadsButtons('NOTdocumentosSocietariosFile', false);
            valores.minutaContratoId ? blockUploadsButtons('NOTminutaNotificaFile', true, false, false, true) : blockUploadsButtons('NOTminutaNotificaFile', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('NOTuploadLGPDDocFile', true, false, false, true) : blockUploadsButtons('NOTuploadLGPDDocFile', false);

            if (valores.RadioPrazo == 'determinado') {
                $("#NOTPrazoDet").prop('checked', true)
                $("#divNOTdatasPrazo").show()
                $("#NOTinicioVigencia").val(valores.inicioVigencia)
                $("#NOTfimVigencia").val(valores.fimVigencia)
                $("#NOTdataAviso").val(valores.dataAviso)
                $("#NOTPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#NOTPrazoIndet").prop('checked', true)
                $("#divNOTdatasPrazo").show()
                $("#NOTDivFimVigencia").hide()
                $("#NOTinicioVigencia").val(valores.inicioVigencia)
                $("#NOTdataAviso").val(valores.dataAviso)
                $("#NOTPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#NOTPrazoRenov").prop('checked', true)
                $("#divNOTdatasPrazo").show()
                $("#NOTinicioVigencia").val(valores.inicioVigencia)
                $("#NOTfimVigencia").val(valores.fimVigencia)
                $("#NOTdataAviso").val(valores.dataAviso)
                $("#NOTRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }


        } else if (type == 'negocios') {
            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)

            for (let property in newData.content.values[0]) {
                if (property.includes('NTN')) {
                    if (valores.hasOwnProperty(property.split('NTN')[1])) {
                        valores[property.split('NTN')[1]] = newData.content.values[0][property]
                    }
                }
            }

            consultDataset('ds_processo_contrato', 'NTNtabelaClienteRep', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('NOTtabelaClienteRep');
                    $('#NOTrazaoSocialA___' + linha).val(element.NTNrazaoSocialA)
                    $('#NOTnomeFantasiaA___' + linha).val(element.NTNnomeFantasiaA)
                    $('#NOTcpfCnpjA___' + linha).val(element.NTNcpfCnpjA)
                    $('#NOTemailA___' + linha).val(element.NTNemailA)
                    $('#NOTtelefoneA___' + linha).val(element.NTNtelefoneA)
                    $('#NOTenderecoA___' + linha).val(element.NTNenderecoA)
                    $('#NOTcepA___' + linha).val(element.NTNcepA)
                    $('#NOTbairroA___' + linha).val(element.NTNbairroA)
                    $('#NOTcidadeA___' + linha).val(element.NTNcidadeA)
                    $('#NOTufA___' + linha).val(element.NTNufA)
                    $('#NOTpaisA___' + linha).val(element.NTNpaisA)
                    $('#NOTbancoA___' + linha).val(element.NTNbancoA)
                    $('#NOTagenciaA___' + linha).val(element.NTNagenciaA)
                    $('#NOTcontaA___' + linha).val(element.NTNcontaA)
                    $('#NOTnacionalEstrangeiraA___' + linha).val(element.NTNnacionalEstrangeiraA)
                    $('#NOTtipoA___' + linha).val(element.NTNtipoA)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaCorretIntermed', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('NOTtabelaCorretIntermed');
                    $('#NOTrazaoSocialB___' + linha).val(element.NTNrazaoSocialB)
                    $('#NOTnomeFantasiaB___' + linha).val(element.NTNnomeFantasiaB)
                    $('#NOTcpfCnpjB___' + linha).val(element.NTNcpfCnpjB)
                    $('#NOTemailB___' + linha).val(element.NTNemailB)
                    $('#NOTtelefoneB___' + linha).val(element.NTNtelefoneB)
                    $('#NOTenderecoB___' + linha).val(element.NTNenderecoB)
                    $('#NOTcepB___' + linha).val(element.NTNcepB)
                    $('#NOTbairroB___' + linha).val(element.NTNbairroB)
                    $('#NOTcidadeB___' + linha).val(element.NTNcidadeB)
                    $('#NOTufB___' + linha).val(element.NTNufB)
                    $('#NOTpaisB___' + linha).val(element.NTNpaisB)
                    $('#NOTbancoB___' + linha).val(element.NTNbancoB)
                    $('#NOTagenciaB___' + linha).val(element.NTNagenciaB)
                    $('#NOTcontaB___' + linha).val(element.NTNcontaB)
                    $('#NOTnacionalEstrangeiraB___' + linha).val(element.NTNnacionalEstrangeiraB)
                    $('#NOTtipoB___' + linha).val(element.NTNtipoB)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaParSegu', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('NOTtabelaParSegu');
                    $('#NOTrazaoSocialC___' + linha).val(element.NTNrazaoSocialC)
                    $('#NOTnomeFantasiaC___' + linha).val(element.NTNnomeFantasiaC)
                    $('#NOTcpfCnpjC___' + linha).val(element.NTNcpfCnpjC)
                    $('#NOTemailC___' + linha).val(element.NTNemailC)
                    $('#NOTtelefoneC___' + linha).val(element.NTNtelefoneC)
                    $('#NOTenderecoC___' + linha).val(element.NTNenderecoC)
                    $('#NOTcepC___' + linha).val(element.NTNcepC)
                    $('#NOTbairroC___' + linha).val(element.NTNbairroC)
                    $('#NOTcidadeC___' + linha).val(element.NTNcidadeC)
                    $('#NOTufC___' + linha).val(element.NTNufC)
                    $('#NOTpaisC___' + linha).val(element.NTNpaisC)
                    $('#NOTbancoC___' + linha).val(element.NTNbancoC)
                    $('#NOTagenciaC___' + linha).val(element.NTNagenciaC)
                    $('#NOTcontaC___' + linha).val(element.NTNcontaC)
                    $('#NOTnacionalEstrangeiraC___' + linha).val(element.NTNnacionalEstrangeiraC)
                    $('#NOTtipoC___' + linha).val(element.NTNtipoC)
                });
            });
            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);

            window["NOTempPartNeg"].setValue(valores.empPartNeg);
            $("#NOTtituloContrato").val(valores.tituloContrato);
            $('#tituloContrato').val(valores.tituloContrato);
            $('#NOTnomeFantGrup').val(valores.nomeFantGrup);
            $('#NOTobjetoContrato').val(valores.objetoContrato);
            $('#NOTprodComeInte').val(valores.prodComeInter);
            $('#NOTobservacoes').val(valores.observacoes);
            $('#NOTgarantiaContrato').val(valores.garantiaContrato);
            $('#NOTtipoGarantia').val(valores.tipoGarantia);
            $('#NOTDescGarantia').val(valores.DescGarantia);
            $('#NOTinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
            $('#NOTfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
            $('#NOTdataAvisoVenc').val(valores.dataAvisoVenc);

            $('#NOTminutaContratoName').val(valores.minutaContratoName);
            $('#NOTnbpName').val(valores.nbpName);
            $('#NOTpmName').val(valores.pmName);
            $('#NOTuploadEmailNameA').val(valores.uploadEmailName);
            $('#NOTdocumentosSocietariosNameA').val(valores.documentosSocietariosName);
            $('#NOTuploadLGPDDocNameA').val(valores.uploadLGPDDocName);
            $('#NOTminutaContratoId').val(valores.minutaContratoId);
            $('#NOTnbpId').val(valores.nbpId);
            $('#NOTpmId').val(valores.pmId);
            $('#NOTuploadEmailIdA').val(valores.uploadEmailId);
            $('#NOTdocumentosSocietariosIdA').val(valores.documentosSocietariosId);
            $('#NOTuploadLGPDDocIdA').val(valores.uploadLGPDDocId);

            valores.minutaContratoId ? blockUploadsButtons('NOTminutaContratoFile', true, false, false, true) : blockUploadsButtons('NOTminutaContratoFile', false);
            valores.nbpId ? blockUploadsButtons('NOTnbpFile', true, false, false, true) : blockUploadsButtons('NOTnbpFile', false);
            valores.pmId ? blockUploadsButtons('NOTpmFile', true, false, false, true) : blockUploadsButtons('NOTpmFile', false);
            valores.uploadEmailId ? blockUploadsButtons('NOTuploadEmailFileA', true, false, false, true) : blockUploadsButtons('NOTuploadEmailFileA', false);
            valores.documentosSocietariosId ? blockUploadsButtons('NOTdocumentosSocietariosFileA', true, false, false, true) : blockUploadsButtons('NOTdocumentosSocietariosFileA', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('NOTuploadLGPDDocFileA', true, false, false, true) : blockUploadsButtons('NOTuploadLGPDDocFileA', false);

            (valores.contNegAdit == 'sim') ? $('#NOTcontNegAditSim').prop('checked', true): $('#NOTcontNegAditNao').prop('checked', true);
            (valores.quaisInvestMarketMinGarant != null) ? $('#NOTquaisInvestMarketMinGarant').prop('checked', true): $('#NOTquaisInvestMarketMinGarant').prop('checked', false);
            (valores.quaisFindesFee != null) ? $('#NOTquaisFindesFee').prop('checked', true): $('#NOTquaisFindesFee').prop('checked', false);
            (valores.quaisIncluAltDespAgeCamp != null) ? $('#NOTquaisIncluAltDespAgeCamp').prop('checked', true): $('#NOTquaisIncluAltDespAgeCamp').prop('checked', false);
            if (valores.quaisUpfrontBonus != null) {
                $("#NOTquaisUpfrontBonus").prop('checked', true)
                $("#divNOTBonusDetalhamento").show()
                $("#NOTBonusDetalhamento").val(valores.BonusDetalhamento)
            }
            if (valores.quaisBonusPerformance != null) {
                $("#NOTquaisBonusPerformance").prop('checked', true)
                $("#divNOTBonusPerformDet").show()
                $("#NOTBonusPerformDet").val(valores.BonusPerformDet)
            }
            if (valores.quaisProfitSharing != null) {
                $("#NOTquaisProfitSharing").prop('checked', true)
                $("#divNOTquaisProfitSharing").show()
                $("#NOTProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
            }
            if (valores.quaisReembCartaCredito != null) {
                $("#NOTquaisReembCartaCredito").prop('checked', true)
                $("#divNOTReembCartaCreditoDet").show()
                $("#NOTReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
            }
            if (valores.quaisIncluAltDespPrestServ != null) {
                $("#NOTquaisIncluAltDespPrestServ").prop('checked', true)
                $("#divNOTIncluAltDespPrestServDet").show()
                $("#NOTIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
            }
            if (valores.quaisIncluAltDespVar != null) {
                $("#NOTquaisIncluAltDespVar").prop('checked', true)
                $("#divNOTIncluAltDespVarDet").show()
                $("#NOTIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
            }

            if (valores.RadioPrazo == 'determinado') {
                $("#NOTPrazoDet").prop('checked', true)
                $("#divNOTdatasPrazo").show()
                $("#NOTinicioVigencia").val(valores.inicioVigencia)
                $("#NOTfimVigencia").val(valores.fimVigencia)
                $("#NOTdataAviso").val(valores.dataAviso)
                $("#NOTPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#NOTPrazoIndet").prop('checked', true)
                $("#divNOTdatasPrazo").show()
                $("#NOTDivFimVigencia").hide()
                $("#NOTinicioVigencia").val(valores.inicioVigencia)
                $("#NOTdataAviso").val(valores.dataAviso)
                $("#NOTPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divNOTPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#NOTPrazoRenov").prop('checked', true)
                $("#divNOTdatasPrazo").show()
                $("#NOTinicioVigencia").val(valores.inicioVigencia)
                $("#NOTfimVigencia").val(valores.fimVigencia)
                $("#NOTdataAviso").val(valores.dataAviso)
                $("#NOTRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divNOTinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#NOTDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divNOTRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }


        }
    });
}


const carregaCedentes = (dataChange, tabela, nomeCampo) => {
    $("#CESlistaCedente").html('');
    consultDataset('ds_processo_contrato', tabela, [{
        "_field": "documentid",
        "_initialValue": dataChange.target.value,
        "_finalValue": dataChange.target.value,
        "_type": 1
    }]).success(newData => {
        for (let i = 0; i < newData.content.values.length; i++) {
            $('#CESlistaCedente').append('<option value="' + newData.content.values[i]['' + nomeCampo] + '">' + newData.content.values[i]['' + nomeCampo] + '</option>');
        }
    });
}

const addFieldsCessao = (dataChange, type) => {
    var dataCedente = []
    consultDataset('ds_processo_contrato', null, [{
        "_field": "documentid",
        "_initialValue": dataChange.target.value,
        "_finalValue": dataChange.target.value,
        "_type": 1
    }]).success(newData => {
        $("#documentIdHidden").val(dataChange.target.value)
        let valores = {
            tituloContrato: '',
            contratante: '',
            empPartNeg: '',
            objetoContrato: '',
            contratoIndeterminado: '',
            flagContratoVigencia: 'checked',
            dataAviso: '',
            inicioVigencia: '',
            fimVigencia: '',
            AFPSidentifAditivo: '',
            valorTotal1: '',
            valorTotalMensal1: '',
            valorTotalAnual1: '',
            observacoes: '',
            minutaContratoName: '',
            nbpName: '',
            pmName: '',
            uploadEmailName: '',
            uploadOutrosDocName: '',
            uploadLGPDDocName: '',
            propostaComercialName: '',
            documentosSocietariosName: '',
            minutaContratoId: '',
            nbpId: '',
            pmId: '',
            uploadEmailId: '',
            uploadOutrosDocId: '',
            propostaComercialId: '',
            documentosSocietariosId: '',
            uploadLGPDDocId: '',
            outrosDetalhes: '',
            nomeFantGrup: '',
            objetoContrato: '',
            prodComeInter: '',
            contNegAdit: '',
            quaisUpfrontBonus: '',
            BonusDetalhamento: '',
            quaisBonusPerformance: '',
            BonusPerformDet: '',
            quaisProfitSharing: '',
            ProfitSharingDetalhamento: '',
            quaisReembCartaCredito: '',
            ReembCartaCreditoDet: '',
            quaisInvestMarketMinGarant: '',
            quaisFindesFee: '',
            quaisIncluAltDespAgeCamp: '',
            quaisIncluAltDespPrestServ: '',
            IncluAltDespPrestServDet: '',
            quaisIncluAltDespVar: '',
            IncluAltDespVarDet: '',
            garantiaContrato: '',
            tipoGarantia: '',
            DescGarantia: '',
            inicioVidenciaGarantia: '',
            fimVigenciaGarantia: '',
            dataAvisoVenc: '',
            RadioPrazo: '',
            inicioVigencia: '',
            fimVigencia: '',
            dataAviso: '',
            AvisoPrevio: '',
            RenovacaoAutomatica: '',
            contratado: ''
        }

        if (type == 'forncedorPrestadorServico') {
            for (let property in newData.content.values[0]) {
                if (property.includes('NFPS')) {
                    if (valores.hasOwnProperty(property.split('NFPS')[1])) {
                        valores[property.split('NFPS')[1]] = newData.content.values[0][property]
                    }
                }
            }

            var tipoService = $("#servicoJuridico").val()
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)

            consultDataset('ds_processo_contrato', 'NFPStabelaContratado', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('CEStabelaCessionario');

                    $('#CESrazaoSocial___' + linha).val(element.NFPSrazaoSocial)
                    $('#CESnomeFantasia___' + linha).val(element.NFPSnomeFantasia)
                    $('#CEScpfCnpj___' + linha).val(element.NFPScpfCnpj)
                    $('#CESemail___' + linha).val(element.NFPSemail)
                    $('#CEStelefone___' + linha).val(element.NFPStelefone)
                    $('#CESendereco___' + linha).val(element.NFPSendereco)
                    $('#CEScep___' + linha).val(element.NFPScep)
                    $('#CESbairro___' + linha).val(element.NFPSbairro)
                    $('#CEScidade___' + linha).val(element.NFPScidade)
                    $('#CESuf___' + linha).val(element.NFPSuf)
                    $('#CESpais___' + linha).val(element.NFPSpais)
                    $('#CESbanco___' + linha).val(element.NFPSbanco)
                    $('#CESagencia___' + linha).val(element.NFPSagencia)
                    $('#CESconta___' + linha).val(element.NFPSconta)
                    $('#CESnacionalEstrangeira___' + linha).val(element.NFPSnacionalEstrangeira)
                    $('#CEStipo___' + linha).val(element.NFPStipo)
                });
            });

            // $('#CEScedente').append('<optgroup label="Contratante"></optgroup>');
            $('#CESlistaCedenteContratante').append('<option value="' + valores["contratante"] + '">' + valores["contratante"] + '</option>');


            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);

            window["DIScontratante"].setValue(valores.contratante);
            $('#tituloContrato').val(valores.tituloContrato);
            $('#CESvalorTotal').val(valores.valorTotal1);
            $('#CESvalorTotalMensal').val(valores.valorTotalMensal1);
            $('#CESvalorTotalAnual').val(valores.valorTotalAnual1);
            $('#CESminutaCessaoName').val(valores.minutaContratoName);
            $('#CESuploadEmailName').val(valores.uploadEmailName);
            $('#CESuploadLGPDDocName').val(valores.uploadLGPDDocName);
            $('#CESpropostaComercialName').val(valores.propostaComercialName);
            $('#CESdocumentosSocietariosName').val(valores.documentosSocietariosName);
            $('#CESminutaCessaoId').val(valores.minutaContratoId);
            $('#CESuploadEmailId').val(valores.uploadEmailId);
            $('#CESpropostaComercialId').val(valores.propostaComercialId);
            $('#CESdocumentosSocietariosId').val(valores.documentosSocietariosId);
            $('#CESuploadLGPDDocId').val(valores.uploadLGPDDocId);

            valores.uploadEmailId ? blockUploadsButtons('CESuploadEmailFile', true, false, false, true) : blockUploadsButtons('CESuploadEmailFile', false);
            valores.propostaComercialId ? blockUploadsButtons('CESpropostaComercialFile', true, false, false, true) : blockUploadsButtons('CESpropostaComercialFile', false);
            valores.documentosSocietariosId ? blockUploadsButtons('CESdocumentosSocietariosFile', true, false, false, true) : blockUploadsButtons('CESdocumentosSocietariosFile', false);
            valores.minutaContratoId ? blockUploadsButtons('CESminutaCessaoFile', true, false, false, true) : blockUploadsButtons('CESminutaCessaoFile', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('CESuploadLGPDDocFile', true, false, false, true) : blockUploadsButtons('CESuploadLGPDDocFile', false);
            if (valores.RadioPrazo == 'determinado') {
                $("#CESPrazoDet").prop('checked', true)
                $("#divCESdatasPrazo").show()
                $("#CESinicioVigencia").val(valores.inicioVigencia)
                $("#CESfimVigencia").val(valores.fimVigencia)
                $("#CESdataAviso").val(valores.dataAviso)
                $("#CESPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#CESPrazoIndet").prop('checked', true)
                $("#divCESdatasPrazo").show()
                $("#CESDivFimVigencia").hide()
                $("#CESinicioVigencia").val(valores.inicioVigencia)
                $("#CESdataAviso").val(valores.dataAviso)
                $("#CESPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divCESPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#CESPrazoRenov").prop('checked', true)
                $("#divCESdatasPrazo").show()
                $("#CESinicioVigencia").val(valores.inicioVigencia)
                $("#CESfimVigencia").val(valores.fimVigencia)
                $("#CESdataAviso").val(valores.dataAviso)
                $("#CESRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }

            consultDataset('ds_processo_contrato', 'NFPStabelaContratado', [{
                "_field": "documentid",
                "_initialValue": dataChange.target.value,
                "_finalValue": dataChange.target.value,
                "_type": 1
            }]).success(newData => {
                dataCedente.push({
                    id: "",
                    text: ""
                }, {
                    id: "Contratante",
                    text: "Contratante"
                }, {
                    id: "Contratado",
                    text: "Contratado"
                })
                $("#CEScedente").select2({
                    data: dataCedente,
                    allowClear: true,
                    theme: "bootstrap",
                    language: "pt-BR",
                    tags: true,
                    tokenSeparators: [',', '']
                }).on('select2:select', (selected) => {
                    var data = $('#CEScedente').select2('data')
                    var dataString = ''
                    for (let i = 0; i < data.length; i++) {
                        let optionSelected = data[i].id

                        if (i == 0) {
                            dataString += optionSelected
                        } else {
                            dataString += "," + optionSelected
                        }
                    }

                    $("#CEScedenteHidden").val(dataString)
                    if (selected.params.data.id == 'Contratado') {
                        $('#CESdivListaCedenteContratado').removeClass('fs-display-none')
                        for (let i = 0; i < newData.content.values.length; i++) {
                            $('#CESlistaCedenteContratado').append('<option value="' + newData.content.values[i]['NFPSrazaoSocial'] + '">' + newData.content.values[i]['NFPSrazaoSocial'] + '</option>');
                        }
                    } else if (selected.params.data.id == 'Contratante') {
                        $('#CESdivListaCedenteContratante').removeClass('fs-display-none')
                    }
                })
            });

        } else if (type == 'negocios') {
            habilitarRisco(tipoService)
            $(`#riscoContrato option:contains(${newData.content.values[0]['riscoContrato']})`).attr('selected', true)
            $(`#riscoContrato`).parent().css('pointer-events', 'none')

            for (let property in newData.content.values[0]) {
                if (property.includes('NTN')) {
                    if (valores.hasOwnProperty(property.split('NTN')[1])) {
                        valores[property.split('NTN')[1]] = newData.content.values[0][property]
                    }
                }
            }

            dataCedente.push({
                id: "",
                text: ""
            }, {
                id: "empresaParticipante",
                text: "Empresa Participante"
            }, {
                id: "clienteRep",
                text: "Cliente Representante"
            }, {
                id: "corretora",
                text: "Corretora"
            }, {
                id: "parceiro",
                text: "Parceiro"
            })


            $("#CEScedenteNeg").select2({
                data: dataCedente,
                allowClear: true,
                theme: "bootstrap",
                language: "pt-BR",
                tags: true,
                tokenSeparators: [',', '']
            }).on('select2:select', (selected) => {
                var data = $('#CEScedenteNeg').select2('data')
                var dataString = ''
                for (let i = 0; i < data.length; i++) {
                    let optionSelected = data[i].id

                    if (i == 0) {
                        dataString += optionSelected
                    } else {
                        dataString += "," + optionSelected
                    }
                }

                $("#CEScedenteNegHidden").val(dataString)

                if (selected.params.data.id == 'empresaParticipante') {
                    $('#divCESlistaCedenteEmpPart').removeClass('fs-display-none')
                    $('#CESlistaCedenteEmpPart').append('<option value="' + valores.empPartNeg + '">' + valores.empPartNeg + '</option>');
                } else if (selected.params.data.id == 'clienteRep') {
                    var optionClienteRep = []
                    $('#divCESlistaCedenteclienteRep').removeClass('fs-display-none')
                    consultDataset('ds_processo_contrato', 'NTNtabelaClienteRep', [{
                        "_field": "documentid",
                        "_initialValue": dataChange.target.value,
                        "_finalValue": dataChange.target.value,
                        "_type": 1
                    }]).success(newData => {
                        for (let i = 0; i < newData.content.values.length; i++) {
                            optionClienteRep.push({
                                id: newData.content.values[i]['NTNrazaoSocialA'],
                                text: newData.content.values[i]['NTNrazaoSocialA']
                            })
                        }

                        $("#CESlistaCedenteclienteRep").select2({
                            data: optionClienteRep,
                            allowClear: true,
                            theme: "bootstrap",
                            language: "pt-BR",
                            tags: true,
                            tokenSeparators: [',', '']
                        }).on('select2:select', (selected) => {
                            var data1 = $('#CESlistaCedenteclienteRep').select2('data')
                            var dataString1 = ''
                            for (let i = 0; i < data1.length; i++) {
                                let optionSelected1 = data1[i].id

                                if (i == 0) {
                                    dataString1 += optionSelected1
                                } else {
                                    dataString1 += "," + optionSelected1
                                }
                            }

                            $("#CESlistaCedentecliRepHidden").val(dataString1)
                        })
                    })
                } else if (selected.params.data.id == 'corretora') {
                    var optionCorretora = []
                    $('#divCESlistaCedentecorretora').removeClass('fs-display-none')
                    consultDataset('ds_processo_contrato', 'NTNtabelaCorretIntermed', [{
                        "_field": "documentid",
                        "_initialValue": dataChange.target.value,
                        "_finalValue": dataChange.target.value,
                        "_type": 1
                    }]).success(newData => {
                        for (let i = 0; i < newData.content.values.length; i++) {
                            optionCorretora.push({
                                id: newData.content.values[i]['NTNrazaoSocialB'],
                                text: newData.content.values[i]['NTNrazaoSocialB']
                            })
                        }

                        $("#CESlistaCedentecorretora").select2({
                            data: optionCorretora,
                            allowClear: true,
                            theme: "bootstrap",
                            language: "pt-BR",
                            multiple: true
                        }).on('select2:select', (selected) => {
                            var data1 = $('#CESlistaCedentecorretora').select2('data')
                            var dataString1 = ''
                            for (let i = 0; i < data1.length; i++) {
                                let optionSelected1 = data1[i].id

                                if (i == 0) {
                                    dataString1 += optionSelected1
                                } else {
                                    dataString1 += "," + optionSelected1
                                }
                            }
                            $("#CESlistaCedentecorHidden").val(dataString1)
                        })
                    });
                } else if (selected.params.data.id == 'parceiro') {
                    var optionParceiro = []
                    $('#divCESlistaCedenteparceiro').removeClass('fs-display-none')
                    consultDataset('ds_processo_contrato', 'NTNtabelaParSegu', [{
                        "_field": "documentid",
                        "_initialValue": dataChange.target.value,
                        "_finalValue": dataChange.target.value,
                        "_type": 1
                    }]).success(newData => {
                        for (let i = 0; i < newData.content.values.length; i++) {
                            optionParceiro.push({
                                id: newData.content.values[i]['NTNrazaoSocialC'],
                                text: newData.content.values[i]['NTNrazaoSocialC']
                            })
                        }

                        $("#CESlistaCedenteparceiro").select2({
                            data: optionParceiro,
                            allowClear: true,
                            theme: "bootstrap",
                            language: "pt-BR",
                            multiple: true
                        }).on('select2:select', (selected) => {
                            var data1 = $('#CESlistaCedenteparceiro').select2('data')
                            var dataString1 = ''
                            for (let i = 0; i < data1.length; i++) {
                                let optionSelected1 = data1[i].id

                                if (i == 0) {
                                    dataString1 += optionSelected1
                                } else {
                                    dataString1 += "," + optionSelected1
                                }
                            }
                            $("#CESlistaCedenteparcHidden").val(dataString1)
                        })
                    });

                }
            }).on("select2:unselect", (selected) => {
                console.log('entrou no unselect Empresa Cedente')
                if (selected.params.data.id == 'empresaParticipante') {
                    $('#divCESlistaCedenteEmpPart').addClass('fs-display-none')
                } else if (selected.params.data.id == 'clienteRep') {
                    $('#divCESlistaCedenteclienteRep').addClass('fs-display-none')
                } else if (selected.params.data.id == 'corretora') {
                    $('#divCESlistaCedentecorretora').addClass('fs-display-none')
                } else if (selected.params.data.id == 'parceiro') {
                    $('#divCESlistaCedenteparceiro').addClass('fs-display-none')
                }
            });


            consultDataset('ds_processo_contrato', 'NTNtabelaClienteRep', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('CEStabelaClienteRep');
                    $('#CESrazaoSocialA___' + linha).val(element.NTNrazaoSocialA)
                    $('#CESnomeFantasiaA___' + linha).val(element.NTNnomeFantasiaA)
                    $('#CEScpfCnpjA___' + linha).val(element.NTNcpfCnpjA)
                    $('#CESemailA___' + linha).val(element.NTNemailA)
                    $('#CEStelefoneA___' + linha).val(element.NTNtelefoneA)
                    $('#CESenderecoA___' + linha).val(element.NTNenderecoA)
                    $('#CEScepA___' + linha).val(element.NTNcepA)
                    $('#CESbairroA___' + linha).val(element.NTNbairroA)
                    $('#CEScidadeA___' + linha).val(element.NTNcidadeA)
                    $('#CESufA___' + linha).val(element.NTNufA)
                    $('#CESpaisA___' + linha).val(element.NTNpaisA)
                    $('#CESbancoA___' + linha).val(element.NTNbancoA)
                    $('#CESagenciaA___' + linha).val(element.NTNagenciaA)
                    $('#CEScontaA___' + linha).val(element.NTNcontaA)
                    $('#CESnacionalEstrangeiraA___' + linha).val(element.NTNnacionalEstrangeiraA)
                    $('#CEStipoA___' + linha).val(element.NTNtipoA)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaCorretIntermed', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('CEStabelaCorretIntermed');
                    $('#CESrazaoSocialB___' + linha).val(element.NTNrazaoSocialB)
                    $('#CESnomeFantasiaB___' + linha).val(element.NTNnomeFantasiaB)
                    $('#CEScpfCnpjB___' + linha).val(element.NTNcpfCnpjB)
                    $('#CESemailB___' + linha).val(element.NTNemailB)
                    $('#CEStelefoneB___' + linha).val(element.NTNtelefoneB)
                    $('#CESenderecoB___' + linha).val(element.NTNenderecoB)
                    $('#CEScepB___' + linha).val(element.NTNcepB)
                    $('#CESbairroB___' + linha).val(element.NTNbairroB)
                    $('#CEScidadeB___' + linha).val(element.NTNcidadeB)
                    $('#CESufB___' + linha).val(element.NTNufB)
                    $('#CESpaisB___' + linha).val(element.NTNpaisB)
                    $('#CESbancoB___' + linha).val(element.NTNbancoB)
                    $('#CESagenciaB___' + linha).val(element.NTNagenciaB)
                    $('#CEScontaB___' + linha).val(element.NTNcontaB)
                    $('#CESnacionalEstrangeiraB___' + linha).val(element.NTNnacionalEstrangeiraB)
                    $('#CEStipoB___' + linha).val(element.NTNtipoB)
                });
            });

            consultDataset('ds_processo_contrato', 'NTNtabelaParSegu', [{
                "_field": "documentid",
                "_initialValue": newData.content.values[0]['documentid'],
                "_finalValue": newData.content.values[0]['documentid'],
                "_type": 1
            }]).success(dataTable => {
                dataTable.content.values.forEach((element, index) => {
                    let linha = wdkAddChild('CEStabelaParSegu');
                    $('#CESrazaoSocialC___' + linha).val(element.NTNrazaoSocialC)
                    $('#CESnomeFantasiaC___' + linha).val(element.NTNnomeFantasiaC)
                    $('#CEScpfCnpjC___' + linha).val(element.NTNcpfCnpjC)
                    $('#CESemailC___' + linha).val(element.NTNemailC)
                    $('#CEStelefoneC___' + linha).val(element.NTNtelefoneC)
                    $('#CESenderecoC___' + linha).val(element.NTNenderecoC)
                    $('#CEScepC___' + linha).val(element.NTNcepC)
                    $('#CESbairroC___' + linha).val(element.NTNbairroC)
                    $('#CEScidadeC___' + linha).val(element.NTNcidadeC)
                    $('#CESufC___' + linha).val(element.NTNufC)
                    $('#CESpaisC___' + linha).val(element.NTNpaisC)
                    $('#CESbancoC___' + linha).val(element.NTNbancoC)
                    $('#CESagenciaC___' + linha).val(element.NTNagenciaC)
                    $('#CEScontaC___' + linha).val(element.NTNcontaC)
                    $('#CESnacionalEstrangeiraC___' + linha).val(element.NTNnacionalEstrangeiraC)
                    $('#CEStipoC___' + linha).val(element.NTNtipoC)
                });
            });
            var dataDeAviso = valores.dataAviso
            var dia2 = dataDeAviso.substring(0, 2)
            var mes2 = dataDeAviso.substring(3, 5)
            var ano2 = dataDeAviso.substring(6, 10)
            var dataCont = ano2 + "/" + mes2 + "/" + dia2
            $("#dataNotificacaoSolicitante").val(dataCont);
            $('#tituloContrato').val(valores.tituloContrato);
            $('#CESobjetoContrato').val(valores.objetoContrato);
            $('#CESprodComeInte').val(valores.prodComeInter);
            $('#CESobservacoes').val(valores.observacoes);
            $('#CESgarantiaContrato').val(valores.garantiaContrato);
            $('#CEStipoGarantia').val(valores.tipoGarantia);
            $('#CESDescGarantia').val(valores.DescGarantia);
            $('#CESinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
            $('#CESfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
            $('#CESdataAvisoVenc').val(valores.dataAvisoVenc);

            $('#CESminutaContratoName').val(valores.minutaContratoName);
            $('#CESnbpName').val(valores.nbpName);
            $('#CESpmName').val(valores.pmName);
            $('#CESuploadEmailNameA').val(valores.uploadEmailName);
            $('#CESdocumentosSocietariosNameA').val(valores.documentosSocietariosName);
            $('#CESuploadLGPDDocNameA').val(valores.uploadLGPDDocName);
            $('#CESminutaContratoId').val(valores.minutaContratoId);
            $('#CESnbpId').val(valores.nbpId);
            $('#CESpmId').val(valores.pmId);
            $('#CESuploadEmailIdA').val(valores.uploadEmailId);
            $('#CESdocumentosSocietariosIdA').val(valores.documentosSocietariosId);
            $('#CESuploadLGPDDocIdA').val(valores.uploadLGPDDocId);

            valores.minutaContratoId ? blockUploadsButtons('CESminutaContratoFile', true, false, false, true) : blockUploadsButtons('CESminutaContratoFile', false);
            valores.nbpId ? blockUploadsButtons('CESnbpFile', true, false, false, true) : blockUploadsButtons('CESnbpFile', false);
            valores.pmId ? blockUploadsButtons('CESpmFile', true, false, false, true) : blockUploadsButtons('CESpmFile', false);
            valores.uploadEmailId ? blockUploadsButtons('CESuploadEmailFileA', true, false, false, true) : blockUploadsButtons('CESuploadEmailFileA', false);
            valores.documentosSocietariosId ? blockUploadsButtons('CESdocumentosSocietariosFileA', true, false, false, true) : blockUploadsButtons('CESdocumentosSocietariosFileA', false);
            valores.uploadLGPDDocId ? blockUploadsButtons('CESuploadLGPDDocFileA', true, false, false, true) : blockUploadsButtons('CESuploadLGPDDocFileA', false);

            (valores.contNegAdit == 'sim') ? $('#CEScontNegAditSim').prop('checked', true): $('#CEScontNegAditNao').prop('checked', true);
            (valores.quaisInvestMarketMinGarant != null) ? $('#CESquaisInvestMarketMinGarant').prop('checked', true): $('#CESquaisInvestMarketMinGarant').prop('checked', false);
            (valores.quaisFindesFee != null) ? $('#CESquaisFindesFee').prop('checked', true): $('#CESquaisFindesFee').prop('checked', false);
            (valores.quaisIncluAltDespAgeCamp != null) ? $('#CESquaisIncluAltDespAgeCamp').prop('checked', true): $('#CESquaisIncluAltDespAgeCamp').prop('checked', false);
            if (valores.quaisUpfrontBonus != null) {
                $("#CESquaisUpfrontBonus").prop('checked', true)
                $("#divCESBonusDetalhamento").show()
                $("#CESBonusDetalhamento").val(valores.BonusDetalhamento)
            }
            if (valores.quaisBonusPerformance != null) {
                $("#CESquaisBonusPerformance").prop('checked', true)
                $("#divCESBonusPerformDet").show()
                $("#CESBonusPerformDet").val(valores.BonusPerformDet)
            }
            if (valores.quaisProfitSharing != null) {
                $("#CESquaisProfitSharing").prop('checked', true)
                $("#divCESquaisProfitSharing").show()
                $("#CESProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
            }
            if (valores.quaisReembCartaCredito != null) {
                $("#CESquaisReembCartaCredito").prop('checked', true)
                $("#divCESReembCartaCreditoDet").show()
                $("#CESReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
            }
            if (valores.quaisIncluAltDespPrestServ != null) {
                $("#CESquaisIncluAltDespPrestServ").prop('checked', true)
                $("#divCESIncluAltDespPrestServDet").show()
                $("#CESIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
            }
            if (valores.quaisIncluAltDespVar != null) {
                $("#CESquaisIncluAltDespVar").prop('checked', true)
                $("#divCESIncluAltDespVarDet").show()
                $("#CESIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
            }

            if (valores.RadioPrazo == 'determinado') {
                $("#CESPrazoDet").prop('checked', true)
                $("#divCESdatasPrazo").show()
                $("#CESinicioVigencia").val(valores.inicioVigencia)
                $("#CESfimVigencia").val(valores.fimVigencia)
                $("#CESdataAviso").val(valores.dataAviso)
                $("#CESPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESPeriodoRenovacao").show().removeClass('col-sm-4').addClass('col-sm-3')

            } else if (valores.RadioPrazo == 'indeterminado') {
                $("#CESPrazoIndet").prop('checked', true)
                $("#divCESdatasPrazo").show()
                $("#CESDivFimVigencia").hide()
                $("#CESinicioVigencia").val(valores.inicioVigencia)
                $("#CESdataAviso").val(valores.dataAviso)
                $("#CESPeriodoRenovacao").val(valores.AvisoPrevio)
                $("#divCESPeriodoRenovacao").show().removeClass('col-sm-3').addClass('col-sm-4')

            } else if (valores.RadioPrazo == 'renovacao') {
                $("#CESPrazoRenov").prop('checked', true)
                $("#divCESdatasPrazo").show()
                $("#CESinicioVigencia").val(valores.inicioVigencia)
                $("#CESfimVigencia").val(valores.fimVigencia)
                $("#CESdataAviso").val(valores.dataAviso)
                $("#CESRenovacaoAut").val(valores.RenovacaoAutomatica)
                $("#divCESinicioVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#CESDivFimVigencia").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESdataAviso").show().removeClass('col-sm-4').addClass('col-sm-3')
                $("#divCESRenovacaoAut").show().removeClass('col-sm-4').addClass('col-sm-3')
            }

        }

    });

}

const preencheValoresCessao = (letra, newData) => {
    if (global.historicoCessaoSelect.indexOf(letra)) {
        global.historicoCessaoSelect.push(letra);
        var valores = {};
        for (let i = 0; i < newData.content.values.length; i++) {
            global.contadorRazao++;
            var property = newData.content.values[i]['NTNrazaoSocial' + letra];
            let numRazao = 'razaoSocial' + global.contadorRazao; //numero razao dinamico por se tratar de pai e filho   
            let razaoSocial = {
                NTNrazaoSocial: property
            }
            razaoSocial = JSON.parse(JSON.stringify(razaoSocial).replace('NTNrazaoSocial', numRazao)) //substituição do numero da razao
            Object.assign(valores, razaoSocial);
        }
        let sessao = {
            A: 'Cliente-Representante',
            B: 'Corretora',
            C: 'Parceiro'
        }
        $('#CEScedente').append('<optgroup label="' + sessao[letra] + '"></optgroup>');
        for (val in valores) {
            $('#CEScedente').append('<option value="' + val + '">' + valores[val] + '</option>');
        }
    }
}



const blockUploadsButtons = (nameField = '', blockLoad = false, blockView = false, blockDownload = false, blockDelete = false) => {
    if (nameField) {
        nameField.split(';').forEach(e => {
            $(`[name="${e}"]`).attr('disabled', blockLoad)
            $(`[name="${e}"]`).parent().attr('disabled', blockLoad)
            $(`[name="${e}"]`).parent().siblings(".visualizeFile").attr('disabled', blockView)
            $(`[name="${e}"]`).parent().siblings(".downloadFile").attr('disabled', blockDownload)
            $(`[name="${e}"]`).parent().siblings(".deleteFile").attr('disabled', blockDelete)
        })
    }
}

const clearFieldsAditivo = () => {
    var tipoContrato = $("#tipoContrato").val()

    let valores = {
        tituloContrato: '',
        contratante: '',
        empPartNeg: '',
        objetoContrato: '',
        contratoIndeterminado: '',
        flagContratoVigencia: 'checked',
        dataAviso: '',
        inicioVigencia: '',
        fimVigencia: '',
        AFPSidentifAditivo: '',
        valorTotal: '',
        valorTotalMensal: '',
        valorTotalAnual: '',
        observacoes: '',
        minutaContratoName: '',
        nbpName: '',
        pmName: '',
        uploadEmailName: '',
        uploadOutrosDocName: '',
        uploadLGPDDocName: '',
        propostaComercialName: '',
        documentosSocietariosName: '',
        minutaContratoId: '',
        nbpId: '',
        pmId: '',
        uploadEmailId: '',
        uploadOutrosDocId: '',
        propostaComercialId: '',
        documentosSocietariosId: '',
        uploadLGPDDocId: '',
        outrosDetalhes: '',
        nomeFantGrup: '',
        objetoContrato: '',
        prodComeInter: '',
        contNegAdit: '',
        quaisUpfrontBonus: '',
        BonusDetalhamento: '',
        quaisBonusPerformance: '',
        BonusPerformDet: '',
        quaisProfitSharing: '',
        ProfitSharingDetalhamento: '',
        quaisReembCartaCredito: '',
        ReembCartaCreditoDet: '',
        quaisInvestMarketMinGarant: '',
        quaisFindesFee: '',
        quaisIncluAltDespAgeCamp: '',
        quaisIncluAltDespPrestServ: '',
        IncluAltDespPrestServDet: '',
        quaisIncluAltDespVar: '',
        IncluAltDespVarDet: '',
        garantiaContrato: '',
        tipoGarantia: '',
        DescGarantia: '',
        inicioVidenciaGarantia: '',
        fimVigenciaGarantia: '',
        dataAvisoVenc: '',
        RadioPrazo: '',
        inicioVigencia: '',
        fimVigencia: '',
        dataAviso: '',
        avisoPrevio: '',
        RenovacaoAutomatica: ''
    }
    if (tipoContrato == "forncedorPrestadorServico") {
        $('#AFPStituloContrato').val(valores.tituloContrato);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);

        $('#tituloContrato').val(valores.tituloContrato);
        window['AFPScontratante'].value = valores.contratante;
        $('#AFPSobjetoContrato').val(valores.objetoContrato);
        $('#AFPScontratoIndeterminado').val(valores.contratoIndeterminado);
        (valores.flagContratoVigencia == 'on') ? $('#AFPSflagContratoVigencia').prop('checked', true): $('#AFPSflagContratoVigencia').prop('checked', false);
        $('#AFPSdataAviso').val(valores.dataAviso);
        $('#AFPSinicioVigencia').val(valores.inicioVigencia);
        $('#AFPSfimVigencia').val(valores.fimVigencia);
        $('#AFPSvalorTotal').val(valores.valorTotal);
        $('#AFPSvalorTotalMensal').val(valores.valorTotalMensal);
        $('#AFPSvalorTotalAnual').val(valores.valorTotalAnual);
        $('#AFPSobservacoes').val(valores.observacoes);

        $('#AFPSminutaContratoName').val(valores.minutaContratoName);
        $('#AFPSpropostaComercialName').val(valores.propostaComercialName);
        $('#AFPSuploadEmailName').val(valores.uploadEmailName);
        $('#AFPSdocumentosSocietariosName').val(valores.documentosSocietariosName);
        $('#AFPSuploadLGPDDocName').val(valores.uploadLGPDDocName);

        $('#AFPSminutaContratoId').val(valores.minutaContratoId);
        $('#AFPSpropostaComercialId').val(valores.uploadEmailId);
        $('#AFPSuploadEmailId').val(valores.uploadEmailId);
        $('#AFPSdocumentosSocietariosId').val(valores.documentosSocietariosId);
        $('#AFPSuploadLGPDDocId').val(valores.uploadLGPDDocId);


        valores.minutaContratoId ? $('#AFPSminutaContratoFile').parent().attr('disabled', 'disabled') : $('#AFPSminutaContratoFile').parent().attr('disabled', false);
        valores.propostaComercialId ? $('#AFPSpropostaComercialFile').parent().attr('disabled', 'disabled') : $('#AFPSpropostaComercialFile').parent().attr('disabled', false);
        valores.uploadEmailId ? $('#AFPSuploadEmailFile').parent().attr('disabled', 'disabled') : $('#AFPSuploadEmailFile').parent().attr('disabled', false);
        valores.documentosSocietariosId ? $('#AFPSdocumentosSocietariosFile').parent().attr('disabled', 'disabled') : $('#AFPSdocumentosSocietariosFile').parent().attr('disabled', false);
        valores.uploadLGPDDocId ? $('#AFPSuploadLGPDDocFile').parent().attr('disabled', 'disabled') : $('#AFPSuploadLGPDDocFile').parent().attr('disabled', false);

        $('#AFPStabelaContratado tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
        $('#AFPStabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    } else if (tipoContrato == "negocios") {
        $('#AFPStituloContrato').val(valores.tituloContrato);
        $('#tituloContrato').val(valores.tituloContrato);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);
        window["AFPScontratante"].setValue(valores.empPartNeg);
        $('#AFPSobjetoContrato').val(valores.objetoContrato);
        $('#AFPSNomeFantasiaGrupo').val(valores.nomeFantGrup);
        $('#AFPSobjetoContrato').val(valores.objetoContrato);
        $('#AFPSprodComeInte').val(valores.prodComeInter);
        $('#AFPSobservacoes').val(valores.observacoes);
        $('#AFPSgarantiaContrato').val(valores.garantiaContrato);
        $('#AFPStipoGarantia').val(valores.tipoGarantia);
        $('#AFPSDescGarantia').val(valores.DescGarantia);
        $('#AFPSinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
        $('#AFPSfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
        $('#AFPSdataAvisoVenc').val(valores.dataAvisoVenc);


        $('#ATNminutaContratoName').val(valores.minutaContratoName);
        $('#ATNnbpName').val(valores.nbpName);
        $('#ATNpmName').val(valores.pmName);
        $('#ATNuploadEmailName').val(valores.uploadEmailName);
        $('#ATNdocumentosSocietariosName').val(valores.documentosSocietariosName);
        $('#ATNuploadLGPDDocName').val(valores.uploadLGPDDocName);
        $('#ATNminutaContratoId').val(valores.minutaContratoId);
        $('#ATNnbpId').val(valores.nbpId);
        $('#ATNpmId').val(valores.pmId);
        $('#ATNuploadEmailId').val(valores.uploadEmailId);
        $('#ATNdocumentosSocietariosId').val(valores.documentosSocietariosId);
        $('#ATNuploadLGPDDocId').val(valores.uploadLGPDDocId);

        valores.minutaContratoId ? $('#ATNminutaContratoFile').parent().attr('disabled', 'disabled') : $('#ATNminutaContratoFile').parent().attr('disabled', false);
        valores.nbpId ? $('#ATNnbpFile').parent().attr('disabled', 'disabled') : $('#ATNnbpFile').parent().attr('disabled', false);
        valores.pmId ? $('#ATNpmFile').parent().attr('disabled', 'disabled') : $('#ATNpmFile').parent().attr('disabled', false);
        valores.uploadEmailId ? $('#ATNuploadEmailFile').parent().attr('disabled', 'disabled') : $('#ATNuploadEmailFile').parent().attr('disabled', false);
        valores.documentosSocietariosId ? $('#ATNdocumentosSocietariosFile').parent().attr('disabled', 'disabled') : $('#ATNdocumentosSocietariosFile').parent().attr('disabled', false);
        valores.uploadLGPDDocId ? $('#ATNuploadLGPDDocFile').parent().attr('disabled', 'disabled') : $('#ATNuploadLGPDDocFile').parent().attr('disabled', false);

        if (valores.contNegAdit == '') {
            $('#AFPScontNegAditSim').prop('checked', false)
            $('#AFPScontNegAditNao').prop('checked', false)
        }
        if (valores.quaisUpfrontBonus == '') {
            $("#AFPSquaisUpfrontBonus").prop('checked', false)
            $("#divAFPSBonusDetalhamento").hide()
            $("#AFPSBonusDetalhamento").val(valores.BonusDetalhamento)
        }
        if (valores.quaisBonusPerformance == '') {
            $("#AFPSquaisBonusPerformance").prop('checked', false)
            $("#divAFPSBonusPerformDet").hide()
            $("#AFPSBonusPerformDet").val(valores.BonusPerformDet)
        }
        if (valores.quaisProfitSharing == '') {
            $("#AFPSquaisProfitSharing").prop('checked', false)
            $("#divAFPSquaisProfitSharing").hide()
            $("#AFPSProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
        }
        if (valores.quaisReembCartaCredito == '') {
            $("#AFPSquaisReembCartaCredito").prop('checked', false)
            $("#divAFPSReembCartaCreditoDet").hide()
            $("#AFPSReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
        }
        if (valores.quaisIncluAltDespPrestServ == '') {
            $("#AFPSquaisIncluAltDespPrestServ").prop('checked', false)
            $("#divAFPSIncluAltDespPrestServDet").hide()
            $("#AFPSIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
        }
        if (valores.quaisIncluAltDespVar == '') {
            $("#AFPSquaisIncluAltDespVar").prop('checked', false)
            $("#divAFPSIncluAltDespVarDet").hide()
            $("#AFPSIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
        }

        if (valores.RadioPrazo == '') {
            $("#AFPSPrazoDet").prop('checked', false)
            $("#AFPSPrazoIndet").prop('checked', false)
            $("#AFPSPrazoRenov").prop('checked', false)
            $("#AFPSinicioVigencia").val(valores.inicioVigencia)
            $("#AFPSfimVigencia").val(valores.fimVigencia)
            $("#AFPSdataAviso").val(valores.dataAviso)
            $("#AFPSPeriodoRenovacao").val(valores.avisoPrevio)
            $("#AFPSRenovacaoAut").val(valores.RenovacaoAutomatica)
            $("#divAFPSinicioVigencia").hide()
            $("#AFPSDivFimVigencia").hide()
            $("#divAFPSdataAviso").hide()
            $("#divAFPSPeriodoRenovacao").hide()
            $("#divAFPSRenovacaoAut").hide()
        }

        $('#AFPStabelaContratado tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#ATNtabelaCorretIntermed tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#ATNtabelaParSegu tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#AFPStabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    }




}

const clearFieldsDistrato = () => {
    var tipoContrato = $("#tipoContrato").val()

    let valores = {
        tituloContrato: '',
        contratante: '',
        empPartNeg: '',
        objetoContrato: '',
        contratoIndeterminado: '',
        flagContratoVigencia: 'checked',
        dataAviso: '',
        inicioVigencia: '',
        fimVigencia: '',
        AFPSidentifAditivo: '',
        valorTotal: '',
        valorTotalMensal: '',
        valorTotalAnual: '',
        observacoes: '',
        minutaContratoName: '',
        nbpName: '',
        pmName: '',
        uploadEmailName: '',
        uploadOutrosDocName: '',
        uploadLGPDDocName: '',
        propostaComercialName: '',
        documentosSocietariosName: '',
        minutaContratoId: '',
        nbpId: '',
        pmId: '',
        uploadEmailId: '',
        uploadOutrosDocId: '',
        propostaComercialId: '',
        documentosSocietariosId: '',
        uploadLGPDDocId: '',
        outrosDetalhes: '',
        nomeFantGrup: '',
        objetoContrato: '',
        prodComeInter: '',
        contNegAdit: '',
        quaisUpfrontBonus: '',
        BonusDetalhamento: '',
        quaisBonusPerformance: '',
        BonusPerformDet: '',
        quaisProfitSharing: '',
        ProfitSharingDetalhamento: '',
        quaisReembCartaCredito: '',
        ReembCartaCreditoDet: '',
        quaisInvestMarketMinGarant: '',
        quaisFindesFee: '',
        quaisIncluAltDespAgeCamp: '',
        quaisIncluAltDespPrestServ: '',
        IncluAltDespPrestServDet: '',
        quaisIncluAltDespVar: '',
        IncluAltDespVarDet: '',
        garantiaContrato: '',
        tipoGarantia: '',
        DescGarantia: '',
        inicioVidenciaGarantia: '',
        fimVigenciaGarantia: '',
        dataAvisoVenc: '',
        RadioPrazo: '',
        inicioVigencia: '',
        fimVigencia: '',
        dataAviso: '',
        avisoPrevio: '',
        RenovacaoAutomatica: ''
    }

    if (tipoContrato == "forncedorPrestadorServico") {
        window["DIScontratante"].setValue(valores.contratante);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);
        $('#tituloContrato').val(valores.tituloContrato);
        $('#DISminutaDistratoName').val(valores.minutaContratoName);
        $('#DISuploadEmailName').val(valores.uploadEmailName);
        $('#DISuploadLGPDDocName').val(valores.uploadLGPDDocName);
        $('#DISpropostaComercialName').val(valores.propostaComercialName);
        $('#DISdocumentosSocietariosName').val(valores.documentosSocietariosName);
        $('#DISminutaDistratoId').val(valores.minutaContratoId);
        $('#DISuploadEmailId').val(valores.uploadEmailId);
        $('#DISpropostaComercialId').val(valores.propostaComercialId);
        $('#DISdocumentosSocietariosId').val(valores.documentosSocietariosId);
        $('#DISuploadLGPDDocId').val(valores.uploadLGPDDocId);
        valores.uploadEmailId ? $('#DISuploadEmailFile').attr('disabled', 'disabled') : $('#DISuploadEmailFile').attr('disabled', false);
        valores.propostaComercialId ? $('#DISpropostaComercialFile').attr('disabled', 'disabled') : $('#DISpropostaComercialFile').attr('disabled', false);
        valores.documentosSocietariosId ? $('#DISdocumentosSocietariosFile').attr('disabled', 'disabled') : $('#DISdocumentosSocietariosFile').attr('disabled', false);
        valores.minutaContratoId ? $('#DISminutaDistratoFile').attr('disabled', 'disabled') : $('#DISminutaDistratoFile').attr('disabled', false);
        valores.uploadLGPDDocId ? $('#DISuploadLGPDDocFile').attr('disabled', 'disabled') : $('#DISuploadLGPDDocFile').attr('disabled', false);


        $('#DIStabelaContratado tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#DIStabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    } else if (tipoContrato == "negocios") {
        window["DISempPartNeg"].setValue(valores.empPartNeg);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);
        $('#tituloContrato').val(valores.tituloContrato);
        $("#DIStituloContrato").val(valores.tituloContrato)
        $('#DISnomeFantGrup').val(valores.nomeFantGrup);
        $('#DISobjetoContrato').val(valores.objetoContrato);
        $('#DISprodComeInte').val(valores.prodComeInter);
        $('#DISobservacoes').val(valores.observacoes);
        $('#DISgarantiaContrato').val(valores.garantiaContrato);
        $('#DIStipoGarantia').val(valores.tipoGarantia);
        $('#DISDescGarantia').val(valores.DescGarantia);
        $('#DISinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
        $('#DISfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
        $('#DISdataAvisoVenc').val(valores.dataAvisoVenc);

        $('#DISminutaContratoName').val(valores.minutaContratoName);
        $('#DISnbpName').val(valores.nbpName);
        $('#DISpmName').val(valores.pmName);
        $('#DISuploadEmailNameA').val(valores.uploadEmailName);
        $('#DISdocumentosSocietariosNameA').val(valores.documentosSocietariosName);
        $('#DISuploadLGPDDocNameA').val(valores.uploadLGPDDocName);
        $('#DISminutaContratoId').val(valores.minutaContratoId);
        $('#DISnbpId').val(valores.nbpId);
        $('#DISpmId').val(valores.pmId);
        $('#DISuploadEmailIdA').val(valores.uploadEmailId);
        $('#DISdocumentosSocietariosIdA').val(valores.documentosSocietariosId);
        $('#DISuploadLGPDDocIdA').val(valores.uploadLGPDDocId);

        valores.minutaContratoId ? $('#DISminutaContratoFile').parent().attr('disabled', 'disabled') : $('#DISminutaContratoFile').parent().attr('disabled', false);
        valores.nbpId ? $('#DISnbpFile').parent().attr('disabled', 'disabled') : $('#DISnbpFile').parent().attr('disabled', false);
        valores.pmId ? $('#DISpmFile').parent().attr('disabled', 'disabled') : $('#DISpmFile').parent().attr('disabled', false);
        valores.uploadEmailId ? $('#DISuploadEmailFileA').parent().attr('disabled', 'disabled') : $('#DISuploadEmailFileA').parent().attr('disabled', false);
        valores.documentosSocietariosId ? $('#DISdocumentosSocietariosFileA').parent().attr('disabled', 'disabled') : $('#DISdocumentosSocietariosFileA').parent().attr('disabled', false);
        valores.uploadLGPDDocId ? $('#DISuploadLGPDDocFileA').parent().attr('disabled', 'disabled') : $('#DISuploadLGPDDocFileA').parent().attr('disabled', false);

        if (valores.contNegAdit == '') {
            $('#DIScontNegAditSim').prop('checked', false)
            $('#DIScontNegAditNao').prop('checked', false)
        }
        if (valores.quaisUpfrontBonus == '') {
            $("#DISquaisUpfrontBonus").prop('checked', false)
            $("#divDISBonusDetalhamento").hide()
            $("#DISBonusDetalhamento").val(valores.BonusDetalhamento)
        }
        if (valores.quaisBonusPerformance == '') {
            $("#DISquaisBonusPerformance").prop('checked', false)
            $("#divDISBonusPerformDet").hide()
            $("#DISBonusPerformDet").val(valores.BonusPerformDet)
        }
        if (valores.quaisProfitSharing == '') {
            $("#DISquaisProfitSharing").prop('checked', false)
            $("#divDISquaisProfitSharing").hide()
            $("#DISProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
        }
        if (valores.quaisReembCartaCredito == '') {
            $("#DISquaisReembCartaCredito").prop('checked', false)
            $("#divDISReembCartaCreditoDet").hide()
            $("#DISReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
        }
        if (valores.quaisIncluAltDespPrestServ == '') {
            $("#DISquaisIncluAltDespPrestServ").prop('checked', false)
            $("#divDISIncluAltDespPrestServDet").hide()
            $("#DISIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
        }
        if (valores.quaisIncluAltDespVar == '') {
            $("#DISquaisIncluAltDespVar").prop('checked', false)
            $("#divDISIncluAltDespVarDet").hide()
            $("#DISIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
        }

        if (valores.RadioPrazo == '') {
            $("#DISPrazoDet").prop('checked', false)
            $("#DISPrazoIndet").prop('checked', false)
            $("#DISPrazoRenov").prop('checked', false)
            $("#DISinicioVigencia").val(valores.inicioVigencia)
            $("#DISfimVigencia").val(valores.fimVigencia)
            $("#DISdataAviso").val(valores.dataAviso)
            $("#DISPeriodoRenovacao").val(valores.avisoPrevio)
            $("#DISRenovacaoAut").val(valores.RenovacaoAutomatica)
            $("#divDISinicioVigencia").hide()
            $("#DISDivFimVigencia").hide()
            $("#divDISdataAviso").hide()
            $("#divDISPeriodoRenovacao").hide()
            $("#divDISRenovacaoAut").hide()
        }

        $('#DIStabelaClienteRep tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#DIStabelaCorretIntermed tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#DIStabelaParSegu tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#DIStabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    }

    // window["DIScontratante"].setValue(valores.contratante);
    // $('#DISminutaDistratoName').val(valores.minutaContratoName);
    // $('#DISuploadEmailName').val(valores.uploadEmailName);
    // $('#DISuploadLGPDDocName').val(valores.uploadLGPDDocName);
    // $('#DISpropostaComercialName').val(valores.propostaComercialName);
    // $('#DISdocumentosSocietariosName').val(valores.documentosSocietariosName);
    // $('#DISminutaDistratoId').val(valores.minutaContratoId);
    // $('#DISuploadEmailId').val(valores.uploadEmailId);
    // $('#DISpropostaComercialId').val(valores.propostaComercialId);
    // $('#DISdocumentosSocietariosId').val(valores.documentosSocietariosId);
    // $('#DISuploadLGPDDocId').val(valores.uploadLGPDDocId);
    // valores.uploadEmailId ? $('#DISuploadEmailFile').attr('disabled', 'disabled') : $('#DISuploadEmailFile').attr('disabled', false);
    // valores.propostaComercialId ? $('#DISpropostaComercialFile').attr('disabled', 'disabled') : $('#DISpropostaComercialFile').attr('disabled', false);
    // valores.documentosSocietariosId ? $('#DISdocumentosSocietariosFile').attr('disabled', 'disabled') : $('#DISdocumentosSocietariosFile').attr('disabled', false);
    // valores.minutaContratoId ? $('#DISminutaDistratoFile').attr('disabled', 'disabled') : $('#DISminutaDistratoFile').attr('disabled', false);
    // valores.uploadLGPDDocId ? $('#DISuploadLGPDDocFile').attr('disabled', 'disabled') : $('#DISuploadLGPDDocFile').attr('disabled', false);


    // $('#DIStabelaContratado tbody tr:visible').each((index, element) => {
    //     fnWdkRemoveChild(element)
    // })

    // $('#DIStabelaUploadFiles tbody tr:visible').each((index, element) => {
    //     fnWdkRemoveChild(element)
    // })
}

const clearFieldsProposta = () => {
    let valores = {
        tituloContrato: '',
        contratante: '',
        objetoContrato: '',
        contratoIndeterminado: '',
        flagContratoVigencia: 'checked',
        dataAviso: '',
        inicioVigencia: '',
        AFPSidentifAditivo: '',
        fimVigencia: '',
        valorTotal: '',
        valorTotalMensal: '',
        valorTotalAnual: '',
        observacoes: '',
        minutaContratoName: '',
        uploadEmailName: '',
        propostaComercialName: '',
        documentosSocietariosName: '',
        uploadLGPDDocName: '',
        minutaContratoId: '',
        uploadEmailId: '',
        propostaComercialId: '',
        documentosSocietariosId: '',
        uploadLGPDDocId: '',
        outrosDetalhes: '',
        riscoContrato: ''
    }


    window["PROCcontratante"].setValue(valores.contratante);
    $("#dataNotificacaoSolicitante").val(valores.dataAviso);
    $('#tituloContrato').val(valores.tituloContrato);
    $('#PROCminutaPropostaName').val(valores.minutaContratoName);
    $('#PROCuploadEmailName').val(valores.uploadEmailName);
    $('#PROCuploadLGPDDocName').val(valores.uploadLGPDDocName);
    $('#PROCpropostaComercialName').val(valores.propostaComercialName);
    $('#PROCdocumentosSocietariosName').val(valores.documentosSocietariosName);
    $('#PROCminutaPropostaId').val(valores.minutaContratoId);
    $('#PROCuploadEmailId').val(valores.uploadEmailId);
    $('#PROCpropostaComercialId').val(valores.propostaComercialId);
    $('#PROCdocumentosSocietariosId').val(valores.documentosSocietariosId);
    $('#PROCuploadLGPDDocId').val(valores.uploadLGPDDocId);
    valores.uploadEmailId ? $('#PROCuploadEmailFile').attr('disabled', 'disabled') : $('#PROCuploadEmailFile').attr('disabled', false);
    valores.propostaComercialId ? $('#PROCpropostaComercialFile').attr('disabled', 'disabled') : $('#PROCpropostaComercialFile').attr('disabled', false);
    valores.documentosSocietariosId ? $('#PROCdocumentosSocietariosFile').attr('disabled', 'disabled') : $('#PROCdocumentosSocietariosFile').attr('disabled', false);
    valores.minutaContratoId ? $('#PROCminutaPropostaFile').attr('disabled', 'disabled') : $('#PROCminutaPropostaFile').attr('disabled', false);
    valores.uploadLGPDDocId ? $('#PROCuploadLGPDDocFile').attr('disabled', 'disabled') : $('#PROCuploadLGPDDocFile').attr('disabled', false);


    $('#PROCtabelaContratado tbody tr:visible').each((index, element) => {
        fnWdkRemoveChild(element)
    })

    $('#PROCtabelaUploadFiles tbody tr:visible').each((index, element) => {
        fnWdkRemoveChild(element)
    })
}

const clearFieldsNotificacao = () => {
    var tipoContrato = $("#tipoContrato").val()

    let valores = {
        tituloContrato: '',
        contratante: '',
        empPartNeg: '',
        objetoContrato: '',
        contratoIndeterminado: '',
        flagContratoVigencia: 'checked',
        dataAviso: '',
        inicioVigencia: '',
        fimVigencia: '',
        AFPSidentifAditivo: '',
        valorTotal: '',
        valorTotalMensal: '',
        valorTotalAnual: '',
        observacoes: '',
        minutaContratoName: '',
        nbpName: '',
        pmName: '',
        uploadEmailName: '',
        uploadOutrosDocName: '',
        uploadLGPDDocName: '',
        propostaComercialName: '',
        documentosSocietariosName: '',
        minutaContratoId: '',
        nbpId: '',
        pmId: '',
        uploadEmailId: '',
        uploadOutrosDocId: '',
        propostaComercialId: '',
        documentosSocietariosId: '',
        uploadLGPDDocId: '',
        outrosDetalhes: '',
        nomeFantGrup: '',
        objetoContrato: '',
        prodComeInter: '',
        contNegAdit: '',
        quaisUpfrontBonus: '',
        BonusDetalhamento: '',
        quaisBonusPerformance: '',
        BonusPerformDet: '',
        quaisProfitSharing: '',
        ProfitSharingDetalhamento: '',
        quaisReembCartaCredito: '',
        ReembCartaCreditoDet: '',
        quaisInvestMarketMinGarant: '',
        quaisFindesFee: '',
        quaisIncluAltDespAgeCamp: '',
        quaisIncluAltDespPrestServ: '',
        IncluAltDespPrestServDet: '',
        quaisIncluAltDespVar: '',
        IncluAltDespVarDet: '',
        garantiaContrato: '',
        tipoGarantia: '',
        DescGarantia: '',
        inicioVidenciaGarantia: '',
        fimVigenciaGarantia: '',
        dataAvisoVenc: '',
        RadioPrazo: '',
        inicioVigencia: '',
        fimVigencia: '',
        dataAviso: '',
        avisoPrevio: '',
        RenovacaoAutomatica: ''
    }

    if (tipoContrato == "forncedorPrestadorServico") {
        window["NOTcontratante"].setValue(valores.contratante);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);
        $('#tituloContrato').val(valores.tituloContrato);
        $('#NOTminutaDistratoName').val(valores.minutaContratoName);
        $('#NOTuploadEmailName').val(valores.uploadEmailName);
        $('#NOTuploadLGPDDocName').val(valores.uploadLGPDDocName);
        $('#NOTpropostaComercialName').val(valores.propostaComercialName);
        $('#NOTdocumentosSocietariosName').val(valores.documentosSocietariosName);
        $('#NOTminutaDistratoId').val(valores.minutaContratoId);
        $('#NOTuploadEmailId').val(valores.uploadEmailId);
        $('#NOTpropostaComercialId').val(valores.propostaComercialId);
        $('#NOTdocumentosSocietariosId').val(valores.documentosSocietariosId);
        $('#NOTuploadLGPDDocId').val(valores.uploadLGPDDocId);
        valores.uploadEmailId ? $('#NOTuploadEmailFile').attr('disabled', 'disabled') : $('#NOTuploadEmailFile').attr('disabled', false);
        valores.propostaComercialId ? $('#NOTpropostaComercialFile').attr('disabled', 'disabled') : $('#NOTpropostaComercialFile').attr('disabled', false);
        valores.documentosSocietariosId ? $('#NOTdocumentosSocietariosFile').attr('disabled', 'disabled') : $('#NOTdocumentosSocietariosFile').attr('disabled', false);
        valores.minutaContratoId ? $('#NOTminutaDistratoFile').attr('disabled', 'disabled') : $('#NOTminutaDistratoFile').attr('disabled', false);
        valores.uploadLGPDDocId ? $('#NOTuploadLGPDDocFile').attr('disabled', 'disabled') : $('#NOTuploadLGPDDocFile').attr('disabled', false);


        $('#NOTtabelaContratado tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#NOTtabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    } else if (tipoContrato == "negocios") {
        window["NOTempPartNeg"].setValue(valores.empPartNeg);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);
        $('#tituloContrato').val(valores.tituloContrato);
        $("#NOTtituloContrato").val(valores.tituloContrato)
        $('#NOTnomeFantGrup').val(valores.nomeFantGrup);
        $('#NOTobjetoContrato').val(valores.objetoContrato);
        $('#NOTprodComeInte').val(valores.prodComeInter);
        $('#NOTobservacoes').val(valores.observacoes);
        $('#NOTgarantiaContrato').val(valores.garantiaContrato);
        $('#NOTtipoGarantia').val(valores.tipoGarantia);
        $('#NOTDescGarantia').val(valores.DescGarantia);
        $('#NOTinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
        $('#NOTfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
        $('#NOTdataAvisoVenc').val(valores.dataAvisoVenc);

        $('#NOTminutaContratoName').val(valores.minutaContratoName);
        $('#NOTnbpName').val(valores.nbpName);
        $('#NOTpmName').val(valores.pmName);
        $('#NOTuploadEmailNameA').val(valores.uploadEmailName);
        $('#NOTdocumentosSocietariosNameA').val(valores.documentosSocietariosName);
        $('#NOTuploadLGPDDocNameA').val(valores.uploadLGPDDocName);
        $('#NOTminutaContratoId').val(valores.minutaContratoId);
        $('#NOTnbpId').val(valores.nbpId);
        $('#NOTpmId').val(valores.pmId);
        $('#NOTuploadEmailIdA').val(valores.uploadEmailId);
        $('#NOTdocumentosSocietariosIdA').val(valores.documentosSocietariosId);
        $('#NOTuploadLGPDDocIdA').val(valores.uploadLGPDDocId);

        valores.minutaContratoId ? $('#NOTminutaContratoFile').parent().attr('disabled', 'disabled') : $('#NOTminutaContratoFile').parent().attr('disabled', false);
        valores.nbpId ? $('#NOTnbpFile').parent().attr('disabled', 'disabled') : $('#NOTnbpFile').parent().attr('disabled', false);
        valores.pmId ? $('#NOTpmFile').parent().attr('disabled', 'disabled') : $('#NOTpmFile').parent().attr('disabled', false);
        valores.uploadEmailId ? $('#NOTuploadEmailFileA').parent().attr('disabled', 'disabled') : $('#NOTuploadEmailFileA').parent().attr('disabled', false);
        valores.documentosSocietariosId ? $('#NOTdocumentosSocietariosFileA').parent().attr('disabled', 'disabled') : $('#NOTdocumentosSocietariosFileA').parent().attr('disabled', false);
        valores.uploadLGPDDocId ? $('#NOTuploadLGPDDocFileA').parent().attr('disabled', 'disabled') : $('#NOTuploadLGPDDocFileA').parent().attr('disabled', false);

        if (valores.contNegAdit == '') {
            $('#NOTcontNegAditSim').prop('checked', false)
            $('#NOTcontNegAditNao').prop('checked', false)
        }
        if (valores.quaisUpfrontBonus == '') {
            $("#NOTquaisUpfrontBonus").prop('checked', false)
            $("#divNOTBonusDetalhamento").hide()
            $("#NOTBonusDetalhamento").val(valores.BonusDetalhamento)
        }
        if (valores.quaisBonusPerformance == '') {
            $("#NOTquaisBonusPerformance").prop('checked', false)
            $("#divNOTBonusPerformDet").hide()
            $("#NOTBonusPerformDet").val(valores.BonusPerformDet)
        }
        if (valores.quaisProfitSharing == '') {
            $("#NOTquaisProfitSharing").prop('checked', false)
            $("#divNOTquaisProfitSharing").hide()
            $("#NOTProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
        }
        if (valores.quaisReembCartaCredito == '') {
            $("#NOTquaisReembCartaCredito").prop('checked', false)
            $("#divNOTReembCartaCreditoDet").hide()
            $("#NOTReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
        }
        if (valores.quaisIncluAltDespPrestServ == '') {
            $("#NOTquaisIncluAltDespPrestServ").prop('checked', false)
            $("#divNOTIncluAltDespPrestServDet").hide()
            $("#NOTIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
        }
        if (valores.quaisIncluAltDespVar == '') {
            $("#NOTquaisIncluAltDespVar").prop('checked', false)
            $("#divNOTIncluAltDespVarDet").hide()
            $("#NOTIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
        }

        if (valores.RadioPrazo == '') {
            $("#NOTPrazoDet").prop('checked', false)
            $("#NOTPrazoIndet").prop('checked', false)
            $("#NOTPrazoRenov").prop('checked', false)
            $("#NOTinicioVigencia").val(valores.inicioVigencia)
            $("#NOTfimVigencia").val(valores.fimVigencia)
            $("#NOTdataAviso").val(valores.dataAviso)
            $("#NOTPeriodoRenovacao").val(valores.avisoPrevio)
            $("#NOTRenovacaoAut").val(valores.RenovacaoAutomatica)
            $("#divNOTinicioVigencia").hide()
            $("#NOTDivFimVigencia").hide()
            $("#divNOTdataAviso").hide()
            $("#divNOTPeriodoRenovacao").hide()
            $("#divNOTRenovacaoAut").hide()
        }

        $('#NOTtabelaClienteRep tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#NOTtabelaCorretIntermed tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#NOTtabelaParSegu tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#NOTtabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    }

}

const clearFieldsCessao = () => {
    var tipoContrato = $("#tipoContrato").val()

    let valores = {
        tituloContrato: '',
        contratante: '',
        empPartNeg: '',
        objetoContrato: '',
        contratoIndeterminado: '',
        flagContratoVigencia: 'checked',
        dataAviso: '',
        inicioVigencia: '',
        fimVigencia: '',
        AFPSidentifAditivo: '',
        valorTotal: '',
        valorTotalMensal: '',
        valorTotalAnual: '',
        observacoes: '',
        minutaContratoName: '',
        nbpName: '',
        pmName: '',
        uploadEmailName: '',
        uploadOutrosDocName: '',
        uploadLGPDDocName: '',
        propostaComercialName: '',
        documentosSocietariosName: '',
        minutaContratoId: '',
        nbpId: '',
        pmId: '',
        uploadEmailId: '',
        uploadOutrosDocId: '',
        propostaComercialId: '',
        documentosSocietariosId: '',
        uploadLGPDDocId: '',
        outrosDetalhes: '',
        nomeFantGrup: '',
        objetoContrato: '',
        prodComeInter: '',
        contNegAdit: '',
        quaisUpfrontBonus: '',
        BonusDetalhamento: '',
        quaisBonusPerformance: '',
        BonusPerformDet: '',
        quaisProfitSharing: '',
        ProfitSharingDetalhamento: '',
        quaisReembCartaCredito: '',
        ReembCartaCreditoDet: '',
        quaisInvestMarketMinGarant: '',
        quaisFindesFee: '',
        quaisIncluAltDespAgeCamp: '',
        quaisIncluAltDespPrestServ: '',
        IncluAltDespPrestServDet: '',
        quaisIncluAltDespVar: '',
        IncluAltDespVarDet: '',
        garantiaContrato: '',
        tipoGarantia: '',
        DescGarantia: '',
        inicioVidenciaGarantia: '',
        fimVigenciaGarantia: '',
        dataAvisoVenc: '',
        RadioPrazo: '',
        inicioVigencia: '',
        fimVigencia: '',
        dataAviso: '',
        avisoPrevio: '',
        RenovacaoAutomatica: ''
    }

    if (tipoContrato == "forncedorPrestadorServico") {
        window["CEScontratante"].setValue(valores.contratante);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);
        $('#tituloContrato').val(valores.tituloContrato);
        $('#CESminutaDistratoName').val(valores.minutaContratoName);
        $('#CESuploadEmailName').val(valores.uploadEmailName);
        $('#CESuploadLGPDDocName').val(valores.uploadLGPDDocName);
        $('#CESpropostaComercialName').val(valores.propostaComercialName);
        $('#CESdocumentosSocietariosName').val(valores.documentosSocietariosName);
        $('#CESminutaDistratoId').val(valores.minutaContratoId);
        $('#CESuploadEmailId').val(valores.uploadEmailId);
        $('#CESpropostaComercialId').val(valores.propostaComercialId);
        $('#CESdocumentosSocietariosId').val(valores.documentosSocietariosId);
        $('#CESuploadLGPDDocId').val(valores.uploadLGPDDocId);
        valores.uploadEmailId ? $('#CESuploadEmailFile').attr('disabled', 'disabled') : $('#CESuploadEmailFile').attr('disabled', false);
        valores.propostaComercialId ? $('#CESpropostaComercialFile').attr('disabled', 'disabled') : $('#CESpropostaComercialFile').attr('disabled', false);
        valores.documentosSocietariosId ? $('#CESdocumentosSocietariosFile').attr('disabled', 'disabled') : $('#CESdocumentosSocietariosFile').attr('disabled', false);
        valores.minutaContratoId ? $('#CESminutaDistratoFile').attr('disabled', 'disabled') : $('#CESminutaDistratoFile').attr('disabled', false);
        valores.uploadLGPDDocId ? $('#CESuploadLGPDDocFile').attr('disabled', 'disabled') : $('#CESuploadLGPDDocFile').attr('disabled', false);


        $('#CEStabelaContratado tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#CEStabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    } else if (tipoContrato == "negocios") {
        window["CESempPartNeg"].setValue(valores.empPartNeg);
        $("#dataNotificacaoSolicitante").val(valores.dataAviso);
        $("#CEStituloContrato").val(valores.tituloContrato)
        $('#tituloContrato').val(valores.tituloContrato);
        $('#CESnomeFantGrup').val(valores.nomeFantGrup);
        $('#CESobjetoContrato').val(valores.objetoContrato);
        $('#CESprodComeInte').val(valores.prodComeInter);
        $('#CESobservacoes').val(valores.observacoes);
        $('#CESgarantiaContrato').val(valores.garantiaContrato);
        $('#CEStipoGarantia').val(valores.tipoGarantia);
        $('#CESDescGarantia').val(valores.DescGarantia);
        $('#CESinicioVidenciaGarantia').val(valores.inicioVidenciaGarantia);
        $('#CESfimVigenciaGarantia').val(valores.fimVigenciaGarantia);
        $('#CESdataAvisoVenc').val(valores.dataAvisoVenc);

        $('#CESminutaContratoName').val(valores.minutaContratoName);
        $('#CESnbpName').val(valores.nbpName);
        $('#CESpmName').val(valores.pmName);
        $('#CESuploadEmailNameA').val(valores.uploadEmailName);
        $('#CESdocumentosSocietariosNameA').val(valores.documentosSocietariosName);
        $('#CESuploadLGPDDocNameA').val(valores.uploadLGPDDocName);
        $('#CESminutaContratoId').val(valores.minutaContratoId);
        $('#CESnbpId').val(valores.nbpId);
        $('#CESpmId').val(valores.pmId);
        $('#CESuploadEmailIdA').val(valores.uploadEmailId);
        $('#CESdocumentosSocietariosIdA').val(valores.documentosSocietariosId);
        $('#CESuploadLGPDDocIdA').val(valores.uploadLGPDDocId);

        valores.minutaContratoId ? $('#CESminutaContratoFile').parent().attr('disabled', 'disabled') : $('#CESminutaContratoFile').parent().attr('disabled', false);
        valores.nbpId ? $('#CESnbpFile').parent().attr('disabled', 'disabled') : $('#CESnbpFile').parent().attr('disabled', false);
        valores.pmId ? $('#CESpmFile').parent().attr('disabled', 'disabled') : $('#CESpmFile').parent().attr('disabled', false);
        valores.uploadEmailId ? $('#CESuploadEmailFileA').parent().attr('disabled', 'disabled') : $('#CESuploadEmailFileA').parent().attr('disabled', false);
        valores.documentosSocietariosId ? $('#CESdocumentosSocietariosFileA').parent().attr('disabled', 'disabled') : $('#CESdocumentosSocietariosFileA').parent().attr('disabled', false);
        valores.uploadLGPDDocId ? $('#CESuploadLGPDDocFileA').parent().attr('disabled', 'disabled') : $('#CESuploadLGPDDocFileA').parent().attr('disabled', false);

        if (valores.contNegAdit == '') {
            $('#CEScontNegAditSim').prop('checked', false)
            $('#CEScontNegAditNao').prop('checked', false)
        }
        if (valores.quaisUpfrontBonus == '') {
            $("#CESquaisUpfrontBonus").prop('checked', false)
            $("#divCESBonusDetalhamento").hide()
            $("#CESBonusDetalhamento").val(valores.BonusDetalhamento)
        }
        if (valores.quaisBonusPerformance == '') {
            $("#CESquaisBonusPerformance").prop('checked', false)
            $("#divCESBonusPerformDet").hide()
            $("#CESBonusPerformDet").val(valores.BonusPerformDet)
        }
        if (valores.quaisProfitSharing == '') {
            $("#CESquaisProfitSharing").prop('checked', false)
            $("#divCESquaisProfitSharing").hide()
            $("#CESProfitSharingDetalhamento").val(valores.ProfitSharingDetalhamento)
        }
        if (valores.quaisReembCartaCredito == '') {
            $("#CESquaisReembCartaCredito").prop('checked', false)
            $("#divCESReembCartaCreditoDet").hide()
            $("#CESReembCartaCreditoDet").val(valores.ReembCartaCreditoDet)
        }
        if (valores.quaisIncluAltDespPrestServ == '') {
            $("#CESquaisIncluAltDespPrestServ").prop('checked', false)
            $("#divCESIncluAltDespPrestServDet").hide()
            $("#CESIncluAltDespPrestServDet").val(valores.IncluAltDespPrestServDet)
        }
        if (valores.quaisIncluAltDespVar == '') {
            $("#CESquaisIncluAltDespVar").prop('checked', false)
            $("#divCESIncluAltDespVarDet").hide()
            $("#CESIncluAltDespVarDet").val(valores.IncluAltDespVarDet)
        }

        if (valores.RadioPrazo == '') {
            $("#CESPrazoDet").prop('checked', false)
            $("#CESPrazoIndet").prop('checked', false)
            $("#CESPrazoRenov").prop('checked', false)
            $("#CESinicioVigencia").val(valores.inicioVigencia)
            $("#CESfimVigencia").val(valores.fimVigencia)
            $("#CESdataAviso").val(valores.dataAviso)
            $("#CESPeriodoRenovacao").val(valores.avisoPrevio)
            $("#CESRenovacaoAut").val(valores.RenovacaoAutomatica)
            $("#divCESinicioVigencia").hide()
            $("#CESDivFimVigencia").hide()
            $("#divCESdataAviso").hide()
            $("#divCESPeriodoRenovacao").hide()
            $("#divCESRenovacaoAut").hide()
        }

        $('#CEStabelaClienteRep tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#CEStabelaCorretIntermed tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#CEStabelaParSegu tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })

        $('#CEStabelaUploadFiles tbody tr:visible').each((index, element) => {
            fnWdkRemoveChild(element)
        })
    }

}



function habilitarRisco(servico, state) {
    if (state == 7) {
        $("#div_riscoContrato :input").prop("disabled", false)
        $("#riscoContrato").attr('readonly', false)

    } else {
        $("#div_riscoContrato").css('pointer-events', 'none')
    }

    if (servico == "aditivo" || servico == "distrato" || servico == "propostaComercial" || servico == "notificacao" || servico == "cessaoContrato") {
        $("#div_riscoContrato :input").prop("disabled", false)
        $("#riscoContrato").attr('readonly', false)
    }
}

var beforeSendValidate = function (numState, nextState) {
    let msg = "";

    if ($('[name="aprovacaoSolicitacao"]:visible:not([readonly])').val() == "") {
        msg += 'Não foi definido a aprovação.</br>';

    }

    if ($("#tipoContrato").val() == "forncedorPrestadorServico" && $("#servicoJuridico").val() == "novoContrato") {
        var linhasTabelaNFPS = $("#NFPStabelaContratado tbody tr:not(:first)").length

        if (linhasTabelaNFPS == 0) {
            msg += '\nÉ necessário incluir pelo menos um Item na tabela Contratado\n';
        }

        if ($('[name=NFPSRadioPrazo]:checked').val() == "" || $('[name=NFPSRadioPrazo]:checked').val() == undefined) {
            msg += '\nSelecionar uma opção para Prazo de Contrato\n';
        }

        $(".NFPSobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })

        $(".NFPSfileRequired").each((i, e) => {
            if ($(e).siblings().first().is(":visible") && $(e).val() == "") {
                if (e.id == "NFPSpropostaComercialId" || e.id == "NFPSuploadLGPDDocId" || e.id == "NFPSdocumentosSocietariosId") {
                    let label = $($(e).parents()[1]).children("label").text().split(":")[0];
                    msg += `\nÉ necessário fazer o upload do Documento '${label}'`
                }
            }
        });
    }

    if ($("#tipoContrato").val() == "negocios" && $("#servicoJuridico").val() == "novoContrato") {
        var linhasTabelaNTN = $("#NTNtabelaClienteRep tbody tr:not(:first)").length
        var garantia = $("#NTNgarantiaContrato").val()

        if (linhasTabelaNTN == 0) {
            msg += 'É necessário incluir pelo menos um Item na Tabela Dados do Cliente/Representante/Estipulante\n';
        }

        if ($('[name=NTNRadioPrazo]:checked').val() == "" || $('[name=NTNRadioPrazo]:checked').val() == undefined) {
            msg += 'Selecionar uma opção para Prazo de Contrato\n';
        }

        $(".NTNobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })

        if (garantia == "" || garantia == null) {
            msg += 'Escolha uma opção para o campo "Existe garantia para esse contrato?"\n';
        } else if (garantia == 'sim') {
            if ($('#NTNtipoGarantia').val() == "" || $('#NTNDescGarantia').val() == "" || $('#NTNinicioVidenciaGarantia').val() == "" || $('#NTNfimVigenciaGarantia').val() == "" || $('#NTNdataAvisoVenc').val() == "") {
                $(".NTNObriGarantia:visible:not([readonly])").each((index, element) => {
                    if (element.tagName != 'SPAN') {
                        msg += validateEmptyFields(element);
                    }
                })
            }
        }

        $(".NTNfileRequired").each((i, e) => {
            if ($(e).siblings().first().is(":visible") && $(e).val() == "") {
                if (e.id == "NTNpmId" || e.id == "NTNdocumentosSocietariosId" || e.id == "NTNnbpId" || e.id == "NTNuploadLGPDDocId") {
                    let label = $($(e).parents()[1]).children("label").text().split(":")[0];
                    msg += `\nÉ necessário fazer o upload do Documento '${label}'`
                }
            }
        });


    }

    if ($("#tipoContrato").val() == "forncedorPrestadorServico" && $("#servicoJuridico").val() == "aditivo") {
        $(".AFPSobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })
    }

    if ($("#tipoContrato").val() == "negocios" && $("#servicoJuridico").val() == "aditivo") {
        var programaSeguro = $("#AFPSvaloresContratoAlt").val()
        var novoProdAlteracao = $("#AFPSnovoServReneg").val()


        if (programaSeguro == "" || programaSeguro == null) {
            msg += 'Escolha uma opção para o campo "O programa de seguros será alterado?"\n';
        } else if (programaSeguro == 'sim') {
            if (novoProdAlteracao == "" || novoProdAlteracao == null) {
                msg += 'Escolha uma opção para o campo "Novos Produto ou Alteração?"\n';
            }
        }
        $(".AFPSobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })

        $(".AFPSfileRequired").each((i, e) => {
            if ($(e).siblings().first().is(":visible") && $(e).val() == "") {
                if (e.id == "ATNanexoTabelaId") {
                    let label = $($(e).parents()[1]).children("label").text().split(":")[0];
                    msg += `\nÉ necessário fazer o upload do Documento '${label}'`
                }
            }
        });

    }



    if ($("#tipoContrato").val() == "forncedorPrestadorServico" && $("#servicoJuridico").val() == "distrato") {
        $(".DISobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })
    }

    if ($("#tipoContrato").val() == "negocios" && $("#servicoJuridico").val() == "distrato") {
        $(".DISobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })
    }

    if ($("#tipoContrato").val() == "forncedorPrestadorServico" && $("#servicoJuridico").val() == "propostaComercial") {
        $(".PROCobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);

                if ($('[name=PROCRadioPrazo]:checked').val() == "" || $('[name=PROCRadioPrazo]:checked').val() == undefined) {
                    msg += '\nSelecionar uma opção para Prazo de Contrato\n';
                }

            }
        })
    }

    if ($("#tipoContrato").val() == "forncedorPrestadorServico" && $("#servicoJuridico").val() == "notificacao") {
        $(".NOTobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })
    }

    if ($("#tipoContrato").val() == "negocios" && $("#servicoJuridico").val() == "notificacao") {
        $(".NOTobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })
    }

    if ($("#tipoContrato").val() == "forncedorPrestadorServico" && $("#servicoJuridico").val() == "cessaoContrato") {
        var linhasTabela = $("#CEStabelaNovoCessionario tbody tr:not(:first)").length

        if (linhasTabela == 0) {
            msg += '\nÉ necessário incluir pelo menos um Item na tabela Nova Contratada\n';
        }
        $(".CESobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })
    }

    if ($("#tipoContrato").val() == "negocios" && $("#servicoJuridico").val() == "cessaoContrato") {


        $(".CESobrigatorio:visible:not([readonly])").each((index, element) => {
            if (element.tagName != 'SPAN') {
                msg += validateEmptyFields(element);
            }
        })
    }

    let statesAprov = [74, 7, 13, 30];
    if (statesAprov.indexOf(getCurrentState()) > -1) {
        if (!$('[name=aprovacaoSolicitacao]:checked').val()) {
            msg += '\nÉ necessário preencher aprovação \n';

        }

        if ($('[name=aprovacaoSolicitacao]:checked').val() == "REPROVAR") {
            $(".textAprovacao").each((i, e) => {
                if ($(e).is(":visible") && !e.value) {
                    msg += '\nÉ necessário informar motivo da Reprovação \n';
                }
            })
        } else if ($('[name=aprovacaoSolicitacao]:checked').val() == "CONTESTADO") {
            $(".textAprovacao").each((i, e) => {
                if ($(e).is(":visible") && !e.value) {
                    msg += '\nÉ necessário informar motivo da Contestação \n';
                }
            })
        } else {
            $(".obrigatorio:visible:not([readonly])").each((index, element) => {
                if (element.tagName != 'SPAN') {
                    msg += validateEmptyFields(element);
                }
            })
        }
    }

    if (getCurrentState() == ABRIRPROCESSO) {
        var empresaParticipanteNeg = $("#NTNempPartNegHidden").val()
        var empresaCedente = $("#NTNempPartNegHidden").val()

        vaiPular()
        if ($("#tipoContrato").val() == "negocios" && $("#servicoJuridico").val() == "novoContrato") {
            if (empresaParticipanteNeg == "" || empresaParticipanteNeg == undefined) {
                msg += "\nO campo 'Empresa Participante' é obrigatório!\n";
            }

            if ($('[name=NTNcontNegAdit]:checked').val() == "" || $('[name=NTNcontNegAdit]:checked').val() == undefined) {
                msg += 'Escolha uma opção "Em caso de CONTRATO DE NEGÓCIO ou ADITIVO, alguma das condições financeiras abaixo é tratada no documento?"\n';
            } else if ($('[name=NTNcontNegAdit]:checked').val() == "sim" && $('.NTNChecked:checked').val() == undefined) {
                msg += 'Escolha pelo menos uma opção do quadro "Quais?"\n';

            }
        }
        if ($("#servicoJuridico").val() == "novoContrato") {
            $(".obrigatorio:visible:not([readonly])").each((index, element) => {
                if (element.tagName != 'SPAN') {
                    if (element.id != 'riscoContrato') {
                        msg += validateEmptyFields(element);
                    }

                }
            })
        } else {
            $(".obrigatorio:visible:not([readonly])").each((index, element) => {
                if (element.tagName != 'SPAN') {
                    msg += validateEmptyFields(element);
                }
            })
        }

    } else if (getCurrentState() == AVALICAOELABREV) {
        if (!$("[name=escolhaAssinatura]:checked").val() && $('[name=aprovacaoSolicitacao]:checked').val() == "APROVADO" && $("#servicoJuridico").val() != 'notificacao') {
            msg += "\nÉ necessário selecionar uma assinatura \n";

        }
    }

    if (msg != "") {
        throw msg;
    }
}

var validateEmptyFields = (campo) => {
    var msg = "";
    var lineBreaker = "<br>";

    if (campo.name.split('___')[1]) {
        if ($(campo).val() == "" || $(campo).val() == undefined || $(campo).val() == null || $(campo).val() == "R$ 0,00" || $(campo).val() == "0,00" || $(campo).val() == "R$ NaN") {
            msg += "Campo'" + $(campo).siblings("label").text() + "' é obrigatório!" + lineBreaker;
            // fnWdkRemoveChild(campo.parentElement)
        }

        $('#validacao').val('true')
        return msg;
    } else {

        var lineBreaker = "<br>";

        if ($(campo).val() == "" || $(campo).val() == undefined || $(campo).val() == null || $(campo).val() == "R$ 0,00" || $(campo).val() == "0,00" || $(campo).val() == "R$ NaN") {

            msg += "Campo'" + $(campo).siblings("label").text() + "' é obrigatório!" + lineBreaker;

        } else if ($(campo).siblings("label").text() == 'Telefone') {

            if ($(campo).val().length < 14) {
                msg += "Numero de telefone não esta completo !" + lineBreaker;
            }

        } else if ($(campo).siblings("label").text() == 'CEP') {

            let validacep = /^[0-9]{8}$/

            if (validacep.test($(campo).val())) {
                msg += "CEP invalido na linha " + campo.split('___')[1] + " !" + lineBreaker;
            }
        }
        $('#validacao').val('true')
        return msg;
    }
}

$('#riscoContrato').on('change', function () {

    var risco = document.getElementById('riscoContrato')

    $('#hidden_riscoContrato').val(risco.value)
})
$('[name=aprovacaoSolicitacao]').on('change', function () {
    marcaAprovador()
})

function marcaAprovador() {
    var atividade = getWKNumState()
    console.info("Atividade Atual Script")
    console.dir(atividade)
    if (atividade == 74) {
        $('#flagAprovador').val('avaliacao')
    }
    if (atividade == 7) {
        $('#flagAprovador').val('compliance')
    }
    if (atividade == 13) {
        $('#flagAprovador').val('avaliacaoER')
    }
    if (atividade == 30) {
        $('#flagAprovador').val('analise')
    }

}