const PARENTID = "103";
const TOAST = (message, type) => {
    FLUIGC.toast({
        title: '',
        message: message,
        type: type
    });
}

$(document).ready(() => {
    setarVisibilidade()
    adicionaMascaras()

    if ($("[name^='tipoAcerto']").val() == 'Adiantamento') {
        if ($("#mostrarAviso").val() == "sim") {
            $("#aviso").show();
        } else {
            $("#aviso").hide();
        }
    } else {
        $('[tablename="tabelaDespesas"] tr:not(:first-child)').each((i, e) => {
            if ($("#mostrarAvisoPaiFilho___" + (i + 1)).val() == "sim") {
                $("#mostrarAvisoPaiFilho___" + (i + 1)).parent().find("#avisoPaiFilho").show()
            } else {
                $("#mostrarAvisoPaiFilho___" + (i + 1)).parent().find("#avisoPaiFilho").hide()
            }
        })
    }

    if ($('#tipoVisualizacao').val() == "ADD" || $('#stateAtual').val() == "4") {
        if ($('#tipoVisualizacao').val() == "ADD") {
            dataSolicitacao()
            $('#descricao').val(setDescription($('#usuarioAtual').val()))
            esconderDivs()
            setTimeout(() => {
                usuarioInicial()
            }, 1200)
            $('#iniciador').val($('#usuarioAtual').val())
        }
        if ($('#stateAtual').val() == "4") {
            ajustaDisplay()
            hideDuplicateAprover()
        }
        if ($('#tipoVisualizacao').val() == "VIEW") {
            bloquearBotao()
        }
    } else {
        bloquearBotao()
        setProxAprovador(0)
        ajustaDisplay()
    }
    if (detectar_mobile()) {
        $('#divAnexo').addClass('hidden')
    }
    if ($('#stateAtual').val() == '20' && $('#tipoVisualizacao').val() == 'MOD') {
        setAprovadorFinanceiro()
        if ($("#selGrupoHidden").val().indexOf("Pool") < 0 && $("[name=aprovOutroGrupo]:checked").val() == "sim") {
            $("#divAprovacao, .aprovGrupo").css("pointer-events", "none");
        } else {
            $(".parecerGrupo").hide();
        }
        $(".aprovGrupo").show()
        $(".divGrupo").show()
    }

    if ($("#stateAtual").val() == '52') {
        $(".aprovGrupo").first().css("pointer-events", 'none')
    }
    if ($("#stateAtual").val() != '20' && $("#stateAtual").val() != '52') {
        $(".aprovGrupo").hide();
    } else {
        $(".aprovGrupo, .divGrupo").show();
    }

    $("[name^='aprovOutroGrupo']").on('change', (e) => {
        if (e.currentTarget.value == 'nao') {
            $(".divGrupo").hide();
        } else {
            $(".divGrupo").show();
        }
    })
    if ($("[name^='aprovOutroGrupo']:checked").val() == 'nao' || $("[name^='aprovOutroGrupo']:checked").val() == '') {
        $(".divGrupo").hide();
    } else {
        $(".divGrupo").show();
    }

    $("[name^=valorReal___]").on('blur', (e) => {
            let id = e.target.id.split("___")[1];
            if (parseFloat($('#valorMaximoDespesas___' + id).val().replace('.', '').replace(',', '.')) < parseFloat(e.target.value.replace('.', '').replace(',', '.'))) {
                $("#avisoPaiFilho___" + id).show();
                $("#mostrarAvisoPaiFilho___" + id).val('sim');
            } else {
                $("#mostrarAvisoPaiFilho___" + id).val('nao');
                $("#avisoPaiFilho___" + id).hide();
            }
            alterarValorTotalReembolso();
        })
        // if (realToNumber($('#valorMaximoAdiantamento').val()) < realToNumber($('#valorAdiantamento').val()) || realToNumber($('#valorMaximoAdiantamento').val()) < realToNumber($('#valorAdiantamento').text())) {
        //     $('#aviso').show()
        // } else {
        //     $('#aviso').hide()
        // }

    $('[name^="politica___"]').on('change', (element) => {
        let id = element.currentTarget.name.split("___")[1];
        $('#infos___' + id).show()
        if (element.currentTarget.value == 'NACIONAL') {
            $('[name="contabilNacional___' + id + '"]').parent().show()
            $('[name="contabilInternacional___' + id + '"]').parent().hide()
            window["contabilInternacional___" + id + ""].clear()
            $('[name="valorDolar___' + id + '"]').parent().parent().hide()
            $('[name="valorReal___' + id + '"]').parent().show()
            $('[name="valorDolar___' + id + '"]').val('')
            $('[name="taxaCambio___' + id + '"]').val('')
            $('[name="valorFinal___' + id + '"]').val('')
                // $('[name="codEstadoTable___' + id + '"]').val('selecione')
                // $('[name="codEstadoTable___' + id + '"]').attr('readonly', false)
                // $('[name="codEstadoTable___' + id + '"]').removeAttr('style')
            alterarValorTotalReembolso()
        } else {
            $('[name="contabilNacional___' + id + '"]').parent().hide()
            $('[name="contabilInternacional___' + id + '"]').parent().show()
            window["contabilNacional___" + id + ""].clear()
            $('[name="valorDolar___' + id + '"]').parent().parent().show()
            $('[name="valorReal___' + id + '"]').parent().hide()
            $('[name="valorReal___' + id + '"]').val('')
                // $('[name="codEstadoTable___' + id + '"]').val('EX')
                // $('[name="codEstadoTable___' + id + '"]').attr('readonly', true)
                // $('[name="codEstadoTable___' + id + '"]').css('pointer-events', 'none')
            alterarValorTotalReembolso()
        }
        eventsTabela(id);
    })

})

function usuarioInicial() {
    let dataRetorno = DatasetFactory.getDataset('ds_paifilho_cadastro_usuario', null, null, null)
    let userCod = dataRetorno.values.find((e) => { return getUser() === e['UsuarioId'] })

    window['centroCusto'].setValue(userCod['namCentroCusto'])
    $('#codCentroCusto').val(userCod['codCentroCusto'])
        //window['centroCustoResp'].setValue(userCod['namCentroCusto'])
        //$('#codCentroCustoResp').val(userCod['codCentroCusto'])
    $('#cpf').val(userCod['CPF'])
    $('#zoomSelectedID').val(userCod['UsuarioId'])
    window['zoomSolicitante'].setValue(userCod['Usuario'])

    let datasetContabilNacional = DatasetFactory.getDataset('ds_paifilho_politica_nacional', null, null, null);
    let nacional = datasetContabilNacional.values.find(e => "ADIANTAMENTO VIAGEM" == e.acsel)
    $('#valorMaximoAdiantamento').val(nacional['valorMaximo'])
    $('#codPolitica').val("ADIANTAMENTO VIAGEM")
    window['contabilAdiantNacional'].setValue(nacional['despesa'])

    let datasetContabilInter = DatasetFactory.getDataset('ds_paifilho_politica_internacional', null, null, null);
    let internacional = datasetContabilInter.values.find(e => "ADIANTAMENTO VIAGEM" == e.acsel)
    $('#valorMaximoAdiantamento').val(internacional['valorMaximo'])
    $('#codPolitica').val("ADIANTAMENTO VIAGEM")
    window['contabilAdiantInternacional'].setValue(internacional['despesa'])


    adiantamentosAnteriores()
    setProxAprovador()
}

$('input[type=radio][name="politicaAdiantamento"]').on("change", function() {
    if ($('[name="politicaAdiantamento"]:checked').val() == "NACIONAL") {
        $('[name="contabilAdiantNacional"]').parent().show()
        $('[name="contabilAdiantInternacional"]').parent().hide()
        $('[name="codEstado"]').val('selecione')
    } else {
        $('[name="contabilAdiantNacional"]').parent().hide()
        $('[name="contabilAdiantInternacional"]').parent().show()
        $('[name="codEstado"]').val('EX')
    }
});

$('input[type=radio][name="tipoAcerto"]').on("change", function() {
    if ($('[name="tipoAcerto"]:checked').val() == "ADIANTAMENTO") {
        $('#divReembolso').hide()
        $('#politicaAdiantemantoDiv').show()
        $('#divAdiantamento').show()
        $('#valorAdiantamento').blur()
        if ($("#mostrarAviso").val() == "sim") {
            $("#avisoAdiantamento").show();
        }
    } else {
        $('#divReembolso').show()
        $('#divAdiantamento').hide()
        $('#politicaAdiantemantoDiv').hide()
        $('#valorReembolso').blur()
        $("#avisoAdiantamento").hide();
    }
});

$('input[type=radio][name="vincularAdiantamento"]').on("change", function() {
    if ($('[name="vincularAdiantamento"]:checked').val() == 'SIM') {
        $('#divZoomAdiantamento').show()
        $('#divValorAdiantado').show()
        $('#divValorJustificado').show()
    } else {
        $('#divZoomAdiantamento').hide()
        $('#divValorAdiantado').hide()
        $('#divValorJustificado').hide()
    }
});

function eventsTabela(id) {
    $("#valorReal___" + id).on('blur', (e) => {
        if (parseFloat($('#valorMaximoDespesas___' + id).val().replace('.', '').replace(',', '.')) < parseFloat(e.target.value.replace('.', '').replace(',', '.'))) {
            $("#avisoPaiFilho___" + id).show();
            $("#mostrarAvisoPaiFilho___" + id).val('sim');
        } else {
            $("#mostrarAvisoPaiFilho___" + id).val('nao');
            $("#avisoPaiFilho___" + id).hide();
        }
    })


    $("#valorFinal___" + id).on('change', (e) => {
        if (parseFloat($('#valorMaximoDespesas___' + id).val().replace('.', '').replace(',', '.')) < parseFloat(e.target.value.replace('.', '').replace(',', '.'))) {
            $("#mostrarAvisoPaiFilho___" + id).val('sim');
        } else {
            $("#mostrarAvisoPaiFilho___" + id).val('nao');
        }
    })

    document.getElementById('dataContas___' + id).max = new Date().toISOString().split("T")[0];
    $('[name="dataContas___' + id + '"]').on('change', (element) => {
        var value = element.target.value
        var date = new Date().toISOString().split("T")[0]
        if (value > date) {
            element.target.value = date
        }
    })

    $('.quantidadeKm').on('change', (element) => {
        let id = element.currentTarget.name.split('___')
        if (isNaN(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value))) {
            $('#valorKm___' + id[1]).val('')
            alterarValorTotalReembolso()
        } else {
            $('#valorKm___' + id[1]).val(numberToReal(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value)))
            alterarValorTotalReembolso()
        }
    })

    $('.valorDolar').on('change', (element) => {
        let id = element.currentTarget.name.split('___')
        if (isNaN(realToNumber($('#taxaCambio___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value)))) {
            $('#valorFinal___' + id[1]).val('')
            alterarValorTotalReembolso()
        } else {
            $('#valorFinal___' + id[1]).val(numberToReal(realToNumber($('#taxaCambio___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value))))
            alterarValorTotalReembolso()
        }
    })

    $('.taxaCambio').on('change', (element) => {
        let id = element.currentTarget.name.split('___')
        if (isNaN(realToNumber($('#valorDolar___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value)))) {
            $('#valorFinal___' + id[1]).val('')
            alterarValorTotalReembolso()
        } else {
            $('#valorFinal___' + id[1]).val(numberToReal(realToNumber($('#valorDolar___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value))))
            alterarValorTotalReembolso()
        }
    })

    $("#botaoAdicionarAnexo___" + id).fileupload({
        dataType: 'json',
        start: () => FLUIGC.loading(window).show,
        done: (e, data) => {
            var file = data.result.files[0];

            saveDocuments(file, id);
        },
        fail: (e, data) => {
            console.log("Falha no fileupload", data);
            TOAST('Não foi possivel publicar o arquivo.', 'danger');
        },
        stop: () => FLUIGC.loading(window).hide()
    });

    $('#ver_arquivo___' + id).click((e) => {
        var documentId = $('[name="idAnexo___' + id + '"]').val();
        var versao = 1000
        openDocument(documentId, versao)
    });

    $("#deletar_arquivo___" + id).click(e => {
        var documentId = $('[name="idAnexo___' + id + '"]').val();
        deleteDocument(documentId);

        $("#anexo___" + id).show();
        $('#ver_arquivo___' + id).hide();
        $("#deletar_arquivo___" + id).hide();
    });

    $('.totalReembolso').on('blur', (element) => {
        if (!$(element.currentTarget).attr('readonly')) {
            alterarValorTotalReembolso()
        }
    })
}

$('#botaoAdicionarTabela').on('click', () => {
    var id = wdkAddChild('tabelaDespesas')
    adicionaMascaras();
    $("#avisoPaiFilho___" + id).hide();
    window[`centroCustoResp1___${id}`].setValue(window['centroCusto'].getSelectedItems()[0]);
    $(`#codCentroCustoResp1___${id}`).val($("#codCentroCusto").val());
    $("#valorReal___" + id).on('blur', (e) => {
        if (parseFloat($('#valorMaximoDespesas___' + id).val().replace('.', '').replace(',', '.')) < parseFloat(e.target.value.replace('.', '').replace(',', '.'))) {
            $("#avisoPaiFilho___" + id).show();
            $("#mostrarAvisoPaiFilho___" + id).val('sim');
        } else {
            $("#mostrarAvisoPaiFilho___" + id).val('nao');
            $("#avisoPaiFilho___" + id).hide();
        }
    })


    $("#valorFinal___" + id).on('change', (e) => {
        if (parseFloat($('#valorMaximoDespesas___' + id).val().replace('.', '').replace(',', '.')) < parseFloat(e.target.value.replace('.', '').replace(',', '.'))) {
            $("#mostrarAvisoPaiFilho___" + id).val('sim');
        } else {
            $("#mostrarAvisoPaiFilho___" + id).val('nao');
        }
    })

    document.getElementById('dataContas___' + id).max = new Date().toISOString().split("T")[0];
    $('[name="dataContas___' + id + '"]').on('change', (element) => {
        var value = element.target.value
        var date = new Date().toISOString().split("T")[0]
        if (value > date) {
            element.target.value = date
        }
    })

    $('.quantidadeKm').on('change', (element) => {
        let id = element.currentTarget.name.split('___')
        if (isNaN(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value))) {
            $('#valorKm___' + id[1]).val('')
            alterarValorTotalReembolso()
        } else {
            $('#valorKm___' + id[1]).val(numberToReal(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value)))
            alterarValorTotalReembolso()
        }
    })

    $('.valorDolar').on('change', (element) => {
        let id = element.currentTarget.name.split('___')
        if (isNaN(realToNumber($('#taxaCambio___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value)))) {
            $('#valorFinal___' + id[1]).val('')
            alterarValorTotalReembolso()
        } else {
            $('#valorFinal___' + id[1]).val(numberToReal(realToNumber($('#taxaCambio___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value))))
            alterarValorTotalReembolso()
        }
    })

    $('.taxaCambio').on('change', (element) => {
        let id = element.currentTarget.name.split('___')
        if (isNaN(realToNumber($('#valorDolar___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value)))) {
            $('#valorFinal___' + id[1]).val('')
            alterarValorTotalReembolso()
        } else {
            $('#valorFinal___' + id[1]).val(numberToReal(realToNumber($('#valorDolar___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value))))
            alterarValorTotalReembolso()
        }
    })

    $("#botaoAdicionarAnexo___" + id).fileupload({
        dataType: 'json',
        start: () => FLUIGC.loading(window).show,
        done: (e, data) => {
            var file = data.result.files[0];

            saveDocuments(file, id);
        },
        fail: (e, data) => {
            console.log("Falha no fileupload", data);
            TOAST('Não foi possivel publicar o arquivo.', 'danger');
        },
        stop: () => FLUIGC.loading(window).hide()
    });

    $('#ver_arquivo___' + id).click((e) => {
        var documentId = $('[name="idAnexo___' + id + '"]').val();
        var versao = 1000
        openDocument(documentId, versao)
    });

    $("#deletar_arquivo___" + id).click(e => {
        var documentId = $('[name="idAnexo___' + id + '"]').val();
        deleteDocument(documentId);

        $("#anexo___" + id).show();
        $('#ver_arquivo___' + id).hide();
        $("#deletar_arquivo___" + id).hide();
    });

    $('[name="politica___' + id + '"]').on('change', (element) => {
        $('#infos___' + id).show()
        if (element.currentTarget.value == 'NACIONAL') {
            $('[name="contabilNacional___' + id + '"]').parent().show()
            $('[name="contabilInternacional___' + id + '"]').parent().hide()
            window["contabilInternacional___" + id + ""].clear()
            $('[name="valorDolar___' + id + '"]').parent().parent().hide()
            $('[name="valorReal___' + id + '"]').parent().show()
            $('[name="valorDolar___' + id + '"]').val('')
            $('[name="taxaCambio___' + id + '"]').val('')
            $('[name="valorFinal___' + id + '"]').val('')
                // $('[name="codEstadoTable___' + id + '"]').val('selecione')
                // $('[name="codEstadoTable___' + id + '"]').attr('readonly', false)
                // $('[name="codEstadoTable___' + id + '"]').removeAttr('style')
            alterarValorTotalReembolso()
        } else {
            $('[name="contabilNacional___' + id + '"]').parent().hide()
            $('[name="contabilInternacional___' + id + '"]').parent().show()
            window["contabilNacional___" + id + ""].clear()
            $('[name="valorDolar___' + id + '"]').parent().parent().show()
            $('[name="valorReal___' + id + '"]').parent().hide()
            $('[name="valorReal___' + id + '"]').val('')
                // $('[name="codEstadoTable___' + id + '"]').val('EX')
                // $('[name="codEstadoTable___' + id + '"]').attr('readonly', true)
                // $('[name="codEstadoTable___' + id + '"]').css('pointer-events', 'none')
            alterarValorTotalReembolso()
        }
    })

    $('.totalReembolso').on('blur', (element) => {
        if (!$(element.currentTarget).attr('readonly')) {
            alterarValorTotalReembolso()
        }
    })
})

function bloquearBotao() {
    $('.bloqueavel').attr('disabled', true);
    $('.fluigicon-trash').hide()
    $('.bloqueavel').on('focus mousedown click change', function(e) {
        // cancel stack events
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        // remove focus
        $(this).blur();

        return false;
    });
}

function fnCustomDelete(oElement) {
    var tr = $(oElement).parents('tr')
    var documentId = $(tr[0]).find('[name^="idAnexo___"]').val()
    if (documentId != '') {
        deleteDocument(documentId);
    }
    fnWdkRemoveChild(oElement);
    alterarValorTotalReembolso();
}

const deleteDocument = (documentId) => {
    top.WCMAPI.Create({
        url: "/api/public/2.0/documents/deleteDocument/" + documentId,
        method: "POST",
        success: e => {
            $('#idAnexo').val('')
            TOAST("Arquivo deletado com sucesso.", "success")
        },
        error: e => {
            console.log("Falha ao deletar o arquivo", e);
            TOAST("Falha ao deletar o arquivo.", "danger");
        }
    });
}

function saveDocuments(file, index) {
    $.ajax({
        url: '/api/public/ecm/document/createDocument',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            "description": file.name,
            "parentId": PARENTID,
            "attachments": [{
                "fileName": file.name
            }]
        })
    }).done((result) => {
        let documentId = result.content.id;

        $('[name="idAnexo___' + index + '"]').val(documentId);

        $("#anexo___" + index).hide();
        $('#ver_arquivo___' + index).show();
        $("#deletar_arquivo___" + index).show();

        TOAST('Arquivo ' + file.name + ' publicado com sucesso.', 'success');
    }).fail((result) => {
        TOAST('Não foi possivel publicar o arquivo.', 'danger');
        console.log("Falha", result);
    });
}

function openDocument(docId, docVersion) {
    var parentOBJ;

    if (window.opener) {
        parentOBJ = window.opener.parent;
    } else {
        parentOBJ = parent;
    }

    var cfg = {
        url: "/ecm_documentview/documentView.ftl",
        maximized: true,
        title: "Visualizador de Documentos",
        callBack: function() {
            parentOBJ.ECM.documentView.getDocument(docId, docVersion);
        },
        customButtons: []
    };
    parentOBJ.ECM.documentView.panel = parentOBJ.WCMC.panel(cfg);
}

function ajustaDisplay() {
    if ($('#tipoVisualizacao').val() == "VIEW" || $('#stateAtual').val() == "4") {

        if ($('#parecerFinanceiro').val() != '' || $('#parecerFinanceiro').val() != null) {
            $('#div_financeiro').show()
        }

        if ($('[name="vincularAdiantamento"]:checked').val() == 'SIM') {
            $('#divZoomAdiantamento').show()
            $('#divValorAdiantado').show()
            $('#divValorJustificado').show()
        } else {
            $('#divZoomAdiantamento').hide()
            $('#divValorAdiantado').hide()
            $('#divValorJustificado').hide()
        }
        if ($('[name="tipoAcerto"]:checked').val() == "ADIANTAMENTO") {
            $('#divReembolso').hide()
            $('#politicaAdiantemantoDiv').show()
            $('#divAdiantamento').show()
            setProxAprovador(realToNumber($('#valorAdiantamento').val()))
        } else {
            $('#divReembolso').show()
            $('#divAdiantamento').hide()
            setProxAprovador(realToNumber($('#valorReembolso').val()))
        }
        if ($('[name="politicaAdiantamento"]:checked').val() == "INTERNACIONAL") {
            $('[name="contabilAdiantNacional"]').parent().hide()
            $('[name="contabilAdiantInternacional"]').parent().show()
        }
        if ($('[name="vincularAdiantamento"]:checked').val() == "SIM" && $('#tipoVisualizacao').val() != "VIEW") {
            adiantamentosAnteriores()
            let idSelect = $('#valAdiantamento').attr('data-idSelect')
            let valueSelect = $('#valAdiantamento').attr('data-valueSelect')
            let textSelect = $('#valAdiantamento').val()
            $('#selectAdiantamento').append(`<option id="${idSelect}" value="${valueSelect}" selected>${textSelect}</option>`)
            setProxAprovador(realToNumber($('#valorJustificado').val()))
        } else {
            if ($('[name="vincularAdiantamento"]:checked').val() == "SIM") {
                $('#selectAdiantamento').hide()
                $('#valAdiantamento').show()
            }
        }

        if ($('#tipoVisualizacao').val() == "VIEW") {
            $('#subSuperiorImediato').hide()
                // $('#subAprovadorAlcada').hide()

            $('#nameSubSuperior').show()
                //$('#nameSubAprovador').show()
        }

        $('.quantidadeKm').on('change', (element) => {
            let id = element.currentTarget.name.split('___')
            if (isNaN(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value))) {
                $('#valorKm___' + id[1]).val('')
                alterarValorTotalReembolso()
            } else {
                $('#valorKm___' + id[1]).val(numberToReal(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value)))
                alterarValorTotalReembolso()
            }
        })

        $('.valorDolar').on('change', (element) => {
            let id = element.currentTarget.name.split('___')
            if (isNaN(realToNumber($('#taxaCambio___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value)))) {
                $('#valorFinal___' + id[1]).val('')
                alterarValorTotalReembolso()
            } else {
                $('#valorFinal___' + id[1]).val(numberToReal(parseFloat(realToNumber($('#taxaCambio___' + id[1]).val())) * parseFloat(realToNumber(element.currentTarget.value))))
                alterarValorTotalReembolso()
            }
        })

        $('.taxaCambio').on('change', (element) => {
            let id = element.currentTarget.name.split('___')
            if (isNaN(realToNumber($('#taxaCambio___' + id[1]).val()) * parseFloat(realToNumber(element.currentTarget.value)))) {
                $('#taxaCambio___' + id[1]).val('')
                alterarValorTotalReembolso()
            } else {
                $('#valorFinal___' + id[1]).val(numberToReal(parseFloat(realToNumber($('#taxaCambio___' + id[1]).val())) * parseFloat(realToNumber(element.currentTarget.value))))
                alterarValorTotalReembolso()
            }
        })

        $('[name^= "politica___"]').each((index, element) => {
            let id = element.name.split('___')[1]
            if (element.checked) {
                if (element.value == "NACIONAL") {
                    $(element).parents('div').siblings('#infos').show();
                    $('[name="contabilNacional___' + id + '"]').parent().show();
                    $('[name="contabilInternacional___' + id + '"]').parent().hide();
                    $('[name="valorDolar___' + id + '"]').parent().parent().hide();
                    $('[name="valorReal___' + id + '"]').parent().show();
                } else {
                    $(element).parents('div').siblings('#infos').show();
                    $('[name="contabilNacional___' + id + '"]').parent().hide();
                    $('[name="contabilInternacional___' + id + '"]').parent().show();
                    $('[name="valorDolar___' + id + '"]').parent().parent().show();
                    $('[name="valorReal___' + id + '"]').parent().hide();
                }
                if ($('[name="distancia___' + id + '"]').val() == 'true') {
                    $('[name="easyAcessDivKm___' + id + '"]').parent().show();
                    $('[name="easyAcessDivVal___' + id + '"]').parent().hide();
                    $('[name="botaoAdicionarAnexo___' + id + '"]').parents('#divAnexo').hide();
                } else {
                    $('[name="easyAcessDivKm___' + id + '"]').parent().hide();
                    $('[name="easyAcessDivVal___' + id + '"]').parent().show();
                    $('[name="botaoAdicionarAnexo___' + id + '"]').parents('#divAnexo').show();
                }
            }
        })

        $('.visualizar').each((index, element) => {
            if (index != 0) {
                let id = $(element).parent().parent().find('[name^="idAnexo___"]')[0].name.split('___')[1]
                if ($('[name="idAnexo___' + id + '"]').val() != '') {
                    element.id = 'ver_arquivo___' + id
                    $('[name="idAnexo___' + id + '"]').parent().attr('id', 'anexo___' + id);
                    $('#ver_arquivo___' + id).siblings('#deletar_arquivo').attr('id', 'deletar_arquivo___' + id);
                    if ($('#stateAtual').val() == "4" && $('#tipoVisualizacao').val() != "VIEW") {
                        $('#deletar_arquivo___' + id).show()
                        $('#deletar_arquivo___' + id).click((e) => {
                            var documentId = $('[name="idAnexo___' + id + '"]').val();
                            deleteDocument(documentId);

                            $("#anexo___" + id).show();
                            $('#ver_arquivo___' + id).hide();
                            $("#deletar_arquivo___" + id).hide();
                        })
                    }
                    $(element).show()
                    $('[name="idAnexo___' + id + '"]').parent().hide()
                    element.id = 'ver_arquivo___' + id
                    $('#ver_arquivo___' + id).click((e) => {
                        var documentId = $('[name="idAnexo___' + id + '"]').val();
                        var versao = 1000
                        openDocument(documentId, versao)
                    });
                    $("#botaoAdicionarAnexo___" + id).fileupload({
                        dataType: 'json',
                        start: () => FLUIGC.loading(window).show,
                        done: (e, data) => {
                            var file = data.result.files[0];

                            saveDocuments(file, id);
                        },
                        fail: (e, data) => {
                            console.log("Falha no fileupload", data);
                            TOAST('Não foi possivel publicar o arquivo.', 'danger');
                        },
                        stop: () => FLUIGC.loading(window).hide()
                    });
                    $('[name="politica___' + id + '"]').on('change', (element) => {
                        $('#infos___' + id).show()
                        if (element.currentTarget.value == 'NACIONAL') {
                            $('[name="contabilNacional___' + id + '"]').parent().show()
                            $('[name="contabilInternacional___' + id + '"]').parent().hide()
                            window["contabilInternacional___" + id + ""].clear()
                            $('[name="valorDolar___' + id + '"]').parent().parent().hide()
                            $('[name="valorReal___' + id + '"]').parent().show()
                            $('[name="valorDolar___' + id + '"]').val('')
                            $('[name="taxaCambio___' + id + '"]').val('')
                            $('[name="valorFinal___' + id + '"]').val('')
                            alterarValorTotalReembolso()
                        } else {
                            $('[name="contabilNacional___' + id + '"]').parent().hide()
                            $('[name="contabilInternacional___' + id + '"]').parent().show()
                            window["contabilNacional___" + id + ""].clear()
                            $('[name="valorDolar___' + id + '"]').parent().parent().show()
                            $('[name="valorReal___' + id + '"]').parent().hide()
                            $('[name="valorReal___' + id + '"]').val('')
                            alterarValorTotalReembolso()
                        }
                    })
                }
            }
        });
        $('.quantidadeKm').on('change', (element) => {
            let id = element.currentTarget.name.split('___')
            if (isNaN(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value))) {
                $('#valorKm___' + id[1]).val('')
                alterarValorTotalReembolso()
            } else {
                $('#valorKm___' + id[1]).val(numberToReal(realToNumber($('#taxa___' + id[1]).val()) * parseFloat(element.currentTarget.value)))
                alterarValorTotalReembolso()
            }
        })

    } else {
        // $('[name^= "_codEstadoTable___"]').attr('readonly', true);
        $('input').attr('readonly', true)
        if ($("#stateAtual").val() == 20) {
            $("#selGrupo").prop('readonly', false).attr('type', 'zoom');
        }
        $('.justificativa').attr('readonly', true)
        if ($('[name="_vincularAdiantamento"]:checked').val() == 'SIM') {
            $('#divZoomAdiantamento').show()
            $('#divValorAdiantado').show()
            $('#divValorJustificado').show()
        } else {
            $('#divZoomAdiantamento').hide()
            $('#divValorAdiantado').hide()
            $('#divValorJustificado').hide()
        }
        if ($('[name="_tipoAcerto"]:checked').val() == "ADIANTAMENTO") {
            $('#divReembolso').hide()
            $('#politicaAdiantemantoDiv').show()
            $('#divAdiantamento').show()
        } else {
            $('#divReembolso').show()
            $('#divAdiantamento').hide()
        }
        if ($('[name="_politicaAdiantamento"]:checked').val() == "INTERNACIONAL") {
            $('[name="contabilAdiantNacional"]').parent().hide()
            $('[name="contabilAdiantInternacional"]').parent().show()
        }
        if ($('[name="_vincularAdiantamento"]:checked').val() == "SIM") {
            $('#selectAdiantamento').hide()
            $('#valAdiantamento').show()
        }

        if ($('#tipoVisualizacao').val() == "VIEW" || $('#stateAtual').val() == '11') {
            $('#subSuperiorImediato').hide()
                //$('#subAprovadorAlcada').hide()

            $('#nameSubSuperior').show()
                // $('#nameSubAprovador').show()
        }

        $('.visualizar').each((index, element) => {
            if (index != 0) {
                let id = $(element).parent().parent().find('[name^="idAnexo___"]')[0].name.split('___')[1]
                if ($('[name="idAnexo___' + id + '"]').val() != '') {
                    $(element).show()
                    $('[name="idAnexo___' + id + '"]').parent().hide()
                    element.id = 'ver_arquivo___' + id
                    $('#ver_arquivo___' + id).click((e) => {
                        var documentId = $('[name="idAnexo___' + id + '"]').val();
                        var versao = 1000
                        openDocument(documentId, versao)
                    });
                }
            }
        });
        $('[name^= "_politica___"]').each((index, element) => {
            let id = element.name.split('___')[1]
            if (element.checked) {
                if (element.value == "NACIONAL") {
                    $(element).parents('div').siblings('#infos').show()
                    $('[name="contabilNacional___' + id + '"]').parent().show()
                    $('[name="contabilInternacional___' + id + '"]').parent().hide()
                    $('[name="valorDolar___' + id + '"]').parent().parent().hide()
                    $('[name="valorReal___' + id + '"]').parent().show()
                } else {
                    $(element).parents('div').siblings('#infos').show()
                    $('[name="contabilNacional___' + id + '"]').parent().hide()
                    $('[name="contabilInternacional___' + id + '"]').parent().show()
                    $('[name="valorDolar___' + id + '"]').parent().parent().show()
                    $('[name="valorReal___' + id + '"]').parent().hide()
                }
                if ($('[name="distancia___' + id + '"]').val() == 'true') {
                    $('[name="easyAcessDivKm___' + id + '"]').parent().show()
                    $('[name="easyAcessDivVal___' + id + '"]').parent().hide()
                    $('[name="divAnexo___' + id + '"]').hide()
                } else {
                    $('[name="easyAcessDivKm___' + id + '"]').parent().hide()
                    $('[name="easyAcessDivVal___' + id + '"]').parent().show()
                    $('[name="divAnexo___' + id + '"]').show()
                }
            }
        })
    }
}

function esconderDivs() {
    $('#divReembolso').hide()
    $('#divAdiantamento').hide()
    $('#divZoomAdiantamento').hide()
    $('#divValorAdiantado').hide()
    $('#divValorJustificado').hide()
    $('.divItemsPaifilho').hide()
}

function dataSolicitacao() {
    let data = new Date;
    var dataString = "" + ((parseInt(data.getDate()) < 10) ? "0" + data.getDate() : data.getDate()) + "/" + (((parseInt(data.getMonth()) + 1) < 10) ? "0" + (parseInt(data.getMonth()) + 1) : data.getMonth() + 1) + "/" + data.getFullYear() + ""
    $('#dataAbertura').val(dataString)
}

function preencheOutroUser(usuario) {
    let dataRetorno = DatasetFactory.getDataset('ds_paifilho_cadastro_usuario', null, null, null)
    let userCod = dataRetorno.values.find(e => usuario === e['UsuarioId']);
    window['centroCusto'].setValue(userCod['namCentroCusto'])
    $('#codCentroCusto').val(userCod['codCentroCusto'])
}

function setSelectedZoomItem(selectedItem) {
    let name = selectedItem.inputName.split('___')[0]
    let item = selectedItem.inputName.split('___')[1]
    switch (name) {
        case 'zoomSolicitante':

            $('#cpf').val(selectedItem.CPF)
            if (selectedItem.UsuarioId == parent.WCMAPI.userId) {
                $('#zoomSelectedID').val(parent.WCMAPI.userId)
            } else {
                $('#zoomSelectedID').val(selectedItem.UsuarioId);
            }
            preencheOutroUser($('#zoomSelectedID').val());
            adiantamentosAnteriores()

            if ($('[name="tipoAcerto"]:checked').val() == "ADIANTAMENTO") {
                $('#valorAdiantamento').blur()
            } else {
                $('#valorReembolso').blur()
            }

            break;

        case 'contabilNacional':

        case 'contabilInternacional':
            $('#taxa___' + item).val(selectedItem.taxa)
            $('#taxaCambio___' + item).val(numberToReal(realToNumber(selectedItem.taxa)))
            $('#valorMaximoDespesas___' + item).val(selectedItem.valorMaximo)
            $('#codAcsel___' + item).val(selectedItem.acsel)
            if (selectedItem.distancia == 'on') {
                $('[name="easyAcessDivKm___' + item + '"]').parent().show()
                $('[name="easyAcessDivVal___' + item + '"]').parent().hide()
                $('[name="divAnexo___' + item + '"]').hide()
                $('[name="distancia___' + item + '"]').val('true')
            } else {
                $('[name="easyAcessDivKm___' + item + '"]').parent().hide()
                $('[name="easyAcessDivVal___' + item + '"]').parent().show()
                $('[name="divAnexo___' + item + '"]').show()
                $('[name="distancia___' + item + '"]').val('false')
            }
            break;

        case 'contabilAdiantNacional':

        case 'contabilAdiantInternacional':
            $('#valorMaximoAdiantamento').val(selectedItem.valorMaximo)
            $('#codPolitica').val(selectedItem.acsel)
            $('#valorAdiantamento').blur()
            break;

        case 'centroCustoResp1':

            $('[name="codCentroCustoResp1___' + item + '"]').val(selectedItem.Cod)

            break;

        case 'centroCusto':

            $('[name="codCentroCusto"]').val(selectedItem.Cod)

            break;
        case 'selGrupo':
            $("#selGrupoHidden").val("Pool:Group:" + selectedItem.id);
            break;

    }
}

function removedZoomItem(removedItem) {
    let item = removedItem.inputName.split('___')
    switch (item[0]) {
        case 'zoomSolicitante':
            $('#cpf').val('')

            $('#zoomSelectedID').val('')

            adiantamentosAnteriores()

            if ($('[name="tipoAcerto"]:checked').val() == "ADIANTAMENTO") {
                $('#valorAdiantamento').blur()
            } else {
                $('#valorReembolso').blur()
            }

            break;

        case 'contasContabilPaiFilho':
            $('#taxa___' + item[1]).val('')
            $('#valorMaximoDespesas___' + item[1]).val('')
            $('#codAcsel___' + item[1]).val('')
            $('[name="distancia___' + item[1] + '"]').val('')
            $('.divKm').hide()
            $('.divValores').hide()
            break;

        case 'contasContabilAdiantamento':
            $('#valorMaximoAdiantamento').val('')
            $('#codPolitica').val('')
            break;
    }
}

function adicionaMascaras() {
    $('.cpf').mask('999.999.999-99');
    $('.dinheiro').mask('#.##0,00', { reverse: true });
    $('.txCambioDin').mask('#.##0,000', { reverse: true });

}

function somenteNumeros(num) {
    var er = /[^0-9.]/;
    er.lastIndex = 0;
    var campo = num;
    if (er.test(campo.value)) {
        campo.value = "";
    }
}

function calculaDistancia(element) {
    let array = element.name.split('___')
    let id = array[1]

    let endInicial = $('[name="enderecoInicial___' + id + '"]').val()
    let endFinal = $('[name="enderecoFinal___' + id + '"]').val()

    if (array[0] === "enderecoInicial") {
        if (endFinal != undefined && endFinal != "") {
            try {
                requisicaoEndereco(endInicial, endFinal, id)
                $('[name="quantidadeKm___' + id + '"]').attr('readonly', true)
            } catch (e) {
                $('[name="quantidadeKm___' + id + '"]').attr('readonly', false)
                console.error(e)
            }
        }
    } else {
        if (endInicial != undefined && endInicial != "") {
            try {
                requisicaoEndereco(endInicial, endFinal, id)
                $('[name="quantidadeKm___' + id + '"]').attr('readonly', true)

            } catch (e) {
                $('[name="quantidadeKm___' + id + '"]').attr('readonly', false)
                console.error(e)
            }
        }
    }
}

function requisicaoEndereco(init, final, id) {

    let service = new google.maps.DistanceMatrixService;
    service.getDistanceMatrix({
        origins: [init],
        destinations: [final],
        travelMode: 'DRIVING',
        unitSystem: google.maps.UnitSystem.METRIC,
        avoidHighways: false,
        avoidTolls: false
    }, function(response, status) {
        if (status !== 'OK') {
            alert('Error: ' + status);
            $('[name="quantidadeKm___' + id + '"]').attr('readonly', false);
            $('[name="quantidadeKm___' + id + '"]').val('').change();
        } else {
            let originAddresses = response.originAddresses;
            let destinationAddresses = response.destinationAddresses;
            let km = response.rows[0].elements[0].distance.value / 1000;
            $('[name="enderecoInicial___' + id + '"]').val(originAddresses)
            $('[name="enderecoFinal___' + id + '"]').val(destinationAddresses)
            $('[name="quantidadeKm___' + id + '"]').val(km).change();
            $('[name="quantidadeKm___' + id + '"]').attr('readonly', true);
        }
    });
}

function detectar_mobile() {
    var check = false;
    (function(a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
}

function adiantamentosAnteriores() {
    $('#selectAdiantamento').html(`<option id="0" value="escolha" checked>Escolha um Adiantamento</option>`)

    let constraint = DatasetFactory.createConstraint('zoomSelectedID', $("#zoomSelectedID").val(), $("#zoomSelectedID").val(), ConstraintType.MUST);
    let dataset = DatasetFactory.getDataset('ds_acerto_despesas', null, [constraint], null);

    if (dataset.values.length != 0) {
        dataset.values.forEach((element, index) => {
            if (element.tipoAcerto === "ADIANTAMENTO" && element.reembolsado === 'false') {
                $('#selectAdiantamento').append(`<option id="${element.documentid}" value="${element.valorAdiantamento}">Adiantamento de ${element.dataAbertura} - ${element.valorAdiantamento}</option>`)
            }
        })
    } else {
        alterarValorAdiantado({ value: '', id: '' })
    }
}

function alterarValorAdiantado(element) {
    if (element.id == '') {
        $('#valorAdiantado').val(element.value);
        $('#codRegistroAlterar').val(element.id);
        $('#valAdiantamento').val(element.text);
        $('#valAdiantamento').attr('data-valueSelect', element.value)
        $('#valAdiantamento').attr('data-idSelect', element.id)
    } else {
        $('#valorAdiantado').val(element.selectedOptions[0].value);
        $('#codRegistroAlterar').val(element.selectedOptions[0].id);
        $('#valAdiantamento').val(element.selectedOptions[0].text);
        $('#valAdiantamento').attr('data-valueSelect', element.selectedOptions[0].value)
        $('#valAdiantamento').attr('data-idSelect', element.selectedOptions[0].id)
    }

    alterarValorTotalReembolso()
}

function alterarValorTotalReembolso() {
    let array = $('.totalReembolso')
    let aux1 = 0
    let total = 0
    array.each((index, element) => {
        if (index != 0) {
            let id = element.name.split('___')
            if (aux1 != id[1]) {
                if (id[0] == 'valorKm' && element.value != '') {
                    aux1 = id[1]
                    total += realToNumber(element.value)
                }
                if (id[0] == 'valorFinal' && element.value != '') {
                    aux1 = id[1]
                    total += realToNumber(element.value)
                }
                if (id[0] == 'valorReal' && element.value != '') {
                    aux1 = id[1]
                    total += realToNumber(element.value)
                }
            }
        }
    })
    $('#valorReembolso').val(numberToReal(total))
    $('#valorReembolso').blur()
    let valorAdiantamento = realToNumber($('#valorAdiantado').val())
    if (isNaN(valorAdiantamento)) {
        $('#valorJustificado').val('Selecione um Adiantamento')
    } else {
        $('#valorJustificado').val(numberToReal(valorAdiantamento - total))
    }
}

$('#valorReembolso').on('blur', (element) => {
    if (element.currentTarget.value) {
        setProxAprovador(realToNumber(element.currentTarget.value))
    }
})

function realToNumber(numero) {
    return parseFloat(numero.replace(/\./g, '').replace(',', '.'))
}

function numberToReal(numero) {
    if (numero < 0) {
        var numero = numero.toFixed(2).split('.');
        numero[0] = numero[0].replace('-', '')
        numero[0] = numero[0].split(/(?=(?:...)*$)/).join('.');
        return '-' + numero.join(',');
    } else {
        var numero = numero.toFixed(2).split('.');
        numero[0] = numero[0].split(/(?=(?:...)*$)/).join('.');
        return numero.join(',');
    }
}

function setarVisibilidade() {
    let state = $('#stateAtual').val()
    if (state == 20 || state == 11 || state == 9 || state == 52) {
        $('#divAprovacao').show()
    } else {
        $('#divAprovacao').hide()
    }
    if (state <= 20) {
        $('#divDatas').hide()
    }
    if (state <= 20) {
        $('.divHistorico').hide()
    }
    if (state < 20) {
        $('#div_financeiro').hide()
    }
}

function setProxAprovador(valor) {

    let usuario = $('#zoomSelectedID').val()
    let state = stateAtual.value
    let aux
    let aux2
    aux = true
    aux2 = true

    if (usuario != '' && valor != undefined) {

        //$('#subAprovadorAlcada').html(`<option value="manter">Manter Aprovador</option>`)
        $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)

        // let constraint = DatasetFactory.createConstraint('Id', usuario, usuario, ConstraintType.MUST);
        // let dataset = DatasetFactory.getDataset('ds_paifilho_usuario_grupo', null, new Array(constraint), null);

        // let grupo = dataset.values[0].Grupo

        // let constraintGrupo = DatasetFactory.createConstraint('grupo', grupo, grupo, ConstraintType.MUST);
        // let datasetGrupo = DatasetFactory.getDataset('ds_cadastro_grupo', null, new Array(constraintGrupo), null);

        // let constraintCardId = DatasetFactory.createConstraint('metadata#id', datasetGrupo.values[0].documentid, datasetGrupo.values[0].documentid, ConstraintType.MUST)
        // let datasetAprovadores = DatasetFactory.getDataset('ds_paifilho_grupos_aprovacao', null, new Array(constraintCardId), [''])
        let codCentroCusto = $("#codCentroCusto").val();
        let user = $("#zoomSolicitante").val()[0];
        var c1 = DatasetFactory.createConstraint('tablename', 'tabelaUserCpf', 'tabelaUserCpf', ConstraintType.MUST);

        var datasetGrupo = DatasetFactory.getDataset("ds_usuario_cpf", null, [c1], null);
        let grupo = "";
        datasetGrupo.values.forEach((e) => {
                if (e.cpf == $("#cpf").val()) {
                    grupo = e.grupo;
                }
            })
            //var c1 = DatasetFactory.createConstraint('codCentroCusto', codCentroCusto, codCentroCusto, ConstraintType.MUST);
            //var datasetAprovadores = DatasetFactory.getDataset('ds_alcada_assurant', null, [c1], null);

        c1 = DatasetFactory.createConstraint('tablename', 'tableCadastroAlcada', 'tableCadastroAlcada', ConstraintType.MUST);
        //c2 = DatasetFactory.createConstraint('metadata#version', 2000, 2000, ConstraintType.MUST);
        //let c3 = DatasetFactory.createConstraint('grupo', grupo, grupo, ConstraintType.MUST);
        datasetAprovadores = DatasetFactory.getDataset('ds_alcada_assurant', null, [c1], ['prioridade']);

        console.table(datasetAprovadores.values, ['index', 'documentid', 'usuario', 'substitutos'])
        let users_processo_despesa = []
        
        datasetAprovadores.values.forEach((e) => {
            let aprovers = e.grupo.split('\u0018').map(s => s.trim())
            //if (e.hiddenProcesso.indexOf('acerto_despesa') > -1 && e.grupo.indexOf(grupo) > -1) {
            if (e.hiddenProcesso.indexOf('acerto_despesa') > -1 && aprovers.includes(grupo.trim())) {
            	users_processo_despesa.push(e);
            }
        })
        
        datasetAprovadores.values = users_processo_despesa

        let prioridadeUsuario = datasetAprovadores.values.find((element) => { return element.idUsuario === usuario })

        // if (prioridadeUsuario != undefined) {
        //     for (let x = 0; x < datasetAprovadores.values.length; x++) {
        //         if (prioridadeUsuario.prioridade <= datasetAprovadores.values[x].prioridade) {
        //             if (aux) {
        //                 if (state == '4' || state == '0') {
        //                     $('#superiorImediato').val(datasetAprovadores.values[x].usuario)
        //                     $('#superiorId').val(userNameToId(datasetAprovadores.values[x].usuario))
        //                     $('#proximoAprovador').val(userNameToId(datasetAprovadores.values[x].usuario))
        //                 }
        //                 if (datasetAprovadores.values[x].substitutos != '' && datasetAprovadores.values[x].substitutos != null) {
        //                     let subs = datasetAprovadores.values[x].substitutos.split('')
        //                     $('#subSuperiorImediato').html('');
        //                     $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
        //                     subs.forEach(element => {
        //                         $('#subSuperiorImediato').append(`<option value="${userNameToId(element)}">${element}</option>`)
        //                     })
        //                 }

        //                 aux = false
        //             } else {
        //                 if (datasetAprovadores.values[x].substitutos != '' && datasetAprovadores.values[x].substitutos != null) {
        //                     let subs = datasetAprovadores.values[x].substitutos.split('')
        //                     $('#subSuperiorImediato').append(`<option value="${userNameToId(datasetAprovadores.values[x].usuario)}">${datasetAprovadores.values[x].usuario}</option>`)
        //                     $('#subSuperiorImediato').html('');
        //                     $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
        //                     subs.forEach(element => {
        //                         $('#subSuperiorImediato').append(`<option value="${userNameToId(element)}">${element}</option>`)
        //                     })
        //                 }
        //             }

        //             if (valor < (realToNumber(datasetAprovadores.values[x].valorFinal)) || x == (datasetAprovadores.values.length - 1)) {
        //                 if (aux2) {
        //                     if (state == '4' || state == '0') {
        //                         //$('#aprovadorAlcada').val(datasetAprovadores.values[x].usuario)
        //                         // $('#aprovadorId').val(userNameToId(datasetAprovadores.values[x].usuario))
        //                     }
        //                     if (datasetAprovadores.values[x].substitutos != '' && datasetAprovadores.values[x].substitutos != null) {
        //                         let subs = datasetAprovadores.values[x].substitutos.split('')
        //                             //$('#subAprovadorAlcada').html('');
        //                             // $('#subAprovadorAlcada').html(`<option value="manter">Manter Aprovador</option>`)
        //                             // subs.forEach(element => {
        //                             //      $('#subAprovadorAlcada').append(`<option value="${userNameToId(element)}">${element}</option>`)
        //                             // })
        //                     }
        //                     aux = false
        //                 } else {
        //                     if (datasetAprovadores.values[x].substitutos != '' && datasetAprovadores.values[x].substitutos != null) {
        //                         // let subs = datasetAprovadores.values[x].substitutos.split('')
        //                         // $('#subAprovadorAlcada').append(`<option value="${userNameToId(datasetAprovadores.values[x].usuario)}">${datasetAprovadores.values[x].usuario}</option>`)
        //                         // $('#subAprovadorAlcada').html('');
        //                         // $('#subAprovadorAlcada').html(`<option value="manter">Manter Aprovador</option>`)
        //                         // subs.forEach(element => {
        //                         //     $('#subAprovadorAlcada').append(`<option value="${userNameToId(element)}">${element}</option>`)
        //                         // })
        //                     }
        //                 }
        //             }
        //         }
        //     }
        // } else {
        prioridadeUsuario = (!prioridadeUsuario) ? { prioridade: 0 } : prioridadeUsuario;
        for (let x = 0; x < datasetAprovadores.values.length; x++) {
            if (!(prioridadeUsuario.prioridade >= datasetAprovadores.values[x].prioridade)) {
                let valorFinal = realToNumber(datasetAprovadores.values[x].valorFinal);
                let idUser = userNameToId(datasetAprovadores.values[x].usuario);
                if ((state == '4' || state == '0') && valor <= valorFinal) {
                    $('#superiorImediato').val(datasetAprovadores.values[x].usuario)
                    $('#superiorId').val(idUser)
                    $('#proximoAprovador').val(idUser)
                    let subs = datasetAprovadores.values[x].substitutos.split('')
                    $('#subSuperiorImediato').html('');
                    $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
                    subs.forEach(element => {
                        $('#subSuperiorImediato').append(`<option value="${userNameToId(element)}">${element}</option>`)
                    })
                    $(".alertAlcada").addClass("fs-display-none");
                    break;
                } else {
                    if (state == 4 || state == 0) {
                        $(".alertAlcada").removeClass("fs-display-none");
                        $('#superiorImediato').val('')
                        $('#superiorId').val('')
                        $('#proximoAprovador').val('')
                    }
                }

                // aux = false
            }
            //     let idUser = userNameToId(datasetAprovadores.values[x].usuario);
            //     if ($('#superiorId').val() == idUser && datasetAprovadores.values[x].substitutos) {
            //         let subs = datasetAprovadores.values[x].substitutos.split('')
            //         $('#subSuperiorImediato').append(`<option value="${userNameToId(datasetAprovadores.values[x].usuario)}">
            //             ${datasetAprovadores.values[x].usuario}</option>`)
            //         $('#subSuperiorImediato').html('');
            //         $('#subSuperiorImediato').html(`<option value="manter">Manter Superior</option>`)
            //         subs.forEach(element => {
            //             $('#subSuperiorImediato').append(`<option value="${userNameToId(element)}">${element}</option>`)
            //         })
            //     }
            // }

            if (valor < (realToNumber(datasetAprovadores.values[x].valorFinal))) {
                if (aux2) {
                    // if (state == '4' || state == '0') {
                    //     $('#aprovadorAlcada').val(datasetAprovadores.values[x].usuario)
                    //     $('#aprovadorId').val(userNameToId(datasetAprovadores.values[x].usuario))
                    // }
                    // if (datasetAprovadores.values[x].substitutos != '' && datasetAprovadores.values[x].substitutos != null) {
                    //     let subs = datasetAprovadores.values[x].substitutos.split('')
                    //     $('#subAprovadorAlcada').html('');
                    //     $('#subAprovadorAlcada').html(`<option value="manter">Manter Aprovador</option>`)
                    //     subs.forEach(element => {
                    //         $('#subAprovadorAlcada').append(`<option value="${userNameToId(element)}">${element}</option>`)
                    //     })
                    // }
                    // aux = false
                }
            } else {
                // if (datasetAprovadores.values[x].substitutos != '' && datasetAprovadores.values[x].substitutos != null) {
                //     let subs = datasetAprovadores.values[x].substitutos.split('')
                //     $('#subAprovadorAlcada').append(`<option value="${userNameToId(datasetAprovadores.values[x].usuario)}">${datasetAprovadores.values[x].usuario}</option>`)
                //     $('#subAprovadorAlcada').html('');
                //     $('#subAprovadorAlcada').html(`<option value="manter">Manter Aprovador</option>`)
                //     subs.forEach(element => {
                //         $('#subAprovadorAlcada').append(`<option value="${userNameToId(element)}">${element}</option>`)
                //     })
                // }
            }
        }
        //}


    } else {
        // $('#aprovadorAlcada').val("")
        // $('#aprovadorId').val("")
        $('#superiorImediato').val("")
        $('#superiorId').val("")
    }
    hideDuplicateAprover()
    ajusteSubAprovadores()
    $('[role="log"]').hide()
}

function hideDuplicateAprover() {
    if ($('#superiorId').val() === $('#aprovadorId').val()) {
        $('#div_subSuperiorImediato').hide()
    } else {
        $('#div_subSuperiorImediato').show()
    }
}

function userNameToId(id) {
    if (id == 'manter') {
        return 'Manter Aprovador'
    } else {
        var constraintColleague1 = DatasetFactory.createConstraint('colleagueName', id, id, ConstraintType.MUST);
        var colunasColleague = new Array('colleaguePK.colleagueId');
        var datasetColleague = DatasetFactory.getDataset('colleague', colunasColleague, new Array(constraintColleague1), null);
        return datasetColleague.values[0]["colleaguePK.colleagueId"]
    }
}

// $('#subAprovadorAlcada').on('change', (e) => {
//     let valor = $('[name="subAprovadorAlcada"]>option:selected')
//     if (valor.val() == 'manter') {
//         $('#proximoAprovador').val($('#aprovadorId').val())
//     } else {
//         $('#proximoAprovador').val(valor.val())
//     }
//     $('#idSubAprovador').val(e.currentTarget.selectedOptions[0].value)
//     $('#nameSubAprovador').val(e.currentTarget.selectedOptions[0].text)
// })

$('#subSuperiorImediato').on('change', (e) => {
    let valor = $('[name="subSuperiorImediato"]>option:selected')
    if (valor.val() == 'manter') {
        $('#proximoAprovador').val($('#superiorId').val())

    } else {
        $('#proximoAprovador').val(valor.val())
    }
    $('#idSubSuperior').val(e.currentTarget.selectedOptions[0].value)
    $('#nameSubSuperior').val(e.currentTarget.selectedOptions[0].text)
})

$('#valorAdiantamento').on('blur', (element) => {
    if (!$(element.currentTarget).attr('readonly')) {
        if (element.currentTarget.value) {
            setProxAprovador(realToNumber(element.currentTarget.value))
        }
        let valorMaximo = realToNumber($('#valorMaximoAdiantamento').val())
        if (parseFloat($('#valorMaximoAdiantamento').val().replace('.', '').replace(',', '.')) < parseFloat(element.target.value.replace('.', '').replace(',', '.'))) {
            $("#aviso").show();
            $("#mostrarAviso").val('sim');
        } else {
            $("#mostrarAviso").val('nao');
            $("#aviso").hide();
        }

    }
})

function setDescription(usuario) {
    var descricao = 'Acerto de Despesa - Usuário :' + (usuario);
    return descricao;
}

function setAprovadorFinanceiro() {
    // $("#div_aprovadorAlcada").hide()
    $("#div_subSuperiorImediato").hide()
    let usuario = ($('#usuarioAtual').val())
    $('#financeiro').val(usuario)
    $('#parecerFinanceiro').attr('readonly', false)
}

function ajusteSubAprovadores() {
    $('[name="subSuperiorImediato"]').val($('#idSubSuperior').val())
        //$('[name="subAprovadorAlcada"]').val($('#idSubAprovador').val())
}

var beforeSendValidate = function(numState, nextState) {
    if (numState == 52) {
        if ($("[name^='botaoAprovacao']").val() == "APROVADO") {
            $("#selGrupoHidden").val("aprovado");
        } else {
            $("#selGrupoHidden").val("reprovado");
        }
    }

    if ((numState == 0 || numState == 4) && $(".alertAlcada").is(":visible")) {
        throw "É necessário que o solicitante possua aprovadores para o valor solicitado";
    }


}