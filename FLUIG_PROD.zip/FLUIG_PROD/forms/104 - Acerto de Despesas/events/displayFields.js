function displayFields(form, customHTML) {
    var user = getValue("WKUser");
    var state = getValue("WKNumState");
    var mode = form.getFormMode();

    form.setValue("tipoVisualizacao", mode);
    form.setValue("stateAtual", state);
    form.setValue("usuarioAtual", user);
    customHTML.append('<script>function getUser(){return "' + user + '"}</script>')
    form.setHidePrintLink(true);

    if (state != 4) {
        if (mode != "ADD") {
            form.setHideDeleteButton(false);
        } else {
            form.setVisibleById('div_parecerAprovador', false);
            form.setVisibleById('div_parecerSuperior', false);
        }

        if (mode == "MOD") {
            form.setEnabled("tipoAcerto", false);
            form.setEnabled("vincularAdiantamento", false);
            form.setEnabled("codEstado", false, true);
            var indexes = form.getChildrenIndexes("tabelaDespesas");
            for (var i = 0; i < indexes.length; i++) {
                form.setEnabled("politica___" + indexes[i], false, true);
                form.setEnabled("codEstadoTable___" + indexes[i], false, true);
                form.setEnabled("descricaoLinha___" + indexes[i], false, true);
            }
            form.setEnabled("parecerAprovador", false);
            form.setEnabled("parecerSuperior", false);
            form.setEnabled("politicaAdiantamento", false);
            if (state == 11) {
                form.setVisible('subSuperiorImediato', false);
                form.setVisible('subAprovadorAlcada', false);
                if (form.getValue('aprovadorId') == user || form.getValue('idSubAprovador') == user) {
                    form.setValue("proximoAprovador", "nenhum");
                    form.setEnabled("parecerAprovador", true);
                    form.setEnabled("parecerSuperior", false);
                } else {
                    if (form.getValue('idSubSuperior') == user && (form.getValue('idSubSuperior') == form.getValue('aprovadorId') || form.getValue('idSubSuperior') == form.getValue('idSubAprovador'))) {
                        form.setValue("proximoAprovador", "nenhum");
                        form.setEnabled("parecerAprovador", true);
                        form.setEnabled("parecerSuperior", false);
                    } else {
                        if (form.getValue('idSubAprovador') != 'manter') {
                            form.setValue("proximoAprovador", form.getValue('idSubAprovador'));
                            form.setEnabled("parecerSuperior", true);
                            form.setEnabled("parecerAprovador", false);
                        } else {
                            form.setValue("proximoAprovador", form.getValue('aprovadorId'));
                            form.setEnabled("parecerSuperior", true);
                            form.setEnabled("parecerAprovador", false);
                        }
                    }
                }
            }
        }
    } else {
        form.setEnabled('parecerSuperior', false);
        form.setEnabled('parecerAprovador', false);
        form.setEnabled('pagamentoConcluido', false);

        if (form.getValue("proximoAprovador") == 'nenhum' && state == 4) {
            form.setValue("proximoAprovador", form.getValue('superiorId'));
        }
    }

    if (state == 20) {
        form.setEnabled("parecerFinanceiro", true);
        form.setEnabled("aprovOutroGrupo", true);
        form.setEnabled("selGrupo", true);
        form.setEnabled("parecerGrupo", false);
    } else {
        form.setEnabled("parecerFinanceiro", false);
    }

    if (state == 31) {
        form.setEnabled('subSuperiorImediato', false);
        form.setEnabled('subAprovadorAlcada', false);
    }
}