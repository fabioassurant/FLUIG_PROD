function validateForm(form) {

    if (form.getValue('stateAtual') == 4 || form.getValue('stateAtual') == 0) {
        if (form.getValue('zoomSolicitante') == null || form.getValue('zoomSolicitante') == '') {
            throw 'Solicitante não preenchido'
        }
        if (form.getValue('cpf') == '' || form.getValue('cpf') == null) {
            throw 'Solicitante não preenchido'
        }
        if (form.getValue('centroCusto') == '' || form.getValue('centroCusto') == null) {
            throw 'Centro de Custo não informado'
        }
        if (form.getValue('tipoAcerto') == 'ADIANTAMENTO') {
            if (form.getValue('politicaAdiantamento') == 'NACIONAL') {
                if (form.getValue('contabilAdiantNacional') == '' || form.getValue('contabilAdiantNacional') == null) {
                    throw 'Conta contabil não preenchido'
                }
            } else {
                if (form.getValue('contabilAdiantInternacional') == '' || form.getValue('contabilAdiantInternacional') == null) {
                    throw 'Conta contabil não preenchido'
                }
            }
            if (form.getValue('valorAdiantamento') == '' || form.getValue('valorAdiantamento') == null) {
                throw 'Valor do adiantamento não informado'
            }
            if (form.getValue('justificativaAdiantamento') == '' || form.getValue('justificativaAdiantamento') == null) {
                throw 'Justificativa não informada'
            }
        } else {
            if (form.getValue('vincularAdiantamento') == 'SIM') {
                if (form.getValue('valAdiantamento') === 'Escolha um Adiantamento' || form.getValue('valAdiantamento') == null || form.getValue('valAdiantamento') == '') {
                    throw 'Adiantamento não selecionado'
                }
                var string = form.getValue('valorJustificado') + ""
                var valJustificado = string.replace(/\./g, '').replace(',', '.')
                if (parseFloat(valJustificado) > 0) {
                    throw 'Valor de reembolso deve ser maior que valor adiantado!'
                }
            }

            var indexes = form.getChildrenIndexes("tabelaDespesas");


            if (indexes.length > 0) {

                for (var i = 0; i < indexes.length; i++) {
                    if (form.getValue('politica___' + indexes[i]) == "NACIONAL") {
                        if (form.getValue('contabilNacional___' + indexes[i]) == '' || form.getValue('contabilNacional___' + indexes[i]) == null) {
                            throw 'Conta contabil não preenchido'
                        }
                    } else {
                        if (form.getValue('contabilInternacional___' + indexes[i]) == '' || form.getValue('contabilInternacional___' + indexes[i]) == null) {
                            throw 'Conta contabil não preenchido'
                        }
                    }

                    if (form.getValue('dataContas___' + indexes[i]) == '' || form.getValue('dataContas___' + indexes[i]) == null) {
                        throw 'Data da Conta não informado'
                    }

                    if (form.getValue('descricaoLinha___' + indexes[i]) == '' || form.getValue('descricaoLinha___' + indexes[i]) == null) {
                        throw 'Descrição da linha não informado'
                    }

                    if (form.getValue('distancia___' + indexes[i]) == 'false') {

                        if (form.getValue('politica___' + indexes[i]) == "NACIONAL") {
                            if (form.getValue('valorReal___' + indexes[i]) == '' || form.getValue('valorReal___' + indexes[i]) == null) {
                                throw 'Valor não preenchido em uma das linhas!'
                            }
                        } else {
                            if (form.getValue('valorDolar___' + indexes[i]) == '' || form.getValue('valorDolar___' + indexes[i]) == null) {
                                throw 'Valor não preenchido em uma das linhas!'
                            }
                        }

                    } else {
                        if (form.getValue('quantidadeKm___' + indexes[i]) == '' || form.getValue('quantidadeKm___' + indexes[i]) == null) {
                            throw 'Quilometragem não preenchida em uma das linhas !'
                        }
                        if (form.getValue('valorKm___' + indexes[i]) == '' || form.getValue('valorKm___' + indexes[i]) == null) {
                            throw 'Quilometragem não preenchida em uma das linhas !'
                        }
                    }
                    if ((form.getValue('idAnexo___' + indexes[i]) == '' || form.getValue('idAnexo___' + indexes[i]) == null) && form.getValue('distancia___' + indexes[i]) == 'false') {
                        throw 'Anexo não informado'
                    }
                }

            } else {
                throw "Nenhuma despesa adicionada!";
            }
        }
    }
    if (form.getValue('stateAtual') == 20) {
        if ((form.getValue('parecerFinanceiro') == '' || form.getValue('parecerFinanceiro') == null) && form.getValue('aprovacaoSolicitacao') != 'APROVADO') {
            throw "Parecer não informado!";
        }
    }
    if (form.getValue('stateAtual') == 9 || form.getValue('stateAtual') == 11 || form.getValue('stateAtual') == 20) {
        if (form.getValue('aprovacaoSolicitacao') == '' || form.getValue('aprovacaoSolicitacao') == null) {
            throw "Selecionar se será Aprovado/Contestado/Reprovado !";
        }
    }
}