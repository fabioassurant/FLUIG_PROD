function createDataset(fields, constraints, sortFields) {

    var newDataset = DatasetBuilder.newDataset();
    var ic = new javax.naming.InitialContext()
    var created = false;
    var filtro = '';
    var banco = '';
    var zoom = 0;
    var dataSource = 'jdbc/';
    var servico = 'Conector_Acsel';
    var cpfcnpj = "";
    if(constraints){
        for(var i = 0; i < constraints.length; i++){
            if(constraints[i].fieldname == 'cpfcnpj'){
                cpfcnpj = constraints[i].initialValue;
            }
        }
    }

    var query = "SELECT NUMDOCTO FROM OBLIGACION O WHERE O.NUMID || DVID = " + cpfcnpj + " AND TIPOID = 'CNPJ' AND O.NUMDOCTO IS NOT NULL";

    var ds = ic.lookup(dataSource + '/' + servico)

    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(query);
        var columnCount = rs.getMetaData().getColumnCount();
        var counter = 0;
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }

                created = true;
            }

            var Arr = new Array();

            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));

                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }

            newDataset.addRow(Arr);

            counter++;
            if(counter > 100000){
                
                break;
            }
        }
    } catch (e) {
        log.info("ERRO ==============> " + e.message);
        newDataset.addColumn("ERRO");
        newDataset.addRow(new Array(e.message));
    } finally {
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
    }

    return newDataset;
}