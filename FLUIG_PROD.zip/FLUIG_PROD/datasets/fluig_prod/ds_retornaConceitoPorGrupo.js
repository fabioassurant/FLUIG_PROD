function createDataset(fields, constraints, sortFields) {
    try {
        return processResult(callService(fields, constraints, sortFields));
    } catch (e) {
        log.info('Error')
        return processErrorResult(e, constraints);
    }
}

function callService(fields, constraints, sortFields) {
    var grupo_conceito = "";
    if (constraints) {
        for (var j = 0; j < constraints.length; j++) {
            if (constraints[j].fieldName == 'grupo_conceito') {
                grupo_conceito = constraints[j].initialValue
            }
        }
    }

    var serviceData = data(grupo_conceito);
    var params = serviceData.inputValues;
    var assigns = serviceData.inputAssignments;


    verifyConstraints(serviceData.inputValues, constraints);
    var serviceHelper = ServiceManager.getService(serviceData.fluigService);
    var serviceLocator = serviceHelper.instantiate(serviceData.locatorClass);
    var service = serviceLocator.getServicosWebServicePort();
    var response = service.retornaConceito(getParamValue(params.cChaveAutent, assigns.cChaveAutent), getParamValue(params.cCodClaEgre, assigns.cCodClaEgre), getParamValue(params.cCodCptoEgre, assigns.cCodCptoEgre), "F");
    return response;
}

function defineStructure() {
    addColumn("cODGRUPOCONCEITO");
    addColumn("dESCGRUPOCONCEITO");
}

function onSync(lastSyncDate) {
    var serviceData = data();
    var synchronizedDataset = DatasetBuilder.newDataset();
    try {
        var resultDataset = processResult(callService());
        if (resultDataset != null) {
            var values = resultDataset.getValues();
            for (var i = 0; i < values.length; i++) {
                synchronizedDataset.addRow(values[i]);
            }
        }

    } catch (e) {
        log.info('Dataset synchronization error : ' + e.message);

    }
    return synchronizedDataset;
}

function verifyConstraints(params, constraints) {
    if (constraints != null) {
        for (var i = 0; i < constraints.length; i++) {
            try {
                params[constraints[i].fieldName] = JSON.parse(constraints[i].initialValue);
            } catch (e) {
                params[constraints[i].fieldName] = constraints[i].initialValue;
            }
        }
    }
}

function processResult(result) {
    var dataset = DatasetBuilder.newDataset();
    result = result.getConceitoList().getConceito();
    dataset.addColumn("codConceito");
    dataset.addColumn("descConceito");
    for (var i = 0; i < result.size(); i++) {
        dataset.addRow([result.get(i).getCODCONCEITO(), result.get(i).getDESCCONCEITO()]);
    }
    return dataset;
}

function processErrorResult(error, constraints) {
    var dataset = DatasetBuilder.newDataset();

    var params = data().inputValues;
    verifyConstraints(params, constraints);

    dataset.addColumn('error');
    dataset.addColumn('cChaveAutent');
    dataset.addColumn('cCodClaEgre');

    var cChaveAutent = isPrimitive(params.cChaveAutent) ? params.cChaveAutent : JSONUtil.toJSON(params.cChaveAutent);
    var cCodClaEgre = isPrimitive(params.cCodClaEgre) ? params.cCodClaEgre : JSONUtil.toJSON(params.cCodClaEgre);

    dataset.addRow([error.message, cChaveAutent, cCodClaEgre]);

    return dataset;
}

function getParamValue(param, assignment) {
    if (assignment == 'VARIABLE') {
        return getValue(param);
    } else if (assignment == 'NULL') {
        return null;
    }
    return param;
}

function hasValue(value) {
    return value !== null && value !== undefined;
}

function isPrimitive(value) {
    return ((typeof value === 'string') || value.substring !== undefined) || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined';
}


function getObjectFactory(serviceHelper) {
    var objectFactory = serviceHelper.instantiate("webservice.ObjectFactory");

    return objectFactory;
}



function data(grupo_conceito) {
    return {
        "fluigService": "Acsel",
        "operation": "retornaGrupoConceito",
        "soapService": "AizServicosWebBeanService",
        "portType": "ServicosWebService",
        "locatorClass": "webservice.AizServicosWebBeanService",
        "portTypeMethod": "getServicosWebServicePort",
        "parameters": [],
        "inputValues": {
            "cChaveAutent": encriptar(),
            "cCodClaEgre": grupo_conceito,
            "cCodCptoEgre": "",
            "cCodWorkflow": "F"
        },
        "inputAssignments": {
            "cChaveAutent": "VALUE",
            "cCodClaEgre": "VALUE",
            "cCodCptoEgre": "VALUE",
            "cCodWorklow": "F"
        },
        "outputValues": {},
        "outputAssignments": {},
        "extraParams": {
            "enabled": false
        }
    }
}

function encriptar() {
    var token = DatasetFactory.getDataset("ds_getToken", null, null, null);

    if (token.rowsCount > 0) {
        if (token.getValue(0, "token") != undefined) {
            return token.getValue(0, "token");
        }
    }

    return "";
}