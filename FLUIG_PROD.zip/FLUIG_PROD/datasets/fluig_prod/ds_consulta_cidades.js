function createDataset(fields, constraints, sortFields) {
	
	log.info('CONSULTA CIDADES -----------@@@');

    var gson = new com.google.gson.Gson();
	var newDataset = DatasetBuilder.newDataset();
	var estado = "";
	
	try {
		
		if (constraints) {
			for (var i = 0; i < constraints.length; i++) {
				if (constraints[i].fieldName == "estado") {
					estado = constraints[i].initialValue;
				}
			}
		}
		
		log.info('INICIANDO CONSULTA -----------@@@');
		var cChaveAutent = encriptar();
		log.info('cChaveAutent -----------@@@: ' + cChaveAutent);
		var cCodWorkflow = "F";
		var cPais = "BRA";
		var cEstado = estado;
		var retornoCidade = consultaCidades(cChaveAutent, cPais, cEstado, "", cCodWorkflow);	
        var retornoCidadeJSON = JSON.parse(gson.toJson(retornoCidade));
        
		newDataset.addColumn("CODIGO");
		newDataset.addColumn("DESCRICAO");
        
		log.info('retornoCidadeJSON -----------@@@: ' + retornoCidadeJSON);
		
		if (retornoCidade != "Erro") {
			for (var i = 0; i < retornoCidadeJSON.length; i++) {
                newDataset.addRow(
                    [
                 		retornoCidadeJSON[i]['codigo'],
                 		retornoCidadeJSON[i]['descricao']
                    ]
                )
			}
		} else {
			newDataset.addColumn("Erro");
			newDataset.addRow(retornoCidade);
		}
		log.info("########## Retorno Cidade newDataset =====");
		log.dir(newDataset);

		return newDataset
	} catch (e) {
		log.info('ERROOOOR-----------@@@: ' + e);
		newDataset.addColumn("Erro");
		newDataset.addRow(e);
		return newDataset;
	}
}

function consultaCidades(cChaveAutent, cPais, cEstado, cConsulta, cCodWorkflow) {
	
	log.info('INICIANDO CHAMADA DA API consultaCidades -----------@@@')
	
	var properties = {};
	properties["receive.timeout"] = "100000000";

	var supplierService = ServiceManager.getService('Acsel_8');
	var serviceHelper = supplierService.getBean();
	var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
	var service = serviceLocator.getServicosWebServicePort();
	var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
	
	try {
		var ListaCidadesList = customClient.listaCidades(cChaveAutent, cPais, cEstado, cConsulta, cCodWorkflow);
		if (ListaCidadesList['retorno'] == 0 || ListaCidadesList['retorno'] == "0") {
			return ListaCidadesList['listaCidadesList']['cidades'];
		} else {
			var mensagemRetorno = 'Erro consultaCidades';
			log.info(mensagemRetorno);
			return "Erro";
		}
	} catch (e) {
		log.info('ERRO SERVIÇO consultaCidades -----------@@@: ' + e.toString())
		throw e.toString();
	}
}

function encriptar() {
	var token = DatasetFactory.getDataset("ds_getToken", null, null, null);
	
	if (token.rowsCount > 0) {
		if (token.getValue(0, "token") != undefined) {
			return token.getValue(0, "token");			
		}
	}
	return "";
}