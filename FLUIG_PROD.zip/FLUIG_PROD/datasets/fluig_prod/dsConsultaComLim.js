function defineStructure() {
	addColumn("NUM_OBLIG");
	addColumn("VALOR");
    addColumn("TIPOOBLIG");
    addColumn("RAZAO_SOCIAL");
    addColumn("CNPJ");
    addColumn("ENDERECO");
    addColumn("DATA_CRIACAO");
    addColumn("DATA_VENCIMENTO");
    addColumn("HISTORICO");
    addColumn("BANCO");
    addColumn("AGENCIA");
    addColumn("TIPO_CONTA");
    addColumn("CONTA");
    addColumn("DIGITO");

    setKey(["NUM_OBLIG", "VALOR"]);
    addIndex(["NUM_OBLIG"]);
    addIndex(["NUM_OBLIG", "VALOR", "TIPOOBLIG"]);
}

function onSync(lastSyncDate) {
    var newDataset = DatasetBuilder.newDataset();

    var ic = new javax.naming.InitialContext()
    var created = false;
    var filtro = '';
    var banco = '';
    var zoom = 0;
    var dataSource = 'jdbc/';
    var servico = 'Conector_Acsel';

    var query = "SELECT O.NUMOBLIG AS NUM_OBLIG, O.MTOBRUTOOBLIGLOCAL AS VALOR, O.TIPOOBLIG, TER.NOMTER AS RAZAO_SOCIAL, TER.NUMID || TER.DVID AS CNPJ,  TER.DIREC AS ENDERECO, O.FECSTS AS DATA_CRIACAO, O.FECGTIAPAGO AS DATA_VENCIMENTO,O.HISTORICO, EF.DESCENTFINAN AS BANCO, FP.AGENCIA, FP.TIPO_CONTA, FP.CUENTACOR as CONTA, FP.DVCUENTACOR AS DIGITO FROM OBLIGACION O, TERCERO TER, FORMA_PAGO FP, ENT_FINAN EF WHERE O.STSOBLIG = 'ACT' AND O.TIPOOBLIG IN  ('COM','LIM') AND TER.TIPOID = O.TIPOID AND TER.NUMID = O.NUMID AND TER.DVID = O.DVID AND TER.TIPOID = 'CNPJ' AND FP.TIPOID = TER.TIPOID AND FP.NUMID = TER.NUMID AND FP.DVID = TER.DVID AND EF.CODENTFINAN (+)= O.CODENTFINAN";
    log.dir(query)

    var ds = ic.lookup(dataSource + '/' + servico)

    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(query);
        var columnCount = rs.getMetaData().getColumnCount();
        var counter = 0;
        while (rs.next()) {

            var Arr = new Array();

            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));

                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }

            newDataset.addOrUpdateRow(Arr);
            counter++;
            if (counter > 10000) {
                log.info('parou por quantidade.......')
                break;
            }
        }
    } catch (e) {
        newDataset.addRow(new Array(e.message));
    } finally {
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
    }

    return newDataset;
}

function createDataset(fields, constraints, sortFields) {

}

function onMobileSync(user) {

}