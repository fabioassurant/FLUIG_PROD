function defineStructure() {
    addColumn("TIPO");
    addColumn("TIPOID");
    addColumn("CNPJ");
    addColumn("NOME");
    addColumn("STATUS");
    addColumn("ENDERECO");
    addColumn("CIDADE");
    addColumn("CEP");

    setKey(["CNPJ", "NOME"]);
    addIndex(["CNPJ"]);
    addIndex(["CNPJ", "NOME", "ENDERECO"]);
}
function onSync(lastSyncDate) {
    var gson = new com.google.gson.Gson();
    var newDataset = DatasetBuilder.newDataset();
    try {
		var cChaveAutent = encriptar();
		var cCodWorkflow = "F"
		
		var retornoLista = listaFornecedores(cChaveAutent, "", cCodWorkflow);
        var respRetornoListaJSON = JSON.parse(gson.toJson(retornoLista));
		if (retornoLista != "Erro") {
			for (var i = 0; i < respRetornoListaJSON.length; i++) {
                newDataset.addRow(
                    [
                        respRetornoListaJSON[i]['tipo'],
                        respRetornoListaJSON[i]['tipoid'],
                        respRetornoListaJSON[i]['numid'] + respRetornoListaJSON[i]['dvid'],
                        respRetornoListaJSON[i]['nome'],
                        respRetornoListaJSON[i]['status'],
                        respRetornoListaJSON[i]['endereco'],
                        respRetornoListaJSON[i]['cidade'],
                        respRetornoListaJSON[i]['cep']
                    ]
                )
			}
		} else {
			newDataset.addColumn("Erro");
			newDataset.addRow([respRetornoListaJSON]);
		}
		log.info("########## Retorno da Lista newDataset =====");
		log.dir(newDataset);

		return newDataset
	} catch (e) {
		log.info('ERROOOOR-----------@@@')
		log.dir(e)
		newDataset.addColumn("Erro");
		newDataset.addRow(e);
		return newDataset;
	}
}
function createDataset(fields, constraints, sortFields) {

}function onMobileSync(user) {

}


function listaFornecedores(cChaveAutent, cConsulta, cCodWorkflow) {
	
	var properties = {};
	properties["receive.timeout"] = "100000000";

	var supplierService = ServiceManager.getService('Acsel_8');
	var serviceHelper = supplierService.getBean();
	var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
	var service = serviceLocator.getServicosWebServicePort();
	var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
	
	try {
		var ListaFornecedoresList = customClient.listaFornecedores(cChaveAutent, cConsulta, cCodWorkflow);
		if (ListaFornecedoresList['retorno'] == 0 || ListaFornecedoresList['retorno'] == "0") {
			return ListaFornecedoresList['listaFornecedoresList']['fornecedores'];
		} else {
			var mensagemRetorno = 'Erro';
			return mensagemRetorno;
		}
	} catch (e) {
		throw e.toString();
	}

}

function encriptar() {
	var token = DatasetFactory.getDataset("ds_getToken", null, null, null);
	if (token.rowsCount > 0) {
		if (token.getValue(0, "token") != undefined) {
			return token.getValue(0, "token");
		}
	}
	return "";
}