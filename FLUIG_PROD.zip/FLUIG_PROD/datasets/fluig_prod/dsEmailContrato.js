function defineStructure() {
    addColumn("email")
    addColumn("envio")
}

function onSync(lastSyncDate) {

}

function createDataset(fields, constraints, sortFields) {
    log.info("----------------Entrou no Dataset-----------------")
    var dataset = DatasetBuilder.newDataset()

    var hoje = new Date()
    var hojeString = hoje.toDateString()
    var destinatarios = new java.util.ArrayList()
    var parametros = new java.util.HashMap()
    var dsColleague = DatasetFactory.getDataset("colleague", null, null, null)
    var c1 = DatasetFactory.createConstraint("metadata#active", true, true, ConstraintType.MUST)
    var dsContrato = DatasetFactory.getDataset("ds_processo_contrato_v2", null, new Array(c1), null)
    var colleagueGroup = DatasetFactory.getDataset("colleagueGroup", null, null, null)


    for (var i = 0; i < dsContrato.rowsCount; i++) {

        var dataVencimento = dsContrato.getValue(i, "dataNotificacaoSolicitante")
        var tituloContrato = dsContrato.getValue(i, "tituloContrato")
        var solicitante = dsContrato.getValue(i, "solicitante")
        var NumProcesso = dsContrato.getValue(i, "WKNumProces")
        var NumAtividade = dsContrato.getValue(i, "WKNumState")
        var linkSolicita = "https://fluig.assurant.com/portal/p/ASSURANT/pageworkflowview?app_ecm_workflowview_detailsProcessInstanceID=" + NumProcesso
        var d1 = new Date(dataVencimento);
        var dataString = d1.toDateString()




        if (hojeString == dataString && NumAtividade != "28") {
            parametros.put("subject", "Contrato a Vencer")
            parametros.put("tituloContrato", tituloContrato)
            parametros.put("numSolicitacao", linkSolicita)


            for (var j = 0; j < dsColleague.rowsCount; j++) {
                var colleagueId = dsColleague.getValue(j, ["colleaguePK.colleagueId"])
                var email = dsColleague.getValue(j, "mail")

                if (solicitante == colleagueId) {
                    destinatarios.add(email)
                }

                for (var k = 0; k < colleagueGroup.rowsCount; k++) {
                    var groupId = colleagueGroup.getValue(k, ["colleagueGroupPK.groupId"])
                    var userGroupId = colleagueGroup.getValue(k, ["colleagueGroupPK.colleagueId"])

                    if (groupId == "ADMINISTRATIVO" || groupId == "JURÍDICO") {
                        if (colleagueId == userGroupId) {
                            destinatarios.add(email)
                        }
                    }
                }
            }

            log.info('ds_email - DESTINATARIO @@@@@')
            log.dir(destinatarios)

            log.info('ds_email - Parametros @@@@@')
            log.dir(parametros)
            notifier.notify("admin", "templateNotificaAviso", parametros, destinatarios, "text/html");

        }

    }

    return dataset
}