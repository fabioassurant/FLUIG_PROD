function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
    log.info('### DATASET SET SAFX09 ###');

    var newDataset = DatasetBuilder.newDataset();
    var dataSource = '/jdbc/MASTERSAF_DW_CONECT';
    var ic = new javax.naming.InitialContext();
    var ds = ic.lookup(dataSource);
    var colums = '', values = '';

    if(fields){
        for(var i = 0; i < fields.length; i++){
            var objParams = JSON.parse(fields[i]);
            var keys = Object.keys(objParams);
            var value;
            var column = keys[0];
            
            if(objParams[keys[1]] == 'string'){
                value = "'" + objParams[keys[0]] + "'";
    
            }else if(objParams[keys[1]] == 'number'){
                value = objParams[keys[0]];
    
            }
    
            values += i == (fields.length - 1) ? value : value + ', ';
            colums += i == (fields.length - 1) ? column : column + ', '
    
        }
    }
    if(objParams && colums && values){
        var insertQuery = "INSERT INTO SAFX09 (" + colums + ") VALUES (" + values + ") ";
        log.info('## QUERY = ' + insertQuery);
    
        try{
            var conn = ds.getConnection();
            var stmt = conn.createStatement();
            var rs = stmt.executeUpdate(insertQuery);

            log.info('## RETORNO INSERT = ' + rs.toString())
            var lines = rs.toString();

            if(lines > 0){
                newDataset.addColumn('Status');
                newDataset.addColumn('Table');
                newDataset.addColumn('Response');
                newDataset.addRow(['Sucess', 'SAFX09', 'Insert realizado com sucesso!']);

            }else{
                newDataset.addColumn('Status');
                newDataset.addColumn('Table');
                newDataset.addColumn('Response');
                newDataset.addRow(['Error', 'SAFX09', 'Ocorreu um erro no insert!']);
            }

        }catch (error){
            newDataset.addColumn('Status');
            newDataset.addColumn('Response');
            newDataset.addColumn('Insert Query');
            newDataset.addRow(['Erro', error, insertQuery]);
    
        }finally{
           if(conn != null){
               conn.close();
           }
        }

    }else{
        newDataset.addColumn('Response');
        newDataset.addColumn('Status');
        newDataset.addRow(['É necessário passar os parametros', 'Erro']);
    }

    return newDataset;

}function onMobileSync(user) {

}