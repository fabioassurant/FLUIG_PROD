function defineStructure() {

}

function onSync(lastSyncDate) {

}

function createDataset(fields, constraints, sortFields) {

    var dataset = DatasetBuilder.newDataset();
    var retorno = "";

    try {

        var chave = "AssurantBrasil";
        if (chave.trim().length == 0) return dataset;

        let data = new Date();
        let ano = data.getFullYear();
        let mes = data.getMonth() + 1;
        let dia = data.getDate();

        let strBase = chave + ano + mes + dia;

        let strMapa = ' ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÃÕÑÂÊÎÔÛÄËÏÖÜÀÈÌÒÙabcdefghijklmnopqrstuvwxyz0123456789áéíóúãõñâêîôûäëïöüàèìòùÇç/';
        let strEncripto = '89áéíxyz01ìòùÇç67óúãÒÙabcvw23lmJKLM ABCD45õñâpqrstuêîÜÀÈÌôûäëïöüÃÕÑàèÏÖdeÉÍÔÛÄYZÁÓÚÂfgOPQ/XÊÎËINSTVWhijkGHUnEFoR';

        let caracter = '';
        let posicao;
        log.info('Parte 2');
        for (let indice = 0; indice < strBase.length; indice++) {
            posicao = strMapa.search(strBase[indice])

            if (posicao == -1) {
                caracter = strBase[indice]
            } else {
                caracter = strEncripto[posicao]
            }

            retorno = retorno + charParaAsc(caracter, dia)
        }

        dataset.addColumn("token");
        dataset.addRow([retorno]);

    } catch (e) {
        dataset.addColumn("erro");
        dataset.addRow([e.message]);

        log.info('Erro --- -- -- - -- -- -- - --')
        log.dir(e)
    }
    return dataset;

}

function onMobileSync(user) {

}

//FUNCAO DE APOIO A "encriptar"
function charParaAsc(caracter, incremento) {
    return caracter.charCodeAt(0) + incremento
}