function createDataset(fields, constraints, sortFields) {
    var ds = DatasetBuilder.newDataset();
    try {
        var cpfCnpj = '';
        if (constraints) {
            for (var i = 0; i < constraints.length; i++) {
                if (constraints[i].fieldName == "cpfCnpj") {
                    cpfCnpj = constraints[i].initialValue;
                }
            }
        }
        var constraintDsPO = DatasetFactory.createConstraint("cpfCnpj", cpfCnpj, cpfCnpj, ConstraintType.MUST);
        var constraintDsPO2 = DatasetFactory.createConstraint('responsavelFinanceiro', '', '', ConstraintType.MUST_NOT);
        var colunas = [
            "metadata#id",
            "cpfCnpj",
            "saldo",
            "valorPO",
            "grupoContaContabil",
            "contaContabil",
            "centCusSolic",
            "cenCustResp",
            "idCenCusResp",
            "idCenCusSolic",
            "aprovOutroGrupo",
            "selGrupo"
        ];
        var datasetPO = DatasetFactory.getDataset("ds_processo_po_assurant", colunas, [constraintDsPO, constraintDsPO2], null);
        var arrSolicitacao = [];
        ds.addColumn("solicitacao");
        ds.addColumn("document");
        ds.addColumn("cpfCnpj");
        ds.addColumn("saldo");
        ds.addColumn("valor");
        ds.addColumn("grupoContaContabil");
        ds.addColumn("contaContabil");
        ds.addColumn("idCentroCustoSolicitante");
        ds.addColumn("centroCustoSolicitante");
        ds.addColumn("idCentroCustoResponsavel");
        ds.addColumn("centroCustoResponsavel");

        for (var i = 0; i < datasetPO.rowsCount; i++) {
            var metadata = datasetPO.getValue(i, "metadata#id");
            var constraintDsWP = DatasetFactory.createConstraint("cardDocumentId", metadata, metadata, ConstraintType.MUST);
            var constraintDsWP2 = DatasetFactory.createConstraint("status", 2, 2, ConstraintType.MUST);
            var colunasWP = ["workflowProcessPK.processInstanceId", "cardDocumentId", "status"];
            var datasetWP = DatasetFactory.getDataset("workflowProcess", colunasWP, [constraintDsWP, constraintDsWP2], null);
            if (datasetWP.rowsCount > 0) {
                ds.addRow([
                    datasetWP.getValue(0, "workflowProcessPK.processInstanceId"),
                    datasetWP.getValue(0, "cardDocumentId"),
                    datasetPO.getValue(i, "cpfCnpj"),
                    datasetPO.getValue(i, "saldo"),
                    datasetPO.getValue(i, "valorPO"),
                    datasetPO.getValue(i, "grupoContaContabil"),
                    datasetPO.getValue(i, "contaContabil"),
                    datasetPO.getValue(i, "idCenCusSolic"),
                    datasetPO.getValue(i, "centCusSolic"),
                    datasetPO.getValue(i, "idCenCusResp"),
                    datasetPO.getValue(i, "cenCustResp")
                ])
            }
        }
    } catch (e) {
        log.info("###### error ds po inclusao #####");
        log.dir(e.message);
    }
    return ds;
}