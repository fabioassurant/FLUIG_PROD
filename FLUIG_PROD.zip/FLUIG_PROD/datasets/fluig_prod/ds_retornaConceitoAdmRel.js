function createDataset(fields, constraints, sortFields) {
    var ds = DatasetBuilder.newDataset();
    ds.addColumn('codConceito');
    ds.addColumn('descConceito');
    ds.addColumn('grupo');
    try {
        var datasetAdm = DatasetFactory.getDataset('ds_retornaConceito', null, null, null);

        var datasetRel = DatasetFactory.getDataset('ds_retorna_conceito_rel', null, null, null);
        for (var i = 0; i < datasetAdm.rowsCount; i++) {
            ds.addRow([
                datasetAdm.getValue(i, 'codConceito'),
                datasetAdm.getValue(i, 'descConceito'),
                'DSPADM'

            ])
        }

        for (var j = 0; j < datasetRel.rowsCount; j++) {
            ds.addRow([
                datasetRel.getValue(j, 'codConceito'),
                datasetRel.getValue(j, 'descConceito'),
                'DSPREL'
            ])
        }

        // for(var i = 0; i < datasetAdm.rowsCount; i++){
        // 	aux.push(datasetAdm.getRow(i));
        // }
    } catch (e) {
        log.info('ERRO ==================> ' + e.message);
    }
    return ds;
}