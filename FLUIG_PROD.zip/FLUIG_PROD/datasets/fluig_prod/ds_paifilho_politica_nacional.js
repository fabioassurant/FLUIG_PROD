function createDataset(fields, constraints, sortFields) {
	var dataset = DatasetBuilder.newDataset();
    dataset.addColumn("NumProcesso");
    dataset.addColumn("NumFormulario");
    dataset.addColumn("acsel");
    dataset.addColumn("despesa");
    dataset.addColumn("valorMaximo");
    dataset.addColumn("distancia");
    dataset.addColumn("taxa");

    
    var constraints = new Array();
    constraints.push(DatasetFactory.createConstraint("metadata#active", true, true, ConstraintType.MUST));

    var datasetPrincipal = DatasetFactory.getDataset("ds_cadastro_politica_nacional", null, constraints, null);
    
    for (var i = 0; i < datasetPrincipal.rowsCount; i++) {
        var WKNumProces     = datasetPrincipal.getValue(i, "WKNumProces");
        var documentId      = datasetPrincipal.getValue(i, "metadata#id");
        var documentVersion = datasetPrincipal.getValue(i, "metadata#version");

        var constraintsFilhos = new Array();
        constraintsFilhos.push(DatasetFactory.createConstraint("tablename", "tableCadastroPoliticaNacional" ,"tableCadastroPoliticaNacional", ConstraintType.MUST));
        constraintsFilhos.push(DatasetFactory.createConstraint("metadata#id", documentId, documentId, ConstraintType.MUST));
        constraintsFilhos.push(DatasetFactory.createConstraint("metadata#version", documentVersion, documentVersion, ConstraintType.MUST));

        var datasetFilhos = DatasetFactory.getDataset("ds_cadastro_politica_nacional", null, constraintsFilhos, null);

        for (var j = 0; j < datasetFilhos.rowsCount; j++) {
            dataset.addRow(new Array(
                    WKNumProces,
                    documentId,
                    datasetFilhos.getValue(j, "acsel"),
                    datasetFilhos.getValue(j, "despesa"),
                    datasetFilhos.getValue(j, "valorMaximo"),
                    datasetFilhos.getValue(j, "distancia"),
                    datasetFilhos.getValue(j, "taxa")));
        }
    }

    return dataset;

}