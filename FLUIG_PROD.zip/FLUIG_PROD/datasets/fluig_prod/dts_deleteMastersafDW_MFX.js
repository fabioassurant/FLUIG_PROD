function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
    log.info('### DATASET DELETE SAFX04 ###');
    
    var newDataset = DatasetBuilder.newDataset();
    var dataSource = '/jdbc/MASTERSAF_DW_CONECT';
    var ic = new javax.naming.InitialContext();
    var ds = ic.lookup(dataSource);

    if(fields){
        var id = fields[0];
        if(id){
            var deleteQuery = "BEGIN "+
                                "DELETE FROM SAFX04 WHERE CPF_CGC = '" + id + "'; "+
                                "DELETE FROM SAFX07 WHERE COD_FIS_JUR = '" + id + "'; "+
                                "DELETE FROM SAFX09 WHERE COD_FIS_JUR = '" + id + "'; "+
                                "COMMIT; "+
                              "END; "
                          
            log.info('## QUERY = ' + deleteQuery);

            try{
                var conn = ds.getConnection();
                var stmt = conn.createStatement();
                var rs = stmt.executeUpdate(deleteQuery);

                log.info('## RETORNO DELETE = ' + rs.toString())
                var lines = rs.toString();

                if(lines == 3){
                    newDataset.addColumn('Status');
                    newDataset.addColumn('Response');
                    newDataset.addRow(['Sucess', 'Deletes realizado com sucesso!']);

                }else{
                    newDataset.addColumn('Status');
                    newDataset.addColumn('Response');
                    newDataset.addRow(['Error', 'Ocorreu um erro no deletes!']);
                }


            }catch (error){
                newDataset.addColumn('Status');
                newDataset.addColumn('Response');
                newDataset.addColumn('Insert Query');
                newDataset.addRow(['Erro', error, deleteQuery]);
            
            }finally{
               if(stmt != null){
                   stmt.close();
               }

               if(conn != null){
                   conn.close();
               }
            }
        }
    }else{
        newDataset.addColumn('Response');
        newDataset.addColumn('Status');
        newDataset.addRow(['É necessário passar os parametros', 'Erro']);
    }

    return newDataset;

}function onMobileSync(user) {

}