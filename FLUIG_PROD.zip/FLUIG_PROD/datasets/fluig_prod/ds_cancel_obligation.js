function createDataset(fields, constraints, sortFields) {
    var dsCancelOblig = DatasetBuilder.newDataset();
    var numOblig = 0;
    log.dir(constraints);
    if (constraints) {
        for (var i = 0; i < constraints.length; i++) {
            if (constraints[i].fieldName == "obligation") {
                numOblig = constraints[i].initialValue;
            }
        }
    } else {
        dsCancelOblig.addColumn("Erro");
        dsCancelOblig.addRow(["É necessário informar o número da obrigação para o campo 'obligation'"])
        return dsCancelOblig;
    }
    try {

        var ic = new javax.naming.InitialContext()
        var dataSource = 'jdbc/';
        var servico = 'Conector_Acsel';

        var query = "begin pr_obligacion.anular(" + numOblig + "); end;";

        var ds = ic.lookup(dataSource + '/' + servico)
        var conn = ds.getConnection();
        var stmt = conn.prepareCall(query);
        var rs = stmt.execute();

        dsCancelOblig.addColumn("Sucesso");
        dsCancelOblig.addRow(["Obrigação Cancelada"]);

    } catch (e) {
        dsCancelOblig.addColumn("erro");
        dsCancelOblig.addRow([e.message]);
    }
    return dsCancelOblig;
}