function createDataset(fields, constraints, sortFields) {
	try {
		return processResult(callService(fields, constraints, sortFields));
	} catch(e) {
		return processErrorResult(e, constraints);
	}
}

function callService(fields, constraints, sortFields) {
	var serviceData = data();
	var params = serviceData.inputValues;
	var assigns = serviceData.inputAssignments;

	verifyConstraints(serviceData.inputValues, constraints);

	var serviceHelper = ServiceManager.getService(serviceData.fluigService);
	var serviceLocator = serviceHelper.instantiate(serviceData.locatorClass);
	var service = serviceLocator.getServicosWebServicePort();
	var response = service.validaCodigoBarras(getParamValue(params.cChaveAutent, assigns.cChaveAutent), getParamValue(params.nNumOblig, assigns.nNumOblig), 
		getParamValue(params.cIdSolicitacao, assigns.cIdSolicitacao), getParamValue(params.cNumDoctoBanco, assigns.cNumDoctoBanco), 
		getParamValue(params.cLinhaDigit, assigns.cLinhaDigit), getParamValue(params.cTipoPago, assigns.cTipoPago), 
		getParamValue(params.cDataVencimento, assigns.cDataVencimento), getParamValue(params.nValorObrigacao, assigns.nValorObrigacao), 
		getParamValue(params.cCodUsr, assigns.cCodUsr), getParamValue(params.cCodWorkFlow, assigns.cCodWorkFlow)
		);

	return response;
}

function defineStructure() {
		addColumn("cODBARRAS");
}

function onSync(lastSyncDate) {
	var serviceData = data();
	var synchronizedDataset = DatasetBuilder.newDataset();

	try {
		var resultDataset = processResult(callService());
		if (resultDataset != null) {
			var values = resultDataset.getValues();
			for (var i = 0; i < values.length; i++) {
				synchronizedDataset.addRow(values[i]);
			}
		}

	} catch(e) {
		log.info('Dataset synchronization error : ' + e.message);

	}
	return synchronizedDataset;
}

function verifyConstraints(params, constraints) {

	if (constraints != null) {
		for (var i = 0; i < constraints.length; i++) {
			try {
				params[constraints[i].fieldName] = constraints[i].initialValue;
			} catch(e) {
				params[constraints[i].fieldName] = constraints[i].initialValue;
			}
		}
	}
}

function processResult(result) {
	var dataset = DatasetBuilder.newDataset();

		dataset.addColumn("CODBARRAS");
		dataset.addColumn("RETORNO");
		dataset.addColumn("DESCRICAO");

	dataset.addRow([result['codbarras'], result['retorno'], result['descricaoErro']]);

	log.info('Retorno do valida codigo barras result');
	log.dir(result);

	return dataset;
}

function processErrorResult(error, constraints) {
	var dataset = DatasetBuilder.newDataset();

	var params = data().inputValues;
verifyConstraints(params, constraints);

dataset.addColumn('error');
	dataset.addColumn('cChaveAutent');
	dataset.addColumn('cIdSolicitacao');
	dataset.addColumn('cCodUsr');
	dataset.addColumn('cTipoPago');
	dataset.addColumn('cLinhaDigit');
	dataset.addColumn('nNumOblig');
	dataset.addColumn('cNumDoctoBanco');
	dataset.addColumn('cDataVencimento');
	dataset.addColumn('nValorObrigacao');
	dataset.addColumn('cCodWorkFlow');

	var cChaveAutent = isPrimitive(params.cChaveAutent) ? params.cChaveAutent : JSONUtil.toJSON(params.cChaveAutent);
	var cIdSolicitacao = isPrimitive(params.cIdSolicitacao) ? params.cIdSolicitacao : JSONUtil.toJSON(params.cIdSolicitacao);
	var cCodUsr = isPrimitive(params.cCodUsr) ? params.cCodUsr : JSONUtil.toJSON(params.cCodUsr);
	var cTipoPago = isPrimitive(params.cTipoPago) ? params.cTipoPago : JSONUtil.toJSON(params.cTipoPago);
	var cLinhaDigit = isPrimitive(params.cLinhaDigit) ? params.cLinhaDigit : JSONUtil.toJSON(params.cLinhaDigit);
	var nNumOblig = isPrimitive(params.nNumOblig) ? params.nNumOblig : JSONUtil.toJSON(params.nNumOblig);
	var cNumDoctoBanco = isPrimitive(params.cNumDoctoBanco) ? params.cNumDoctoBanco : JSONUtil.toJSON(params.cNumDoctoBanco);
	var cDataVencimento = isPrimitive(params.cDataVencimento) ? params.cDataVencimento : JSONUtil.toJSON(params.cDataVencimento);
	var nValorObrigacao = isPrimitive(params.nValorObrigacao) ? params.nValorObrigacao : JSONUtil.toJSON(params.nValorObrigacao);
	var cCodWorkFlow = isPrimitive(params.cCodWorkFlow) ? params.cCodWorkFlow : JSONUtil.toJSON(params.cCodWorkFlow);

	dataset.addRow([error.message, cChaveAutent, cIdSolicitacao, cCodUsr, cTipoPago, cLinhaDigit, nNumOblig, cNumDoctoBanco, cDataVencimento, nValorObrigacao, cCodWorkFlow]);

	return dataset;
}

function getParamValue(param, assignment) {
	if (assignment == 'VARIABLE') {
		return getValue(param);
	} else if (assignment == 'NULL') {
		return null;
	}
	return param;
}

function hasValue(value) {
	return value !== null && value !== undefined;
}

function isPrimitive(value) {
	return ((typeof value === 'string') || value.substring !== undefined) || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined';
}


function getObjectFactory(serviceHelper) {
	var objectFactory = serviceHelper.instantiate("com.assurant.servicoswebservice.ObjectFactory");

	return objectFactory;
}



function data() {
	return {
  "fluigService" : "Acsel_4",
  "operation" : "validaCodigoBarras",
  "soapService" : "AizServicosWebBeanService",
  "portType" : "ServicosWebService",
  "locatorClass" : "com.assurant.servicoswebservice.AizServicosWebBeanService",
  "portTypeMethod" : "getServicosWebServicePort",
  "parameters" : [ ],
  "inputValues" : {
    "cChaveAutent" : encriptar(),
    "cIdSolicitacao" : "",
    "cCodUsr" : "",
    "cTipoPago" : "",
    "cLinhaDigit" : "",
    "nNumOblig" : "",
    "cNumDoctoBanco" : "",
    "cDataVencimento" : "",
    "nValorObrigacao" : "",
    "cCodWorkFlow" : "F"
  },
  "inputAssignments" : {
    "cChaveAutent" : "",
    "cIdSolicitacao" : "",
    "cCodUsr" : "",
    "cTipoPago" : "",
    "cLinhaDigit" : "",
    "nNumOblig" : "",
    "cNumDoctoBanco" : "",
    "cDataVencimento" : "",
    "nValorObrigacao" : "",
    "cCodWorkFlow" : ""
  },
  "outputValues" : { },
  "outputAssignments" : { },
  "extraParams" : {
    "enabled" : false
  }
}
}

 function stringToBoolean(param) {
	 if(typeof(param) === 'boolean') { 
		 return param; 
	 } 
	 if (param == null || param === 'null') { 
		 return false; 
	 } 
	 switch(param.toLowerCase().trim()) { 
		 case 'true': case 'yes': case '1': return true; 
		 case 'false': case 'no': case '0': case null: return false; 
		 default: return Boolean(param); 
	 } 
} 


function encriptar() {

    var token = DatasetFactory.getDataset("ds_getToken", null, null, null);

    if (token.rowsCount > 0) {
        if (token.getValue(0, "token") != undefined) {
            return token.getValue(0, "token");
        }
    }

    return "";
}