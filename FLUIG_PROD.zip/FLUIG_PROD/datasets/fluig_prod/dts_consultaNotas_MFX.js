function defineStructure() {}
function onSync(lastSyncDate) {}
function onMobileSync(user) {}

function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();
    var dataSource = "jdbc/FluigDS";
    var ic = new javax.naming.InitialContext();
    var ds = ic.lookup(dataSource)
    var created = false;

    var cQryFrom, cQryWhr, cQryGrp, cQryOrd, cQryCpo = 
    " SELECT " +
    " COALESCE(documentid, 0) AS  ID_DOC,  " +
    " num_processo AS NUM_PROCESS, " +
    " CASE WHEN nomeFornecedorHidden IS NOT NULL THEN nomeFornecedorHidden WHEN fornecedor IS NOT NULL THEN fornecedor ELSE fornecedorHidden END AS NOME_FORNECEDOR, " +
    " fornecedorHidden AS CNPJ_FORNECEDOR," +
    " CASE " +
        " WHEN  tipoAcerto = 'adiantamento' THEN 'Adiantamento' " + 
        " WHEN  tipoAcerto = 'despesaNF' THEN 'Despesas NF' " + 
        " WHEN  tipoAcerto = 'RH' THEN 'RH' " + 
        " WHEN  tipoAcerto = 'ovidoria' THEN 'Ouvidoria' " + 
        " WHEN  tipoAcerto = 'comissao' THEN 'Comissão' " + 
        " WHEN  tipoAcerto = 'imposto' THEN 'Imposto' " + 
        " WHEN  tipoAcerto = 'presConta' THEN 'Prestação de contas' " + 
        " WHEN  tipoAcerto = 'cosseguro' THEN 'Cosseguro' " + 
        " WHEN  tipoAcerto = 'devolucao_franquia' THEN 'Devolução de franquia' " + 
        " WHEN  tipoAcerto = 'despesa_apolice' THEN 'Despesa de ápolice' " + 
    " ELSE '---' END AS TIPO_ACERTO, " +
    " dataAbertura AS DT_ABERTURA, " +
    " stateAtual AS ATIVIDADE, " +
    " CASE " +
        " WHEN numeroNF IS NOT NULL THEN numeroNF " +
        " WHEN  tipoAcerto = 'adiantamento' THEN numeroNF1 " + 
        " WHEN  tipoAcerto = 'despesaNF' THEN numeroNF2 " + 
        " WHEN  tipoAcerto = 'RH' THEN numeroNF3 " + 
        " WHEN  tipoAcerto = 'ovidoria' THEN numeroNF4 " + 
        " WHEN  tipoAcerto = 'comissao' THEN numeroNF5 " + 
        " WHEN  tipoAcerto = 'imposto' THEN numeroNF6 " + 
        " WHEN  tipoAcerto = 'presConta' THEN numeroNF7 " + 
        " WHEN  tipoAcerto = 'cosseguro' THEN numeroNF8 " + 
        " WHEN  tipoAcerto = 'devolucao_franquia' THEN numeroNF9 " + 
        " WHEN  tipoAcerto = 'despesa_apolice' THEN numeroNF10 " + 
    " ELSE '---' END AS NOTA_FISCAL, " +
    
    " CASE " +
        " WHEN h_dataVencimento IS NOT NULL      THEN h_dataVencimento " +
        " WHEN dataVencimento IS NOT NULL        THEN SUBSTR(dataVencimento, 9, 2) || '/' || SUBSTR(dataVencimento, 6, 2) || '/' || SUBSTR(dataVencimento, 0, 4) " +
        " WHEN tipoAcerto = 'adiantamento'       THEN SUBSTR(dataVencimento_1, 9, 2) || '/' || SUBSTR(dataVencimento_1, 6, 2) || '/' || SUBSTR(dataVencimento_1, 0, 4) " + 
        " WHEN tipoAcerto = 'despesaNF'          THEN SUBSTR(dataVencimento_2, 9, 2) || '/' || SUBSTR(dataVencimento_2, 6, 2) || '/' || SUBSTR(dataVencimento_2, 0, 4) " + 
        " WHEN tipoAcerto = 'RH'                 THEN SUBSTR(dataVencimento_3, 9, 2) || '/' || SUBSTR(dataVencimento_3, 6, 2) || '/' || SUBSTR(dataVencimento_3, 0, 4) " + 
        " WHEN tipoAcerto = 'ovidoria'           THEN SUBSTR(dataVencimento_4, 9, 2) || '/' || SUBSTR(dataVencimento_4, 6, 2) || '/' || SUBSTR(dataVencimento_4, 0, 4) " + 
        " WHEN tipoAcerto = 'comissao'           THEN SUBSTR(dataVencimento_5, 9, 2) || '/' || SUBSTR(dataVencimento_5, 6, 2) || '/' || SUBSTR(dataVencimento_5, 0, 4) " + 
        " WHEN tipoAcerto = 'imposto'            THEN SUBSTR(dataVencimento_6, 9, 2) || '/' || SUBSTR(dataVencimento_6, 6, 2) || '/' || SUBSTR(dataVencimento_6, 0, 4) " + 
        " WHEN tipoAcerto = 'presConta'          THEN SUBSTR(dataVencimento_7, 9, 2) || '/' || SUBSTR(dataVencimento_7, 6, 2) || '/' || SUBSTR(dataVencimento_7, 0, 4) " + 
        " WHEN tipoAcerto = 'cosseguro'          THEN SUBSTR(dataVencimento_8, 9, 2) || '/' || SUBSTR(dataVencimento_8, 6, 2) || '/' || SUBSTR(dataVencimento_8, 0, 4) " + 
        " WHEN tipoAcerto = 'devolucao_franquia' THEN SUBSTR(dataVencimento_9, 9, 2) || '/' || SUBSTR(dataVencimento_9, 6, 2) || '/' || SUBSTR(dataVencimento_9, 0, 4) " + 
        " WHEN tipoAcerto = 'despesa_apolice'    THEN SUBSTR(dataVencimento_10, 9, 2) || '/' || SUBSTR(dataVencimento_10, 6, 2) || '/' || SUBSTR(dataVencimento_10, 0, 4) " +
        " ELSE '---' END AS DT_VENC, " +
    
    " COALESCE(CASE " +
        " WHEN h_dataVencimento IS NOT NULL      THEN SUBSTR(h_dataVencimento, 7, 4) || SUBSTR(h_dataVencimento, 4, 2 ) || SUBSTR(h_dataVencimento, 0, 2) " +
        " WHEN dataVencimento IS NOT NULL        THEN SUBSTR(dataVencimento, 0, 4) || SUBSTR(dataVencimento, 6, 2 ) || SUBSTR(dataVencimento, 9, 2) " +
        " WHEN tipoAcerto = 'adiantamento'       THEN SUBSTR(dataVencimento_1, 0, 4) || SUBSTR(dataVencimento_1, 6, 2) || SUBSTR(dataVencimento_1, 9, 2)  " + 
        " WHEN tipoAcerto = 'despesaNF'          THEN SUBSTR(dataVencimento_2, 0, 4) || SUBSTR(dataVencimento_2, 6, 2) || SUBSTR(dataVencimento_2, 9, 2) " + 
        " WHEN tipoAcerto = 'RH'                 THEN SUBSTR(dataVencimento_3, 0, 4) || SUBSTR(dataVencimento_3, 6, 2) || SUBSTR(dataVencimento_3, 9, 2) " + 
        " WHEN tipoAcerto = 'ovidoria'           THEN SUBSTR(dataVencimento_4, 0, 4) || SUBSTR(dataVencimento_4, 6, 2) || SUBSTR(dataVencimento_4, 9, 2)  " + 
        " WHEN tipoAcerto = 'comissao'           THEN SUBSTR(dataVencimento_5, 0, 4) || SUBSTR(dataVencimento_5, 6, 2) || SUBSTR(dataVencimento_5, 9, 2) " + 
        " WHEN tipoAcerto = 'imposto'            THEN SUBSTR(dataVencimento_6, 0, 4) || SUBSTR(dataVencimento_6, 6, 2) || SUBSTR(dataVencimento_6, 9, 2) " + 
        " WHEN tipoAcerto = 'presConta'          THEN SUBSTR(dataVencimento_7, 0, 4) || SUBSTR(dataVencimento_7, 6, 2) || SUBSTR(dataVencimento_7, 9, 2) " + 
        " WHEN tipoAcerto = 'cosseguro'          THEN SUBSTR(dataVencimento_8, 0, 4) || SUBSTR(dataVencimento_8, 6, 2) || SUBSTR(dataVencimento_8, 9, 2) " + 
        " WHEN tipoAcerto = 'devolucao_franquia' THEN SUBSTR(dataVencimento_9, 0, 4) || SUBSTR(dataVencimento_9, 6, 2) || SUBSTR(dataVencimento_9, 9, 2) " + 
        " WHEN tipoAcerto = 'despesa_apolice'    THEN SUBSTR(dataVencimento_10, 0, 4) || SUBSTR(dataVencimento_10, 6, 2) || SUBSTR(dataVencimento_10, 9, 2) " +
        " ELSE '0' END , '0') AS teste, " +
        
        " CASE " +
        /*" WHEN valorTotal IS NOT NULL THEN valorTotal " +*/
        " WHEN valor IS NOT NULL THEN valor " +
        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
        " ELSE '---' END AS VALOR_NOTA, " +
        
    /*" valorTotal AS VALOR_NOTA, " +*/
    " CASE " +
        " WHEN  NUM_SEQ_ESTADO IN (21, 31, 49, 46, 92, 65, 69, 117, 121, 27) THEN 'Nota em análise' " + 
        " WHEN  NUM_SEQ_ESTADO IN (0, 4, 15, 18) THEN 'Nota enviada' " + 
        " WHEN  NUM_SEQ_ESTADO IN (38) THEN 'Pagamento programado' " + 
        " WHEN  NUM_SEQ_ESTADO IN (35) THEN 'Pagamento efetuado' " + 
        " WHEN  NUM_SEQ_ESTADO IN (99, 100) THEN 'Pedido em revisão' " + 
    " ELSE '---' END AS STATUS, NUM_SEQ_ESTADO ";
    
    cQryFrom = " FROM ML001042 notas INNER JOIN PROCES_WORKFLOW pw ON notas.documentid = pw.NR_DOCUMENTO_CARD INNER JOIN HISTOR_PROCES HP ON HP.NUM_PROCES = num_processo AND HP.NUM_SEQ_MOVTO = (SELECT MAX(NUM_SEQ_MOVTO) FROM HISTOR_PROCES WHERE NUM_PROCES = HP.NUM_PROCES) ";

    cQryWhr = " WHERE notas.version = (SELECT MAX(version) FROM ML001042 notasb WHERE notas.documentid = notasb.documentid) AND fornecedorHidden IS NOT NULL AND num_processo <> '0' AND NUM_SEQ_ESTADO NOT IN (26, 57, 106, 43, 30) ";
    cQryGrp = "";
    cQryOrd = " ORDER BY CAST(num_processo AS DECIMAL) DESC ";

    if(constraints != null && constraints.length){
        for(var c=0; c < constraints.length; c++){
            if(constraints[c].fieldName.toUpperCase() != 'SQLLIMIT'){

                if(constraints[c].fieldName.toUpperCase() == 'CANO'){
                    var ano = constraints[c].initialValue.trim();

                    cQryCpo = " SELECT DISTINCT SUBSTR(dataAbertura, 4, 2) AS MES_ABERTURA, COUNT(documentid) AS TOTAL ";
                    cQryGrp = " GROUP BY SUBSTR(dataAbertura, 4, 2) ";
                    cQryWhr +=" AND dataAbertura LIKE '%/" + ano + "' ";
                    cQryOrd = " ORDER BY SUBSTR(dataAbertura, 4, 2) ASC";
                }

                if(constraints[c].fieldName.toUpperCase() == 'C_COM_DESP'){
                    var status = constraints[c].initialValue.trim();

                    if(status == 'COM'){
                        cQryWhr += " AND tipoAcerto = 'comissao' ";
                    }
                    if(status == 'DESP'){
                        cQryWhr += " AND tipoAcerto NOT IN ('comissao') ";
                    }
                }

                if(constraints[c].fieldName.toUpperCase() == 'CFORNECEDOR'){
                    var fornecedor = constraints[c].initialValue.trim();
                    cQryWhr += " AND fornecedorHidden = '" + fornecedor + "' ";
                }

                if(constraints[c].fieldName.toUpperCase() == 'CRESP'){
                    var responsaveis = constraints[c].initialValue.trim();
                    cQryWhr += " AND hd_cod_grupoAdm = 'Pool:Group:" + responsaveis + "'";
                }

                if(constraints[c].fieldName.toUpperCase() == 'CDTVENC'){
                    var dtVenc = constraints[c].initialValue.trim();
                    /*cQryWhr += " AND CASE WHEN h_dataVencimento IS NULL THEN '---' ELSE h_dataVencimento END = '" + dtVenc + "'";*/
                    cQryWhr += " AND CASE " +
                    " WHEN h_dataVencimento IS NOT NULL      THEN h_dataVencimento " +
                    " WHEN dataVencimento IS NOT NULL        THEN SUBSTR(dataVencimento, 9, 2) || '/' || SUBSTR(dataVencimento, 6, 2) || '/' || SUBSTR(dataVencimento, 0, 4) " +
                    " WHEN tipoAcerto = 'adiantamento'       THEN SUBSTR(dataVencimento_1, 9, 2) || '/' || SUBSTR(dataVencimento_1, 6, 2) || '/' || SUBSTR(dataVencimento_1, 0, 4) " + 
                    " WHEN tipoAcerto = 'despesaNF'          THEN SUBSTR(dataVencimento_2, 9, 2) || '/' || SUBSTR(dataVencimento_2, 6, 2) || '/' || SUBSTR(dataVencimento_2, 0, 4) " + 
                    " WHEN tipoAcerto = 'RH'                 THEN SUBSTR(dataVencimento_3, 9, 2) || '/' || SUBSTR(dataVencimento_3, 6, 2) || '/' || SUBSTR(dataVencimento_3, 0, 4) " + 
                    " WHEN tipoAcerto = 'ovidoria'           THEN SUBSTR(dataVencimento_4, 9, 2) || '/' || SUBSTR(dataVencimento_4, 6, 2) || '/' || SUBSTR(dataVencimento_4, 0, 4) " + 
                    " WHEN tipoAcerto = 'comissao'           THEN SUBSTR(dataVencimento_5, 9, 2) || '/' || SUBSTR(dataVencimento_5, 6, 2) || '/' || SUBSTR(dataVencimento_5, 0, 4) " + 
                    " WHEN tipoAcerto = 'imposto'            THEN SUBSTR(dataVencimento_6, 9, 2) || '/' || SUBSTR(dataVencimento_6, 6, 2) || '/' || SUBSTR(dataVencimento_6, 0, 4) " + 
                    " WHEN tipoAcerto = 'presConta'          THEN SUBSTR(dataVencimento_7, 9, 2) || '/' || SUBSTR(dataVencimento_7, 6, 2) || '/' || SUBSTR(dataVencimento_7, 0, 4) " + 
                    " WHEN tipoAcerto = 'cosseguro'          THEN SUBSTR(dataVencimento_8, 9, 2) || '/' || SUBSTR(dataVencimento_8, 6, 2) || '/' || SUBSTR(dataVencimento_8, 0, 4) " + 
                    " WHEN tipoAcerto = 'devolucao_franquia' THEN SUBSTR(dataVencimento_9, 9, 2) || '/' || SUBSTR(dataVencimento_9, 6, 2) || '/' || SUBSTR(dataVencimento_9, 0, 4) " + 
                    " WHEN tipoAcerto = 'despesa_apolice'    THEN SUBSTR(dataVencimento_10, 9, 2) || '/' || SUBSTR(dataVencimento_10, 6, 2) || '/' || SUBSTR(dataVencimento_10, 0, 4) " +
                    " ELSE '---' END = '" + dtVenc + "' ";
                }

                if(constraints[c].fieldName.toUpperCase() == 'CSTATUS'){
                    var status = constraints[c].initialValue.trim();

                    if(status == 'nota_enviada'){
                        cQryWhr += " AND NUM_SEQ_ESTADO IN (0, 4, 15, 18) ";
                    }
                    if(status == 'nota_analise'){
                        cQryWhr += " AND NUM_SEQ_ESTADO IN (21, 31, 49, 46, 92, 65, 69, 117, 121, 27) ";
                    }
                    if(status == 'pag_programado'){
                        cQryWhr += " AND NUM_SEQ_ESTADO IN (38) ";
                    }
                    if(status == 'pag_realizado'){
                        cQryWhr += " AND NUM_SEQ_ESTADO IN (35) ";
                    }
                    if(status == 'pedido_revisao'){
                        cQryWhr += " AND NUM_SEQ_ESTADO IN (99, 100) ";
                    }
                }

                if(constraints[c].fieldName.toUpperCase() == 'CVALOR'){
                    var valor = constraints[c].initialValue.trim();
                    cQryWhr += " AND valorTotal IS NOT NULL ";
                    if(valor == 'zero_cem'){
                         cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') <= 100.00 ";
                        /*cQryWhr += " AND REPLACE(valorTotal, ',', '') <= 10000 ";*/
                    }
                    if(valor == 'cem_quinhentos'){
                        cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') > 100.00 ";
                        
                        cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') <= 500.00  ";
                        /*cQryWhr += " AND REPLACE(valorTotal, ',', '') > 10000 AND REPLACE(valorTotal, ',', '') <= 50000 ";*/
                    }
                    if(valor == 'quinhentos_mil'){
                        cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') > 500.00 ";
                        
                        cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') <= 1000.00  ";
                        /*cQryWhr += " AND REPLACE(valorTotal, ',', '') > 50000 AND REPLACE(valorTotal, ',', '') <= 100000 ";*/
                    }
                    if(valor == 'mil_cincomil'){
                        cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') > 1000.00 ";
                        
                        cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') <= 5000.00  ";
                        /*cQryWhr += " AND REPLACE(valorTotal, ',', '') > 100000 AND REPLACE(valorTotal, ',', '') <= 500000 ";*/
                    }
                    if(valor == 'mais_cincomil'){
                        cQryWhr += " AND TO_NUMBER(REPLACE(REPLACE(CASE " +
                        " WHEN valor IS NOT NULL THEN valor " +
                        " WHEN  tipoAcerto = 'adiantamento' THEN valorAdiantamento " + 
                        " WHEN  tipoAcerto = 'despesaNF' THEN valorDespesa " + 
                        " WHEN  tipoAcerto = 'RH' THEN valorRH " + 
                        " WHEN  tipoAcerto = 'ovidoria' THEN valorOuvidoria " + 
                        " WHEN  tipoAcerto = 'comissao' THEN valorComissao " + 
                        " WHEN  tipoAcerto = 'imposto' THEN valorImposto " + 
                        " WHEN  tipoAcerto = 'presConta' THEN valorPresConta " + 
                        " WHEN  tipoAcerto = 'cosseguro' THEN valorCosseguro " + 
                        " WHEN  tipoAcerto = 'devolucao_franquia' THEN valorDevFranquia " + 
                        " WHEN  tipoAcerto = 'despesa_apolice' THEN valorDespesaApolice " +
                        " END, '.', ''), ',', '.') , '99999999.99') > 5000.00 ";
                        /*cQryWhr += " AND REPLACE(valorTotal, ',', '') > 500000 ";*/
                    }
                }
            }
        }
    }

    var query = cQryCpo + cQryFrom + cQryWhr + cQryGrp + cQryOrd;
    
    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(query);
        var columnCount = rs.getMetaData().getColumnCount();
        var counter = 0;
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }

                created = true;
            }

            var Arr = new Array();

            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));

                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }

            newDataset.addRow(Arr);

            counter++;
            if (counter > 100000) {
                break;
            }
        }
    } catch (e) {
        newDataset.addColumn("CONST");
        newDataset.addColumn("ERRO");
        newDataset.addColumn("INSTRUCTION");
        newDataset.addRow([constraints, e.message, query]);
    } finally {
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
    }

    return newDataset;
}