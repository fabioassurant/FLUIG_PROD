function createDataset(fields, constraints, sortFields) {
    var nNumOblig = "";
    var ds = DatasetBuilder.newDataset();
   
    try {
        if (constraints) {
             for (var i = 0; i < constraints.length; i++) {
            if (constraints[i].fieldName == "obligacion") {
                nNumOblig = constraints[i].initialValue;
            }
        }
        }
        
        var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
        var cIndAutomatico = ""
        var cCodWorkflow = "F"
        var retornoFinaliza = finalizaObrigacao(cChaveAutent, nNumOblig, cIndAutomatico,cCodWorkflow)
        
       if(retornoFinaliza == "sucesso") {
              ds.addColumn("Sucesso");
              ds.addRow(["Obrigação Finalizada"]);
       }else {
           ds.addColumn("Erro");
              ds.addRow([retornoFinaliza]);
       }
        
        // ds.addColumn("Sucesso");
        // ds.addRow(["Obrigação Finalizada"]);
        
        return ds
    }catch (e) {
        log.info('ERROOOOR-----------@@@')
        log.dir(e)
        ds.addColumn("Erro");
        ds.addRow(e);
        return ds;
    }
}

function finalizaObrigacao(aut, numObrig,cIndAutomatico,codWorkflow) {
    
    var properties = {};
    properties["receive.timeout"] = "100000000";


    var supplierService = ServiceManager.getService('Acsel');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    
    try {
        var RetornoFinalizaObrigacao = customClient.finalizaObrigacao(aut, numObrig, cIndAutomatico, codWorkflow);
        
        if(RetornoFinalizaObrigacao['retorno'] == 0) {
            var sucesso ="sucesso"
            return sucesso
        }else {
            var mensagemRetorno = RetornoFinalizaObrigacao['descricaoErro']
            return mensagemRetorno
        }
    } catch (e) {
        throw e.toString()
    }

    if (RetornoFinalizaObrigacao.getRetorno() != 0) {
        if (restart) {
           customClient.finalizaObrigacao(aut, numObrig, cIndAutomatico, cCodWorkflow);
        }
        throw 'Erro: webservice retornou o valor ' + RetornoGravaDetalheObrigacao.getRetorno()
    }
}