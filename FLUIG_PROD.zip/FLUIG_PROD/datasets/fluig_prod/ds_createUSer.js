function createDataset(fields, constraints, sortFields) {
    var dataset = DatasetBuilder.newDataset();

    var username = "admin";
    var password = "LcHpC7kLNb6#497" // inserir a senha do ambiente de produção;
    var companyId = 1;

    var params = [
        {
            "login": "WW2049",
            "colleagueName": "ADELMO DE MOURA MACHADO",
            "email": "adelmo.machado@assurant.com",
            "groupId": "JURIDICO",
            "passwd": 123,
            "colleagueId": 1414225
        },
        {
            "login": "PR5486",
            "colleagueName": "ADRIANA GOMES LAURIANO",
            "email": "adriana.lauriano@assurant.com",
            "groupId": "TESOURARIA",
            "passwd": 123,
            "colleagueId": 150006
        },
        {
            "login": "IC2530",
            "colleagueName": "ADRINE PEREIRA DE CARVALHO",
            "email": "adrine.carvalho@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 304225
        },
        {
            "login": "ST5905",
            "colleagueName": "ALEX GOMES DA SILVA",
            "email": "alex.gomes@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 1423738
        },
        {
            "login": "ES2984",
            "colleagueName": "ALEX SANDRO CELESTINO DOS SANTOS",
            "email": "alex.santos@assurant.com",
            "groupId": "SINISTRO VSC",
            "passwd": 123,
            "colleagueId": 1416401
        },
        {
            "login": "NJ2402",
            "colleagueName": "ALEXANDRA PETILO ALMEIDA",
            "email": "alexandra.almeida@assurant.com",
            "groupId": "CONTABILIDADE",
            "passwd": 123,
            "colleagueId": 150253
        },
        {
            "login": "TS7628",
            "colleagueName": "AMANDA OLIVEIRA DE BRITO",
            "email": "amanda.brito@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1428876
        },
        {
            "login": "TW7826",
            "colleagueName": "ANA MONISA DOS SANTOS SILVERIO",
            "email": "ana.silverio@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1436337
        },
        {
            "login": "HF5090",
            "colleagueName": "ANA PAULA MOREIRA SCHOTI",
            "email": "ana.schoti@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 150299
        },
        {
            "login": "ZT6393",
            "colleagueName": "ANA PAULA OLIVEIRA LIMA",
            "email": "ana.paula.lima@assurant.com",
            "groupId": "COMERCIAL VSC",
            "passwd": 123,
            "colleagueId": 1438818
        },
        {
            "login": "ER6321",
            "colleagueName": "ANA PAULA RONDON GARCIA DOS REIS",
            "email": "ana.rondon@assurant.com",
            "groupId": "RELACIONAMENTO ESC",
            "passwd": 123,
            "colleagueId": 1426404
        },
        {
            "login": "GI8121",
            "colleagueName": "ANDRE DE QUEIROZ DIAS",
            "email": "andre.dias@assurant.com",
            "groupId": "ATUARIAL",
            "passwd": 123,
            "colleagueId": 1421766
        },
        {
            "login": "BZ0BZ89",
            "colleagueName": "ANDREA BONINI MARINHO BARRANHA",
            "email": "andrea.barranha@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 1403388
        },
        {
            "login": "SM6572",
            "colleagueName": "ANDREIA MENDES LESSI",
            "email": "andreia.lessi@assurant.com",
            "groupId": "FINANCEIRO",
            "passwd": 123,
            "colleagueId": 302212
        },
        {
            "login": "SR6048",
            "colleagueName": "ANDRESSA MEDEIROS DE QUEIROZ MOREIRA",
            "email": "andressa.moreira@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 1414743
        },
        {
            "login": "DQ6714",
            "colleagueName": "ARTHUR MATOS DOS SANTOS",
            "email": "arthur.santos@assurant.com",
            "groupId": "TAXES",
            "passwd": 123,
            "colleagueId": 150296
        },
        {
            "login": "MT1098",
            "colleagueName": "BARBARA LAIS CHAVES",
            "email": "barbara.chaves@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110736
        },
        {
            "login": "NJ4349",
            "colleagueName": "BEATRIZ ZAHRA DA SILVA",
            "email": "beatriz.silva@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 14202781
        },
        {
            "login": "UF4226",
            "colleagueName": "BRUNO CARETA CARREIRA",
            "email": "bruno.carreira@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 150254
        },
        {
            "login": "WB4190",
            "colleagueName": "BRUNO DE SOUZA OLIVEIRA",
            "email": "bruno.oliveira@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1427867
        },
        {
            "login": "CP2282",
            "colleagueName": "BRUNO MAGALHÃES DE BARROS",
            "email": "bruno.barros@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1417283
        },
        {
            "login": "NU5229",
            "colleagueName": "BRUNO RODRIGUES DE SOUZA",
            "email": "bruno.souza@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1435264
        },
        {
            "login": "BZ0Z72",
            "colleagueName": "BRUNO SOUZA DE ALMEIDA",
            "email": "bruno.almeida@assurant.com",
            "groupId": "TI INFRA",
            "passwd": 123,
            "colleagueId": 14059951
        },
        {
            "login": "DE4287",
            "colleagueName": "BRUNO TOGNOZZI VIEIRA DA CRUZ",
            "email": "bruno.tognozzi@assurant.com",
            "groupId": "WIRELESS",
            "passwd": 123,
            "colleagueId": 1464971
        },
        {
            "login": "TE8644",
            "colleagueName": "CAIO PAULIN VERISSIMO DA SILVA",
            "email": "caio.silva@assurant.com",
            "groupId": "RELACIONAMENTO ESC",
            "passwd": 123,
            "colleagueId": 1428880
        },
        {
            "login": "XY8043",
            "colleagueName": "CAMILA FERNANDES ALMEIDA",
            "email": "camila.almeida@assurant.com",
            "groupId": "MARKETING TRADE",
            "passwd": 123,
            "colleagueId": 1460676
        },
        {
            "login": "MJ8068",
            "colleagueName": "CAMILA ROSSI RODRIGUES DA COSTA",
            "email": "camila.costa@assurant.com",
            "groupId": "OUVIDORIA",
            "passwd": 123,
            "colleagueId": 1461067
        },
        {
            "login": "ZJ4013",
            "colleagueName": "CARINA BENEDICTO",
            "email": "carina.benedicto@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 1408593
        },
        {
            "login": "HG5924",
            "colleagueName": "CARLA RIBEIRO DE ARAUJO",
            "email": "carla.araujo@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1408594
        },
        {
            "login": "CY0104",
            "colleagueName": "CARLOS EDUARDO HERNANDEZ CANTÃO",
            "email": "carlos.cantao@assurant.com",
            "groupId": "MARKETING TREINAMENTO",
            "passwd": 123,
            "colleagueId": 1432951
        },
        {
            "login": "NS7084",
            "colleagueName": "CARLOS HENRIQUE REOLON AMADIO",
            "email": "carlos.amadio@assurant.com",
            "groupId": "COMERCIAL VSC",
            "passwd": 123,
            "colleagueId": 302699
        },
        {
            "login": "EL0777",
            "colleagueName": "CIBELLE DE CASSIA RIBEIRO DA SILVA",
            "email": "cibelle.silva@assurant.com",
            "groupId": "RECURSOS HUMANOS",
            "passwd": 123,
            "colleagueId": 1440764
        },
        {
            "login": "HJ0216",
            "colleagueName": "CINTIA COSTA DE BONIS",
            "email": "cintia.bonis@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110427
        },
        {
            "login": "PV4141",
            "colleagueName": "CLAUDIA VIEIRA MOREIRA",
            "email": "claudia.moreira@assurant.com",
            "groupId": "MARKETING",
            "passwd": 123,
            "colleagueId": 14376221
        },
        {
            "login": "LM9843",
            "colleagueName": "CLEBER ALVES V DE ANDRADE",
            "email": "cleber.andrade@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 150211
        },
        {
            "login": "MX7101",
            "colleagueName": "CRISTIANO FRANCO FURTADO",
            "email": "cristiano.furtado@assurant.com",
            "groupId": "CONTROLADORIA",
            "passwd": 123,
            "colleagueId": 1417282
        },
        {
            "login": "FC7124",
            "colleagueName": "DAFNE AUGUSTO DA SILVA RICCI",
            "email": "dafne.silva@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110546
        },
        {
            "login": "BZ0S8X",
            "colleagueName": "DANIEL ANDRE BRANDAO",
            "email": "daniel.brandao@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 1403403
        },
        {
            "login": "GN8086",
            "colleagueName": "DANIEL QUEIROZ DE ALBUQUERQUE",
            "email": "daniel.albuquerque@assurant.com",
            "groupId": "CONTROLADORIA",
            "passwd": 123,
            "colleagueId": 1420522
        },
        {
            "login": "ZO3254",
            "colleagueName": "DANIELE DELIBI AZEVEDO",
            "email": "daniele.azevedo@assurant.com",
            "groupId": "OPERACIONAL",
            "passwd": 123,
            "colleagueId": 14318101
        },
        {
            "login": "XK6172",
            "colleagueName": "DANIELE REGINA DE ANDRADE",
            "email": "daniele.andrade@assurant.com",
            "groupId": "MARKETING",
            "passwd": 123,
            "colleagueId": 150290
        },
        {
            "login": "YX1822",
            "colleagueName": "DAVID ALVES SANTOS",
            "email": "david.a.santos@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 14380081
        },
        {
            "login": "HB0682",
            "colleagueName": "DENISE KAROLYN DE BARROS",
            "email": "denise.barros@assurant.com",
            "groupId": "JURIDICO",
            "passwd": 123,
            "colleagueId": 1426410
        },
        {
            "login": "CR5506",
            "colleagueName": "DOUGLAS ROGERIO DENTI",
            "email": "douglas.denti@assurant.com",
            "groupId": "CONTABILIDADE",
            "passwd": 123,
            "colleagueId": 1429227
        },
        {
            "login": "LQ3653",
            "colleagueName": "EDNA PERES LEME",
            "email": "edna.leme@assurant.com",
            "groupId": "ATUARIAL",
            "passwd": 123,
            "colleagueId": 301593
        },
        {
            "login": "RA9142",
            "colleagueName": "EDRIA ADRIA SILVA DO CARMO",
            "email": "edria.carmo@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 150336
        },
        {
            "login": "NS9790",
            "colleagueName": "EDUARDO ALDECOA",
            "email": "eduardo.aldecoa@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 302146
        },
        {
            "login": "LB9237",
            "colleagueName": "EDUARDO POMPERMAYER FAZOLIM",
            "email": "eduardo.fazolim@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 300217
        },
        {
            "login": "CF6337",
            "colleagueName": "EDWIN SCHULZE",
            "email": "edwin.schulze@assurant.com",
            "groupId": "RECURSOS HUMANOS",
            "passwd": 123,
            "colleagueId": 1460113
        },
        {
            "login": "HK0147",
            "colleagueName": "EMILIANA LESSI",
            "email": "emiliana.lessi@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 150302
        },
        {
            "login": "GR6757",
            "colleagueName": "ESTHER NESPOLI DE OLIVEIRA",
            "email": "esther.oliveira@assurant.com",
            "groupId": "WIRELESS",
            "passwd": 123,
            "colleagueId": 1415110
        },
        {
            "login": "ZS5086",
            "colleagueName": "FABIANA LIMA MAIA",
            "email": "fabiana.maia@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110707
        },
        {
            "login": "BZ0XQO",
            "colleagueName": "FABIANO PIRES ALTIERI TELATIN",
            "email": "fabiano.telatin@assurant.com",
            "groupId": "COMERCIAL VSC",
            "passwd": 123,
            "colleagueId": 1410442
        },
        {
            "login": "YC0577",
            "colleagueName": "FELIPE SOARES BARROS",
            "email": "felipe.barros@assurant.com",
            "groupId": "CONTABILIDADE",
            "passwd": 123,
            "colleagueId": 1416268
        },
        {
            "login": "JP6517",
            "colleagueName": "FERNANDA CHRISTINA ZAMBONI",
            "email": "fernanda.zamboni@assurant.com",
            "groupId": "MARKETING",
            "passwd": 123,
            "colleagueId": 1413066
        },
        {
            "login": "NP3538",
            "colleagueName": "FERNANDA GOMES DE SOUSA",
            "email": "fernanda.gomes@assurant.com",
            "groupId": "MARKETING TREINAMENTO",
            "passwd": 123,
            "colleagueId": 1421053
        },
        {
            "login": "FZ4751",
            "colleagueName": "FERNANDA MAGALHAES JALORETO",
            "email": "fernanda.jaboreto@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110727
        },
        {
            "login": "FB8258",
            "colleagueName": "FERNANDA RAMALHO BOTSMAN",
            "email": "fernanda.botsman@assurant.com",
            "groupId": "COMPLIANCE",
            "passwd": 123,
            "colleagueId": 1437068
        },
        {
            "login": "ZL7486",
            "colleagueName": "FERNANDO BRAGA DUARTE",
            "email": "fernando.duarte@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 1427109
        },
        {
            "login": "WS9815",
            "colleagueName": "FERNANDO ROMEIRO DA SILVA",
            "email": "fernando.romeiro@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 1426437
        },
        {
            "login": "CA2750",
            "colleagueName": "GABRIELA LEANDRO CORREIA DE SOUZA",
            "email": "gabriela.correia@assurant.com",
            "groupId": "TAXES",
            "passwd": 123,
            "colleagueId": 1426409
        },
        {
            "login": "XQ0591",
            "colleagueName": "GABRIELA QUEIROZ SANTOS",
            "email": "gabriela.santos@assurant.com",
            "groupId": "MARKETING",
            "passwd": 123,
            "colleagueId": 1440709
        },
        {
            "login": "JB9606",
            "colleagueName": "GABRIELLA MAY KOMATI",
            "email": "gabriella.komati@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 14392271
        },
        {
            "login": "IC6301",
            "colleagueName": "GEOVANI SILVA DE JESUS",
            "email": "geovani.jesus@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 1425873
        },
        {
            "login": "KM3339",
            "colleagueName": "GILBERTO AIRES DA CRUZ",
            "email": "gilberto.cruz@assurant.com",
            "groupId": "FACILITIES",
            "passwd": 123,
            "colleagueId": 1408595
        },
        {
            "login": "YI9541",
            "colleagueName": "GIOVANNA CÉLIA ZAMPERLINI FERREIRA AGNOLETTO",
            "email": "giovanna.ferreira@assurant.com",
            "groupId": "MARKETING TREINAMENTO",
            "passwd": 123,
            "colleagueId": 301779
        },
        {
            "login": "XY8610",
            "colleagueName": "GISLAINE MARQUES OLIVEIRA",
            "email": "gislaine.oliveira@assurant.com",
            "groupId": "CONTABILIDADE",
            "passwd": 123,
            "colleagueId": 150286
        },
        {
            "login": "BZ0KQY",
            "colleagueName": "GLAUCIA PRISCILA DE FRANCA MORENO",
            "email": "glaucia.moreno@assurant.com",
            "groupId": "TESOURARIA",
            "passwd": 123,
            "colleagueId": 1405989
        },
        {
            "login": "XM8083",
            "colleagueName": "GRAYSON EDO ALTOMANI",
            "email": "grayson.altomani@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 150342
        },
        {
            "login": "NA2853",
            "colleagueName": "GUILHERME ALVES DOS SANTOS",
            "email": "guilherme.a.santos@assurant.com",
            "groupId": "OUVIDORIA",
            "passwd": 123,
            "colleagueId": 1438300
        },
        {
            "login": "FA1215",
            "colleagueName": "GUSTAVO DUARTE CANDIDO",
            "email": "gustavo.candido@assurant.com",
            "groupId": "JURIDICO",
            "passwd": 123,
            "colleagueId": 1424783
        },
        {
            "login": "TU7492",
            "colleagueName": "HANAN AHMAD DORGHAM TAHA",
            "email": "hanan.dorgham@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 1417288
        },
        {
            "login": "JI8641",
            "colleagueName": "HAURELENE FERNANDES",
            "email": "haurelene.fernandes@assurant.com",
            "groupId": "MARKETING TRADE",
            "passwd": 123,
            "colleagueId": 1424404
        },
        {
            "login": "MC5234",
            "colleagueName": "HELLEN MENDES MAIA",
            "email": "helen.maia@assurant.com",
            "groupId": "COMPLIANCE",
            "passwd": 123,
            "colleagueId": 150214
        },
        {
            "login": "LR6078",
            "colleagueName": "HELTON CARDOSO MORENO",
            "email": "helton.moreno@assurant.com",
            "groupId": "TI INFRA",
            "passwd": 123,
            "colleagueId": 1407279
        },
        {
            "login": "EX6943",
            "colleagueName": "IGOR CARDOSO SOARES GIL",
            "email": "igor.cardoso@assurant.com",
            "groupId": "ATUARIAL",
            "passwd": 123,
            "colleagueId": 1428879
        },
        {
            "login": "EF9550",
            "colleagueName": "JAMIL HERMOGENES SILVA",
            "email": "jamil.silva@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110754
        },
        {
            "login": "VS6159",
            "colleagueName": "JANAINA ALMEIDA LOPES",
            "email": "janaina.lopes@assurant.com",
            "groupId": "RECURSOS HUMANOS",
            "passwd": 123,
            "colleagueId": 1430052
        },
        {
            "login": "UJ1878",
            "colleagueName": "JEAN FERREIRA AIRES",
            "email": "jean.aires@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150305
        },
        {
            "login": "CA1322",
            "colleagueName": "JESSICA ALINE ALVES PINHEIRO SOUZA",
            "email": "jessica.alves@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1418310
        },
        {
            "login": "GA1605",
            "colleagueName": "JESSICA DANDARA RODRIGUES FARINELLI",
            "email": "jessica.farinelli@assurant.com",
            "groupId": "OUVIDORIA",
            "passwd": 123,
            "colleagueId": 150261
        },
        {
            "login": "WZ3562",
            "colleagueName": "JESSICA KASSIA DA SILVA",
            "email": "jessica.silva@assurant.com",
            "groupId": "CONTABILIDADE",
            "passwd": 123,
            "colleagueId": 150223
        },
        {
            "login": "EB0963",
            "colleagueName": "JESSICA LUZ GOMES DOS SANTOS",
            "email": "jessica.luz@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110478
        },
        {
            "login": "RH7694",
            "colleagueName": "JESSICA SANTOS PINHEIRO",
            "email": "jessica.pinheiro@assurant.com",
            "groupId": "OUVIDORIA",
            "passwd": 123,
            "colleagueId": 150227
        },
        {
            "login": "MV1591",
            "colleagueName": "JONATAS ALVES DE OLIVEIRA SOUZA",
            "email": "jonatas.souza@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 301520
        },
        {
            "login": "HF5538",
            "colleagueName": "JONES FAEDO JUNIOR",
            "email": "jones.faedo.junior@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 1463363
        },
        {
            "login": "BT5095",
            "colleagueName": "JOSE AUGUSTO GOMES CODESSO",
            "email": "jose.codesso@assurant.com",
            "groupId": "OPERACIONAL",
            "passwd": 123,
            "colleagueId": 1416267
        },
        {
            "login": "WZ7944",
            "colleagueName": "JULIA LAMEIRÃO DE FREITAS",
            "email": "julia.freitas@assurant.com",
            "groupId": "ATUARIAL",
            "passwd": 123,
            "colleagueId": 1420280
        },
        {
            "login": "IL8247",
            "colleagueName": "JULIANA CALIXTO ALMEIDA",
            "email": "juliana.almeida@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 303992
        },
        {
            "login": "FS4330",
            "colleagueName": "JULIANA DIAS HRADEC",
            "email": "juliana.hradec@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 110725
        },
        {
            "login": "OM8394",
            "colleagueName": "JULIO CESAR MARTINS",
            "email": "julio.martins@assurant.com",
            "groupId": "MARKETING",
            "passwd": 123,
            "colleagueId": 1425258
        },
        {
            "login": "DB4716",
            "colleagueName": "JUSSARA CRISTINA DE O. SOUZA",
            "email": "jussara.souza@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 110574
        },
        {
            "login": "RV2690",
            "colleagueName": "KAROLINE RODRIGUES DE LIMA",
            "email": "karoline.lima@assurant.com",
            "groupId": "CONTABILIDADE",
            "passwd": 123,
            "colleagueId": 1415356
        },
        {
            "login": "OK6578",
            "colleagueName": "KEINY CRISTINA ARENA",
            "email": "keiny.arena@assurant.com",
            "groupId": "JURIDICO",
            "passwd": 123,
            "colleagueId": 150187
        },
        {
            "login": "OW7181",
            "colleagueName": "KETILI BATISTA DE SOUZA",
            "email": "ketili.souza@assurant.com",
            "groupId": "MARKETING TRADE",
            "passwd": 123,
            "colleagueId": 150274
        },
        {
            "login": "KV3226",
            "colleagueName": "KHIM SILVA CARVALHO",
            "email": "khim.carvalho@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 302391
        },
        {
            "login": "TG6329",
            "colleagueName": "KLEBER AECIO KALIZUK",
            "email": "kleber.kalizuk@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1426400
        },
        {
            "login": "LZ1853",
            "colleagueName": "LAIS ELASCAR DUARTE",
            "email": "lais.duarte@assurant.com",
            "groupId": "WIRELESS",
            "passwd": 123,
            "colleagueId": 1432619
        },
        {
            "login": "MF2481",
            "colleagueName": "LALUXA GARCIA SILVA",
            "email": "laluxa.garcia@assurant.com",
            "groupId": "MARKETING",
            "passwd": 123,
            "colleagueId": 150209
        },
        {
            "login": "NY3842",
            "colleagueName": "LARISSA RODRIGUES CAMARGO",
            "email": "larissa.camargo@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110763
        },
        {
            "login": "CU8191",
            "colleagueName": "LEIDIANE PEREIRA DE MACEDO NEVES",
            "email": "leidiane.neves@assurant.com",
            "groupId": "TESOURARIA",
            "passwd": 123,
            "colleagueId": 150283
        },
        {
            "login": "OI5083",
            "colleagueName": "LILIAN APARECIDA CARDOSO",
            "email": "lilian.cardoso@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110404
        },
        {
            "login": "WC7200",
            "colleagueName": "LUANA MINERVINA DA SILVA CAVALCANTE",
            "email": "luana.cavalcante@assurant.com",
            "groupId": "TESOURARIA",
            "passwd": 123,
            "colleagueId": 1426461
        },
        {
            "login": "SM1047",
            "colleagueName": "LUARA DA SILVA GADELHA",
            "email": "luara.gadelha@assurant.com",
            "groupId": "OUVIDORIA",
            "passwd": 123,
            "colleagueId": 1461069
        },
        {
            "login": "GZ0811",
            "colleagueName": "LUCA DE CASTRO ZALESKI",
            "email": "luca.zaleski@assurant.com",
            "groupId": "IMPLANTAÇÃO",
            "passwd": 123,
            "colleagueId": 1436338
        },
        {
            "login": "VE4648",
            "colleagueName": "LUCAS FERNANDES",
            "email": "lucas.fernandes@assurant.com",
            "groupId": "TI INFRA",
            "passwd": 123,
            "colleagueId": 1441063
        },
        {
            "login": "HK1438-20200713",
            "colleagueName": "LUIS GUSTAVO MIRANDA DE OLIVEIRA",
            "email": "gustavo.miranda@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 1461240
        },
        {
            "login": "HK1438",
            "colleagueName": "LUIS GUSTAVO MIRANDA DE OLIVEIRA",
            "email": "gustavo.miranda@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 1461240
        },
        {
            "login": "PY6463",
            "colleagueName": "LUIZ ANTONIO SUPRIANO JUNIOR",
            "email": "luiz.supriano@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1420282
        },
        {
            "login": "PK5126",
            "colleagueName": "LUIZ CARLOS DA SILVA JUNIOR",
            "email": "luiz.pires@assurant.com",
            "groupId": "WIRELESS",
            "passwd": 123,
            "colleagueId": 1461167
        },
        {
            "login": "AG2260",
            "colleagueName": "LUIZ EDUARDO CALHEIROS RIBEIRO FERREIRA PIFFER AFFONSO",
            "email": "luiz.affonso@assurant.com",
            "groupId": "OPERACIONAL",
            "passwd": 123,
            "colleagueId": 14247201
        },
        {
            "login": "SJ1833",
            "colleagueName": "LUIZ HENRIQUE FREIRE CAZARIM",
            "email": "luiz.cazarim@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1416402
        },
        {
            "login": "KM1911",
            "colleagueName": "MARCEL OLIVEIRA GIACON",
            "email": "marcel.giacon@assurant.com",
            "groupId": "MARKETING",
            "passwd": 123,
            "colleagueId": 14601461
        },
        {
            "login": "ED7808",
            "colleagueName": "MARCEL PASCOLAT GIBIN MONGE",
            "email": "marcel.monge@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1416622
        },
        {
            "login": "DR0832",
            "colleagueName": "MARCELO FERREIRA",
            "email": "marcelo.acenco@assurant.com",
            "groupId": "TI INFRA",
            "passwd": 123,
            "colleagueId": 1441064
        },
        {
            "login": "AZ4389",
            "colleagueName": "MARCIO MARTINI",
            "email": "marcio.martini@assurant.com",
            "groupId": "TI INFRA",
            "passwd": 123,
            "colleagueId": 1425109
        },
        {
            "login": "BZ0KNE",
            "colleagueName": "MARCIO RODRIGUES DOS SANTOS",
            "email": "marcio.santos@assurant.com",
            "groupId": "FACILITIES",
            "passwd": 123,
            "colleagueId": 1403434
        },
        {
            "login": "RX3902",
            "colleagueName": "MARCOS SANTOS",
            "email": "marcos.santos@assurant.com",
            "groupId": "CONTAS A RECEBER",
            "passwd": 123,
            "colleagueId": 1416621
        },
        {
            "login": "MM2983",
            "colleagueName": "MARCOS WILSON FERREIRA",
            "email": "marcos.ferreira@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150306
        },
        {
            "login": "UO3488",
            "colleagueName": "MARIA BERNARDO GONZAGA",
            "email": "maria.gonzaga@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 302073
        },
        {
            "login": "DG3150",
            "colleagueName": "MARIA TERESA BARROZO LUIGI",
            "email": "maria.luigi@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150321
        },
        {
            "login": "KT1333",
            "colleagueName": "MARIANA DELÁZARI CORRÊA",
            "email": "mariana.correa@assurant.com",
            "groupId": "GESTÃO DE RISCO",
            "passwd": 123,
            "colleagueId": 1440668
        },
        {
            "login": "KZ7973",
            "colleagueName": "MARIANA FERREIRA",
            "email": "mariana.ferreira@assurant.com",
            "groupId": "MARKETING TREINAMENTO",
            "passwd": 123,
            "colleagueId": 110429
        },
        {
            "login": "MN0669",
            "colleagueName": "MARIANA RIBEIRO OLIVEIRA",
            "email": "mariana.oliveira@assurant.com",
            "groupId": "FINANCEIRO",
            "passwd": 123,
            "colleagueId": 301524
        },
        {
            "login": "G9CSOI",
            "colleagueName": "MARIANA ROTH MARTINS",
            "email": "mariana.roth@assurant.com",
            "groupId": "RELACIONAMENTO ESC",
            "passwd": 123,
            "colleagueId": 1403438
        },
        {
            "login": "JZ2625",
            "colleagueName": "MARIELLA SOARES DA SILVA",
            "email": "mariella.silva@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110673
        },
        {
            "login": "LY0980",
            "colleagueName": "MARINA DE SOUZA ALEXANDRE BAGALHO",
            "email": "marina.bagalho@assurant.com",
            "groupId": "TAXES",
            "passwd": 123,
            "colleagueId": 1427458
        },
        {
            "login": "SN2183",
            "colleagueName": "MAURI MORINA MARQUES NOGUEIRA",
            "email": "mauri.nogueira@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 1440402
        },
        {
            "login": "AF7488",
            "colleagueName": "MELISSA LINS DE SOUZA",
            "email": "melissa.souza@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 302404
        },
        {
            "login": "GY5938",
            "colleagueName": "MIGUEL MACIEL ROCHEDO",
            "email": "miguel.rochedo@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 1439946
        },
        {
            "login": "KC8833",
            "colleagueName": "MONICA CRISTHIANNE RAMOS ROSA",
            "email": "monica.rosa@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 110733
        },
        {
            "login": "YM9272",
            "colleagueName": "MOYSES BORGHESI FILHO",
            "email": "moyses.borghesi@assurant.com",
            "groupId": "GESTÃO DE RISCO",
            "passwd": 123,
            "colleagueId": 1438301
        },
        {
            "login": "DV0719",
            "colleagueName": "MURILO ZUFFO ROSSETTI",
            "email": "murilo.rossetti@assurant.com",
            "groupId": "COMERCIAL VSC",
            "passwd": 123,
            "colleagueId": 1427437
        },
        {
            "login": "XE1725",
            "colleagueName": "NELZA PEREIRA DE SOUZA",
            "email": "nelza.souza@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 110579
        },
        {
            "login": "TW9590",
            "colleagueName": "ORLANDO SIDRONIO LOURENCO FILHO",
            "email": "orlando.filho@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150307
        },
        {
            "login": "VW7833",
            "colleagueName": "PATRICIA PEREIRA QUEIROZ",
            "email": "patricia.queiroz@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 110680
        },
        {
            "login": "ZY6910",
            "colleagueName": "PATRICIA RUSSO HABIS",
            "email": "patricia.habis@assurant.com",
            "groupId": "RECURSOS HUMANOS",
            "passwd": 123,
            "colleagueId": 1424480
        },
        {
            "login": "JB3038",
            "colleagueName": "PAULO ANGEL MARCHESI",
            "email": "paulo.marchesi@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 1437297
        },
        {
            "login": "NS3312",
            "colleagueName": "PAULO DE TARSO MAGALHÃES PAES DE BARROS FILHO",
            "email": "paulo.barros@assurant.com",
            "groupId": "ATUARIAL",
            "passwd": 123,
            "colleagueId": 1421038
        },
        {
            "login": "TO6828",
            "colleagueName": "PAULO ERIK DE SOUZA SANTOS",
            "email": "paulo.santos1@assurant.com",
            "groupId": "TAXES",
            "passwd": 123,
            "colleagueId": 1428328
        },
        {
            "login": "JJ4818",
            "colleagueName": "PRISCILLA PETCOV MARCONDES",
            "email": "priscilla.marcondes@assurant.com",
            "groupId": "WIRELESS",
            "passwd": 123,
            "colleagueId": 1436732
        },
        {
            "login": "FZ8802",
            "colleagueName": "RACHEL PEDRICO",
            "email": "rachel.pedrico@assurant.com",
            "groupId": "MARKETING TRADE",
            "passwd": 123,
            "colleagueId": 300616
        },
        {
            "login": "BI8773",
            "colleagueName": "RAFAEL MILANI LIMA",
            "email": "rafael.lima@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150308
        },
        {
            "login": "FU6750",
            "colleagueName": "RAFAEL NEVES PALETTA",
            "email": "rafael.paletta@assurant.com",
            "groupId": "TI INFRA",
            "passwd": 123,
            "colleagueId": 1435750
        },
        {
            "login": "CO0983",
            "colleagueName": "RAFAEL SILVA MESQUITA",
            "email": "rafael.mesquita@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150309
        },
        {
            "login": "HJ9192",
            "colleagueName": "RAPHAEL MATHEUS RIBEIRO",
            "email": "raphael.ribeiro@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 14296511
        },
        {
            "login": "DJ8130",
            "colleagueName": "RAQUEL REGINA DA CONCEICAO",
            "email": "raquel.conceicao@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1425695
        },
        {
            "login": "PF1999",
            "colleagueName": "RENAN BERTO DO NASCIMENTO",
            "email": "renan.nascimento@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1428877
        },
        {
            "login": "BZ0HH9",
            "colleagueName": "RENATA MONTEIRO PEIXE",
            "email": "renata.peixe@assurant.com",
            "groupId": "FINANCEIRO",
            "passwd": 123,
            "colleagueId": 1407159
        },
        {
            "login": "BZ0V4J",
            "colleagueName": "RENATO FERREIRA GUIMARAES",
            "email": "renato.guimaraes@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 1403874
        },
        {
            "login": "EI6163",
            "colleagueName": "RICARDO BEZERRA DOS SANTOS",
            "email": "ricardo.bezerra@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 150310
        },
        {
            "login": "MS7351",
            "colleagueName": "RICARDO EDVAL DA FONSECA",
            "email": "ricardo.fonseca@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150311
        },
        {
            "login": "DK2185",
            "colleagueName": "RICARDO MARIOTTI BAUEB",
            "email": "ricardo.baueb@assurant.com",
            "groupId": "CONTROLADORIA",
            "passwd": 123,
            "colleagueId": 1437260
        },
        {
            "login": "YU9325",
            "colleagueName": "ROBERTA AMARAL DE FREITAS IBIAPINA",
            "email": "roberta.freitas@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 150335
        },
        {
            "login": "ZD9899",
            "colleagueName": "ROBERTA LUCAS FERNANDES",
            "email": "roberta.fernandes@assurant.com",
            "groupId": "CONTAS A RECEBER",
            "passwd": 123,
            "colleagueId": 1427879
        },
        {
            "login": "HG4929",
            "colleagueName": "ROBERTA OLIVEIRA SANTOS",
            "email": "roberta.santos@assurant.com",
            "groupId": "FINANCEIRO",
            "passwd": 123,
            "colleagueId": 1427878
        },
        {
            "login": "LQ4390",
            "colleagueName": "RODRIGO AUGUSTO BELINI",
            "email": "rodrigo.belini@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 150226
        },
        {
            "login": "JT3912",
            "colleagueName": "RODRIGO FAGUNDES DE MÉDIO",
            "email": "rodrigo.fagundes@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 150314
        },
        {
            "login": "DS9022",
            "colleagueName": "RODRIGO PASSETI DA SILVA",
            "email": "rodrigo.passeti@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 150332
        },
        {
            "login": "LZ2622",
            "colleagueName": "RODRIGO VANUCHI",
            "email": "rodrigo.vanuchi@assurant.com",
            "groupId": "CONTAS A RECEBER",
            "passwd": 123,
            "colleagueId": 1426462
        },
        {
            "login": "W5F6ZJ",
            "colleagueName": "ROGERIO PEREIRA DA SILVA",
            "email": "rogerio.pereira@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 14066401
        },
        {
            "login": "AN1882",
            "colleagueName": "ROSEMARI REBOLLO DE ALMEIDA CARVALHO",
            "email": "rosemari.carvalho@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 1418312
        },
        {
            "login": "BZ0Z1L",
            "colleagueName": "ROSIANE PEREIRA DA SILVA ASSIS",
            "email": "rosiane.assis@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 1406617
        },
        {
            "login": "BP1019",
            "colleagueName": "SIMONE DO PRADO MARSOLLA",
            "email": "simone.marsolla@assurant.com",
            "groupId": "COMERCIAL VSC",
            "passwd": 123,
            "colleagueId": 1434077
        },
        {
            "login": "UL5462",
            "colleagueName": "SIMONE TAVARES DA SILVA",
            "email": "simone.silva@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 150334
        },
        {
            "login": "ML9255",
            "colleagueName": "TAMIRIS FASSIO DA ROCHA",
            "email": "tamiris.rocha@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150316
        },
        {
            "login": "RQ3781",
            "colleagueName": "TATIANA GONORETZKY MARDONES",
            "email": "tatiana.gonoretzky@assurant.com",
            "groupId": "RECURSOS HUMANOS",
            "passwd": 123,
            "colleagueId": 1429149
        },
        {
            "login": "BQ9781",
            "colleagueName": "TATIANE MARINHO QUINTILIANO",
            "email": "tatiane.quintiliano@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 1427459
        },
        {
            "login": "XN4323",
            "colleagueName": "THAMARA MORAES PIRES",
            "email": "thamara.pires@assurant.com",
            "groupId": "JURIDICO",
            "passwd": 123,
            "colleagueId": 1460403
        },
        {
            "login": "KL8124",
            "colleagueName": "THAMIRES TAKEI",
            "email": "thamires.takei@assurant.com",
            "groupId": "OUVIDORIA",
            "passwd": 123,
            "colleagueId": 150260
        },
        {
            "login": "GO8633",
            "colleagueName": "THIAGO ALEGRETI FANTINATTI",
            "email": "thiago.fantinatti@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150317
        },
        {
            "login": "MO5793",
            "colleagueName": "VANESSA DOS SANTOS PIOVESANI SOUZA",
            "email": "vanessa.piovesani@assurant.com",
            "groupId": "EMISSAO",
            "passwd": 123,
            "colleagueId": 110634
        },
        {
            "login": "OL1453",
            "colleagueName": "VICTOR FABIANO PRATES DA SILVA",
            "email": "victor.silva@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 14241971
        },
        {
            "login": "WW1933",
            "colleagueName": "VIVIAN CRISTINA BATISTA",
            "email": "vivian.batista@assurant.com",
            "groupId": "CALL CENTER",
            "passwd": 123,
            "colleagueId": 110598
        },
        {
            "login": "HC4793",
            "colleagueName": "VIVIANE SILVA LOPES",
            "email": "viviane.silva2@assurant.com",
            "groupId": "SINISTRO ESC",
            "passwd": 123,
            "colleagueId": 150318
        },
        {
            "login": "YE5817",
            "colleagueName": "WALDIR MARIANO DE OLIVEIRA JUNIOR",
            "email": "waldir.oliveira@assurant.com",
            "groupId": "TI SISTEMAS",
            "passwd": 123,
            "colleagueId": 150289
        },
        {
            "login": "KO2683",
            "colleagueName": "WILLIAMS DE CARVALHO BEZERRA JUNIOR",
            "email": "williams.bezerra@assurant.com",
            "groupId": "COMERCIAL ESC",
            "passwd": 123,
            "colleagueId": 1409587
        },
        {
            "login": "ZO7449",
            "colleagueName": "WILSON APARECIDO FEITOSA LOPES",
            "email": "wilson.lopes@assurant.com",
            "groupId": "MARKETING TREINAMENTO",
            "passwd": 123,
            "colleagueId": 150331
        }
    ]

    try {
        var service = ServiceManager.getService("ECMColleagueService");
        var serviceClass = service.instantiate("com.totvs.technology.ecm.foundation.ws.ECMColleagueServiceService");
        var servicePort = serviceClass.getColleagueServicePort();

        // log.info("###Params Length");
        // log.dir(params.length);

        for (var i = 0; i < params.length; i++) {
            var colleagueDtoArray = service.instantiate("com.totvs.technology.ecm.foundation.ws.ColleagueDtoArray");
            var groupDtoArray = service.instantiate("com.totvs.technology.ecm.foundation.ws.GroupDtoArray");
            var workflowRoleDtoArray = service.instantiate("com.totvs.technology.ecm.foundation.ws.WorkflowRoleDtoArray");

            // log.info('###Value of i');
            // log.dir(i);

            var colleagueDto = service.instantiate("com.totvs.technology.ecm.foundation.ws.ColleagueDto");
            var groupDto = service.instantiate("com.totvs.technology.ecm.foundation.ws.GroupDto");
            var workflowRoleDto = service.instantiate("com.totvs.technology.ecm.foundation.ws.WorkflowRoleDto");

            colleagueDto.setColleagueId(params[i].colleagueId);
            colleagueDto.setColleagueName(params[i].colleagueName);
            colleagueDto.setCompanyId(companyId);
            colleagueDto.setLogin(params[i].login);
            colleagueDto.setMail(params[i].email);
            colleagueDto.setPasswd(params[i].passwd);

            groupDto.setGroupId(params[i].groupId);

            // log.info('###colleagueDto');
            // log.dir(colleagueDto);

            colleagueDtoArray.getItem().add(colleagueDto);
            groupDtoArray.getItem().add(groupDto);
            var response = servicePort.createColleaguewithDependencies(username, password, companyId, colleagueDtoArray, groupDtoArray, workflowRoleDtoArray);
        }

        // log.info('###colleagueDtoArray');
        // log.dir(colleagueDtoArray);

        dataset.addColumn('Response');
        dataset.addRow([response.toString()]);
    } catch (error) {
        dataset.addColumn('Erro');
        dataset.addRow([error.toString()]);
    }

    return dataset;
}