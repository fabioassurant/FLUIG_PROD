function createDataset(fields, constraints, sortFields) {
	var dataset = DatasetBuilder.newDataset();
    dataset.addColumn("NumProcesso");
    dataset.addColumn("NumFormulario");
    dataset.addColumn("diaInicio");
    dataset.addColumn("diaFim");
    dataset.addColumn("diaVencimento");

    
    var constraints = new Array();
    constraints.push(DatasetFactory.createConstraint("metadata#active", true, true, ConstraintType.MUST));

    var datasetPrincipal = DatasetFactory.getDataset("ds_cadastro_datas_vencimento", null, constraints, null);
    
    for (var i = 0; i < datasetPrincipal.rowsCount; i++) {
        var WKNumProces     = datasetPrincipal.getValue(i, "WKNumProces");
        var documentId      = datasetPrincipal.getValue(i, "metadata#id");
        var documentVersion = datasetPrincipal.getValue(i, "metadata#version");

        var constraintsFilhos = new Array();
        constraintsFilhos.push(DatasetFactory.createConstraint("tablename", "tableCadastroDatasVencimento" ,"tableCadastroDatasVencimento", ConstraintType.MUST));
        constraintsFilhos.push(DatasetFactory.createConstraint("metadata#id", documentId, documentId, ConstraintType.MUST));
        constraintsFilhos.push(DatasetFactory.createConstraint("metadata#version", documentVersion, documentVersion, ConstraintType.MUST));

        var datasetFilhos = DatasetFactory.getDataset("ds_cadastro_datas_vencimento", null, constraintsFilhos, null);

        for (var j = 0; j < datasetFilhos.rowsCount; j++) {
            dataset.addRow(new Array(
                    WKNumProces,
                    documentId,
                    datasetFilhos.getValue(j, "inicio"),
                    datasetFilhos.getValue(j, "fim"),
                    datasetFilhos.getValue(j, "vencimento")));
        }
    }

    return dataset;

}