function defineStructure() {}
function onSync(lastSyncDate) {}
function onMobileSync(user) {}

/*
==== MODEL:
==== Formulário de Acesso do Portal de Notas : ML001111
==== Pai e filho de usuários de acesso do registro de formulário : ML001112
*/

function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();
    var dataSource = "jdbc/FluigDS";
    var ic = new javax.naming.InitialContext();
    var ds = ic.lookup(dataSource)
    var created = false;

    var cQryFrom, cQryWhr, cQryGrp, cQryOrd, cQryCpo = 
    " SELECT " +
    " COALESCE(acs.documentid, 0) AS ID_DOC,  " +
    " acs.txt_fornecedor_cnpj AS CNPJ, " +
    " acs.txt_fornecedor_tipoId AS TIPO_ID, " +
    " acs.txt_fornecedor_nome AS NOME_FORNECEDOR, " +
    " acs.txt_fornecedor_idGrupo AS GRUPO_ADM, " +
    " acs.txt_acesso_dtCadastro AS DT_CADASTRO, " +
    " txt_usuario_email AS EMAIL_USU, " +
    " txt_usuario_senha AS SENHA_USU, " +
    " txt_usuario_status AS STATUS_USU ";
    
    cQryFrom = " FROM ML001111 acs INNER JOIN ML001112 usu ON acs.documentid = usu.documentid " + 
               " INNER JOIN DOCUMENTO d ON d.NR_DOCUMENTO = acs.DOCUMENTID ";

    cQryWhr = " WHERE acs.version = (SELECT MAX(version) FROM ML001111 acsb WHERE acs.documentid = acsb.documentid) " + 
              " AND usu.version = (SELECT MAX(version) FROM ML001112 usub WHERE usu.documentid = usub.documentid) " +
              " AND d.VERSAO_ATIVA != '0' ";
    cQryGrp = "";
    cQryOrd = " ORDER BY acs.documentid DESC ";

    if(constraints != null && constraints.length){
        for(var c=0; c < constraints.length; c++){
            if(constraints[c].fieldName.toUpperCase() != 'SQLLIMIT'){

                if(constraints[c].fieldName.toUpperCase() == 'C_CNPJ_CPF'){
                    var cnpj_cpf = constraints[c].initialValue.trim();
                    cQryWhr += " AND acs.txt_fornecedor_cnpj = '" + cnpj_cpf + "' ";
                }

                if(constraints[c].fieldName.toUpperCase() == 'C_ACESSOS'){
                    var c_usuario = constraints[c].initialValue.trim();
                    var c_senha = constraints[c].finalValue.trim();
                    cQryWhr += " AND txt_usuario_email = '" + c_usuario + "' AND txt_usuario_senha = '" + c_senha + "' ";
                }
            }
        }
    }

    var query = cQryCpo + cQryFrom + cQryWhr + cQryGrp + cQryOrd;
    
    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(query);
        var columnCount = rs.getMetaData().getColumnCount();
        var counter = 0;
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }

                created = true;
            }

            var Arr = new Array();

            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));

                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }

            newDataset.addRow(Arr);

            counter++;
            if (counter > 100000) {
                break;
            }
        }
    } catch (e) {
        newDataset.addColumn("CONST");
        newDataset.addColumn("ERRO");
        newDataset.addColumn("INSTRUCTION");
        newDataset.addRow([constraints, e.message, query]);
    } finally {
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
    }

    return newDataset;
}