function createDataset(fields, constraints, sortFields) {
	
	log.info('CONSULTA FORNECEDOR -----------@@@');

    var gson = new com.google.gson.Gson();
	var newDataset = DatasetBuilder.newDataset();
	
	try {
		
		if (constraints) {
			for (var i = 0; i < constraints.length; i++) {
				if (constraints[i].fieldName == "cTipoId") {
					cTipoId = constraints[i].initialValue;
				}
				if (constraints[i].fieldName == "cNumId") {
					cNumId = constraints[i].initialValue;
				}
				if (constraints[i].fieldName == "cDvId") {
					cDvId = constraints[i].initialValue;
				}
			}
		}
		
		log.info('INICIANDO CONSULTA -----------@@@');
		var cChaveAutent = encriptar();
		log.info('cChaveAutent -----------@@@: ' + cChaveAutent + " " + typeof cChaveAutent);
		var cCodWorkflow = "F";
		/*var cTipoId = "CNPJ";
		var cNumId = "469239340009";
		var cDvId = "53";*/
		var retornoFornecedor = consultaFornecedor(cChaveAutent, cTipoId, cNumId, cDvId, cCodWorkflow);	
        var retornoFornecedorJSON = JSON.parse(gson.toJson(retornoFornecedor[1]));
        log.info('Objeto 0 recebido -----------@@@: ' + JSONUtil.toJSON(retornoFornecedor[0]));
        log.info('Objeto 1 recebido -----------@@@: ' + JSONUtil.toJSON(retornoFornecedor[1]));
        
		//log.info('retornoFornecedorJSON -----------@@@: ' + retornoFornecedorJSON);
		
		if (retornoFornecedor[0] != "Erro") {
			
			newDataset.addColumn("RETORNO");
	        newDataset.addColumn("NOME");
			newDataset.addColumn("NOME_FANTASIA");
			newDataset.addColumn("EMAIL");
			newDataset.addColumn("TELEFONE");
			newDataset.addColumn("CEP");
			newDataset.addColumn("ENDERECO");
			newDataset.addColumn("NUMERO");
			newDataset.addColumn("BAIRRO");
			newDataset.addColumn("CIDADE");
			newDataset.addColumn("CIDADE_COD");
			newDataset.addColumn("ESTADO_COD");
			newDataset.addColumn("BANCO");
			newDataset.addColumn("AGENCIA");
			newDataset.addColumn("CONTA");
			newDataset.addColumn("TIPO_CONTA");
			newDataset.addColumn("TIPO_CONTA_DESC");
			newDataset.addColumn("EMITE_NOTA");
			newDataset.addColumn("DATA_NF");
			
                newDataset.addRow(
                    [
                     	retornoFornecedor[0],
                 		retornoFornecedorJSON[0]['nome'],
                 		retornoFornecedorJSON[0]['nomefantasia'],
                 		retornoFornecedorJSON[0]['internet'],
                 		retornoFornecedorJSON[0]['ddd1'] + " " + retornoFornecedorJSON[0]['telef1'],
                 		retornoFornecedorJSON[0]['cep'],
                 		retornoFornecedorJSON[0]['endereco'],
                 		retornoFornecedorJSON[0]['numero'],
                 		retornoFornecedorJSON[0]['bairro'],
                 		retornoFornecedorJSON[0]['cidade'],
                 		retornoFornecedorJSON[0]['cidadecod'],
                 		retornoFornecedorJSON[0]['estadocod'],
                 		retornoFornecedorJSON[0]['contas']['conta'][0]['banco'],
                 		retornoFornecedorJSON[0]['contas']['conta'][0]['agencia'],
                 		retornoFornecedorJSON[0]['contas']['conta'][0]['nrconta'] + 
                 		retornoFornecedorJSON[0]['contas']['conta'][0]['dvconta'],
                 		retornoFornecedorJSON[0]['contas']['conta'][0]['tipoconta'],
                 		retornoFornecedorJSON[0]['contas']['conta'][0]['tipocontadesc'],
                 		retornoFornecedorJSON[0]['emitenota'],
                 		retornoFornecedorJSON[0]['ctrdatvig']
                    ]
                )
		} else {
			newDataset.addColumn("RETORNO");
			newDataset.addRow(new Array(retornoFornecedor[1]));
		}
		log.info("########## Retorno Fornecedor newDataset =====");
		log.dir(newDataset);

		return newDataset
	} catch (e) {
		log.info('ERROOOOR-----------@@@: ' + e);
		newDataset.addColumn("Erro");
		newDataset.addRow(e);
		return newDataset;
	}
}

function consultaFornecedor(cChaveAutent, cTipoId, cNumId, cDvId, cCodWorkflow) {
	
	log.info('INICIANDO CHAMADA DA API consultaFornecedor -----------@@@')
	
	var properties = {};
	properties["receive.timeout"] = "100000000";

	var supplierService = ServiceManager.getService('Acsel_8');
	var serviceHelper = supplierService.getBean();
	var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
	var service = serviceLocator.getServicosWebServicePort();
	var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
	
	try {
		var consultaFornecedorList = customClient.consultaFornecedor(cChaveAutent, cTipoId, cNumId, cDvId, cCodWorkflow);
		if (consultaFornecedorList['retorno'] == 0 || consultaFornecedorList['retorno'] == "0") {
			var fornecedor = consultaFornecedorList['consultaFornecedorList']['fornecedor'];
			return new Array("OK", fornecedor);
		} else {
			var mensagemRetorno = 'Erro consultaFornecedor: ';
			log.info(mensagemRetorno + consultaFornecedorList['descricaoErro']);
			
			return new Array("Erro", consultaFornecedorList['descricaoErro']);
		}
	} catch (e) {
		log.info('ERRO SERVIÇO consultaFornecedor -----------@@@: ' + e.toString())
		throw e.toString();
	}
}

function encriptar() {
	var token = DatasetFactory.getDataset("ds_getToken", null, null, null);
	
	if (token.rowsCount > 0) {
		if (token.getValue(0, "token") != undefined) {
			return token.getValue(0, "token");			
		}
	}
	return "";
}