function createDataset(fields, constraints, sortFields) {
	log.info('==========Entrou no atualiza obrigacao  -------  ');
	log.dir(constraints);
	try {
		return processResult(callService(fields, constraints, sortFields));
	} catch (e) {
		return processErrorResult(e, constraints);
	}
}

function callService(fields, constraints, sortFields) {
	var serviceData = data();
	var params = serviceData.inputValues;
	var assigns = serviceData.inputAssignments;

	verifyConstraints(serviceData.inputValues, constraints);

	var serviceHelper = ServiceManager.getService(serviceData.fluigService);
	var serviceLocator = serviceHelper.instantiate(serviceData.locatorClass);
	var service = serviceLocator.getServicosWebServicePort();
	var response = service.atualizaObrigacao(getParamValue(params.cChaveAutent, assigns.cChaveAutent), getParamValue(params.nNumOblig, assigns.nNumOblig),
		getParamValue(params.cNumNF, assigns.cNumNF), getParamValue(params.cTipoSerieNF, assigns.cTipoSerieNF),
		getParamValue(params.nMtoBrutoObligLocal, assigns.nMtoBrutoObligLocal), getParamValue(params.nMtoNetoObligLocal, assigns.nMtoNetoObligLocal),
		getParamValue(params.cTextoOblig, assigns.cTextoOblig), getParamValue(params.cCentroCusto, assigns.cCentroCusto),
		getParamValue(params.cTipoPago, assigns.cTipoPago), getParamValue(params.cHistorico, assigns.cHistorico),
		getParamValue(params.cFecGTiaPago, assigns.cFecGTiaPago), getParamValue(params.cPerApuracao, assigns.cPerApuracao),
		getParamValue(params.nCodPagRec, assigns.nCodPagRec), getParamValue(params.cCompINSS, assigns.cCompINSS),
		getParamValue(params.nCodPagINSS, assigns.nCodPagINSS), getParamValue(params.nCodTributo, assigns.nCodTributo),
		getParamValue(params.cCodMunicGARE, assigns.cCodMunicGARE), getParamValue(params.nNumEtiqueta, assigns.nNumEtiqueta),
		getParamValue(params.nNumParcela, assigns.nNumParcela), getParamValue(params.cOpcaoPAG, assigns.cOpcaoPAG),
		getParamValue(params.nExercicio, assigns.nExercicio), getParamValue(params.nRenavam, assigns.nRenavam),
		getParamValue(params.cCodEstadoDPVAT, assigns.cCodEstadoDPVAT), getParamValue(params.nCodMunicDPVAT, assigns.nCodMunicDPVAT),
		getParamValue(params.cPlaca, assigns.cPlaca), getParamValue(params.cMesAnoRef, assigns.cMesAnoRef),
		getParamValue(params.nValorBoleto, assigns.nValorBoleto), getParamValue(params.cLinhaDigit, assigns.cLinhaDigit),
		getParamValue(params.cNumDocto, assigns.cNumDocto), getParamValue(params.cCodWorkFlow, assigns.cCodWorkFlow)
	);

	return response;
}

function defineStructure() {
	addColumn("descricaoErro");
	addColumn("retorno");
}

function onSync(lastSyncDate) {
	var serviceData = data();
	var synchronizedDataset = DatasetBuilder.newDataset();

	try {
		var resultDataset = processResult(callService());
		if (resultDataset != null) {
			var values = resultDataset.getValues();
			for (var i = 0; i < values.length; i++) {
				synchronizedDataset.addRow(values[i]);
			}
		}

	} catch (e) {
		log.info('Dataset synchronization error : ' + e.message);

	}
	return synchronizedDataset;
}

function verifyConstraints(params, constraints) {
	if (constraints != null) {
		for (var i = 0; i < constraints.length; i++) {
			try {
				// params[constraints[i].fieldName] = JSON.parse(constraints[i].initialValue);
				params[constraints[i].fieldName] = constraints[i].initialValue;
			} catch (e) {
				params[constraints[i].fieldName] = constraints[i].initialValue;
			}
		}
		log.info('==========Entrou no atualiza obrigacao verifyConstraints 7-------  ');

		log.dir(params);
		log.dir(constraints);
	}
}

function processResult(result) {
	var dataset = DatasetBuilder.newDataset();

	dataset.addColumn("descricaoErro");
	dataset.addColumn("retorno");

	dataset.addRow([result.getDescricaoErro(), result.getRetorno()]);

	return dataset;
}

function processErrorResult(error, constraints) {
	var dataset = DatasetBuilder.newDataset();

	var params = data().inputValues;
	verifyConstraints(params, constraints);

	dataset.addColumn('error');
	dataset.addColumn('cOpcaoPAG');
	dataset.addColumn('cTextoOblig');
	dataset.addColumn('nMtoBrutoObligLocal');
	dataset.addColumn('cMesAnoRef');
	dataset.addColumn('nCodTributo');
	dataset.addColumn('cLinhaDigit');
	dataset.addColumn('cFecGTiaPago');
	dataset.addColumn('cCodEstadoDPVAT');
	dataset.addColumn('cCompINSS');
	dataset.addColumn('cTipoPago');
	dataset.addColumn('nNumParcela');
	dataset.addColumn('cTipoSerieNF');
	dataset.addColumn('cCodWorkFlow');
	dataset.addColumn('nValorBoleto');
	dataset.addColumn('cPerApuracao');
	dataset.addColumn('cCodMunicGARE');
	dataset.addColumn('cPlaca');
	dataset.addColumn('cNumNF');
	dataset.addColumn('cNumDocto');
	dataset.addColumn('cChaveAutent');
	dataset.addColumn('nCodMunicDPVAT');
	dataset.addColumn('nCodPagINSS');
	dataset.addColumn('nCodPagRec');
	dataset.addColumn('cCentroCusto');
	dataset.addColumn('nExercicio');
	dataset.addColumn('nNumOblig');
	dataset.addColumn('nNumEtiqueta');
	dataset.addColumn('nRenavam');
	dataset.addColumn('cHistorico');
	dataset.addColumn('nMtoNetoObligLocal');

	var cOpcaoPAG = isPrimitive(params.cOpcaoPAG) ? params.cOpcaoPAG : JSONUtil.toJSON(params.cOpcaoPAG);
	var cTextoOblig = isPrimitive(params.cTextoOblig) ? params.cTextoOblig : JSONUtil.toJSON(params.cTextoOblig);
	var nMtoBrutoObligLocal = isPrimitive(params.nMtoBrutoObligLocal) ? params.nMtoBrutoObligLocal : JSONUtil.toJSON(params.nMtoBrutoObligLocal);
	var cMesAnoRef = isPrimitive(params.cMesAnoRef) ? params.cMesAnoRef : JSONUtil.toJSON(params.cMesAnoRef);
	var nCodTributo = isPrimitive(params.nCodTributo) ? params.nCodTributo : JSONUtil.toJSON(params.nCodTributo);
	var cLinhaDigit = isPrimitive(params.cLinhaDigit) ? params.cLinhaDigit : JSONUtil.toJSON(params.cLinhaDigit);
	var cFecGTiaPago = isPrimitive(params.cFecGTiaPago) ? params.cFecGTiaPago : JSONUtil.toJSON(params.cFecGTiaPago);
	var cCodEstadoDPVAT = isPrimitive(params.cCodEstadoDPVAT) ? params.cCodEstadoDPVAT : JSONUtil.toJSON(params.cCodEstadoDPVAT);
	var cCompINSS = isPrimitive(params.cCompINSS) ? params.cCompINSS : JSONUtil.toJSON(params.cCompINSS);
	var cTipoPago = isPrimitive(params.cTipoPago) ? params.cTipoPago : JSONUtil.toJSON(params.cTipoPago);
	var nNumParcela = isPrimitive(params.nNumParcela) ? params.nNumParcela : JSONUtil.toJSON(params.nNumParcela);
	var cTipoSerieNF = isPrimitive(params.cTipoSerieNF) ? params.cTipoSerieNF : JSONUtil.toJSON(params.cTipoSerieNF);
	var cCodWorkFlow = isPrimitive(params.cCodWorkFlow) ? params.cCodWorkFlow : JSONUtil.toJSON(params.cCodWorkFlow);
	var nValorBoleto = isPrimitive(params.nValorBoleto) ? params.nValorBoleto : JSONUtil.toJSON(params.nValorBoleto);
	var cPerApuracao = isPrimitive(params.cPerApuracao) ? params.cPerApuracao : JSONUtil.toJSON(params.cPerApuracao);
	var cCodMunicGARE = isPrimitive(params.cCodMunicGARE) ? params.cCodMunicGARE : JSONUtil.toJSON(params.cCodMunicGARE);
	var cPlaca = isPrimitive(params.cPlaca) ? params.cPlaca : JSONUtil.toJSON(params.cPlaca);
	var cNumNF = isPrimitive(params.cNumNF) ? params.cNumNF : JSONUtil.toJSON(params.cNumNF);
	var cNumDocto = isPrimitive(params.cNumDocto) ? params.cNumDocto : JSONUtil.toJSON(params.cNumDocto);
	var cChaveAutent = isPrimitive(params.cChaveAutent) ? params.cChaveAutent : JSONUtil.toJSON(params.cChaveAutent);
	var nCodMunicDPVAT = isPrimitive(params.nCodMunicDPVAT) ? params.nCodMunicDPVAT : JSONUtil.toJSON(params.nCodMunicDPVAT);
	var nCodPagINSS = isPrimitive(params.nCodPagINSS) ? params.nCodPagINSS : JSONUtil.toJSON(params.nCodPagINSS);
	var nCodPagRec = isPrimitive(params.nCodPagRec) ? params.nCodPagRec : JSONUtil.toJSON(params.nCodPagRec);
	var cCentroCusto = isPrimitive(params.cCentroCusto) ? params.cCentroCusto : JSONUtil.toJSON(params.cCentroCusto);
	var nExercicio = isPrimitive(params.nExercicio) ? params.nExercicio : JSONUtil.toJSON(params.nExercicio);
	var nNumOblig = isPrimitive(params.nNumOblig) ? params.nNumOblig : JSONUtil.toJSON(params.nNumOblig);
	var nNumEtiqueta = isPrimitive(params.nNumEtiqueta) ? params.nNumEtiqueta : JSONUtil.toJSON(params.nNumEtiqueta);
	var nRenavam = isPrimitive(params.nRenavam) ? params.nRenavam : JSONUtil.toJSON(params.nRenavam);
	var cHistorico = isPrimitive(params.cHistorico) ? params.cHistorico : JSONUtil.toJSON(params.cHistorico);
	var nMtoNetoObligLocal = isPrimitive(params.nMtoNetoObligLocal) ? params.nMtoNetoObligLocal : JSONUtil.toJSON(params.nMtoNetoObligLocal);

	dataset.addRow([error.message, cOpcaoPAG, cTextoOblig, nMtoBrutoObligLocal, cMesAnoRef, nCodTributo, cLinhaDigit, cFecGTiaPago, cCodEstadoDPVAT, cCompINSS, cTipoPago, nNumParcela, cTipoSerieNF, cCodWorkFlow, nValorBoleto, cPerApuracao, cCodMunicGARE, cPlaca, cNumNF, cNumDocto, cChaveAutent, nCodMunicDPVAT, nCodPagINSS, nCodPagRec, cCentroCusto, nExercicio, nNumOblig, nNumEtiqueta, nRenavam, cHistorico, nMtoNetoObligLocal]);

	return dataset;
}

function getParamValue(param, assignment) {

	if (assignment == 'VARIABLE') {
		return getValue(param);
	} else if (assignment == 'NULL') {
		return null;
	}
	return param;
}

function hasValue(value) {
	return value !== null && value !== undefined;
}

function isPrimitive(value) {
	return ((typeof value === 'string') || value.substring !== undefined) || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined';
}


function getObjectFactory(serviceHelper) {
	var objectFactory = serviceHelper.instantiate("com.assurant.servicoswebservice.ObjectFactory");

	return objectFactory;
}



function data() {
	return {
		"fluigService": "Acsel_4",
		"operation": "atualizaObrigacao",
		"soapService": "AizServicosWebBeanService",
		"portType": "ServicosWebService",
		"locatorClass": "com.assurant.servicoswebservice.AizServicosWebBeanService",
		"portTypeMethod": "getServicosWebServicePort",
		"parameters": [],
		"inputValues": {
			"cOpcaoPAG": "",
			"cTextoOblig": "",
			"nMtoBrutoObligLocal": "",
			"cMesAnoRef": "",
			"nCodTributo": "",
			"cLinhaDigit": "",
			"cFecGTiaPago": "",
			"cCodEstadoDPVAT": "",
			"cCompINSS": "",
			"cTipoPago": "",
			"nNumParcela": "",
			"cTipoSerieNF": "",
			"cCodWorkFlow": "",
			"nValorBoleto": "",
			"cPerApuracao": "",
			"cCodMunicGARE": "",
			"cPlaca": "",
			"cNumNF": "",
			"cNumDocto": "",
			"cChaveAutent": encriptar(),
			"nCodMunicDPVAT": "",
			"nCodPagINSS": "",
			"nCodPagRec": "",
			"cCentroCusto": "",
			"nExercicio": "",
			"nNumOblig": "",
			"nNumEtiqueta": "",
			"nRenavam": "",
			"cHistorico": "",
			"nMtoNetoObligLocal": ""
		},
		"inputAssignments": {
			"cOpcaoPAG": "VALUE",
			"cTextoOblig": "VALUE",
			"nMtoBrutoObligLocal": "VALUE",
			"cMesAnoRef": "VALUE",
			"nCodTributo": "VALUE",
			"cLinhaDigit": "VALUE",
			"cFecGTiaPago": "VALUE",
			"cCodEstadoDPVAT": "VALUE",
			"cCompINSS": "VALUE",
			"cTipoPago": "VALUE",
			"nNumParcela": "VALUE",
			"cTipoSerieNF": "VALUE",
			"cCodWorkFlow": "VALUE",
			"nValorBoleto": "VALUE",
			"cPerApuracao": "VALUE",
			"cCodMunicGARE": "VALUE",
			"cPlaca": "VALUE",
			"cNumNF": "VALUE",
			"cNumDocto": "VALUE",
			"cChaveAutent": "VALUE",
			"nCodMunicDPVAT": "VALUE",
			"nCodPagINSS": "VALUE",
			"nCodPagRec": "VALUE",
			"cCentroCusto": "VALUE",
			"nExercicio": "VALUE",
			"nNumOblig": "VALUE",
			"nNumEtiqueta": "VALUE",
			"nRenavam": "VALUE",
			"cHistorico": "VALUE",
			"nMtoNetoObligLocal": "VALUE"
		},
		"outputValues": {},
		"outputAssignments": {},
		"extraParams": {
			"enabled": false
		}
	}
}

function stringToBoolean(param) {
	if (typeof (param) === 'boolean') {
		return param;
	}
	if (param == null || param === 'null') {
		return false;
	}
	switch (param.toLowerCase().trim()) {
		case 'true': case 'yes': case '1': return true;
		case 'false': case 'no': case '0': case null: return false;
		default: return Boolean(param);
	}
}

function encriptar() {

	var token = DatasetFactory.getDataset("ds_getToken", null, null, null);

	if (token.rowsCount > 0) {
		if (token.getValue(0, "token") != undefined) {
			return token.getValue(0, "token");
		}
	}

	return "";
}