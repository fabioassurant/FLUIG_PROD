function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
    log.info("### DATASET INCLUDE MASTERSAF DW NEW ###");
    
    var newDataset = DatasetBuilder.newDataset();
    
    newDataset.addColumn('Status');
    newDataset.addColumn('Tabela');
    newDataset.addColumn('Response');
    
    if(fields){
        var id = fields[0];
    }
    
    if(constraints){
        var returnsValidateValues = {
            SAFX04 : null,
            SAFX07 : null,
            SAFX09 : null
        };

        for(var x = 0; x < constraints.length; x++){
            var objJSON = JSON.parse(constraints[x].initialValue);
            var returnValidateValues = validateValues(constraints[x].fieldName, objJSON);

            if(returnValidateValues.status == 'success'){
                returnsValidateValues[constraints[x].fieldName] = returnValidateValues.response;
                
            }else{
                for(var y = 0; y < returnValidateValues.response.length; y++){
                    newDataset.addRow(returnValidateValues.response[y]);
                }
            }
        }
  
        if(returnsValidateValues.SAFX04 != null && returnsValidateValues.SAFX07 != null && returnsValidateValues.SAFX09 != null){
            for(var x = 0; x < constraints.length; x++){
                if(constraints[x].fieldName == 'SAFX04'){
                    var retunDtsInsert = DatasetFactory.getDataset('dts_setSAFX04_MFX', returnsValidateValues.SAFX04, null, null);
                }
                else if(constraints[x].fieldName == 'SAFX07'){
                    var retunDtsInsert = DatasetFactory.getDataset('dts_setSAFX07_MFX', returnsValidateValues.SAFX07, null, null);
                }
                else if(constraints[x].fieldName == 'SAFX09'){
                    var retunDtsInsert = DatasetFactory.getDataset('dts_setSAFX09_MFX', returnsValidateValues.SAFX09, null, null);
                }
    
                if(retunDtsInsert){
                    if(retunDtsInsert.values.length > 0){
                        if(retunDtsInsert.getValue(0, 'Status') == 'Sucess'){
                            newDataset.addRow([
                                retunDtsInsert.getValue(0, 'Status'),
                                retunDtsInsert.getValue(0, 'Table'),
                                retunDtsInsert.getValue(0, 'Response')
                            ]);
                        }
                        else{
                            deleteData(id);
                            x = constraints.length;

                            newDataset.addRow([
                                'ERRO',
                                constraints[x].fieldName,
                                'Ocorreu um erro no Insert!'
                            ]);
                        }
                    }
                }
            }
        }

    }
    
    
    //Funcão para validar tamanho, tipo e obrigatoriedade dos valores (se caso nenhum parametro estiver incorreto ele retorna os parametros a ser passados para o dts de insert)
    function validateValues(table, params){
        log.info('## validateValues() ##');
        
        var dtsColumns = DatasetFactory.getDataset('dts_getColumns_MFX', [table], null, null);
        var returnColumns = new Array(), returnParams = new Array();
        var status = 'success';

        for(var i = 0; i < dtsColumns.values.length; i++){
            var column = {
                name : dtsColumns.getValue(i, 'COLUMN_NAME'),
                type : convertTypeSQLtoJS(dtsColumns.getValue(i, 'DATA_TYPE')),
                length : dtsColumns.getValue(i, 'DATA_LENGTH'),
                required : dtsColumns.getValue(i, 'NULLABLE')
            };
            
            if(params[column.name]){

                //Valida o tamanho do campo  
                if(params[column.name].length > column.length){
                    status = 'error';
                    returnColumns.push(['ERRO', table, 'Erro no campo : ' + column.name + ' | Tamanho incorreto! | Tamanho correto : ' + column.length]);
                }
                
                //Valida o tipo do campo
                if(typeof params[column.name] != column.type){
                    status = 'error';
                    returnColumns.push(['ERRO', table, 'Erro no campo : ' + column.name + ' | Tipo incorreto! | Tipo correto : ' + column.type]);
                }

                if(status == 'success'){
                    var objParams = new Object();
                    objParams[column.name] = params[column.name];
                    objParams['Type'] = column.type;

                    returnParams.push(JSON.stringify(objParams));
                }
    

            }else{

                //Valida obrigatoriedade do campo
                if(column.required == 'N'){
                    status = 'error';
                    returnColumns.push([table, 'O Campo : ' + column.name + ' é obrigatório!', 'ERRO']);
                }
            }
        }
        return {
            status : status,
            response : status == 'success' ? returnParams : returnColumns
        };
    }

    //Converte o nome do tipo das variaveis de SQL para JS
    function convertTypeSQLtoJS(type){
        var typeJS = '';
    
        if(type == 'VARCHAR2' || type == 'CHAR'){
            typeJS = 'string';
    
        }
        else if(type == 'NUMBER'){
            typeJS = 'number'
        }
    
        return typeJS;
    }

    //Função para deletar um registro caso um dos inserts tiver inconsistencias
    function deleteData(id){
        var returnDtsDelete = DatasetFactory.getDataset('dts_deleteMastersafDW_MFX', [id], null, null);

        if(returnDtsDelete.values.length > 0){
            return returnDtsDelete.getValue(0, 'Status');
        }
    }

    return newDataset;

}function onMobileSync(user) {

}