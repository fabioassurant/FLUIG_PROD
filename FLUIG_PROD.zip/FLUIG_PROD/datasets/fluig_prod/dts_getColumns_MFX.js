function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
    log.info('### DATASET GET COLUMNS ###');

    var newDataset = DatasetBuilder.newDataset();
    var dataSource = '/jdbc/MASTERSAF_DW_CONECT';
    var ic = new javax.naming.InitialContext();
    var ds = ic.lookup(dataSource);
    var created = false;


    if(fields[0]){
        var table = fields[0];
    }

    if(table){
        var myQuery = "SELECT COLUMN_NAME, DATA_TYPE, DATA_LENGTH, NULLABLE FROM ALL_TAB_COLUMNS WHERE TABLE_NAME = '" + table + "'";

        try{
            var conn = ds.getConnection();
            var stmt = conn.createStatement();
            var rs = stmt.executeQuery(myQuery);
            var columnCount = rs.getMetaData().getColumnCount();
    
            while(rs.next()){
                if(!created){
                    for(var i = 1; i <=columnCount; i++){
                        newDataset.addColumn(rs.getMetaData().getColumnName(i));
                    }
                    created = true;
                }
    
                var arr = new Array();
                for(var i = 1; i <= columnCount; i++){
                    var obj = rs.getObject(rs.getMetaData().getColumnName(i));
    
                    if(null != obj){
                        arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
    
                    }else{
                        arr[i - 1] = 'null';
                     
                    }
                }
    
                newDataset.addRow(arr);
            }
        }catch (error){
            newDataset.addColumn('Status');
            newDataset.addColumn('Response');
            newDataset.addColumn('Insert Query');
            newDataset.addRow(['Erro', error, insertQuery]);
    
        }finally{
           if(rs != null){
               rs.close();
           }
        
           if(stmt != null){
               stmt.close();
           }
        
           if(conn != null){
               conn.close();
           }
        }
    }else{
        newDataset.addColumn('Response');
        newDataset.addColumn('Status');
        newDataset.addRow(['É necessário passar os parametros', 'Erro']);
    }

    return newDataset;

}function onMobileSync(user) {

}