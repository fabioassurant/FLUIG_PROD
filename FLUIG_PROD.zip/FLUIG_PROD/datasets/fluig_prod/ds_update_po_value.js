function createDataset(fields, constraints, sortFields) {
    var dataset = DatasetBuilder.newDataset();
    var periodicService = ServiceManager.getServiceInstance("ECMCardService");
    var serviceLocator = periodicService.instantiate("com.totvs.technology.ecm.dm.ws.ECMCardServiceService");
    var service = serviceLocator.getCardServicePort();
    var CardFieldDtoArray = periodicService.instantiate("com.totvs.technology.ecm.dm.ws.CardFieldDtoArray");
    var params = {};
    var processInstanceId = [];
    if (constraints) {
        for (let i = 0; i < constraints.length; i++) {
            if (constraints[i].fieldName == "solicitacao") {
                processInstanceId.push(constraints[i].initialValue);
            } else {
                params[constraints[i].fieldName] = constraints[i].initialValue;
            }
        }
    }
    var valorPO = [];
    var dsPO = [];
    for (i in processInstanceId) {
        var cs = [];
        var constraintDsWP = DatasetFactory.createConstraint("workflowProcessPK.processInstanceId", processInstanceId[i], processInstanceId[i], ConstraintType.MUST);
        var colunasWP = ["workflowProcessPK.processInstanceId", "cardDocumentId"];
        var datasetWP = DatasetFactory.getDataset("workflowProcess", colunasWP, [constraintDsWP], null);
        var docId = datasetWP.getValue(0, 'cardDocumentId');
        cs.push(DatasetFactory.createConstraint('documentid', '' + docId, '' + docId, ConstraintType.MUST));
        var ds = DatasetFactory.getDataset("ds_processo_po_assurant", null, cs, null);
        var dsLength = ds.rowsCount - 1;
        valorPO.push({
            'PO': '' + ds.getValue(dsLength, "metadata#id"),
            'valor': stringToNumber(ds.getValue(dsLength, "saldo")),
            'dataPO': ds.getValue(dsLength, "inicioPO")
        });
    }

    var paramFields = Object.keys(params);
    var valorDesc = stringToNumber(params["valorObg"]);
    for (var i = 0; i < valorPO.length; i++) { //onde muda o valor do campo 
        if (valorDesc >= valorPO[i].valor) {
            valorDesc = valorDesc - valorPO[i].valor;
            valorPO[i].valor = 0;
        } else {
            valorPO[i].valor = valorPO[i].valor - valorDesc;
            valorDesc = 0;
        }
        var cardField = periodicService.instantiate('com.totvs.technology.ecm.dm.ws.CardFieldDto');
        cardField.setField("saldo");
        cardField.setValue(numberToReal(valorPO[i].valor));
        CardFieldDtoArray.getItem().add(cardField);
        var companyId = 1;
        var user = 'admin';
        var password = 'LcHpC7kLNb6#497';
        var cardId = valorPO[i].PO;
        var update = service.updateCardData(companyId, user, password, cardId, CardFieldDtoArray);
    }


    return dataset;
}

function numberToReal(numero) {
    if (numero < 0) {
        var numero = numero.toFixed(2).split('.');
        numero[0] = numero[0].replace('-', '')
        numero[0] = numero[0].split(/(?=(?:...)*$)/).join('.');
        return '-' + numero.join(',');
    } else {
        var numero = numero.toFixed(2).split('.');
        numero[0] = numero[0].split(/(?=(?:...)*$)/).join('.');
        return numero.join(',');
    }
}

function stringToNumber(numberInString) {
    while (numberInString.indexOf(".") > -1) {
        numberInString = numberInString.replace(".", "");
    }
    numberInString = numberInString.replace(",", ".");
    return Number(numberInString);
}