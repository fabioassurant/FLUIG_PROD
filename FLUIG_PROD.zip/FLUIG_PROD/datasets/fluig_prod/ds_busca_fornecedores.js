function defineStructure() {
    addColumn("TIPOID");
    addColumn("CNPJ");
    addColumn("NOME");
    addColumn("ENDERECO");
    addColumn("CIDADE");
    addColumn("CEP");

    setKey(["CNPJ", "NOME"]);
    addIndex(["CNPJ"]);
    addIndex(["CNPJ", "NOME", "ENDERECO"]);
}

function onSync(lastSyncDate) {
    var newDataset = DatasetBuilder.newDataset();
    var ic = new javax.naming.InitialContext()
    var created = false;
    var filtro = '';
    var banco = '';
    var zoom = 0;
    var dataSource = 'jdbc/';
    var servico = 'Conector_Acsel';

    var query = "SELECT  T.TIPOID, T.NUMID || T.DVID AS CNPJ, T.NOMTER AS NOME,T.DIREC AS ENDERECO ,C.DESCCIUDAD AS CIDADE ,T.ZIP AS CEP FROM TERCERO T ,PROVEEDOR P ,CIUDAD C WHERE T.STSTER = 'ACT' AND T.TIPOID IN ('CNPJ','CPF') AND P.TIPOID = T.TIPOID AND P.NUMID = T.NUMID AND P.DVID = T.DVID  AND P.STSPRO = 'ACT'  AND C.CODPAIS = 'BRA'  AND C.CODESTADO = T.CODESTADO  AND C.CODCIUDAD = T.CODCIUDAD"

    var ds = ic.lookup(dataSource + '/' + servico)

    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(query);
        var columnCount = rs.getMetaData().getColumnCount();
        var counter = 0;
        while (rs.next()) {

            var Arr = new Array();

            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));

                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }

            newDataset.addOrUpdateRow(Arr);

            counter++;
            if (counter > 100000) {
                break;
            }
        }
    } catch (e) {
        newDataset.addRow(new Array(e.message));
    } finally {
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
    }

    return newDataset;
}

function createDataset(fields, constraints, sortFields) {

}

function onMobileSync(user) {

}