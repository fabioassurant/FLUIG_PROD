function createDataset(fields, constraints, sortFields) {
	var cTipoOblig = "";
	var cTipoId = "";
	var cNumId = "";
	var cDvId = "";
	var ds = DatasetBuilder.newDataset();
	log.info("########## entrou no Retorno da Lista =====");
	log.dir(constraints);
	try {
		if (constraints) {
			for (var i = 0; i < constraints.length; i++) {
				if (constraints[i].fieldName == "cTipoOblig") {
					cTipoOblig = constraints[i].initialValue;
				}
				if (constraints[i].fieldName == "cTipoId") {
					cTipoId = constraints[i].initialValue;
				}
				if (constraints[i].fieldName == "cNumId") {
					cNumId = constraints[i].initialValue;
				}
				if (constraints[i].fieldName == "cDvId") {
					cDvId = constraints[i].initialValue;
				}
			}
		}

		var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
		var nNumOblig = ""
		var cCodWorkflow = "F"
		
		var retornoLista = listaObrigacoes(cChaveAutent, cTipoOblig, cTipoId, cNumId, cDvId, nNumOblig, cCodWorkflow)

		log.info("########## Retorno da Lista =====");
		log.dir(retornoLista);

		if (retornoLista != "Erro") {
			ds.addColumn("numoblig");
			ds.addColumn("tipoid");
			ds.addColumn("dvid");
			ds.addColumn("tipooblig");
			ds.addColumn("stsoblig");
			ds.addColumn("fecgtiapago");
			ds.addColumn("mtobrutoobliglocal");
			ds.addColumn("mtonetoobliglocal");
			ds.addColumn("dptoemi");
			ds.addColumn("textooblig");
			ds.addColumn("codmoneda");
			ds.addColumn("codinterlider");
			ds.addColumn("fecanul");
			ds.addColumn("emitecheque");
			ds.addColumn("codoperpag");
			ds.addColumn("centrocusto");
			ds.addColumn("numdoctobanco");
			ds.addColumn("tipopago");
			ds.addColumn("historico");
			ds.addColumn("perapuracao");
			ds.addColumn("codpagrec");
			ds.addColumn("compinss");
			ds.addColumn("codpaginss");
			ds.addColumn("codtributo");
			ds.addColumn("codmunicgare");
			ds.addColumn("numetiqueta");
			ds.addColumn("numparcela");
			ds.addColumn("opcaopag");
			ds.addColumn("exercicio");
			ds.addColumn("renavam");
			ds.addColumn("codestadodpvat");
			ds.addColumn("codmunicdpvat");
			ds.addColumn("placa");
			ds.addColumn("mesanoref");
			ds.addColumn("valorboleto");
			ds.addColumn("linhadigit");


			for (var i = 0; i < retornoLista.size(); i++) {
				log.info('retornoLista ===>')
				log.info('retornoLista ===>' + retornoLista.get(i).getNUMOBLIG())
				ds.addRow(
					[
						retornoLista.get(i).getNUMOBLIG(),
						retornoLista.get(i).getTIPOID(),
						retornoLista.get(i).getDVID(),
						retornoLista.get(i).getTIPOOBLIG(),
						retornoLista.get(i).getSTSOBLIG(),
						retornoLista.get(i).getFECGTIAPAGO(), 
						retornoLista.get(i).getMTOBRUTOOBLIGLOCAL(), 
						retornoLista.get(i).getMTONETOOBLIGLOCAL(), 
						retornoLista.get(i).getDPTOEMI(), 
						retornoLista.get(i).getTEXTOOBLIG(), 
						retornoLista.get(i).getCODMONEDA(), 
						retornoLista.get(i).getCODINTERLIDER(), 
						retornoLista.get(i).getFECANUL(), 
						retornoLista.get(i).getEMITECHEQUE(), 
						retornoLista.get(i).getCODOPERPAG(), 
						retornoLista.get(i).getCENTROCUSTO(), 
						retornoLista.get(i).getNUMDOCTOBANCO(), 
						retornoLista.get(i).getTIPOPAGO(), 
						retornoLista.get(i).getHISTORICO(), 
						retornoLista.get(i).getPERAPURACAO(), 
						retornoLista.get(i).getCODPAGREC(), 
						retornoLista.get(i).getCOMPINSS(), 
						retornoLista.get(i).getCODPAGINSS(), 
						retornoLista.get(i).getCODTRIBUTO(), 
						retornoLista.get(i).getCODMUNICGARE(), 
						retornoLista.get(i).getNUMETIQUETA(), 
						retornoLista.get(i).getNUMPARCELA(), 
						retornoLista.get(i).getOPCAOPAG(), 
						retornoLista.get(i).getEXERCICIO(), 
						retornoLista.get(i).getRENAVAM(), 
						retornoLista.get(i).getCODESTADODPVAT(), 
						retornoLista.get(i).getCODMUNICDPVAT(), 
						retornoLista.get(i).getPLACA(), 
						retornoLista.get(i).getMESANOREF(), 
						retornoLista.get(i).getVALORBOLETO(),
						retornoLista.get(i).getLINHADIGIT()
					]
				)
			}
			

		} else {
			ds.addColumn("Erro");
			ds.addRow([retornoLista]);
		}
		log.info("########## Retorno da Lista ds =====");
		log.dir(ds);

		return ds
	} catch (e) {
		log.info('ERROOOOR-----------@@@')
		log.dir(e)
		ds.addColumn("Erro");
		ds.addRow(e);
		return ds;
	}
}

function listaObrigacoes(aut, cTipoOblig, cTipoId, cNumId, cDvId, nNumOblig, cCodWorkflow) {
	log.info('Inicio integração webservice Lista Obrigações ****************')
	log.dir(aut)
	log.dir(cTipoOblig)
	log.dir(cTipoId)
	log.dir(cNumId)
	log.dir(cDvId)
	log.dir(nNumOblig)
	log.dir(cCodWorkflow)


	var properties = {};
	properties["receive.timeout"] = "100000000";

	var supplierService = ServiceManager.getService('Acsel_4');
	var serviceHelper = supplierService.getBean();
	var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
	var service = serviceLocator.getServicosWebServicePort();
	var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
	try {
		var RetornoListaObrigacoes = customClient.listaObrigacoes(aut, cTipoOblig, cTipoId, cNumId, cDvId, nNumOblig, cCodWorkflow)

		if (RetornoListaObrigacoes['retorno'] == 0 || RetornoListaObrigacoes['retorno'] == "0") {
			log.info('Entrou no if de Retorna Lista Obrigações######')
			log.dir(RetornoListaObrigacoes)

			return RetornoListaObrigacoes['listaObrigacoesList']['obrigacao']
		} else {
			log.info('Erro Return Lista Obrigações@@@@')
			log.dir(RetornoListaObrigacoes['descricaoErro'])
			var mensagemRetorno = 'Erro'
			return mensagemRetorno
		}
	} catch (e) {
		throw e.toString()
	}

	// if (RetornoFinalizaObrigacao.getRetorno() != 0) {
	//     if (restart) {
	//        customClient.finalizaObrigacao(aut, numObrig, cIndAutomatico, cCodWorkflow);
	//     }
	//     throw 'Erro: webservice retornou o valor ' + RetornoGravaDetalheObrigacao.getRetorno()
	// }
}