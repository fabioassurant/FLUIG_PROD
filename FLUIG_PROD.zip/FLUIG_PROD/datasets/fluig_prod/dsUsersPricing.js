function createDataset(fields, constraints, sortFields) {
    var dataset = DatasetFactory.newDataset();
    dataset.addColumn("userId");
    dataset.addColumn("userName");

    var cstGroup = DatasetFactory.createConstraint("colleagueGroupPK.groupId", "PRICING", "PRICING", ConstraintType.MUST);
    var dsGroupColleague = DatasetFactory.getDataset("colleagueGroup", null, [cstGroup], null);

    for (var i = 0; i < dsGroupColleague.rowsCount; i++) {
        var groupUserId = dsGroupColleague.getValue(i, "colleagueGroupPK.colleagueId");
        var cstUserId = DatasetFactory.createConstraint("colleaguePK.colleagueId", groupUserId, groupUserId, ConstraintType.MUST);
        var dsColleague = DatasetFactory.getDataset("colleague", null, [cstUserId], null);
        var userId = dsColleague.getValue(0, "colleaguePK.colleagueId");
        var userName = dsColleague.getValue(0, "colleagueName");
        dataset.addRow([userId, userName]);
    }

    return dataset;
}