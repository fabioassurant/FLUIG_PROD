function createDataset(fields, constraints, sortFields) {

    var cnpj = "";
    if (constraints) {
        for (var i = 0; i < constraints.length; i++) {
            if (constraints[i].fieldName == "cnpj") {
                cnpj = constraints[i].initialValue;
            }
        }
    }
    var newDataset = DatasetBuilder.newDataset();
    var ic = new javax.naming.InitialContext()
    var created = false;
    var filtro = '';
    var banco = '';
    var zoom = 0;
    var dataSource = '/jdbc';
    var servico = 'Conector_Acsel';

    var query = "select TIPOID, NUMID, DVID, TIPO_PAGO, CODENTFINAN, AGENCIA, DVAGENCIA ,CUENTACOR, DVCUENTACOR ,TIPO_CONTA from forma_pago where numid||dvid = '" + cnpj + "' and inddesativado = 'N' and MARCA = 'S'";

    var ds = ic.lookup(dataSource + '/' + servico)

    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(query);
        var columnCount = rs.getMetaData().getColumnCount();
        var counter = 0;
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }

                created = true;
            }

            var Arr = new Array();

            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));

                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }

            newDataset.addRow(Arr);
            counter++;
            if (counter > 10) {
                break;
            }
        }
    } catch (e) {
        newDataset.addColumn("ERRO");
        newDataset.addRow(new Array(e.message));
    } finally {
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
    }

    return newDataset;
}