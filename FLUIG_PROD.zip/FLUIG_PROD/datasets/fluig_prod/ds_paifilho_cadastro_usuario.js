function createDataset(fields, constraints, sortFields) {
    var dataset = DatasetBuilder.newDataset();
    dataset.addColumn("NumProcesso");
    dataset.addColumn("NumFormulario");
    dataset.addColumn("Usuario");
    dataset.addColumn("UsuarioId");
    dataset.addColumn("namCentroCusto");
    dataset.addColumn("codCentroCusto");
    dataset.addColumn("CPF");

    var constraints = new Array();
    constraints.push(DatasetFactory.createConstraint("metadata#active", true, true, ConstraintType.MUST));

    var datasetPrincipal = DatasetFactory.getDataset("ds_usuario_cpf", null, constraints, null);

    for (var i = 0; i < datasetPrincipal.rowsCount; i++) {
        var WKNumProces = datasetPrincipal.getValue(i, "WKNumProces");
        var documentId = datasetPrincipal.getValue(i, "metadata#id");
        var documentVersion = datasetPrincipal.getValue(i, "metadata#version");

        var constraintsFilhos = new Array();
        constraintsFilhos.push(DatasetFactory.createConstraint("tablename", "tabelaUserCpf", "tabelaUserCpf", ConstraintType.MUST));
        constraintsFilhos.push(DatasetFactory.createConstraint("metadata#id", documentId, documentId, ConstraintType.MUST));
        constraintsFilhos.push(DatasetFactory.createConstraint("metadata#version", documentVersion, documentVersion, ConstraintType.MUST));

        var datasetFilhos = DatasetFactory.getDataset("ds_usuario_cpf", null, constraintsFilhos, null);

        for (var j = 0; j < datasetFilhos.rowsCount; j++) {
            dataset.addRow(new Array(
                WKNumProces,
                documentId,
                datasetFilhos.getValue(j, "zoomColleague"),
                datasetFilhos.getValue(j, "userId"),
                datasetFilhos.getValue(j, "centroCusto"),
                datasetFilhos.getValue(j, "centroCustoId"),
                datasetFilhos.getValue(j, "cpf")));
        }
    }

    return dataset;

}