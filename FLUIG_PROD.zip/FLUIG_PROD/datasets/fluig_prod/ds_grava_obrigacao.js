function createDataset(fields, constraints, sortFields) {
    var ds = DatasetBuilder.newDataset();
    try {
        log.info("Grava obrigacao dataset constraints");
        log.dir(constraints);

        var dataObligation = [];
        if (constraints) {
            for (var i = 0; i < constraints.length; i++) {
                var property = constraints[i].fieldName;
                var value = constraints[i].initialValue;
                dataObligation[property] = value;
            }
        }
        // log.info("Grava obrigacao dataset dataPbligation");
        // log.dir(dataObligation);
        var hitType = dataObligation["tipoAcerto"];

        if (hitType) {
            // log.info('Grava obrigacao entrou hitType');
            var cChaveAutent = (DatasetFactory.getDataset('ds_getToken', null, null, null)).values[0][0];
            var cIdSolicitacao = dataObligation["processo"];
            var cTipoOblig = dataObligation["tipoObrigacao"];
            var respFormPag = verifyCpfCnpj(dataObligation["cpfCnpj"]);
            var cTipoId = respFormPag.getValue(0, 'TIPOID');
            var cNumid = respFormPag.getValue(0, 'NUMID');
            var cDvid = respFormPag.getValue(0, 'DVID');
            var cDataEmissao = returnData(dataObligation['dataAbertura']);
            var cDataVencimento = returnData(dataObligation['dataVencimento']);
            var cHistorico = "Inclusão de Obrigação";
            var notaFiscal = dataObligation["numeroNF"];
            var cNumDocto = notaFiscal;
            var cCentroCusto = dataObligation['idCenCusSolic'];
            var cCodEstado = 'SP';
            var nValorObrigacao = dataObligation['valor'];
            nValorObrigacao = nValorObrigacao.replace('.','');           
            var cCodUsr = 'ACSEL';
            var contaContabil = dataObligation['codPolitica'];
            var grupoConceito = dataObligation['idGrupoCont'];
            var cEmiteCheque = "S"; //novo serviço
            var cCodWorkflow = "F"; //novo serviço
            var cTipo_Pago = dataObligation['tipoPagamento'];
            var cCodEntFinan = "";
            var cAgencia = "";
            var cDVAgencia = "";
            var cCuentaCor = "";
            var cDVCuentaCor = "";
            var cTipo_Conta = "";
            var cLinhaDigit = "";
            var cNumDoctoBanco = "";

            // teste verificar tipo pagamento
            // log.info('Grava obrigacao dataset tipo de pagamento no grava obrigacao');
            // log.dir(cTipo_Pago);
            // log.info('===respFormPag');
            // log.dir(respFormPag);

            if (cTipo_Pago == "071" || cTipo_Pago == "073") {
                cTipo = String(respFormPag.getValue(0, 'TIPO_PAGO'));
                if(cTipo == "null"){
                    cTipo_Pago = '';
                }else{
                    cTipo_Pago = String(respFormPag.getValue(0, 'TIPO_PAGO'));
                }
                cCodEnt = String(respFormPag.getValue(0, 'CODENTFINAN'));
                if(cCodEnt == "null"){
                    cCodEntFinan = '';
                }else{
                    cCodEntFinan = String(respFormPag.getValue(0, 'CODENTFINAN'));
                }
                cAgen = String(respFormPag.getValue(0, 'AGENCIA'));
                if(cAgen == "null"){
                    cAgencia = '';
                }else{
                    cAgencia = String(respFormPag.getValue(0, 'AGENCIA'));
                }
                cDVAge = String(respFormPag.getValue(0, 'DVAGENCIA'));
                if(cDVAge == "null"){
                    cDVAgencia = '';
                }else{
                    cDVAgencia = String(respFormPag.getValue(0, 'DVAGENCIA'));
                }
                cCuen = String(respFormPag.getValue(0, 'CUENTACOR'));
                if(cCuen == "null"){
                    cCuentaCor = '';
                }else{
                    cCuentaCor = String(respFormPag.getValue(0, 'CUENTACOR'));
                }
                cDVCuen = String(respFormPag.getValue(0, 'DVCUENTACOR'));
                if(cDVCuen == "null"){
                    cDVCuentaCor = '';
                }else{
                    cDVCuentaCor = String(respFormPag.getValue(0, 'DVCUENTACOR'));
                }
                cTipo_Co = String(respFormPag.getValue(0, 'TIPO_CONTA'));
                if(cTipo_Co == "null"){
                    cTipo_Conta = '';
                }else{
                    cTipo_Conta = String(respFormPag.getValue(0, 'TIPO_CONTA'));
                }
                
            } else if (cTipo_Pago == '081') {
                log.info('Entrou no pagamento no grava obrigacao tip 81');
                cTipo_Pago = "";
                cNumDoctoBanco = dataObligation['codBarras'];
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            } else {
                log.info('Entrou no pagamento no grava obrigacao else');
                cNumDoctoBanco = dataObligation['codBarras'];
                cNumDoctoBanco = cNumDoctoBanco.replace('.','');
                cNumDoctoBanco = cNumDoctoBanco.replace('-','');
                cNumDoctoBanco = cNumDoctoBanco.replace(' ','');
                cLinhaDigit = cNumDoctoBanco;
            }
            // fim

            var obj = {
                cChaveAutent: cChaveAutent,
                cIdSolicitacao: cIdSolicitacao.toString(),
                cTipoOblig: cTipoOblig,
                cTipoId: cTipoId,
                cNumid: cNumid.replaceAll(' ', ''),
                cDvid: cDvid,
                cDataEmissao: cDataEmissao,
                cDataVencimento: cDataVencimento,
                cHistorico: cHistorico,
                cNumDocto: cNumDocto,
                cCentroCusto: cCentroCusto,
                cCodEstado: cCodEstado,
                nValorObrigacao: nValorObrigacao,
                cCodUsr: cCodUsr,
                cEmiteCheque: cEmiteCheque,
                cTipo_Pago: cTipo_Pago,
                cCodEntFinan: cCodEntFinan,
                cAgencia: cAgencia,
                cDVAgencia: cDVAgencia,
                cCuentaCor: cCuentaCor,
                cDVCuentaCor: cDVCuentaCor,
                cTipo_Conta: cTipo_Conta,
                cLinhaDigit: cLinhaDigit,
                cNumDoctoBanco: cNumDoctoBanco,
                cCodWorkflow: cCodWorkflow
            }
            
            log.info('ds_Grava_obrigacao - Obj@@')
            log.dir(obj)
            var numObrigacao = gravaObrigacao(obj, true)
            log.info('ds_Grava_Obrigacao - numObrigacao')
            log.dir(numObrigacao)

            if (numObrigacao == undefined) {
                throw "Erro na execução do Webservice"
            }

            var campos = JSON.parse(dataObligation["campos"]);
            // log.info("grava obrigacao campo:  ");
            // log.dir(campos);
            log.info("tipo:  " );
            log.dir(hitType);
            
            if(hitType != 'presConta'){
                for (var i = 0; i < campos.length; i++) {
                    if (campos[i].toLowerCase().indexOf('idcencusresprateio___') > -1) {
                        var seq = campos[i].split("___")[1];
                        var valor = dataObligation['valorRateio___' + seq];
                        var cClaFluxo = ""; //novo serviço
                        var cNatCPTOEgre = ""; //novo serviço
                        gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, valor.replace('.',''), cClaFluxo, cNatCPTOEgre, cCodWorkflow, true);
                        var porcentagem = (realToNumber(valor) / realToNumber(obj.nValorObrigacao) ) * 100;
                        var centroCusto = dataObligation["idCenCusRespRateio___" + seq];
                        gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor.replace('.',''), porcentagem.toFixed(6).replace('.',','), cCodWorkflow, true);
                    }
                }
            }else{
                log.info(" Campos length do grava detalhe obrigação ");
                log.dir(campos.length);
                for (var i = 0; i < campos.length; i++) {

                    if(campos[i].toLowerCase().indexOf("grupocontacontabilpres___") > -1){
                        log.info("Grava Detalhe Reprocessamento chave");
                        var seqPres = campos[i].split("___")[1];
                        log.info("Grava Detalhe Reprocessamento seq ========> ");
                        log.dir(seqPres);
                        var valorCPres = dataObligation['valorGCContabil___' + seqPres];
                        log.info("Grava Detalhe Reprocessamento valor ========> ");
                        log.dir(valorCPres);
                        valorCPres = valorCPres.replace('.', '');
                        log.info("Grava Detalhe Reprocessamento valor replace . ========> ");
                        log.dir(valorCPres);
                        grupoConceito = dataObligation["idGrupoContPres___" + seqPres];
                        contaContabil = dataObligation["contaContabilPres___" + seqPres];
                        var cClaFluxo = ""; //novo serviço
                        var cNatCPTOEgre = ""; //novo serviço
                        gravaDetalheObrigacao(obj.cChaveAutent, numObrigacao, grupoConceito, contaContabil, valorCPres, cClaFluxo, cNatCPTOEgre, cCodWorkflow, true);
                    }
                    
                }
                log.info(" Campos length do grava centro de custo ");
                log.dir(campos.length);
                for (var j = 0; j < campos.length; j++) {

                    if (campos[j].toLowerCase().indexOf('idcencusresprateio___') > -1) {
                        var seq = campos[j].split("___")[1];
                        var valor = dataObligation['valorRateio___' + seq];
                        log.info("Teste valor centro de custo");
                        log.dir(valor);
                        valor = valor.replace('.','');
                        log.info("Teste valor centro de custo replace . =====>");
                        log.dir(valor);
                        var porcentagem = (Number((valor + "").replace(/\./g, '').replace(",", ".")) / Number((obj.nValorObrigacao + "").replace(",", "."))) * 100;
                        var centroCusto = dataObligation["idCenCusRespRateio___" + seq];
                        gravaCentroCusto(obj.cChaveAutent, numObrigacao, centroCusto, valor, (porcentagem + "").replace(".", ","), cCodWorkflow, true);
                    }
                }
            }

            //finalizaObrigacao(obj.cChaveAutent, numObrigacao, cCodWorkflow);
            var result = numObrigacao + '.0';
            ds.addColumn("NumObrigacao");
            ds.addRow([result]);
            return ds;
        }


    } catch (e) {
        ds.addColumn("Erro");
        ds.addRow([e.message]);
        return ds;
    }
}

function returnData(data) {
    if (data.indexOf('/') > -1) {
        var newData = data.split('/')
        var newString = "" + newData[2] + newData[1] + newData[0] + ""
    } else {
        var newData = data.split('-')
        var newString = "" + newData[0] + newData[1] + newData[2] + ""
    }

    return newString
}

function realToNumber(numero) {
    // var result = (numero + "").replace(/\./g, ',')
    // var result = (numero + "").replace(/\./g, '');
    var result = parseFloat((numero + "").replace(/\./g,'').replace(',','.'));

    return result
}

function verifyCpfCnpj(cpfCnpj) {
    // if (cpfCnpj.length() == 14) {
    //     return 'CPF'
    // } else {
    //     return 'CNPJ'
    // }

    return DatasetFactory.getDataset("ds_forma_pagamento", null, [ DatasetFactory.createConstraint('cnpj', cpfCnpj, cpfCnpj, ConstraintType.MUST) ], null);
}

function gravaObrigacao(obj, restart) {
    log.info('Inicio integração webservice gravaObrigacao ****************')
    log.dir(obj)

    var properties = {};
    properties["receive.timeout"] = "100000000";

    // log.info('properties');
    // log.dir(properties);

    var supplierService = ServiceManager.getService('Acsel_4');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
    var RetornoGravaObrigacao = customClient.gravaObrigacao(obj.cChaveAutent, obj.cIdSolicitacao, obj.cTipoOblig, obj.cTipoId,
        obj.cNumid, obj.cDvid, obj.cDataEmissao, obj.cDataVencimento, obj.cHistorico, obj.cNumDocto, obj.cCentroCusto, obj.cCodEstado,
        obj.nValorObrigacao, obj.cCodUsr, obj.cEmiteCheque, obj.cTipo_Pago, obj.cCodEntFinan, obj.cAgencia, obj.cDVAgencia, obj.cCuentaCor,
        obj.cDVCuentaCor, obj.cTipo_Conta, obj.cLinhaDigit, obj.cNumDoctoBanco, obj.cCodWorkflow);

    if (RetornoGravaObrigacao.getNUMOBRIGACAO() == undefined) {
        // log.info('NumObrigação = Undefined | Webservice Error -------  ')
        // log.dir(RetornoGravaObrigacao)
        if (restart) {
            obj.nValorObrigacao = obj.nValorObrigacao.replace(".", ",");
            gravaObrigacao(obj, false);
        }
    }

    return RetornoGravaObrigacao.getNUMOBRIGACAO();

}



function gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow, restart) {
    log.info('Inicio integração webservice gravaObrigacao detalhe ****************')
    log.dir(aut)
    log.dir(obrig)
    log.dir(cDesp)
    log.dir(typeDesp)
    log.dir(val)

    var properties = {};
    properties["receive.timeout"] = "100000000";

    // log.info('properties');
    // log.dir(properties);

    var supplierService = ServiceManager.getService('Acsel');
    // log.info('supplierService')
    var serviceHelper = supplierService.getBean();
    // log.info('serviceHelper')
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    // log.info('serviceLocator')
    var service = serviceLocator.getServicosWebServicePort();
    // log.info('service')
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    // log.info('customClient')
    try {
        var RetornoGravaDetalheObrigacao = customClient.gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (RetornoGravaDetalheObrigacao.getRetorno() != 0) {
        if (restart) {
            val = val.replace(".", ",");
            gravaDetalheObrigacao(aut, obrig, cDesp, typeDesp, val, cClaFluxo, cNatCPTOEgre, cCodWorkflow, false);
        }
        throw 'Erro: webservice retornou o valor ' + RetornoGravaDetalheObrigacao.getRetorno()
    }

}

function gravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow, restart) {
    log.info('Inicio integração webservice Centro de Custo ****************')
    log.dir(autenticacao);
    log.dir(numObrig);
    log.dir(centroCusto);
    log.dir(montante);
    log.dir(porcentagem);
    var properties = {};
    properties["receive.timeout"] = "100000000";

    var supplierService = ServiceManager.getService('Acsel');
    // log.info('supplierService')
    var serviceHelper = supplierService.getBean();
    // log.info('serviceHelper')
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    // log.info('serviceLocator')
    var service = serviceLocator.getServicosWebServicePort();
    // log.info('service')
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    // log.info('customClient')
    try {
        var Retorno = customClient.gravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        if (restart) {
            log.info("Retorno dif 0 grava Centro Custo");
            log.dir(Retorno.getRetorno());
            montante = montante.replace(".", ",");
            gravaCentroCusto(autenticacao, numObrig, centroCusto, montante, porcentagem, cCodWorkflow, false);
        }
        throw 'Erro: webservice retornou o valor ' + Retorno.getRetorno()
    }

    // log.info('response --- ')
    // log.dir(Retorno.getRetorno());

}


function finalizaObrigacao(autenticacao, num, cCodWorkflow) {
    log.info('Inicio integração webservice finalizaObrigacao ****************')
    log.dir(autenticacao)
    log.dir(num)


    var properties = {};
    properties["receive.timeout"] = "100000000";

    // log.info('properties');
    // log.dir(properties);

    var supplierService = ServiceManager.getService('Acsel');
    // log.info('supplierService')
    var serviceHelper = supplierService.getBean();
    // log.info('serviceHelper')
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    // log.info('serviceLocator')
    var service = serviceLocator.getServicosWebServicePort();
    // log.info('service')
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    // log.info('customClient')
    try {
        var Retorno = customClient.finalizaObrigacao(autenticacao, num, 'S', cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        throw 'Erro: webservice retornou o valor ' + Retorno.getRetorno()
    }

    // log.info('response --- ')
    // log.dir(Retorno.getRetorno());
}

function gravaNotaFiscal(autenticacao, numOblig, cNumNF, nValorNF, cCodWorkflow) {
    var properties = {};

    properties["receive.timeout"] = "100000000";

    // log.info('properties');
    // log.dir(properties);

    var supplierService = ServiceManager.getService('Acsel');
    // log.info('supplierService')
    var serviceHelper = supplierService.getBean();
    // log.info('serviceHelper')
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    // log.info('serviceLocator')
    var service = serviceLocator.getServicosWebServicePort();
    // log.info('service')
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    // log.info('customClient')
    try {
        var Retorno = customClient.gravaNF(autenticacao, numOblig, cNumNF, nValorNF, '', cCodWorkflow);
    } catch (e) {
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        throw 'Erro: webservice retornou o valor ' + Retorno.getRetorno()
    }

}

function retornaTipoPago(cChaveAutent, cTipoId, cNumId, cDvid, cCodWorkflow) {
    var properties = {};

    properties["receive.timeout"] = "100000000";
    var supplierService = ServiceManager.getService('Acsel');
    var serviceHelper = supplierService.getBean();
    var serviceLocator = serviceHelper.instantiate('webservice.AizServicosWebBeanService');
    var service = serviceLocator.getServicosWebServicePort();
    var customClient = serviceHelper.getCustomClient(service, "webservice.ServicosWebService", properties);
    try {
        var Retorno = customClient.retornaTipoPago(cChaveAutent, cTipoId, cNumId, cDvid, cCodWorkflow);

    } catch (e) {
        throw e.toString()
    }

    if (Retorno.getRetorno() != 0) {
        throw 'Erro: webservice retornou o valor ' + Retorno.getRetorno()
    } else {
        return Retorno.getTipoPagoList().getTipoPago();
    }
}