function createDataset(fields, constraints, sortFields) {
	
    var gson = new com.google.gson.Gson();
	var newDataset = DatasetBuilder.newDataset();
	
	try {
		var cChaveAutent = encriptar();
		var cCodWorkflow = "F";
		var cTipo = "TC";
		var retornoTpConta = consultaTpConta(cChaveAutent, cTipo, cCodWorkflow);	
        var retornoTpContaJSON = JSON.parse(gson.toJson(retornoTpConta));
        
		newDataset.addColumn("CODIGO");
		newDataset.addColumn("DESCRICAO");
		
		if (retornoTpConta != "Erro") {
			for (var i = 0; i < retornoTpContaJSON.length; i++) {
                newDataset.addRow(
                    [
                 		retornoTpContaJSON[i]['codigo'],
                 		retornoTpContaJSON[i]['descricao']
                    ]
                )
			}
		} else {
			newDataset.addColumn("Erro");
			newDataset.addRow(retornoTpConta);
		}
		log.info("########## Retorno Tipo Conta newDataset =====");
		log.dir(newDataset);

		return newDataset
	} catch (e) {
		log.info('ERROOOOR-----------@@@: ' + e);
		newDataset.addColumn("Erro");
		newDataset.addRow(e);
		return newDataset;
	}
}

function consultaTpConta(cChaveAutent, cTipo, cCodWorkflow) {	
	
	var properties = {};
	properties["receive.timeout"] = "100000000";

	var supplierService = ServiceManager.getService('Acsel_8');
	var serviceHelper = supplierService.getBean();
	var serviceLocator = serviceHelper.instantiate('com.assurant.servicoswebservice.AizServicosWebBeanService');
	var service = serviceLocator.getServicosWebServicePort();
	var customClient = serviceHelper.getCustomClient(service, "com.assurant.servicoswebservice.ServicosWebService", properties);
	
	try {
		var ListaDadosBancoList = customClient.listaDadosBanco(cChaveAutent, cTipo, cCodWorkflow);
		if (ListaDadosBancoList['retorno'] == 0 || ListaDadosBancoList['retorno'] == "0") {
			return ListaDadosBancoList['listaDadosBancoList']['bancos'];
		} else {
			var mensagemRetorno = 'Erro consultaTpConta';
			log.info(mensagemRetorno);
			return "Erro";
		}
	} catch (e) {
		log.info('ERRO SERVIÇO consultaTpConta -----------@@@: ' + e.toString())
		throw e.toString();
	}
}

function encriptar() {
	var token = DatasetFactory.getDataset("ds_getToken", null, null, null);
	
	if (token.rowsCount > 0) {
		if (token.getValue(0, "token") != undefined) {
			return token.getValue(0, "token");			
		}
	}
	return "";
}