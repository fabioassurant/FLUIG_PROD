function createDataset(fields, constraints, sortFields) {
	try {
		return processResult(callService(fields, constraints, sortFields));
	} catch(e) {
		return processErrorResult(e, constraints);
	}
}

function callService(fields, constraints, sortFields) {
	var serviceData = data();
	var params = serviceData.inputValues;
	var assigns = serviceData.inputAssignments;

	verifyConstraints(serviceData.inputValues, constraints);

	var serviceHelper = ServiceManager.getService(serviceData.fluigService);
	var serviceLocator = serviceHelper.instantiate(serviceData.locatorClass);
	var service = serviceLocator.getServicosWebServicePort();
	var response = service.atribuiSolicitacaoObrigacao(getParamValue(params.cChaveAutent, assigns.cChaveAutent), getParamValue(params.nNumOblig, assigns.nNumOblig), 
		getParamValue(params.nIdSolicitacao, assigns.nIdSolicitacao));

	return response;
}

function defineStructure() {
		addColumn("descricaoErro");
	addColumn("retorno");
}

function onSync(lastSyncDate) {
	var serviceData = data();
	var synchronizedDataset = DatasetBuilder.newDataset();

	try {
		var resultDataset = processResult(callService());
		if (resultDataset != null) {
			var values = resultDataset.getValues();
			for (var i = 0; i < values.length; i++) {
				synchronizedDataset.addRow(values[i]);
			}
		}

	} catch(e) {
		log.info('Dataset synchronization error : ' + e.message);

	}
	return synchronizedDataset;
}

function verifyConstraints(params, constraints) {
	if (constraints != null) {
		for (var i = 0; i < constraints.length; i++) {
			try {
				params[constraints[i].fieldName] = JSON.parse(constraints[i].initialValue);
			} catch(e) {
				params[constraints[i].fieldName] = constraints[i].initialValue;
			}
		}
	}
}

function processResult(result) {
	var dataset = DatasetBuilder.newDataset();

		dataset.addColumn("descricaoErro");
	dataset.addColumn("retorno");

	dataset.addRow([result.getDescricaoErro(), result.getRetorno()]);

	return dataset;
}

function processErrorResult(error, constraints) {
	var dataset = DatasetBuilder.newDataset();

	var params = data().inputValues;
verifyConstraints(params, constraints);

dataset.addColumn('error');
	dataset.addColumn('cChaveAutent');
	dataset.addColumn('nIdSolicitacao');
	dataset.addColumn('nNumOblig');

	var cChaveAutent = isPrimitive(params.cChaveAutent) ? params.cChaveAutent : JSONUtil.toJSON(params.cChaveAutent);
	var nIdSolicitacao = isPrimitive(params.nIdSolicitacao) ? params.nIdSolicitacao : JSONUtil.toJSON(params.nIdSolicitacao);
	var nNumOblig = isPrimitive(params.nNumOblig) ? params.nNumOblig : JSONUtil.toJSON(params.nNumOblig);

	dataset.addRow([error.message, cChaveAutent, nIdSolicitacao, nNumOblig]);

	return dataset;
}

function getParamValue(param, assignment) {
	if (assignment == 'VARIABLE') {
		return getValue(param);
	} else if (assignment == 'NULL') {
		return null;
	}
	return param;
}

function hasValue(value) {
	return value !== null && value !== undefined;
}

function isPrimitive(value) {
	return ((typeof value === 'string') || value.substring !== undefined) || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined';
}


function getObjectFactory(serviceHelper) {
	var objectFactory = serviceHelper.instantiate("com.assurant.servicoswebservice.ObjectFactory");

	return objectFactory;
}



function data() {
	return {
  "fluigService" : "Acsel_4",
  "operation" : "atribuiSolicitacaoObrigacao",
  "soapService" : "AizServicosWebBeanService",
  "portType" : "ServicosWebService",
  "locatorClass" : "com.assurant.servicoswebservice.AizServicosWebBeanService",
  "portTypeMethod" : "getServicosWebServicePort",
  "parameters" : [ ],
  "inputValues" : {
    "cChaveAutent" : encriptar(),
    "nIdSolicitacao" : "",
    "nNumOblig" : ""
  },
  "inputAssignments" : {
    "cChaveAutent" : "VALUE",
    "nIdSolicitacao" : "VALUE",
    "nNumOblig" : "VALUE"
  },
  "outputValues" : { },
  "outputAssignments" : { },
  "extraParams" : {
    "enabled" : false
  }
}
}

function stringToBoolean(param) { 
	if(typeof(param) === 'boolean') {  
		return param;  
	}  
	if (param == null || param === 'null') {  
		return false;  
	}  
	switch(param.toLowerCase().trim()) {  
		case 'true': case 'yes': case '1': return true;  
		case 'false': case 'no': case '0': case null: return false;  
		default: return Boolean(param);  
	}  
} 

 
function encriptar() {

    var token = DatasetFactory.getDataset("ds_getToken", null, null, null);

    if (token.rowsCount > 0) {
        if (token.getValue(0, "token") != undefined) {
            return token.getValue(0, "token");
        }
    }

    return "";
}